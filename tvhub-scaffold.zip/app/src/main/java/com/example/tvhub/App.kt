package com.example.tvhub

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

private enum class Tab(val label: String, val icon: ImageVector) {
    LIVE("Live TV", Icons.Default.PlayArrow),
    GUIDE("Guide", Icons.Default.List),
    LIBRARY("Library", Icons.Default.Home),
    GAMES("Games", Icons.Default.Star),
    RECORDINGS("Recordings", Icons.Default.DateRange),
    SETTINGS("Settings", Icons.Default.Settings),
}

@Composable
fun App() {
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            val ctx = LocalContext.current
            val vm: LiveViewModel = viewModel()
            val plex: PlexViewModel = viewModel()
            val games: GamesViewModel = viewModel()
            val tv = rememberIsTv()
            var tab by remember { mutableStateOf(Tab.LIVE) }
            var crash by remember { mutableStateOf(CrashLog.read(ctx)) }
            val clipboard = LocalClipboardManager.current

            // Live audio keeps playing on the Guide tab, but stops elsewhere.
            LaunchedEffect(tab) { vm.player.playWhenReady = tab == Tab.LIVE || tab == Tab.GUIDE }

            val body: @Composable (Modifier) -> Unit = { m ->
                Box(m) {
                    when (tab) {
                        Tab.LIVE -> LiveTvScreen(vm)
                        Tab.GUIDE -> GuideScreen(vm) { ch -> vm.play(ch); tab = Tab.LIVE }
                        Tab.LIBRARY -> LibraryScreen(plex)
                        Tab.GAMES -> GamesScreen(games)
                        Tab.RECORDINGS -> RecordingsScreen()
                        Tab.SETTINGS -> SettingsScreen(vm)
                    }
                }
            }

            if (tv) {
                // TV: side menu, driven by the remote's arrow keys.
                Row(Modifier.fillMaxSize()) {
                    NavigationRail {
                        Tab.values().forEach { t ->
                            NavigationRailItem(
                                selected = tab == t,
                                onClick = { tab = t },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label) },
                            )
                        }
                    }
                    body(Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                // Phone/tablet: tab bar along the bottom.
                Column(Modifier.fillMaxSize()) {
                    body(Modifier.weight(1f).fillMaxWidth())
                    NavigationBar {
                        Tab.values().forEach { t ->
                            NavigationBarItem(
                                selected = tab == t,
                                onClick = { tab = t },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label, maxLines = 1) },
                            )
                        }
                    }
                }
            }

            // If the app crashed last time, show the error so it can be reported.
            crash?.let { text ->
                AlertDialog(
                    onDismissRequest = {
                        CrashLog.clear(ctx)
                        crash = null
                    },
                    title = { Text("The app crashed last time") },
                    text = {
                        SelectionContainer {
                            Text(
                                text,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                            )
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { clipboard.setText(AnnotatedString(text)) }) { Text("Copy") }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            CrashLog.clear(ctx)
                            crash = null
                        }) { Text("Close") }
                    },
                )
            }
        }
    }
}
