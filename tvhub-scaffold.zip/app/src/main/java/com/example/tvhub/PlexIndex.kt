package com.example.tvhub

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.Normalizer

/**
 * A small copy of every title in the user's Plex libraries, kept on the device so that search is
 * instant and never waits on the server. Only light fields are stored (title, year, poster, IDs, ...);
 * the full item is fetched from the server when a result is opened.
 */
class PlexIndex(context: Context) : SQLiteOpenHelper(context, "plex_index.db", null, 4) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE items(" +
                "lib TEXT NOT NULL, rk TEXT NOT NULL, title TEXT NOT NULL, low TEXT NOT NULL, " +
                "type TEXT NOT NULL, year INTEGER, thumb TEXT, rating REAL, " +
                "leaf INTEGER, viewed INTEGER, views INTEGER, stamp INTEGER, imdb TEXT, guid TEXT, tmdb TEXT, tvdb TEXT, " +
                "PRIMARY KEY(lib, rk))"
        )
        db.execSQL("CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT)")
        db.execSQL("CREATE INDEX items_imdb ON items(imdb)")
        db.execSQL("CREATE INDEX items_guid ON items(guid)")
        db.execSQL("CREATE INDEX items_tmdb ON items(tmdb)")
        db.execSQL("CREATE INDEX items_tvdb ON items(tvdb)")
    }

    // Older copies lack newer columns: start over (the list is saved again in the background).
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS items")
        db.execSQL("DROP TABLE IF EXISTS meta")
        onCreate(db)
    }

    // --- small key/value store (which server, when each library was last saved) ---

    fun getMeta(key: String): String? =
        readableDatabase.rawQuery("SELECT v FROM meta WHERE k = ?", arrayOf(key)).use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    fun setMeta(key: String, value: String) {
        writableDatabase.execSQL("INSERT OR REPLACE INTO meta(k, v) VALUES(?, ?)", arrayOf(key, value))
    }

    fun count(lib: String? = null): Int {
        val sql = if (lib == null) "SELECT COUNT(*) FROM items" else "SELECT COUNT(*) FROM items WHERE lib = ?"
        return readableDatabase.rawQuery(sql, if (lib == null) null else arrayOf(lib)).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
    }

    fun clear() {
        val db = writableDatabase
        db.execSQL("DELETE FROM items")
        db.execSQL("DELETE FROM meta")
    }

    // --- saving ---

    fun upsert(lib: String, items: List<PlexItem>, stamp: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val st = db.compileStatement(
                "INSERT OR REPLACE INTO items(lib, rk, title, low, type, year, thumb, rating, leaf, viewed, views, stamp, imdb, guid, tmdb, tvdb) " +
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            )
            for (item in items) {
                val rk = item.ratingKey ?: continue
                st.clearBindings()
                st.bindString(1, lib)
                st.bindString(2, rk)
                st.bindString(3, item.title)
                st.bindString(4, fold(item.title))
                st.bindString(5, item.type)
                st.bindLong(6, item.year.toLong())
                val poster = item.posterThumb ?: item.thumb
                if (poster != null) st.bindString(7, poster) else st.bindNull(7)
                st.bindDouble(8, item.rating)
                st.bindLong(9, item.leafCount.toLong())
                st.bindLong(10, item.viewedLeafCount.toLong())
                st.bindLong(11, item.viewCount.toLong())
                st.bindLong(12, stamp)
                val imdb = item.imdb
                if (imdb != null) st.bindString(13, imdb.lowercase()) else st.bindNull(13)
                val guid = item.guid
                if (guid != null) st.bindString(14, guid) else st.bindNull(14)
                val tmdb = item.tmdb
                if (tmdb != null) st.bindString(15, tmdb) else st.bindNull(15)
                val tvdb = item.tvdb
                if (tvdb != null) st.bindString(16, tvdb) else st.bindNull(16)
                st.executeInsert()
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** After a full pass over a library: forget titles that were not seen again (removed from Plex). */
    fun deleteOlder(lib: String, stamp: Long) {
        writableDatabase.execSQL("DELETE FROM items WHERE lib = ? AND stamp < ?", arrayOf<Any>(lib, stamp))
    }

    // --- searching ---

    /** Every word typed must appear somewhere in the title; titles that start with the text come first. */
    fun search(query: String, limit: Int = 120): List<PlexItem> {
        imdbIdIn(query)?.let { return byIds(listOf(it), emptyList()) }
        val tokens = fold(query).split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return emptyList()
        val where = tokens.joinToString(" AND ") { "low LIKE ? ESCAPE '\\'" }
        val args = tokens.map { "%${escape(it)}%" } + "${escape(tokens.joinToString(" "))}%"
        val sql = "SELECT $COLUMNS FROM items " +
            "WHERE $where ORDER BY CASE WHEN low LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END, low LIMIT $limit"
        return readableDatabase.rawQuery(sql, args.toTypedArray()).use { read(it) }
    }

    /**
     * Titles in the saved copy that have one of these IMDb numbers or Plex IDs. Used to turn
     * the answers of Plex's online catalog (Discover) into items that exist in this library.
     */
    fun byIds(imdbIds: List<String>, plexGuids: List<String>): List<PlexItem> {
        val args = ArrayList<String>()
        val parts = ArrayList<String>()
        // Chunked so the number of "?" stays small.
        for (chunk in imdbIds.distinct().chunked(200)) {
            parts += "imdb IN (${chunk.joinToString(",") { "?" }})"
            args += chunk.map { it.lowercase() }
        }
        for (chunk in plexGuids.distinct().chunked(200)) {
            parts += "guid IN (${chunk.joinToString(",") { "?" }})"
            args += chunk
        }
        if (parts.isEmpty()) return emptyList()
        val sql = "SELECT $COLUMNS FROM items WHERE ${parts.joinToString(" OR ")} ORDER BY low LIMIT 200"
        return readableDatabase.rawQuery(sql, args.toTypedArray()).use { read(it) }
    }

    /**
     * Matches titles from an outside list (such as Trakt) to this library, keeping the list's order.
     * A title matches by IMDb number, or by TMDB number (movie with movie, show with show), or, for
     * shows, by TVDB number.
     */
    fun matchExternal(ids: List<TraktId>): List<PlexItem> {
        val conds = ArrayList<String>()
        val args = ArrayList<String>()
        for (id in ids.take(150)) {
            if (id.imdb != null) { conds += "imdb = ?"; args += id.imdb.lowercase() }
            if (id.tmdb != null) { conds += "(tmdb = ? AND type = ?)"; args += id.tmdb; args += if (id.isShow) "show" else "movie" }
            if (id.tvdb != null && id.isShow) { conds += "(tvdb = ? AND type = 'show')"; args += id.tvdb }
        }
        if (conds.isEmpty()) return emptyList()
        val candidates = readableDatabase.rawQuery(
            "SELECT $COLUMNS FROM items WHERE ${conds.joinToString(" OR ")}", args.toTypedArray()
        ).use { read(it) }
        val out = ArrayList<PlexItem>()
        for (id in ids) {
            val kind = if (id.isShow) "show" else "movie"
            val hit = candidates.firstOrNull { c ->
                (id.imdb != null && c.imdb == id.imdb.lowercase()) ||
                    (id.tmdb != null && c.tmdb == id.tmdb && c.type == kind) ||
                    (id.isShow && id.tvdb != null && c.tvdb == id.tvdb && c.type == "show")
            }
            if (hit != null && out.none { it.ratingKey == hit.ratingKey }) out += hit
        }
        return out
    }

    private fun read(c: Cursor): List<PlexItem> {
        val out = ArrayList<PlexItem>()
        while (c.moveToNext()) {
            val thumb = if (c.isNull(4)) null else c.getString(4)
            out += PlexItem(
                title = c.getString(1),
                type = c.getString(2),
                ratingKey = c.getString(0),
                year = c.getInt(3),
                thumb = thumb,
                posterThumb = thumb,
                rating = c.getDouble(5),
                leafCount = c.getInt(6),
                viewedLeafCount = c.getInt(7),
                viewCount = c.getInt(8),
                imdb = if (c.isNull(9)) null else c.getString(9),
                guid = if (c.isNull(10)) null else c.getString(10),
                tmdb = if (c.isNull(11)) null else c.getString(11),
                tvdb = if (c.isNull(12)) null else c.getString(12),
                light = true,
            )
        }
        return out
    }

    private fun escape(s: String) = s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    private fun fold(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase()

    companion object {
        private const val COLUMNS = "rk, title, type, year, thumb, rating, leaf, viewed, views, imdb, guid, tmdb, tvdb"
        private val IMDB = Regex("(?i)\\btt\\d{6,10}\\b")

        /** The IMDb number in what the user typed ("tt0118375", or a pasted imdb.com link), else null. */
        fun imdbIdIn(query: String): String? = IMDB.find(query)?.value?.lowercase()
    }
}
