package com.example.tvhub

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Your Trakt account: sign-in (enter a code at trakt.tv/activate), the saved sign-in, and scrobbling.
 * The app's Client ID and Client Secret come from Settings or are built in (assets/trakt_client_id.txt,
 * assets/trakt_client_secret.txt).
 */
object TraktAccount {
    var signedIn by mutableStateOf(false)
        private set
    var username by mutableStateOf<String?>(null)
        private set
    /** The code to enter while signing in. */
    var pending by mutableStateOf<TraktApi.DeviceCode?>(null)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var scrobbleOn by mutableStateOf(true)
        private set

    private var loaded = false
    private var signInJob: Job? = null

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = prefs(ctx)
        signedIn = p.getString("trakt_access", null) != null
        username = p.getString("trakt_user", null)
        scrobbleOn = p.getBoolean("trakt_scrobble", true)
    }

    private fun asset(ctx: Context, name: String): String = try {
        ctx.assets.open(name).bufferedReader().use { it.readText() }
            .lineSequence().map { it.trim() }.firstOrNull { it.isNotEmpty() && !it.startsWith("#") }.orEmpty()
    } catch (_: Exception) {
        ""
    }

    fun clientId(ctx: Context): String =
        prefs(ctx).getString("trakt_client_id", "").orEmpty().trim().ifEmpty { asset(ctx, "trakt_client_id.txt") }

    fun clientSecret(ctx: Context): String =
        prefs(ctx).getString("trakt_client_secret", "").orEmpty().trim().ifEmpty { asset(ctx, "trakt_client_secret.txt") }

    fun setScrobble(ctx: Context, on: Boolean) {
        scrobbleOn = on
        prefs(ctx).edit().putBoolean("trakt_scrobble", on).apply()
    }

    /** Starts sign-in: shows a code, then waits (polling Trakt) until it is entered at trakt.tv/activate. */
    fun startSignIn(ctx: Context, scope: CoroutineScope) {
        val app = ctx.applicationContext
        val id = clientId(app)
        val secret = clientSecret(app)
        if (id.isEmpty() || secret.isEmpty()) {
            message = "Signing in needs the Trakt Client ID and Client Secret (Settings, or built into the app)."
            return
        }
        signInJob?.cancel()
        message = null
        signInJob = scope.launch {
            val code = try {
                withContext(Dispatchers.IO) { TraktApi.deviceCode(id) }
            } catch (e: Exception) {
                message = "Couldn't start Trakt sign-in: ${e.message}"
                return@launch
            }
            pending = code
            val deadline = System.currentTimeMillis() + code.expiresIn * 1000L
            while (System.currentTimeMillis() < deadline) {
                delay(code.interval * 1000L)
                try {
                    val t = withContext(Dispatchers.IO) { TraktApi.pollToken(id, secret, code.deviceCode) }
                    save(app, t)
                    val name = try { withContext(Dispatchers.IO) { TraktApi.username(id, t.access) } } catch (_: Exception) { "" }
                    prefs(app).edit().putString("trakt_user", name).apply()
                    username = name.ifEmpty { null }
                    signedIn = true
                    pending = null
                    message = "Signed in to Trakt" + (if (name.isNotEmpty()) " as $name." else ".")
                    return@launch
                } catch (_: TraktPending) {
                    // still waiting for the code to be entered
                } catch (e: Exception) {
                    pending = null
                    message = e.message
                    return@launch
                }
            }
            pending = null
            message = "The code expired. Start again."
        }
    }

    fun cancelSignIn() {
        signInJob?.cancel()
        pending = null
    }

    fun signOut(ctx: Context) {
        prefs(ctx).edit().remove("trakt_access").remove("trakt_refresh").remove("trakt_expires").remove("trakt_user").apply()
        signedIn = false
        username = null
        message = "Signed out of Trakt."
    }

    private fun save(ctx: Context, t: TraktApi.Tokens) {
        prefs(ctx).edit().putString("trakt_access", t.access).putString("trakt_refresh", t.refresh)
            .putLong("trakt_expires", t.expiresAtMs).apply()
    }

    /** A working access token (renewed when close to expiry), or null when signed out. Call off the main thread. */
    fun token(ctx: Context): String? {
        val p = prefs(ctx)
        val access = p.getString("trakt_access", null) ?: return null
        val expires = p.getLong("trakt_expires", 0L)
        if (expires == 0L || System.currentTimeMillis() < expires - 24 * 3600 * 1000L) return access
        val refresh = p.getString("trakt_refresh", null) ?: return access
        return try {
            val t = TraktApi.refresh(clientId(ctx), clientSecret(ctx), refresh)
            save(ctx, t)
            t.access
        } catch (_: Exception) {
            access
        }
    }

    // --- scrobbling ---

    private val lastState = HashMap<String, String>()

    /**
     * Called with the Plex player's progress reports. Sends Trakt start / pause / stop when the state
     * changes. [media] is the Trakt body ({"movie": {"ids": ...}} or {"episode": {"ids": ...}}).
     */
    fun scrobble(ctx: Context, key: String, state: String, progressPct: Double, media: JSONObject) {
        if (!scrobbleOn) return
        val action = when (state) {
            "playing" -> "start"
            "paused" -> "pause"
            "stopped" -> "stop"
            else -> return
        }
        synchronized(lastState) {
            if (lastState[key] == action) return
            lastState[key] = action
            if (action == "stop") lastState.remove(key)
        }
        val token = token(ctx) ?: return
        try {
            TraktApi.scrobble(clientId(ctx), token, action, media, progressPct)
        } catch (_: Exception) {
        }
    }
}
