package com.example.tvhub

import android.app.Application
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class LiveViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = AppPrefs(app)
    val player: ExoPlayer = ExoPlayer.Builder(app).build()

    var channels by mutableStateOf<List<Channel>>(emptyList())
        private set
    var epg by mutableStateOf<Map<String, List<Programme>>>(emptyMap())
        private set
    var current by mutableStateOf<Channel?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var favorites by mutableStateOf(prefs.favorites)
        private set
    var groupIndex by mutableIntStateOf(0)
        private set

    /** False while another tab is showing, so channel changes from Home don't start sound there. */
    var playbackAllowed = true

    /** Channels you watched, newest first (for Home). */
    private var recentKeys by mutableStateOf(prefs.recentChannels)
    val recentChannels: List<Channel> by derivedStateOf {
        val byKey = channels.associateBy { it.key }
        recentKeys.mapNotNull { byKey[it] }
    }

    private var last: Channel? = null
    private var loadJob: Job? = null

    val groups: List<String> by derivedStateOf {
        listOf("All", "Favorites") + channels.map { it.group }.distinct()
    }
    val groupName: String by derivedStateOf { groups.getOrElse(groupIndex) { "All" } }
    val visibleChannels: List<Channel> by derivedStateOf {
        when (groupName) {
            "All" -> channels
            "Favorites" -> channels.filter { it.key in favorites }
            else -> channels.filter { it.group == groupName }
        }
    }

    init { reload() }

    /** (Re)loads playlist and guide from the saved settings. */
    fun reload() {
        loadJob?.cancel()
        val playlist = prefs.playlistUrl.trim()
        val xc = XtreamApi.Account(prefs.xcServer.trim(), prefs.xcUser.trim(), prefs.xcPass)
        val useXc = xc.server.isNotEmpty() && xc.user.isNotEmpty()
        // With an Xtream Codes login the provider's own guide is used, unless a guide URL is set.
        val guide = prefs.epgUrl.trim().ifEmpty { if (useXc) XtreamApi.guideUrl(xc) else "" }
        error = null
        if (useXc) {
            loadJob = viewModelScope.launch {
                try {
                    channels = withContext(Dispatchers.IO) { XtreamApi.liveChannels(xc) }
                    groupIndex = 0
                    (recentChannels.firstOrNull() ?: channels.firstOrNull())?.let { play(it, remember = false) }
                } catch (e: Exception) {
                    error = "Xtream Codes: " + (e.message ?: "couldn't load channels")
                    return@launch
                }
                loadGuide(guide)
            }
            return
        }
        if (playlist.isEmpty()) {
            channels = emptyList()
            epg = emptyMap()
            error = "No playlist or Xtream Codes login yet. Open Settings to add one."
            return
        }
        loadJob = viewModelScope.launch {
            try {
                channels = withContext(Dispatchers.IO) { M3uParser.fetch(playlist) }
                groupIndex = 0
                (recentChannels.firstOrNull() ?: channels.firstOrNull())?.let { play(it, remember = false) }
            } catch (e: Exception) {
                error = e.message ?: "Could not load playlist"
                return@launch
            }
            loadGuide(guide)
        }
    }

    private suspend fun loadGuide(guide: String) {
        if (guide.isEmpty()) {
            epg = emptyMap()
            return
        }
        // The guide is optional: failures just leave it empty.
        try {
            val ids = channels.mapNotNull { it.tvgId }.toSet()
            val now = System.currentTimeMillis()
            epg = withContext(Dispatchers.IO) {
                XmltvParser.fetch(guide, ids, now - 2 * HOUR, now + 12 * HOUR)
            }
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------ Trakt scrobbling for Live TV

    private data class LiveSession(val key: String, val media: JSONObject, val start: Long, val end: Long)

    private var liveSession: LiveSession? = null
    private val matchCache = HashMap<String, JSONObject?>()

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9]"), "")

    /**
     * Finds the guide programme on Trakt. Episodes need season and episode numbers in the guide;
     * movies need an exact, unambiguous title match. Anything uncertain is skipped, not guessed.
     */
    private fun matchOnTrakt(p: Programme): JSONObject? {
        val ctx = getApplication<Application>()
        val id = TraktAccount.clientId(ctx).ifEmpty { return null }
        val title = p.title.replace(Regex("(?i)^(new|movie|film|premiere)\\s*:\\s*"), "").trim()
        if (title.isEmpty()) return null
        val cacheKey = "${norm(title)}|${p.season}|${p.episode}|${p.year}"
        synchronized(matchCache) { if (matchCache.containsKey(cacheKey)) return matchCache[cacheKey] }
        val result: JSONObject? = try {
            if (p.season > 0 && p.episode > 0) {
                val hit = TraktApi.search(id, "show", title).firstOrNull { norm(it.title) == norm(title) }
                hit?.let {
                    JSONObject()
                        .put("show", JSONObject().put("ids", JSONObject().put("trakt", it.traktId)))
                        .put("episode", JSONObject().put("season", p.season).put("number", p.episode))
                }
            } else if (p.end - p.start >= 70 * 60_000L) {
                val hits = TraktApi.search(id, "movie", title).filter { norm(it.title) == norm(title) }
                val hit = if (p.year > 0) hits.firstOrNull { it.year == p.year } ?: hits.singleOrNull() else hits.singleOrNull()
                hit?.let { JSONObject().put("movie", JSONObject().put("ids", JSONObject().put("trakt", it.traktId))) }
            } else {
                null
            }
        } catch (_: Exception) {
            return null   // network trouble: try again next time, don't cache
        }
        synchronized(matchCache) { matchCache[cacheKey] = result }
        return result
    }

    private fun progress(s: LiveSession, now: Long) =
        ((now - s.start) * 100.0 / (s.end - s.start).coerceAtLeast(1)).coerceIn(0.0, 100.0)

    /** Checks what's playing and tells Trakt (start / pause / stop), at most once a minute. */
    private suspend fun checkLiveScrobble() {
        val ctx = getApplication<Application>()
        if (!prefs.scrobbleLive || !TraktAccount.signedIn || !TraktAccount.scrobbleOn) {
            liveSession = null
            return
        }
        val now = System.currentTimeMillis()
        val ch = current
        val playing = player.isPlaying
        val prog = ch?.let { nowNext(it, now).first }
        val key = if (ch != null && prog != null) "live:${ch.key}:${prog.start}" else null
        val s = liveSession
        if (s != null && s.key != key) {
            withContext(Dispatchers.IO) { TraktAccount.scrobble(ctx, s.key, "stopped", progress(s, now), s.media) }
            liveSession = null
        } else if (s != null) {
            withContext(Dispatchers.IO) {
                TraktAccount.scrobble(ctx, s.key, if (playing) "playing" else "paused", progress(s, now), s.media)
            }
        }
        if (key != null && prog != null && playing && liveSession == null) {
            val media = withContext(Dispatchers.IO) { matchOnTrakt(prog) } ?: return
            val n = LiveSession(key, media, prog.start, prog.end)
            liveSession = n
            withContext(Dispatchers.IO) { TraktAccount.scrobble(ctx, key, "playing", progress(n, now), media) }
        }
    }

    private val scrobbleLoop = viewModelScope.launch {
        TraktAccount.load(app)
        while (true) {
            delay(15_000)
            try {
                checkLiveScrobble()
            } catch (_: Exception) {
            }
            delay(45_000)
        }
    }

    fun play(ch: Channel, remember: Boolean = true) {
        if (current?.url != ch.url) last = current
        current = ch
        player.setMediaItem(MediaItem.fromUri(ch.url))
        player.prepare()
        player.playWhenReady = playbackAllowed
        if (remember) {
            recentKeys = (listOf(ch.key) + recentKeys.filter { it != ch.key }).take(20)
            prefs.recentChannels = recentKeys
        }
        viewModelScope.launch {
            delay(5_000)   // let it start, then tell Trakt about the channel change
            try { checkLiveScrobble() } catch (_: Exception) {}
        }
    }

    private fun step(delta: Int) {
        val list = visibleChannels
        if (list.isEmpty()) return
        val i = list.indexOfFirst { it.url == current?.url }
        play(list[(if (i < 0) 0 else i + delta).mod(list.size)])
    }

    fun next() = step(1)
    fun previous() = step(-1)
    fun playLast() { last?.let { play(it) } }

    fun cycleGroup() { groupIndex = (groupIndex + 1) % groups.size }

    fun toggleFavorite(ch: Channel) {
        favorites = if (ch.key in favorites) favorites - ch.key else favorites + ch.key
        prefs.favorites = favorites
    }

    /** Current and next programme for a channel, if guide data exists. */
    fun nowNext(ch: Channel, now: Long = System.currentTimeMillis()): Pair<Programme?, Programme?> {
        val list = ch.tvgId?.let { epg[it] } ?: return null to null
        val idx = list.indexOfFirst { now >= it.start && now < it.end }
        return if (idx >= 0) list[idx] to list.getOrNull(idx + 1)
        else null to list.firstOrNull { it.start > now }
    }

    override fun onCleared() { player.release() }

    companion object { const val HOUR = 3_600_000L }
}
