package com.example.tvhub

import android.app.Application
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LiveViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = AppPrefs(app)
    val player: ExoPlayer = ExoPlayer.Builder(app).build()

    var channels by mutableStateOf<List<Channel>>(emptyList())
        private set
    var epg by mutableStateOf<Map<String, List<Programme>>>(emptyMap())
        private set
    var current by mutableStateOf<Channel?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var favorites by mutableStateOf(prefs.favorites)
        private set
    var groupIndex by mutableIntStateOf(0)
        private set

    private var last: Channel? = null
    private var loadJob: Job? = null

    val groups: List<String> by derivedStateOf {
        listOf("All", "Favorites") + channels.map { it.group }.distinct()
    }
    val groupName: String by derivedStateOf { groups.getOrElse(groupIndex) { "All" } }
    val visibleChannels: List<Channel> by derivedStateOf {
        when (groupName) {
            "All" -> channels
            "Favorites" -> channels.filter { it.key in favorites }
            else -> channels.filter { it.group == groupName }
        }
    }

    init { reload() }

    /** (Re)loads playlist and guide from the saved settings. */
    fun reload() {
        loadJob?.cancel()
        val playlist = prefs.playlistUrl.trim()
        val guide = prefs.epgUrl.trim()
        error = null
        if (playlist.isEmpty()) {
            channels = emptyList()
            epg = emptyMap()
            error = "No playlist yet. Open Settings to add one."
            return
        }
        loadJob = viewModelScope.launch {
            try {
                channels = withContext(Dispatchers.IO) { M3uParser.fetch(playlist) }
                groupIndex = 0
                channels.firstOrNull()?.let { play(it) }
            } catch (e: Exception) {
                error = e.message ?: "Could not load playlist"
                return@launch
            }
            if (guide.isEmpty()) {
                epg = emptyMap()
                return@launch
            }
            // The guide is optional: failures just leave it empty.
            try {
                val ids = channels.mapNotNull { it.tvgId }.toSet()
                val now = System.currentTimeMillis()
                epg = withContext(Dispatchers.IO) {
                    XmltvParser.fetch(guide, ids, now - 2 * HOUR, now + 12 * HOUR)
                }
            } catch (_: Exception) {
            }
        }
    }

    fun play(ch: Channel) {
        if (current?.url != ch.url) last = current
        current = ch
        player.setMediaItem(MediaItem.fromUri(ch.url))
        player.prepare()
        player.playWhenReady = true
    }

    private fun step(delta: Int) {
        val list = visibleChannels
        if (list.isEmpty()) return
        val i = list.indexOfFirst { it.url == current?.url }
        play(list[(if (i < 0) 0 else i + delta).mod(list.size)])
    }

    fun next() = step(1)
    fun previous() = step(-1)
    fun playLast() { last?.let { play(it) } }

    fun cycleGroup() { groupIndex = (groupIndex + 1) % groups.size }

    fun toggleFavorite(ch: Channel) {
        favorites = if (ch.key in favorites) favorites - ch.key else favorites + ch.key
        prefs.favorites = favorites
    }

    /** Current and next programme for a channel, if guide data exists. */
    fun nowNext(ch: Channel, now: Long = System.currentTimeMillis()): Pair<Programme?, Programme?> {
        val list = ch.tvgId?.let { epg[it] } ?: return null to null
        val idx = list.indexOfFirst { now >= it.start && now < it.end }
        return if (idx >= 0) list[idx] to list.getOrNull(idx + 1)
        else null to list.firstOrNull { it.start > now }
    }

    override fun onCleared() { player.release() }

    companion object { const val HOUR = 3_600_000L }
}
