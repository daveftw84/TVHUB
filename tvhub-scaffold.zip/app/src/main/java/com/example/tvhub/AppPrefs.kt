package com.example.tvhub

import android.content.Context

/** Simple settings store (same file the Plex sign-in uses). */
class AppPrefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)

    var playlistUrl: String
        get() = p.getString("playlist_url", "") ?: ""
        set(v) { p.edit().putString("playlist_url", v).apply() }

    var epgUrl: String
        get() = p.getString("epg_url", "") ?: ""
        set(v) { p.edit().putString("epg_url", v).apply() }

    var traktClientId: String
        get() = p.getString("trakt_client_id", "") ?: ""
        set(v) { p.edit().putString("trakt_client_id", v).apply() }

    var traktClientSecret: String
        get() = p.getString("trakt_client_secret", "") ?: ""
        set(v) { p.edit().putString("trakt_client_secret", v).apply() }

    // Xtream Codes login (used instead of the playlist URL when filled in)
    var xcServer: String
        get() = p.getString("xc_server", "") ?: ""
        set(v) { p.edit().putString("xc_server", v).apply() }
    var xcUser: String
        get() = p.getString("xc_user", "") ?: ""
        set(v) { p.edit().putString("xc_user", v).apply() }
    var xcPass: String
        get() = p.getString("xc_pass", "") ?: ""
        set(v) { p.edit().putString("xc_pass", v).apply() }

    /** Scrobble Live TV programmes to Trakt (off by default: guides can be unreliable). */
    var scrobbleLive: Boolean
        get() = p.getBoolean("trakt_scrobble_live", false)
        set(v) { p.edit().putBoolean("trakt_scrobble_live", v).apply() }

    /** Channels you watched, newest first (channel keys). */
    var recentChannels: List<String>
        get() = (p.getString("recent_channels", "") ?: "").split('\n').filter { it.isNotEmpty() }
        set(v) { p.edit().putString("recent_channels", v.joinToString("\n")).apply() }

    var favorites: Set<String>
        get() = p.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
        set(v) { p.edit().putStringSet("favorites", v.toSet()).apply() }
}
