package com.example.tvhub

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

const val USER_AGENT = "Mozilla/5.0 (Linux; Android TV) TVHub/0.1"

data class Channel(
    val name: String,
    val url: String,
    val group: String,
    val logo: String?,
    val tvgId: String?,
) {
    /** Stable id used for favorites. */
    val key: String get() = tvgId ?: name
}

object M3uParser {
    private val attr = Regex("""([\w-]+)="([^"]*)"""")

    fun fetch(playlistUrl: String): List<Channel> {
        val conn = URL(playlistUrl).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.setRequestProperty("User-Agent", USER_AGENT)
        if (conn.responseCode !in 200..299) throw IOException("Playlist returned HTTP ${conn.responseCode}")
        return conn.inputStream.bufferedReader().use { parse(it.readText()) }
    }

    fun parse(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var info: String? = null
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> info = line
                line.isNotEmpty() && !line.startsWith("#") && info != null -> {
                    val attrs = attr.findAll(info).associate { it.groupValues[1] to it.groupValues[2] }
                    out += Channel(
                        name = info.substringAfterLast(',').trim().ifEmpty { "Channel ${out.size + 1}" },
                        url = line,
                        group = attrs["group-title"].orEmpty().ifEmpty { "Other" },
                        logo = attrs["tvg-logo"]?.ifEmpty { null },
                        tvgId = attrs["tvg-id"]?.ifEmpty { null },
                    )
                    info = null
                }
            }
        }
        return out
    }
}
