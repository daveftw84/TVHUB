package com.example.tvhub

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class PlexServer(val name: String, val url: String, val token: String)

data class PlexLibrary(val id: String, val title: String, val type: String)

data class PlexGenre(val title: String, val path: String)

/** One entry of the A–Z jump bar: its label and where it starts in an A–Z sorted library. */
data class PlexLetter(val label: String, val index: Int)

data class PlexHub(val id: String, val title: String, val key: String?, val items: List<PlexItem>)

data class PlexItem(
    val title: String,
    val type: String,                 // movie, show, season, episode, collection
    val ratingKey: String? = null,
    val showTitle: String? = null,    // for episodes: the show's name
    val season: Int = 0,              // for episodes: season number
    val index: Int = 0,               // episode or season number
    val year: Int = 0,
    val summary: String? = null,
    val contentRating: String? = null,
    val rating: Double = 0.0,
    val thumb: String? = null,        // the item's own picture
    val posterThumb: String? = null,  // portrait poster (an episode uses its show's poster)
    val art: String? = null,
    val partKey: String? = null,      // set for playable items
    val viewOffset: Long = 0,
    val duration: Long = 0,
    val viewCount: Int = 0,
    val leafCount: Int = 0,           // for shows/seasons: number of episodes
    val viewedLeafCount: Int = 0,
    val childCount: Int = 0,          // for collections: number of items
    val released: String? = null,     // release date, like "2026-03-23"
    val imdb: String? = null,         // IMDb number like "tt0118375", when the server includes it
    val guid: String? = null,         // Plex's own ID like "plex://movie/5d77...", when the server includes it
    val tmdb: String? = null,         // The Movie Database number, when the server includes it
    val tvdb: String? = null,         // TheTVDB number, when the server includes it
    val light: Boolean = false,       // true when read from the saved copy: basic details only
) {
    val playable: Boolean get() = partKey != null
    val unwatched: Int get() = (leafCount - viewedLeafCount).coerceAtLeast(0)
    val watched: Boolean get() = if (leafCount > 0) viewedLeafCount >= leafCount else viewCount > 0
    val progress: Float
        get() = if (duration > 0 && viewOffset > 0) (viewOffset.toFloat() / duration).coerceIn(0f, 1f) else 0f
    val displayTitle: String get() = if (type == "episode") showTitle ?: title else title
    val displaySubtitle: String?
        get() = when (type) {
            "episode" -> "S$season • E$index"
            "movie", "show" -> year.takeIf { it > 0 }?.toString()
            "collection" -> childCount.takeIf { it > 0 }?.let { "$it items" }
            else -> null
        }
}

data class PlexPageResult(val items: List<PlexItem>, val total: Int)
data class PlexPin(val id: Long, val code: String)

/** Minimal Plex client. All functions block, so call them off the main thread. */
object PlexApi {
    const val SEARCH_TIMEOUT_MS = 60_000
    private val MEDIA_TYPES = setOf("movie", "show", "season", "episode", "collection")

    private fun request(
        url: String, token: String?, clientId: String,
        method: String = "GET", timeout: Int = 15_000,
    ): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = timeout
        c.readTimeout = timeout
        c.setRequestProperty("Accept", "application/json")
        c.setRequestProperty("X-Plex-Product", "TV Hub")
        c.setRequestProperty("X-Plex-Version", "1.3")
        c.setRequestProperty("X-Plex-Platform", "Android")
        c.setRequestProperty("X-Plex-Client-Identifier", clientId)
        if (token != null) c.setRequestProperty("X-Plex-Token", token)
        if (method == "POST") {
            c.doOutput = true
            c.setFixedLengthStreamingMode(0)
            c.outputStream.close()
        }
        if (c.responseCode !in 200..299) throw IOException("Plex returned HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    // --- Sign-in: the user enters the code at plex.tv/link ---

    fun createPin(clientId: String): PlexPin {
        val o = JSONObject(request("https://plex.tv/api/v2/pins?strong=false", null, clientId, "POST"))
        return PlexPin(o.getLong("id"), o.getString("code"))
    }

    /** Returns the auth token once the user has entered the code, else null. */
    fun checkPin(pin: PlexPin, clientId: String): String? {
        val o = JSONObject(request("https://plex.tv/api/v2/pins/${pin.id}", null, clientId))
        return if (o.isNull("authToken")) null else o.getString("authToken").ifEmpty { null }
    }

    // --- Server discovery ---

    fun findServer(token: String, clientId: String): PlexServer {
        val resources = JSONArray(
            request("https://plex.tv/api/v2/resources?includeHttps=1&includeRelay=1", token, clientId)
        )
        for (i in 0 until resources.length()) {
            val r = resources.getJSONObject(i)
            if (!r.optString("provides").contains("server")) continue
            val accessToken = r.optString("accessToken").ifEmpty { token }
            val conns = r.optJSONArray("connections") ?: continue
            // Prefer local direct connections, relay last.
            val sorted = (0 until conns.length()).map { conns.getJSONObject(it) }
                .sortedWith(compareBy({ it.optBoolean("relay") }, { !it.optBoolean("local") }))
            for (c in sorted) {
                val base = c.optString("uri").trimEnd('/')
                try {
                    request("$base/identity", accessToken, clientId, timeout = 4_000)
                    return PlexServer(r.optString("name", "Plex"), base, accessToken)
                } catch (_: Exception) {
                    // try next connection
                }
            }
        }
        throw IOException("No reachable Plex server found")
    }

    // --- Browsing (always in small pages, so big libraries don't use up the phone's memory) ---

    fun libraries(s: PlexServer, clientId: String): List<PlexLibrary> {
        val dirs = JSONObject(request("${s.url}/library/sections", s.token, clientId))
            .getJSONObject("MediaContainer").optJSONArray("Directory") ?: return emptyList()
        return (0 until dirs.length()).map { dirs.getJSONObject(it) }
            .filter { it.optString("type") in setOf("movie", "show") }
            .map { PlexLibrary(it.getString("key"), it.getString("title"), it.getString("type")) }
    }

    fun page(s: PlexServer, clientId: String, path: String, start: Int, size: Int): PlexPageResult {
        val sep = if (path.contains('?')) '&' else '?'
        val url = "${s.url}$path${sep}X-Plex-Container-Start=$start&X-Plex-Container-Size=$size"
        val container = JSONObject(request(url, s.token, clientId)).getJSONObject("MediaContainer")
        val arr = container.optJSONArray("Metadata")
        val items = if (arr == null) emptyList() else (0 until arr.length()).map { parseItem(arr.getJSONObject(it)) }
        return PlexPageResult(items, container.optInt("totalSize", start + items.size))
    }

    fun children(s: PlexServer, clientId: String, ratingKey: String): List<PlexItem> =
        page(s, clientId, "/library/metadata/$ratingKey/children", 0, 500).items

    /** A list of "hubs": titled rows such as Continue Watching, Recently Added, Top Movies in Thriller. */
    fun hubs(s: PlexServer, clientId: String, path: String, timeout: Int = 15_000): List<PlexHub> {
        val container = JSONObject(request(s.url + path, s.token, clientId, timeout = timeout)).getJSONObject("MediaContainer")
        val arr = container.optJSONArray("Hub") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it) }.mapNotNull { h ->
            val meta = h.optJSONArray("Metadata") ?: return@mapNotNull null
            val items = (0 until meta.length()).map { parseItem(meta.getJSONObject(it)) }
                .filter { it.type in MEDIA_TYPES }
            if (items.isEmpty()) {
                null
            } else {
                PlexHub(
                    id = h.optString("hubIdentifier"),
                    title = h.optString("title"),
                    key = h.optString("key").ifEmpty { null },
                    items = items,
                )
            }
        }
    }

    /**
     * Search one library (or the whole server when [sectionId] is null). Searching a big library for a
     * common word can take the server 15-30+ seconds, so this waits up to [SEARCH_TIMEOUT_MS] instead of
     * giving up early. Searching library by library keeps each request smaller and lets results show up
     * as soon as each one answers.
     */
    fun search(s: PlexServer, clientId: String, query: String, sectionId: String? = null): List<PlexItem> {
        val q = URLEncoder.encode(query, "UTF-8")
        val section = if (sectionId != null) "&sectionId=$sectionId" else ""
        return hubs(s, clientId, "/hubs/search?query=$q&limit=20$section", SEARCH_TIMEOUT_MS)
            .flatMap { it.items }
            .filter { it.type == "movie" || it.type == "show" || it.type == "episode" }
            .distinctBy { it.ratingKey }
    }

    /** IDs found by Plex's online catalog: IMDb numbers and Plex IDs (what the catalog calls its "guid"). */
    data class DiscoverIds(val imdb: List<String>, val guids: List<String>)

    /**
     * Asks Plex's online catalog (Discover) to search by name. It does not look at your server at all,
     * so it is quick, and it only returns IDs, which the app then looks up in its saved copy.
     * Needs the Plex account token (not the server token). Any failure just means "no extra results".
     */
    fun discoverSearch(accountToken: String, clientId: String, query: String): DiscoverIds {
        val q = URLEncoder.encode(query, "UTF-8")
        val url = "https://discover.provider.plex.tv/library/search?query=$q&limit=30" +
            "&searchTypes=movies,tv&includeMetadata=1&searchProviders=discover&includeGuids=1"
        val root = JSONObject(request(url, accountToken, clientId, timeout = 10_000))
        val imdb = LinkedHashSet<String>()
        val guids = LinkedHashSet<String>()
        // The reply is nested; rather than depend on exact nesting, collect IDs wherever they appear.
        fun walk(node: Any?) {
            when (node) {
                is JSONObject -> {
                    val g = node.optString("guid")
                    if (g.startsWith("plex://")) guids += g
                    if (g.startsWith("imdb://")) imdb += g.removePrefix("imdb://").substringBefore('?')
                    val id = node.optString("id")
                    if (id.startsWith("imdb://")) imdb += id.removePrefix("imdb://").substringBefore('?')
                    val keys = node.keys()
                    while (keys.hasNext()) walk(node.opt(keys.next()))
                }
                is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i))
            }
        }
        walk(root)
        return DiscoverIds(imdb.toList(), guids.toList())
    }

    fun genres(s: PlexServer, clientId: String, libId: String): List<PlexGenre> {
        val dirs = JSONObject(request("${s.url}/library/sections/$libId/genre", s.token, clientId))
            .getJSONObject("MediaContainer").optJSONArray("Directory") ?: return emptyList()
        return (0 until dirs.length()).map { dirs.getJSONObject(it) }.mapNotNull { d ->
            val title = d.optString("title")
            var path = d.optString("fastKey")
            if (path.isEmpty()) {
                val key = d.optString("key")
                if (key.isNotEmpty()) {
                    path = "/library/sections/$libId/all?genre=" + URLEncoder.encode(key, "UTF-8")
                }
            }
            if (title.isEmpty() || path.isEmpty()) null else PlexGenre(title, path)
        }
    }

    /** How many items start with each letter, turned into start positions for an A–Z sorted list. */
    fun firstCharacters(s: PlexServer, clientId: String, libId: String): List<PlexLetter> {
        val dirs = JSONObject(request("${s.url}/library/sections/$libId/firstCharacter", s.token, clientId))
            .getJSONObject("MediaContainer").optJSONArray("Directory") ?: return emptyList()
        val out = mutableListOf<PlexLetter>()
        var running = 0
        for (i in 0 until dirs.length()) {
            val d = dirs.getJSONObject(i)
            val label = d.optString("title").ifEmpty { d.optString("key") }
            if (label.isNotEmpty()) out += PlexLetter(label, running)
            running += d.optInt("size")
        }
        return out
    }

    private fun parseItem(o: JSONObject): PlexItem {
        fun str(vararg keys: String): String? {
            for (k in keys) {
                val v = o.optString(k)
                if (v.isNotEmpty()) return v
            }
            return null
        }

        val type = o.optString("type")
        // External IDs: new-style "Guid": [{"id": "imdb://tt123"}], or the older single "guid" string.
        var imdb: String? = null
        var tmdb: String? = null
        var tvdb: String? = null
        val guids = o.optJSONArray("Guid")
        if (guids != null) {
            for (i in 0 until guids.length()) {
                val id = guids.optJSONObject(i)?.optString("id").orEmpty()
                if (id.startsWith("imdb://")) imdb = id.removePrefix("imdb://").substringBefore('?')
                if (id.startsWith("tmdb://")) tmdb = id.removePrefix("tmdb://").substringBefore('?')
                if (id.startsWith("tvdb://")) tvdb = id.removePrefix("tvdb://").substringBefore('?')
            }
        }
        val old = o.optString("guid")
        fun legacy(marker: String): String? =
            if (old.contains(marker)) old.substringAfter(marker).substringBefore('?').substringBefore('/') else null
        if (imdb == null) imdb = legacy("imdb://")
        if (tmdb == null) tmdb = legacy("themoviedb://")
        if (tvdb == null) tvdb = legacy("thetvdb://")
        val part = o.optJSONArray("Media")?.optJSONObject(0)
            ?.optJSONArray("Part")?.optJSONObject(0)?.optString("key")?.ifEmpty { null }
        return PlexItem(
            title = o.optString("title"),
            type = type,
            ratingKey = str("ratingKey"),
            showTitle = str("grandparentTitle"),
            season = o.optInt("parentIndex"),
            index = o.optInt("index"),
            year = o.optInt("year"),
            summary = str("summary"),
            contentRating = str("contentRating"),
            rating = o.optDouble("audienceRating", o.optDouble("rating", 0.0)),
            thumb = str("thumb", "parentThumb", "grandparentThumb"),
            posterThumb = if (type == "episode") str("grandparentThumb", "parentThumb", "thumb")
            else str("thumb", "parentThumb", "grandparentThumb"),
            art = str("art", "grandparentArt"),
            partKey = part,
            viewOffset = o.optLong("viewOffset"),
            duration = o.optLong("duration"),
            viewCount = o.optInt("viewCount"),
            leafCount = o.optInt("leafCount"),
            viewedLeafCount = o.optInt("viewedLeafCount"),
            childCount = o.optInt("childCount"),
            released = str("originallyAvailableAt"),
            imdb = imdb,
            guid = o.optString("guid").takeIf { it.startsWith("plex://") },
            tmdb = tmdb,
            tvdb = tvdb,
        )
    }

    /** Small, resized pictures via the server's photo transcoder (much lighter than the originals). */
    fun imageUrl(s: PlexServer, path: String, width: Int, height: Int): String {
        val inner = URLEncoder.encode(path, "UTF-8")
        return "${s.url}/photo/:/transcode?width=$width&height=$height&minSize=1&upscale=1" +
            "&url=$inner&X-Plex-Token=${s.token}"
    }

    fun streamUrl(s: PlexServer, partKey: String) = "${s.url}$partKey?X-Plex-Token=${s.token}"

    // --- Watch progress ---

    fun reportTimeline(s: PlexServer, clientId: String, item: PlexItem, state: String, timeMs: Long, durationMs: Long) {
        val rk = item.ratingKey ?: return
        val key = URLEncoder.encode("/library/metadata/$rk", "UTF-8")
        request(
            "${s.url}/:/timeline?ratingKey=$rk&key=$key&state=$state&time=$timeMs&duration=$durationMs",
            s.token, clientId,
        )
    }
}
