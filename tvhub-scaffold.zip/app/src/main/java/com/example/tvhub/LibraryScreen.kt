package com.example.tvhub

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

@Composable
fun LibraryScreen(vm: PlexViewModel) {
    val tv = rememberIsTv()
    val playing = vm.playing
    val url = playing?.let { vm.streamUrl(it) }
    if (playing != null && url != null) {
        PlexPlayerScreen(vm, playing, url)
        return
    }

    BackHandler(enabled = vm.canGoBack) { vm.back() }

    Box(Modifier.fillMaxSize()) {
        when (val s = vm.state) {
            PlexState.SignedOut -> CenterColumn {
                Text("Sign in to Plex", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { vm.signIn() }, modifier = Modifier.focusRing(ButtonShape)) {
                    Text("Get sign-in code")
                }
            }
            is PlexState.WaitingForCode -> CenterColumn {
                Text("On your phone or computer, go to")
                Text("plex.tv/link", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(16.dp))
                Text("and enter this code:")
                Text(s.code, style = MaterialTheme.typography.displayMedium)
            }
            PlexState.Loading -> CenterColumn { Text("Connecting to your Plex server…") }
            is PlexState.Failed -> CenterColumn {
                Text(s.message)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { vm.retry() }, modifier = Modifier.focusRing(ButtonShape)) {
                    Text("Try again")
                }
            }
            PlexState.Ready -> Browser(vm)
        }
        if (tv && vm.state == PlexState.Ready) {
            TvClock(Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 16.dp))
        }
    }
}

@Composable
private fun CenterColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content,
    )
}

// ---------------------------------------------------------------- Pages

@Composable
private fun Browser(vm: PlexViewModel) {
    val tv = rememberIsTv()
    when (val scr = vm.screen) {
        PlexScreen.Home ->
            if (tv) TvHome(vm) else TopLevel(vm, onHome = true) { HomeContent(vm) }
        PlexScreen.Libraries ->
            if (tv) {
                Column(Modifier.fillMaxSize()) {
                    TvTopBar(vm, onHome = false)
                    Notice(vm)
                    Box(Modifier.weight(1f).fillMaxWidth()) { LibrariesContent(vm) }
                }
            } else {
                TopLevel(vm, onHome = false) { LibrariesContent(vm) }
            }
        is PlexScreen.Library -> LibraryPage(vm, scr.lib)
        is PlexScreen.Grid -> Column(Modifier.fillMaxSize()) {
            TopBar(scr.title, vm.server?.name, onBack = { vm.back() }, onSearch = { vm.openSearch() })
            Notice(vm)
            PagedGrid(vm, Modifier.weight(1f))
        }
        is PlexScreen.Detail -> DetailScreen(vm, scr.item)
        PlexScreen.Search -> SearchPage(vm)
    }
}

/** Phone: Home and Libraries share a header with a Home / Libraries switch underneath. */
@Composable
private fun TopLevel(vm: PlexViewModel, onHome: Boolean, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar("TV Hub", vm.server?.name, onBack = null, onSearch = { vm.openSearch() })
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Chip("Home", onHome) { vm.goHome() }
            Chip("Libraries", !onHome) { vm.goLibraries() }
        }
        Notice(vm)
        Box(Modifier.weight(1f).fillMaxWidth()) { content() }
    }
}

@Composable
private fun TopBar(title: String, subtitle: String?, onBack: (() -> Unit)?, onSearch: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            TextButton(onClick = onBack, modifier = Modifier.focusRing(ButtonShape)) {
                Text("←", style = MaterialTheme.typography.headlineSmall)
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (onSearch != null) {
            IconButton(onClick = onSearch, modifier = Modifier.focusRing(CircleShape)) {
                Icon(Icons.Default.Search, contentDescription = "Search")
            }
        }
    }
}

@Composable
private fun Notice(vm: PlexViewModel) {
    vm.notice?.let {
        Text(
            it,
            color = MaterialTheme.colorScheme.error,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        modifier = Modifier.focusRing(RoundedCornerShape(8.dp)),
    )
}

/** Tabs in a rounded dark pill, like the Plex library tabs. */
@Composable
private fun PillTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.clip(CircleShape).background(Color(0x33FFFFFF)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        labels.forEachIndexed { i, label ->
            Text(
                label,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier
                    .focusRing(CircleShape)
                    .clip(CircleShape)
                    .then(if (i == selected) Modifier.border(1.dp, Color(0x99FFFFFF), CircleShape) else Modifier)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }
    }
}

// ---------------------------------------------------------------- TV home

@Composable
private fun TvClock(modifier: Modifier) {
    val fmt = remember { java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(15_000)
        }
    }
    Text(fmt.format(java.util.Date(now)), style = MaterialTheme.typography.titleMedium, modifier = modifier)
}

@Composable
private fun TvTopBar(vm: PlexViewModel, onHome: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, top = 10.dp, end = 120.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Chip("Home", onHome) { vm.goHome() }
        Chip("Libraries", !onHome) { vm.goLibraries() }
        IconButton(onClick = { vm.openSearch() }, modifier = Modifier.focusRing(CircleShape)) {
            Icon(Icons.Default.Search, contentDescription = "Search")
        }
    }
}

private fun formatDate(iso: String?): String? {
    if (iso.isNullOrEmpty()) return null
    return try {
        val d = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(iso) ?: return null
        java.text.SimpleDateFormat("MMM d, yyyy", java.util.Locale.getDefault()).format(d)
    } catch (_: Exception) {
        null
    }
}

/** Title, episode name, date, length, rating and summary of whatever poster is focused. */
@Composable
private fun HeroInfo(media: PlexItem?, modifier: Modifier) {
    Column(modifier.padding(horizontal = 24.dp)) {
        if (media != null) {
            Text(
                media.displayTitle,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (media.type == "episode") {
                Text(
                    media.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            val meta = listOfNotNull(
                if (media.type == "episode") "S${media.season} • E${media.index}" else null,
                formatDate(media.released) ?: media.year.takeIf { it > 0 }?.toString(),
                media.duration.takeIf { it > 0 }?.let { "${it / 60000}m" },
            ).joinToString("    ")
            Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                if (meta.isNotEmpty()) Text(meta, style = MaterialTheme.typography.bodyMedium)
                media.contentRating?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier
                            .padding(start = 12.dp)
                            .border(1.dp, Color(0xAAFFFFFF), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                }
            }
            media.summary?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
    }
}

/** TV home: a big backdrop that follows the focused poster, with the rows underneath. */
@Composable
private fun TvHome(vm: PlexViewModel) {
    var focused by remember { mutableStateOf<PlexItem?>(null) }
    val hero = focused ?: vm.homeRows.firstOrNull()?.items?.firstOrNull()
    val bg = MaterialTheme.colorScheme.background

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().fillMaxHeight(0.7f)) {
            val art = hero?.let { vm.backdrop(it) }
            if (art != null) {
                AsyncImage(
                    model = art,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.horizontalGradient(listOf(bg, bg.copy(alpha = 0.7f), Color.Transparent)))
            )
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, bg)))
            )
        }

        Column(Modifier.fillMaxSize()) {
            TvTopBar(vm, onHome = true)
            HeroInfo(hero, Modifier.fillMaxWidth(0.55f).height(150.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(bottom = 16.dp)) {
                if (vm.homeRows.isEmpty()) {
                    item {
                        Text(
                            if (vm.homeLoading) "Loading…" else "Nothing to show yet. Open Libraries to browse.",
                            modifier = Modifier.padding(24.dp),
                        )
                    }
                }
                items(vm.homeRows) { row ->
                    TvMediaRow(vm, row, vm.server?.name, onFocused = { focused = it })
                }
                item {
                    OutlinedButton(
                        onClick = { vm.signOut() },
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp).focusRing(ButtonShape),
                    ) { Text("Sign out of Plex") }
                }
            }
        }
    }
}

@Composable
private fun TvMediaRow(vm: PlexViewModel, row: HomeRow, subtitle: String?, onFocused: (PlexItem) -> Unit) {
    val isContinue = row.title.startsWith("Continue")
    Column {
        Row(Modifier.padding(start = 24.dp, top = 8.dp, bottom = 2.dp), verticalAlignment = Alignment.Bottom) {
            Text(row.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (subtitle != null) {
                Text(
                    "  ·  $subtitle",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(row.items) { entry ->
                MediaCard(vm, entry, Modifier.width(120.dp), onFocused = onFocused) {
                    // Continue Watching resumes right away; everything else opens its page.
                    if (isContinue && entry.playable) vm.play(entry) else vm.open(entry)
                }
            }
            row.seeAll?.let { path ->
                item { SeeAllCard(Modifier.width(120.dp)) { vm.openGrid(row.title, path) } }
            }
        }
    }
}

@Composable
private fun SeeAllCard(modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier
            .aspectRatio(2f / 3f)
            .focusRing(shape, 1.08f)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text("See all ›", style = MaterialTheme.typography.bodyLarge)
    }
}

// ---------------------------------------------------------------- Phone home and Libraries

@Composable
private fun HomeContent(vm: PlexViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        if (vm.homeRows.isEmpty()) {
            item {
                Text(
                    if (vm.homeLoading) "Loading…" else "Nothing to show yet. Open Libraries to browse.",
                    modifier = Modifier.padding(16.dp),
                )
            }
        }
        items(vm.homeRows) { row -> MediaRow(vm, row, vm.server?.name) }
        item {
            Spacer(Modifier.height(16.dp))
            OutlinedButton(
                onClick = { vm.signOut() },
                modifier = Modifier.padding(horizontal = 16.dp).focusRing(ButtonShape),
            ) { Text("Sign out of Plex") }
        }
    }
}

@Composable
private fun LibrariesContent(vm: PlexViewModel) {
    if (vm.libraries.isEmpty()) {
        Text("No movie or TV libraries found on this server.", modifier = Modifier.padding(16.dp))
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(vm.libraries) { lib ->
            val shape = RoundedCornerShape(12.dp)
            Column(
                Modifier
                    .fillMaxWidth()
                    .focusRing(shape)
                    .clip(shape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { vm.openLibrary(lib) }
                    .padding(20.dp)
            ) {
                Text(lib.title, style = MaterialTheme.typography.titleLarge)
                Text(
                    if (lib.type == "movie") "Movies" else "TV Shows",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Library page

@Composable
private fun LibraryPage(vm: PlexViewModel, lib: PlexLibrary) {
    val tv = rememberIsTv()
    val tabs = LibTab.values()
    Column(Modifier.fillMaxSize()) {
        // On TV the Back key goes up a level, so no back arrow is needed.
        if (!tv) TopBar(lib.title, vm.server?.name, onBack = { vm.back() }, onSearch = { vm.openSearch() })
        Row(
            Modifier.horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = if (tv) 12.dp else 4.dp),
        ) {
            PillTabs(tabs.map { it.label }, tabs.indexOf(vm.libTab)) { i -> vm.selectLibTab(tabs[i]) }
        }
        Notice(vm)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (vm.libTab) {
                LibTab.RECOMMENDED -> RecommendedTab(vm)
                LibTab.BROWSE -> BrowseTab(vm, lib)
                LibTab.COLLECTIONS -> CollectionsTab(vm)
                LibTab.CATEGORIES -> CategoriesTab(vm)
            }
        }
    }
}

@Composable
private fun RecommendedTab(vm: PlexViewModel) {
    val tv = rememberIsTv()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        if (vm.libHubs.isEmpty()) {
            item {
                Text(
                    if (vm.libLoading) "Loading…" else "Nothing recommended yet.",
                    modifier = Modifier.padding(16.dp),
                )
            }
        }
        items(vm.libHubs) { row ->
            if (tv) TvMediaRow(vm, row, null, onFocused = {}) else MediaRow(vm, row, null)
        }
    }
}

@Composable
private fun BrowseTab(vm: PlexViewModel, lib: PlexLibrary) {
    val tv = rememberIsTv()
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Chip("All", !vm.gridUnwatched) { vm.setUnwatched(false) }
            Chip("Unwatched", vm.gridUnwatched) { vm.setUnwatched(true) }
            Text("by", style = MaterialTheme.typography.bodyMedium)
            GridSort.values().forEach { sort -> Chip(sort.label, vm.gridSort == sort) { vm.setSort(sort) } }
            if (vm.gridTotalItems > 0) {
                Text(
                    "%,d items".format(vm.gridTotalItems),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Row(Modifier.weight(1f).fillMaxWidth()) {
            PagedGrid(vm, Modifier.weight(1f))
            // A–Z jump bar down the right edge (TV only, and only while sorted A–Z).
            if (tv && vm.gridSort == GridSort.TITLE && !vm.gridUnwatched && vm.letters.isNotEmpty()) {
                JumpBar(vm)
            }
        }
    }
}

@Composable
private fun JumpBar(vm: PlexViewModel) {
    LazyColumn(
        Modifier.width(44.dp).fillMaxHeight().padding(top = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        items(vm.letters) { letter ->
            val shape = RoundedCornerShape(6.dp)
            Text(
                letter.label,
                style = MaterialTheme.typography.labelLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRing(shape)
                    .clip(shape)
                    .clickable { vm.jumpTo(letter.index) }
                    .padding(vertical = 3.dp),
            )
        }
    }
}

@Composable
private fun CollectionsTab(vm: PlexViewModel) {
    val tv = rememberIsTv()
    if (vm.libCollections.isEmpty()) {
        Text(
            if (vm.libLoading) "Loading…" else "No collections in this library.",
            modifier = Modifier.padding(16.dp),
        )
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(if (tv) 130.dp else 110.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        itemsIndexed(vm.libCollections) { _, c ->
            MediaCard(vm, c, Modifier.fillMaxWidth()) { vm.open(c) }
        }
    }
}

private val tileColors = listOf(
    0xFF2E7D9A, 0xFF3B7A57, 0xFF9C3B5B, 0xFF8A5A2B,
    0xFF5B4B9A, 0xFF2F6F6A, 0xFF9A7B2E, 0xFF6A3B7A,
)

private fun tileColor(title: String): Color =
    Color(tileColors[(title.hashCode() and 0x7fffffff) % tileColors.size])

@Composable
private fun CategoriesTab(vm: PlexViewModel) {
    val tv = rememberIsTv()
    if (vm.libGenres.isEmpty()) {
        Text(
            if (vm.libLoading) "Loading…" else "No categories in this library.",
            modifier = Modifier.padding(16.dp),
        )
        return
    }
    LazyVerticalGrid(
        columns = if (tv) GridCells.Adaptive(190.dp) else GridCells.Fixed(2),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        itemsIndexed(vm.libGenres) { _, g ->
            val shape = RoundedCornerShape(10.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(if (tv) 96.dp else 84.dp)
                    .focusRing(shape, if (tv) 1.05f else 1f)
                    .clip(shape)
                    .background(tileColor(g.title))
                    .clickable { vm.openGrid(g.title, g.path) }
                    .padding(8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    g.title,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Search

@Composable
private fun SearchPage(vm: PlexViewModel) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        try {
            focus.requestFocus()
        } catch (_: Throwable) {
        }
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("Search", vm.server?.name, onBack = { vm.back() }, onSearch = null)
        OutlinedTextField(
            value = vm.searchQuery,
            onValueChange = { vm.updateSearch(it) },
            singleLine = true,
            placeholder = { Text("Movies and shows") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).focusRequester(focus),
        )
        vm.indexStatus?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }
        val q = vm.searchQuery.trim()
        when {
            q.length < 2 -> Text("Type at least two letters.", modifier = Modifier.padding(16.dp))
            vm.searching && vm.searchResults.isEmpty() -> Text("Searching…", modifier = Modifier.padding(16.dp))
            vm.searchResults.isEmpty() && vm.searchProblem == null ->
                Text("No results for \"$q\".", modifier = Modifier.padding(16.dp))
        }
        if (vm.searching && vm.searchResults.isNotEmpty()) {
            Text("Still searching…", modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                style = MaterialTheme.typography.bodySmall)
        }
        vm.searchProblem?.let { problem ->
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(problem, modifier = Modifier.weight(1f))
                Chip("Try again", false) { vm.retrySearch() }
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(110.dp),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            itemsIndexed(vm.searchResults) { _, result ->
                MediaCard(vm, result, Modifier.fillMaxWidth()) { vm.openSearchResult(result) }
            }
        }
    }
}

// ---------------------------------------------------------------- Rows, grid, cards

@Composable
private fun RowHeader(title: String, subtitle: String?, onClick: (() -> Unit)?) {
    val shape = RoundedCornerShape(8.dp)
    val base = Modifier.padding(start = 12.dp, top = 14.dp, bottom = 6.dp, end = 12.dp).focusRing(shape).clip(shape)
    val clickable = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(clickable.padding(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (onClick != null) Text("  ›", style = MaterialTheme.typography.titleMedium)
        }
        if (subtitle != null) {
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun MediaRow(vm: PlexViewModel, row: HomeRow, subtitle: String?) {
    val seeAll: (() -> Unit)? = row.seeAll?.let { path -> { vm.openGrid(row.title, path) } }
    val isContinue = row.title.startsWith("Continue")
    Column {
        RowHeader(row.title, subtitle, seeAll)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(row.items) { entry ->
                MediaCard(vm, entry, Modifier.width(112.dp)) {
                    // Continue Watching resumes right away; everything else opens its page.
                    if (isContinue && entry.playable) vm.play(entry) else vm.open(entry)
                }
            }
        }
    }
}

@Composable
private fun PagedGrid(vm: PlexViewModel, modifier: Modifier) {
    val tv = rememberIsTv()
    LazyVerticalGrid(
        state = vm.gridState,
        columns = GridCells.Adaptive(if (tv) 130.dp else 110.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier.fillMaxWidth(),
    ) {
        itemsIndexed(vm.gridItems) { index, entry ->
            // Near the end of what's loaded? Fetch the next page.
            if (index >= vm.gridItems.size - 15) {
                LaunchedEffect(vm.gridItems.size) { vm.loadMore() }
            }
            MediaCard(vm, entry, Modifier.fillMaxWidth()) { vm.open(entry) }
        }
        if (vm.gridLoading) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("Loading…", modifier = Modifier.padding(16.dp))
            }
        } else if (vm.gridItems.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("Nothing here.", modifier = Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
private fun MediaCard(
    vm: PlexViewModel,
    media: PlexItem,
    modifier: Modifier,
    onFocused: ((PlexItem) -> Unit)? = null,
    onClick: () -> Unit,
) {
    val tv = rememberIsTv()
    val shape = RoundedCornerShape(10.dp)
    Column(
        modifier
            .onFocusChanged { if (it.hasFocus) onFocused?.invoke(media) }
            .focusRing(shape, if (tv) 1.08f else 1f)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            val img = vm.poster(media)
            if (img != null) {
                AsyncImage(
                    model = img,
                    contentDescription = media.displayTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Badges(media)
        }
        Text(
            media.displayTitle,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 6.dp),
        )
        media.displaySubtitle?.let {
            Text(
                it,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * Bottom of the picture: a progress bar if partly watched, otherwise the rating.
 * Top corner: a tick for watched items, or the unwatched count for shows.
 */
@Composable
private fun BoxScope.Badges(media: PlexItem) {
    val inProgress = media.progress > 0f && media.progress < 0.97f
    if (inProgress) {
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .height(4.dp)
                .background(Color(0x99000000))
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(media.progress)
                    .background(MaterialTheme.colorScheme.primary)
            )
        }
    } else if (media.rating > 0 && media.type != "episode" && media.type != "collection") {
        Text(
            "★ %.1f".format(media.rating),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(4.dp)
                .background(Color(0xCC000000), RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp),
        )
    }
    val corner: String? = when {
        media.type == "show" || media.type == "season" ->
            if (media.leafCount > 0) (if (media.unwatched > 0) media.unwatched.toString() else "✓") else null
        media.type == "collection" -> null
        media.watched -> "✓"
        else -> null
    }
    if (corner != null) {
        Text(
            corner,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(4.dp)
                .background(Color(0xCC000000), RoundedCornerShape(10.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp),
        )
    }
}

// ---------------------------------------------------------------- Detail page

private fun formatTime(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

private fun playTarget(vm: PlexViewModel, media: PlexItem): PlexItem? =
    if (media.playable) media
    else vm.episodes.firstOrNull { it.viewOffset > 0 }
        ?: vm.episodes.firstOrNull { !it.watched }
        ?: vm.episodes.firstOrNull()

@Composable
private fun DetailScreen(vm: PlexViewModel, media: PlexItem) {
    val background = MaterialTheme.colorScheme.background
    val isSeries = media.type == "show" || media.type == "season"

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Box(Modifier.fillMaxWidth()) {
                Box(Modifier.fillMaxWidth().height(220.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
                    val art = vm.backdrop(media)
                    if (art != null) {
                        AsyncImage(
                            model = art,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(Brush.verticalGradient(listOf(Color(0x66000000), background)))
                    )
                }
                Row(
                    Modifier.padding(start = 16.dp, end = 16.dp, top = 120.dp),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    Box(
                        Modifier
                            .width(110.dp)
                            .aspectRatio(2f / 3f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        val poster = vm.poster(media)
                        if (poster != null) {
                            AsyncImage(
                                model = poster,
                                contentDescription = media.displayTitle,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize(),
                            )
                        }
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            media.displayTitle,
                            style = MaterialTheme.typography.headlineSmall,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                        )
                        val meta = listOfNotNull(
                            media.year.takeIf { it > 0 }?.toString(),
                            media.contentRating,
                            media.duration.takeIf { it > 0 && !isSeries }?.let { "${it / 60000} min" },
                            media.rating.takeIf { it > 0 }?.let { "★ %.1f".format(it) },
                        ).joinToString(" · ")
                        if (meta.isNotEmpty()) {
                            Text(
                                meta,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                OutlinedButton(
                    onClick = { vm.back() },
                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp).focusRing(ButtonShape),
                ) { Text("← Back") }
            }
        }

        item {
            val target = playTarget(vm, media)
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (target != null) {
                    Button(onClick = { vm.play(target) }, modifier = Modifier.focusRing(ButtonShape)) {
                        Text(if (target.viewOffset > 0) "▶ Resume ${formatTime(target.viewOffset)}" else "▶ Play")
                    }
                    if (target.viewOffset > 0) {
                        OutlinedButton(
                            onClick = { vm.play(target.copy(viewOffset = 0)) },
                            modifier = Modifier.focusRing(ButtonShape),
                        ) { Text("Start over") }
                    }
                }
            }
        }

        media.summary?.let { summary ->
            item {
                Text(
                    summary,
                    maxLines = 8,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        }

        if (media.type == "show" && vm.seasons.isNotEmpty()) {
            item {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    vm.seasons.forEach { season ->
                        Chip(season.title, vm.selectedSeason?.ratingKey == season.ratingKey) {
                            vm.selectSeason(season)
                        }
                    }
                }
            }
        }

        if (isSeries) {
            if (vm.detailLoading && vm.episodes.isEmpty()) {
                item { Text("Loading…", modifier = Modifier.padding(16.dp)) }
            }
            items(vm.episodes) { ep -> EpisodeRow(vm, ep) }
        }
    }
}

@Composable
private fun EpisodeRow(vm: PlexViewModel, ep: PlexItem) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .focusRing(shape)
            .clip(shape)
            .clickable { vm.play(ep) }
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier
                .width(140.dp)
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            val img = vm.landscape(ep, 320)
            if (img != null) {
                AsyncImage(
                    model = img,
                    contentDescription = ep.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Badges(ep)
        }
        Column(Modifier.weight(1f)) {
            Text(
                "${ep.index}. ${ep.title}",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge,
            )
            if (ep.duration > 0) {
                Text(
                    "${ep.duration / 60000} min",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            ep.summary?.let {
                Text(
                    it,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Player

@Composable
private fun PlexPlayerScreen(vm: PlexViewModel, media: PlexItem, url: String) {
    val context = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            // Resume where you left off, unless you were nearly finished.
            if (media.viewOffset > 0 && (media.duration == 0L || media.viewOffset < media.duration * 0.95)) {
                seekTo(media.viewOffset)
            }
            prepare()
            playWhenReady = true
        }
    }
    fun duration() = if (player.duration > 0) player.duration else media.duration

    DisposableEffect(Unit) {
        onDispose {
            vm.report(media, "stopped", player.currentPosition, duration())
            player.release()
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            vm.report(media, if (player.isPlaying) "playing" else "paused", player.currentPosition, duration())
        }
    }

    BackHandler { vm.back() }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
    )
}
