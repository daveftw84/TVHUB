package com.example.tvhub

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** One title from Trakt, with every ID Trakt knows for it, so it can be matched to Plex. */
data class TraktId(
    val title: String,
    val imdb: String?,
    val tmdb: String?,
    val tvdb: String?,
    val isShow: Boolean,
)

/** One line on the Trakt page: a title, a detail line, and the IDs used to find it in Plex. */
data class TraktEntry(val title: String, val subtitle: String, val id: TraktId)

/** Thrown while a sign-in code is still waiting to be entered at trakt.tv/activate. */
class TraktPending : Exception("pending")

/**
 * Trakt client (api.trakt.tv). Public lists need only the app's Client ID; your recommendations,
 * calendar, watchlist, history and scrobbling need you to sign in (device code sign-in, made for TVs).
 */
object TraktApi {
    data class DeviceCode(val deviceCode: String, val userCode: String, val url: String, val interval: Int, val expiresIn: Int)
    data class Tokens(val access: String, val refresh: String, val expiresAtMs: Long)

    private fun call(clientId: String, path: String, method: String = "GET", body: JSONObject? = null, token: String? = null): HttpURLConnection {
        val c = URL("https://api.trakt.tv$path").openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15_000
        c.readTimeout = 20_000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("trakt-api-version", "2")
        c.setRequestProperty("trakt-api-key", clientId)
        c.setRequestProperty("User-Agent", "TVHub/2.3")
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        return c
    }

    private fun text(c: HttpURLConnection): String {
        if (c.responseCode !in 200..299) throw IOException("Trakt returned HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun get(clientId: String, path: String, token: String? = null) = text(call(clientId, path, token = token))

    // --- IDs ---

    private fun idsOf(obj: JSONObject, isShow: Boolean): TraktId? {
        val ids = obj.optJSONObject("ids") ?: return null
        fun id(key: String): String? =
            if (ids.isNull(key)) null else ids.opt(key)?.toString()?.takeIf { it.isNotEmpty() }
        return TraktId(obj.optString("title"), id("imdb"), id("tmdb"), id("tvdb"), isShow)
    }

    /** Pulls the movie or show out of any Trakt list item (wrapped or plain). */
    private fun parseItems(arr: JSONArray, kindHint: String?): List<Pair<JSONObject, TraktId>> {
        val out = ArrayList<Pair<JSONObject, TraktId>>()
        for (i in 0 until arr.length()) {
            val el = arr.optJSONObject(i) ?: continue
            val movie = el.optJSONObject("movie")
            val show = el.optJSONObject("show")
            val id = when {
                movie != null -> idsOf(movie, false)
                show != null -> idsOf(show, true)
                else -> idsOf(el, kindHint == "shows")
            } ?: continue
            out += el to id
        }
        return out
    }

    /** Public lists: trending, popular, watched/weekly, ... */
    fun list(clientId: String, kind: String, list: String, limit: Int = 100): List<TraktId> =
        parseItems(JSONArray(get(clientId, "/$kind/$list?limit=$limit")), kind).map { it.second }

    // --- sign-in (device code) ---

    fun deviceCode(clientId: String): DeviceCode {
        val o = JSONObject(text(call(clientId, "/oauth/device/code", "POST", JSONObject().put("client_id", clientId))))
        return DeviceCode(
            o.getString("device_code"), o.getString("user_code"),
            o.optString("verification_url", "https://trakt.tv/activate"),
            o.optInt("interval", 5), o.optInt("expires_in", 600),
        )
    }

    /** Returns tokens once the code was entered; throws [TraktPending] while still waiting. */
    fun pollToken(clientId: String, secret: String, deviceCode: String): Tokens {
        val body = JSONObject().put("code", deviceCode).put("client_id", clientId).put("client_secret", secret)
        val c = call(clientId, "/oauth/device/token", "POST", body)
        return when (c.responseCode) {
            200 -> tokens(JSONObject(c.inputStream.bufferedReader().use { it.readText() }))
            400, 429 -> throw TraktPending()
            404 -> throw IOException("That sign-in code isn't valid. Start again.")
            409 -> throw IOException("That code was already used.")
            410 -> throw IOException("The code expired. Start again.")
            418 -> throw IOException("Sign-in was declined on trakt.tv.")
            else -> throw IOException("Trakt returned HTTP ${c.responseCode}. Check the Client Secret.")
        }
    }

    fun refresh(clientId: String, secret: String, refreshToken: String): Tokens {
        val body = JSONObject()
            .put("refresh_token", refreshToken).put("client_id", clientId).put("client_secret", secret)
            .put("redirect_uri", "urn:ietf:wg:oauth:2.0:oob").put("grant_type", "refresh_token")
        return tokens(JSONObject(text(call(clientId, "/oauth/token", "POST", body))))
    }

    private fun tokens(o: JSONObject): Tokens {
        val created = o.optLong("created_at", System.currentTimeMillis() / 1000)
        return Tokens(o.getString("access_token"), o.optString("refresh_token"), (created + o.optLong("expires_in", 7776000)) * 1000)
    }

    fun username(clientId: String, token: String): String {
        val o = JSONObject(get(clientId, "/users/settings", token))
        val u = o.optJSONObject("user")
        return u?.optString("name")?.ifEmpty { null } ?: u?.optString("username").orEmpty()
    }

    // --- your data ---

    fun recommendations(clientId: String, token: String, kind: String, limit: Int = 50): List<TraktEntry> =
        parseItems(JSONArray(get(clientId, "/recommendations/$kind?limit=$limit&ignore_collected=false", token)), kind)
            .map { (o, id) -> TraktEntry(id.title, listOfNotNull(o.optInt("year").takeIf { it > 0 }?.toString(), if (id.isShow) "Show" else "Movie").joinToString(" · "), id) }

    fun watchlist(clientId: String, token: String, kind: String): List<TraktEntry> =
        parseItems(JSONArray(get(clientId, "/sync/watchlist/$kind?sort=added", token)), kind).map { (el, id) ->
            val obj = el.optJSONObject(if (id.isShow) "show" else "movie") ?: el
            TraktEntry(id.title, listOfNotNull(obj.optInt("year").takeIf { it > 0 }?.toString(), if (id.isShow) "Show" else "Movie").joinToString(" · "), id)
        }

    fun history(clientId: String, token: String, limit: Int = 50): List<TraktEntry> =
        parseItems(JSONArray(get(clientId, "/sync/history?limit=$limit", token)), null).map { (el, id) ->
            val ep = el.optJSONObject("episode")
            val what = if (ep != null) "S${ep.optInt("season")} E${ep.optInt("number")} · ${ep.optString("title")}" else "Movie"
            TraktEntry(id.title, "$what · watched ${el.optString("watched_at").take(10)}", id)
        }

    /** Episodes of shows you follow airing from [start] (yyyy-MM-dd) for [days] days, plus movies releasing. */
    fun calendar(clientId: String, token: String, start: String, days: Int): List<TraktEntry> {
        val shows = parseItems(JSONArray(get(clientId, "/calendars/my/shows/$start/$days", token)), "shows").map { (el, id) ->
            val ep = el.optJSONObject("episode")
            val whenText = el.optString("first_aired").take(16).replace('T', ' ')
            TraktEntry(id.title, "$whenText · S${ep?.optInt("season")} E${ep?.optInt("number")} · ${ep?.optString("title").orEmpty()}", id) to whenText
        }
        val movies = parseItems(JSONArray(get(clientId, "/calendars/my/movies/$start/$days", token)), "movies").map { (el, id) ->
            val whenText = el.optString("released")
            TraktEntry(id.title, "$whenText · Movie release", id) to whenText
        }
        return (shows + movies).sortedBy { it.second }.map { it.first }
    }

    // --- Home hub: titles with pictures, and where you stopped watching ---

    /** A movie or show with its year, overview and poster (when Trakt has one). */
    data class Title(val id: TraktId, val year: Int, val overview: String?, val poster: String?)

    /** Something you paused part-way (movie, or an episode of [id]'s show). */
    data class Playback(
        val id: TraktId,
        val season: Int,
        val episode: Int,
        val episodeTitle: String?,
        val progress: Double,       // 0-100
        val pausedAt: String,       // when paused (or, for Up Next, when you last watched the show)
        val poster: String?,
        val upNext: Boolean = false, // the next episode you haven't watched, not a paused one
    )

    /** Trakt image paths come without "https://"; first poster (or other kind) of an object. */
    private fun image(obj: JSONObject?, kind: String = "poster"): String? {
        val arr = obj?.optJSONObject("images")?.optJSONArray(kind) ?: return null
        val s = arr.optString(0).takeIf { it.isNotEmpty() } ?: return null
        return if (s.startsWith("http")) s else "https://$s"
    }

    private fun titles(clientId: String, path: String, kind: String, token: String? = null): List<Title> =
        parseItems(JSONArray(get(clientId, path, token)), kind).map { (el, id) ->
            val obj = el.optJSONObject(if (id.isShow) "show" else "movie") ?: el
            Title(id, obj.optInt("year"), obj.optString("overview").takeIf { it.isNotEmpty() && it != "null" }, image(obj))
        }

    /** What people are watching on Trakt right now. kind: movies or shows. */
    fun trending(clientId: String, kind: String, limit: Int = 20): List<Title> =
        titles(clientId, "/$kind/trending?limit=$limit&extended=full,images", kind)

    /** Your personal recommendations. kind: movies or shows. */
    fun recommended(clientId: String, token: String, kind: String, limit: Int = 20): List<Title> =
        titles(clientId, "/recommendations/$kind?limit=$limit&ignore_collected=false&extended=full,images", kind, token)

    /** Movies and episodes you paused, newest first, one per show. */
    fun playback(clientId: String, token: String): List<Playback> {
        val out = parseItems(JSONArray(get(clientId, "/sync/playback?limit=40&extended=images", token)), null).map { (el, id) ->
            val ep = el.optJSONObject("episode")
            val owner = el.optJSONObject(if (id.isShow) "show" else "movie")
            Playback(
                id = id,
                season = ep?.optInt("season") ?: 0,
                episode = ep?.optInt("number") ?: 0,
                episodeTitle = ep?.optString("title")?.takeIf { it.isNotEmpty() && it != "null" },
                progress = el.optDouble("progress", 0.0),
                pausedAt = el.optString("paused_at"),
                poster = image(owner),
            )
        }
        return out.sortedByDescending { it.pausedAt }
            .distinctBy { (if (it.id.isShow) "s:" else "m:") + (it.id.imdb ?: it.id.tmdb ?: it.id.tvdb ?: it.id.title) }
    }

    /**
     * Trakt's own Continue Watching, as on trakt.tv: its Up Next list of shows you're watching
     * (sync/progress/up_next_nitro, intent=continue) merged with movies you paused, newest first.
     * Paused episodes keep their progress. Returns null if Trakt doesn't answer, so the caller can
     * build the list another way.
     */
    fun continueWatching(clientId: String, token: String): List<Playback>? {
        val arr = try {
            JSONArray(get(clientId, "/sync/progress/up_next_nitro?intent=continue&limit=100&page=1&extended=images", token))
        } catch (_: Exception) {
            return null
        }
        val paused = try { playback(clientId, token) } catch (_: Exception) { emptyList() }
        fun showKey(id: TraktId) = id.imdb ?: id.tmdb ?: id.tvdb ?: id.title
        val shows = (0 until arr.length()).mapNotNull { i ->
            val el = arr.optJSONObject(i) ?: return@mapNotNull null
            val show = el.optJSONObject("show") ?: el
            val id = idsOf(show, true) ?: return@mapNotNull null
            val prog = el.optJSONObject("progress") ?: el
            val next = prog.optJSONObject("next_episode") ?: el.optJSONObject("next_episode") ?: el.optJSONObject("episode")
                ?: return@mapNotNull null
            val season = next.optInt("season")
            val number = next.optInt("number")
            // If you paused this very episode, keep where you stopped.
            val pausedHere = paused.firstOrNull { it.id.isShow && showKey(it.id) == showKey(id) && it.season == season && it.episode == number }
            val time = listOf(prog.optString("last_watched_at"), el.optString("last_watched_at"), el.optString("updated_at"))
                .firstOrNull { it.isNotEmpty() && it != "null" }.orEmpty()
            Playback(
                id = id,
                season = season,
                episode = number,
                episodeTitle = next.optString("title").takeIf { it.isNotEmpty() && it != "null" },
                progress = pausedHere?.progress ?: 0.0,
                pausedAt = maxOf(time, pausedHere?.pausedAt.orEmpty()),
                poster = image(show),
                upNext = pausedHere == null,
            )
        }
        // Trakt answered with something this app can't read: build the list the other way.
        if (arr.length() > 0 && shows.isEmpty()) return null
        val listed = shows.map { showKey(it.id) }.toSet()
        // Movies you paused, plus any paused episode of a show the Up Next list didn't include.
        val extra = paused.filter { !it.id.isShow || showKey(it.id) !in listed }
        return (shows + extra).sortedByDescending { it.pausedAt }
    }

    /**
     * Up Next, like Trakt's own: for the shows you watched most recently, the next aired episode you
     * haven't seen. Finished shows and shows you hid from progress on trakt.tv are left out.
     */
    fun upNext(clientId: String, token: String, maxShows: Int = 20): List<Playback> {
        val hidden = try {
            val a = JSONArray(get(clientId, "/users/hidden/progress_watched?type=show&limit=200", token))
            (0 until a.length()).mapNotNull { a.optJSONObject(it)?.optJSONObject("show")?.optJSONObject("ids")?.optInt("trakt") }.toSet()
        } catch (_: Exception) {
            emptySet()
        }
        val watched = JSONArray(get(clientId, "/sync/watched/shows?extended=noseasons,images", token))
        val shows = (0 until watched.length()).mapNotNull { watched.optJSONObject(it) }
            .filter { (it.optJSONObject("show")?.optJSONObject("ids")?.optInt("trakt") ?: 0) !in hidden }
            .sortedByDescending { it.optString("last_watched_at") }
            .take(maxShows)
        // One progress call per show, a few at a time.
        val pool = java.util.concurrent.Executors.newFixedThreadPool(4)
        try {
            val tasks = shows.map { el ->
                java.util.concurrent.Callable<Playback?> {
                    val show = el.optJSONObject("show") ?: return@Callable null
                    val id = idsOf(show, true) ?: return@Callable null
                    val traktId = show.optJSONObject("ids")?.optInt("trakt") ?: return@Callable null
                    val prog = try {
                        JSONObject(get(clientId, "/shows/$traktId/progress/watched?hidden=false&specials=false&count_specials=false", token))
                    } catch (_: Exception) {
                        return@Callable null
                    }
                    val next = prog.optJSONObject("next_episode") ?: return@Callable null
                    Playback(
                        id = id,
                        season = next.optInt("season"),
                        episode = next.optInt("number"),
                        episodeTitle = next.optString("title").takeIf { it.isNotEmpty() && it != "null" },
                        progress = 0.0,
                        pausedAt = el.optString("last_watched_at"),
                        poster = image(show),
                        upNext = true,
                    )
                }
            }
            return pool.invokeAll(tasks).mapNotNull { f -> try { f.get() } catch (_: Exception) { null } }
        } finally {
            pool.shutdown()
        }
    }

    // --- search (used to match Live TV programmes) ---

    data class Match(val traktId: Int, val title: String, val year: Int)

    /** type: "show" or "movie". */
    fun search(clientId: String, type: String, query: String): List<Match> {
        val q = java.net.URLEncoder.encode(query, "UTF-8")
        val a = JSONArray(get(clientId, "/search/$type?query=$q&limit=10"))
        return (0 until a.length()).mapNotNull { i ->
            val o = a.getJSONObject(i).optJSONObject(type) ?: return@mapNotNull null
            val id = o.optJSONObject("ids")?.optInt("trakt") ?: 0
            if (id == 0) null else Match(id, o.optString("title"), o.optInt("year"))
        }
    }

    // --- scrobbling ---

    /** action: start, pause or stop. [media] is {"movie": {"ids": ...}} or {"episode": {"ids": ...}}. */
    fun scrobble(clientId: String, token: String, action: String, media: JSONObject, progress: Double) {
        val body = JSONObject(media.toString()).put("progress", progress.coerceIn(0.0, 100.0))
        val c = call(clientId, "/scrobble/$action", "POST", body, token)
        // 409 = already scrobbled recently; not an error worth showing.
        if (c.responseCode !in 200..299 && c.responseCode != 409) throw IOException("Trakt returned HTTP ${c.responseCode}")
    }
}
