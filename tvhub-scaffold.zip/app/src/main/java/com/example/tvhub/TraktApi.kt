package com.example.tvhub

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** One title from a Trakt list, with every ID Trakt knows for it, so it can be matched to Plex. */
data class TraktId(
    val title: String,
    val imdb: String?,
    val tmdb: String?,
    val tvdb: String?,
    val isShow: Boolean,
)

/**
 * Minimal Trakt client for the public lists (trending, popular, anticipated). These need only the
 * app's Client ID (free: trakt.tv/oauth/applications), not a sign-in.
 */
object TraktApi {
    fun list(clientId: String, kind: String, list: String, limit: Int = 100): List<TraktId> {
        val c = URL("https://api.trakt.tv/$kind/$list?limit=$limit").openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 20_000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("trakt-api-version", "2")
        c.setRequestProperty("trakt-api-key", clientId)
        if (c.responseCode !in 200..299) throw IOException("Trakt returned HTTP ${c.responseCode}")
        val arr = JSONArray(c.inputStream.bufferedReader().use { it.readText() })
        val out = ArrayList<TraktId>()
        for (i in 0 until arr.length()) {
            val el = arr.optJSONObject(i) ?: continue
            // Trending/anticipated wrap each title ({"watchers":..,"movie":{..}}); popular lists them plainly.
            val obj: JSONObject = el.optJSONObject("movie") ?: el.optJSONObject("show") ?: el
            val ids = obj.optJSONObject("ids") ?: continue
            fun id(key: String): String? =
                if (ids.isNull(key)) null else ids.opt(key)?.toString()?.takeIf { it.isNotEmpty() }
            out += TraktId(
                title = obj.optString("title"),
                imdb = id("imdb"),
                tmdb = id("tmdb"),
                tvdb = id("tvdb"),
                isShow = kind == "shows",
            )
        }
        return out
    }
}
