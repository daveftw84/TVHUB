package com.example.tvhub

import android.app.Application
import android.content.Context
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

sealed interface PlexState {
    object SignedOut : PlexState
    data class WaitingForCode(val code: String) : PlexState
    object Loading : PlexState
    data class Failed(val message: String) : PlexState
    object Ready : PlexState
}

sealed interface PlexScreen {
    object Home : PlexScreen
    object Libraries : PlexScreen
    data class Library(val lib: PlexLibrary) : PlexScreen
    data class Grid(val title: String, val path: String) : PlexScreen
    data class Detail(val item: PlexItem) : PlexScreen
    object Search : PlexScreen
}

enum class LibTab(val label: String) {
    RECOMMENDED("Recommended"),
    BROWSE("Browse"),
    COLLECTIONS("Collections"),
    CATEGORIES("Categories"),
}

enum class GridSort(val label: String, val param: String) {
    TITLE("A–Z", "titleSort"),
    ADDED("Recently added", "addedAt:desc"),
    RELEASED("Release date", "originallyAvailableAt:desc"),
    RATING("Rating", "audienceRating:desc"),
}

data class HomeRow(val title: String, val items: List<PlexItem>, val seeAll: String? = null)

class PlexViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("tvhub", Context.MODE_PRIVATE)
    private val clientId: String = prefs.getString("client_id", null)
        ?: UUID.randomUUID().toString().also { prefs.edit().putString("client_id", it).apply() }

    var state by mutableStateOf<PlexState>(PlexState.SignedOut)
        private set
    var server by mutableStateOf<PlexServer?>(null)
        private set
    var libraries by mutableStateOf<List<PlexLibrary>>(emptyList())
        private set
    var playing by mutableStateOf<PlexItem?>(null)
        private set
    var notice by mutableStateOf<String?>(null)
        private set

    // --- Home rows ---
    private var plexRows by mutableStateOf<List<HomeRow>>(emptyList())
    val homeRows: List<HomeRow> get() = plexRows
    var homeLoading by mutableStateOf(false)
        private set
    private var homeJob: Job? = null

    // --- Navigation: an empty stack means Home ---
    private val stack = mutableStateListOf<PlexScreen>()
    val screen: PlexScreen get() = stack.lastOrNull() ?: PlexScreen.Home
    val canGoBack: Boolean get() = playing != null || stack.isNotEmpty()

    // --- Library page (tabs) ---
    var libTab by mutableStateOf(LibTab.RECOMMENDED)
        private set
    var libHubs by mutableStateOf<List<HomeRow>>(emptyList())
        private set
    var libCollections by mutableStateOf<List<PlexItem>>(emptyList())
        private set
    var libGenres by mutableStateOf<List<PlexGenre>>(emptyList())
        private set
    var libLoading by mutableStateOf(false)
        private set
    private var libGen = 0

    // --- Paged grid (Browse tab, collections, categories, "see all") ---
    val gridItems = mutableStateListOf<PlexItem>()
    var gridLoading by mutableStateOf(false)
        private set
    var gridSort by mutableStateOf(GridSort.TITLE)
        private set
    var gridState by mutableStateOf(LazyGridState())
        private set
    var gridTotalItems by mutableStateOf(0)
        private set
    var gridUnwatched by mutableStateOf(false)
        private set
    var letters by mutableStateOf<List<PlexLetter>>(emptyList())
        private set
    private var lettersLib: String? = null
    private var gridBase: String? = null
    private var gridSortable = false
    private var gridPath: String? = null
    private var gridOffset = 0
    private var gridTotal = 0
    private var gridGen = 0

    // --- Search ---
    var searchQuery by mutableStateOf("")
        private set
    var searchResults by mutableStateOf<List<PlexItem>>(emptyList())
        private set
    var searching by mutableStateOf(false)
        private set
    /** Set when some libraries did not answer in time, so "nothing found" is not mistaken for "no match". */
    var searchProblem by mutableStateOf<String?>(null)
        private set
    private var searchJob: Job? = null

    // --- On-device copy of all titles, so search is instant ---
    private val index = PlexIndex(app)
    private var indexJob: Job? = null
    /** Progress line for the search page, e.g. "Saving Movies for fast search… 12,000 / 74,545". */
    var indexStatus by mutableStateOf<String?>(null)
        private set
    /** True once every library has been saved on the device. */
    var indexReady by mutableStateOf(false)
        private set

    // --- Detail page ---
    var seasons by mutableStateOf<List<PlexItem>>(emptyList())
        private set
    var episodes by mutableStateOf<List<PlexItem>>(emptyList())
        private set
    var selectedSeason by mutableStateOf<PlexItem?>(null)
        private set
    var detailLoading by mutableStateOf(false)
        private set
    private var detailGen = 0

    init {
        prefs.getString("plex_token", null)?.let { connect(it) }
    }

    /** Runs blocking network code off the main thread and turns any failure (even out-of-memory) into a Result. */
    private suspend fun <T> io(block: () -> T): Result<T> = withContext(Dispatchers.IO) {
        try {
            Result.success(block())
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    // ------------------------------------------------------------ Sign-in

    fun signIn() {
        viewModelScope.launch {
            val pinResult = io { PlexApi.createPin(clientId) }
            val pin = pinResult.getOrNull()
            if (pin == null) {
                state = PlexState.Failed(pinResult.exceptionOrNull()?.message ?: "Sign-in failed")
                return@launch
            }
            state = PlexState.WaitingForCode(pin.code)
            repeat(150) {                       // ~5 minutes
                delay(2_000)
                val token = io { PlexApi.checkPin(pin, clientId) }.getOrNull()
                if (token != null) {
                    prefs.edit().putString("plex_token", token).apply()
                    connect(token)
                    return@launch
                }
            }
            state = PlexState.Failed("The code expired. Try again.")
        }
    }

    private fun connect(token: String) {
        viewModelScope.launch {
            state = PlexState.Loading
            val serverResult = io { PlexApi.findServer(token, clientId) }
            val s = serverResult.getOrNull()
            if (s == null) {
                state = PlexState.Failed(serverResult.exceptionOrNull()?.message ?: "Could not reach Plex")
                return@launch
            }
            server = s
            libraries = io { PlexApi.libraries(s, clientId) }.getOrNull().orEmpty()
            state = PlexState.Ready
            refreshHome()
            startIndexing(s, libraries)
        }
    }

    fun retry() {
        val token = prefs.getString("plex_token", null)
        if (token != null) connect(token) else signIn()
    }

    fun signOut() {
        prefs.edit().remove("plex_token").apply()
        homeJob?.cancel()
        searchJob?.cancel()
        indexJob?.cancel()
        indexStatus = null
        indexReady = false
        viewModelScope.launch { io { index.clear() } }
        server = null
        libraries = emptyList()
        plexRows = emptyList()
        stack.clear()
        libGen++
        libHubs = emptyList()
        libCollections = emptyList()
        libGenres = emptyList()
        libLoading = false
        gridGen++
        gridItems.clear()
        gridPath = null
        gridOffset = 0
        gridTotalItems = 0
        letters = emptyList()
        lettersLib = null
        gridLoading = false
        searchQuery = ""
        searchResults = emptyList()
        playing = null
        notice = null
        state = PlexState.SignedOut
    }

    // ------------------------------------------------------------ Home

    fun refreshHome() {
        val s = server ?: return
        val libs = libraries
        homeJob?.cancel()
        homeJob = viewModelScope.launch {
            homeLoading = true
            try {
                val rows = mutableListOf<HomeRow>()
                io { PlexApi.page(s, clientId, "/library/onDeck", 0, 20).items }.getOrNull()
                    ?.takeIf { it.isNotEmpty() }
                    ?.let { rows += HomeRow("Continue Watching", it) }
                for (lib in libs) {
                    val path = "/library/sections/${lib.id}/all?sort=addedAt:desc"
                    io { PlexApi.page(s, clientId, path, 0, 20).items }
                        .getOrNull()
                        ?.takeIf { it.isNotEmpty() }
                        ?.let { rows += HomeRow("Recently Added in ${lib.title}", it, seeAll = path) }
                }
                plexRows = rows
            } finally {
                homeLoading = false
            }
        }
    }

    fun goHome() {
        stack.clear()
        notice = null
    }

    fun goLibraries() {
        stack.clear()
        stack.add(PlexScreen.Libraries)
        notice = null
    }

    // ------------------------------------------------------------ Library page

    private fun libBrowsePath(lib: PlexLibrary) = "/library/sections/${lib.id}/all"

    fun openLibrary(lib: PlexLibrary) {
        notice = null
        libGen++
        libLoading = false
        libTab = LibTab.RECOMMENDED
        libHubs = emptyList()
        libCollections = emptyList()
        libGenres = emptyList()
        letters = emptyList()
        lettersLib = null
        gridUnwatched = false
        stack.add(PlexScreen.Library(lib))
        loadLibTab()
    }

    fun selectLibTab(tab: LibTab) {
        if (tab == libTab) return
        libTab = tab
        notice = null
        loadLibTab()
    }

    private fun loadLibTab() {
        val lib = (stack.lastOrNull() as? PlexScreen.Library)?.lib ?: return
        val s = server ?: return
        when (libTab) {
            LibTab.RECOMMENDED -> if (libHubs.isEmpty()) loadHubs(lib, s)
            LibTab.BROWSE -> {
                startGrid(libBrowsePath(lib), true)
                loadLetters(lib, s)
            }
            LibTab.COLLECTIONS -> if (libCollections.isEmpty()) loadCollections(lib, s)
            LibTab.CATEGORIES -> if (libGenres.isEmpty()) loadGenres(lib, s)
        }
    }

    private fun loadHubs(lib: PlexLibrary, s: PlexServer) {
        val gen = libGen
        libLoading = true
        viewModelScope.launch {
            val r = io { PlexApi.hubs(s, clientId, "/hubs/sections/${lib.id}?count=15") }
            if (gen != libGen) return@launch
            r.getOrNull()?.let { hubs -> libHubs = hubs.map { HomeRow(it.title, it.items, it.key) } }
            if (r.isFailure) notice = "Couldn't load recommendations."
            libLoading = false
        }
    }

    private fun loadCollections(lib: PlexLibrary, s: PlexServer) {
        val gen = libGen
        libLoading = true
        viewModelScope.launch {
            val r = io { PlexApi.page(s, clientId, "/library/sections/${lib.id}/collections", 0, 300).items }
            if (gen != libGen) return@launch
            libCollections = r.getOrNull().orEmpty()
            if (r.isFailure) notice = "Couldn't load collections."
            libLoading = false
        }
    }

    /** Trakt lists shown as categories (only when a Trakt Client ID is set in Settings). */
    private fun traktTiles(lib: PlexLibrary): List<PlexGenre> {
        if (prefs.getString("trakt_client_id", "").orEmpty().isBlank()) return emptyList()
        val kind = if (lib.type == "show") "shows" else "movies"
        return listOf(
            PlexGenre("Trending on Trakt", "trakt://$kind/trending"),
            PlexGenre("Popular on Trakt", "trakt://$kind/popular"),
            PlexGenre("Most Watched This Week", "trakt://$kind/watched/weekly"),
        )
    }

    private var traktGridGen = -1

    /** A Trakt list as a grid: only the titles of the list that are in your library, in the list's order. */
    private fun loadTraktGrid(path: String) {
        val key = prefs.getString("trakt_client_id", "").orEmpty().trim()
        val spec = path.removePrefix("trakt://")             // e.g. "movies/trending"
        val kind = spec.substringBefore('/')
        val list = spec.substringAfter('/')
        val gen = gridGen
        traktGridGen = gen
        gridLoading = true
        viewModelScope.launch {
            val r = io { TraktApi.list(key, kind, list, 200) }
            if (gen != gridGen) return@launch
            val ids = r.getOrNull()
            if (ids == null) {
                notice = "Couldn't reach Trakt. Check the Client ID in Settings and your connection."
            } else {
                val items = io { index.matchExternal(ids) }.getOrNull().orEmpty()
                gridItems.addAll(items)
                gridTotal = items.size
                gridTotalItems = items.size
                notice = if (items.isEmpty()) {
                    if (indexReady) "None of this list is in your library." else
                        "Your library list is still being saved, so matches may be missing."
                } else null
            }
            gridLoading = false
        }
    }

    private fun loadGenres(lib: PlexLibrary, s: PlexServer) {
        val gen = libGen
        libLoading = true
        viewModelScope.launch {
            val r = io { PlexApi.genres(s, clientId, lib.id) }
            if (gen != libGen) return@launch
            libGenres = traktTiles(lib) + r.getOrNull().orEmpty()
            if (r.isFailure) notice = "Couldn't load categories."
            libLoading = false
        }
    }

    // ------------------------------------------------------------ Paged grid

    private fun gridPathFor(base: String, sortable: Boolean): String {
        if (!sortable) return base
        val sep = if (base.contains('?')) "&" else "?"
        return base + sep + "sort=${gridSort.param}" + (if (gridUnwatched) "&unwatched=1" else "")
    }

    /**
     * Starts (or keeps, if it's already showing) the paged list for [base].
     * [offset] starts the list part-way through, which the A–Z jump bar uses.
     */
    private fun startGrid(base: String, sortable: Boolean, offset: Int = 0) {
        val path = gridPathFor(base, sortable)
        gridBase = base
        gridSortable = sortable
        // Coming back from a detail page: keep the items and scroll position.
        if (path == gridPath && offset == gridOffset && (gridItems.isNotEmpty() || gridLoading)) return
        gridGen++
        gridPath = path
        gridOffset = offset
        gridItems.clear()
        gridTotal = 0
        gridLoading = false
        gridState = LazyGridState()
        loadMore()
    }

    fun openGrid(title: String, path: String) {
        notice = null
        stack.add(PlexScreen.Grid(title, path))
        startGrid(path, false)
    }

    fun setSort(sort: GridSort) {
        if (sort == gridSort) return
        gridSort = sort
        val base = gridBase ?: return
        startGrid(base, gridSortable)
    }

    fun setUnwatched(on: Boolean) {
        if (on == gridUnwatched) return
        gridUnwatched = on
        val base = gridBase ?: return
        startGrid(base, gridSortable)
    }

    /** Jump to a position in the A–Z list. The list then starts there; "#" goes back to the beginning. */
    fun jumpTo(index: Int) {
        val base = gridBase ?: return
        startGrid(base, gridSortable, index)
    }

    private fun loadLetters(lib: PlexLibrary, s: PlexServer) {
        if (lettersLib == lib.id && letters.isNotEmpty()) return
        lettersLib = lib.id
        val gen = libGen
        viewModelScope.launch {
            val r = io { PlexApi.firstCharacters(s, clientId, lib.id) }
            if (gen != libGen) return@launch
            letters = r.getOrNull().orEmpty()
        }
    }

    fun loadMore() {
        val s = server ?: return
        val key = gridPath ?: return
        if (gridLoading) return
        if (key.startsWith("trakt://")) {
            if (traktGridGen != gridGen) loadTraktGrid(key)
            return
        }
        if (gridItems.isNotEmpty() && gridOffset + gridItems.size >= gridTotal) return
        val gen = gridGen
        val start = gridOffset + gridItems.size
        gridLoading = true
        viewModelScope.launch {
            val result = io { PlexApi.page(s, clientId, key, start, PAGE_SIZE) }
            if (gen != gridGen) return@launch       // the user switched list or sort meanwhile
            val pg = result.getOrNull()
            if (pg != null) {
                gridItems.addAll(pg.items)
                gridTotal = pg.total
                gridTotalItems = pg.total
                notice = null
            } else {
                notice = "Couldn't load this list. Check your connection and try again."
            }
            gridLoading = false
        }
    }

    // ------------------------------------------------------------ Search

    fun openSearch() {
        if (screen is PlexScreen.Search) return
        searchQuery = ""
        searchResults = emptyList()
        searching = false
        searchProblem = null
        notice = null
        stack.add(PlexScreen.Search)
    }

    fun updateSearch(q: String) {
        searchQuery = q
        searchJob?.cancel()
        searchProblem = null
        val s = server
        val text = q.trim()
        if (s == null || text.length < 2) {
            searchResults = emptyList()
            searching = false
            return
        }
        runSearch(s, text, delayMs = 400)    // wait until the user stops typing
    }

    /** Try the same search again (after a timeout). */
    fun retrySearch() {
        val s = server ?: return
        val text = searchQuery.trim()
        if (text.length < 2) return
        searchJob?.cancel()
        searchProblem = null
        runSearch(s, text, delayMs = 0)
    }

    private fun runSearch(s: PlexServer, text: String, delayMs: Long) {
        searchJob = viewModelScope.launch {
            delay(delayMs)
            searching = true
            // 1. The saved copy on this device answers straight away.
            val local = io { index.search(text) }.getOrNull().orEmpty()
            searchResults = local
            // An IMDb number can only be looked up in the saved copy (the server cannot search by it).
            if (PlexIndex.imdbIdIn(text) != null) {
                searching = false
                if (local.isEmpty() && !indexReady) {
                    searchProblem = "IMDb search works from the saved list, which is still being saved (see above)."
                }
                return@launch
            }
            // 2. The server is asked too (one request per library, all at once), which also finds
            //    episodes and anything not saved yet. Its answers are added as they arrive.
            val targets: List<String?> = libraries.map { it.id }.ifEmpty { listOf(null) }
            val found = HashMap<String?, List<PlexItem>>()
            var discovered: List<PlexItem> = emptyList()
            var failed = 0
            val lock = Any()
            kotlinx.coroutines.coroutineScope {
                // Plex's online catalog finds titles by name quickly; its IDs are matched to the saved copy.
                val token = prefs.getString("plex_token", null)
                if (token != null) launch {
                    val ids = io { PlexApi.discoverSearch(token, clientId, text) }.getOrNull()
                    val mine = if (ids == null) emptyList() else
                        io { index.byIds(ids.imdb, ids.guids) }.getOrNull().orEmpty()
                    synchronized(lock) {
                        discovered = mine
                        searchResults = (local + discovered + targets.flatMap { found[it].orEmpty() })
                            .distinctBy { it.ratingKey }
                    }
                }
                targets.map { id ->
                    launch {
                        val r = io { PlexApi.search(s, clientId, text, id) }
                        synchronized(lock) {
                            if (r.isSuccess) found[id] = r.getOrThrow() else failed++
                            searchResults = (local + discovered + targets.flatMap { found[it].orEmpty() })
                                .distinctBy { it.ratingKey }
                        }
                    }
                }
            }
            searching = false
            // Only worry the user when the saved copy could not cover the gap.
            if (failed > 0 && (searchResults.isEmpty() || !indexReady)) {
                searchProblem = if (failed == targets.size) {
                    "The server didn't answer in time."
                } else {
                    "$failed of ${targets.size} libraries didn't answer in time, so results may be missing."
                }
            }
        }
    }

    // ------------------------------------------------------------ On-device title list

    /**
     * Saves every title of every library on the device, one page at a time (the same paged requests
     * Browse uses). Runs once in the background; later runs only redo a library when its size changed
     * or it is more than a day old.
     */
    private fun startIndexing(s: PlexServer, libs: List<PlexLibrary>) {
        indexJob?.cancel()
        indexJob = viewModelScope.launch {
            if (io { index.getMeta("server") }.getOrNull() != s.name) {
                io { index.clear(); index.setMeta("server", s.name) }
            }
            var allDone = true
            for (lib in libs) {
                val total = io { PlexApi.page(s, clientId, "/library/sections/${lib.id}/all", 0, 1).total }
                    .getOrNull()
                if (total == null) {
                    allDone = false
                    continue
                }
                val have = io { index.count(lib.id) }.getOrNull() ?: 0
                val last = io { index.getMeta("synced_${lib.id}") }.getOrNull()?.toLongOrNull() ?: 0L
                val fresh = System.currentTimeMillis() - last < 24L * 60 * 60 * 1000
                if (have == total && fresh) continue

                val stamp = System.currentTimeMillis()
                var start = 0
                var ok = true
                while (start < total) {
                    indexStatus = "Saving ${lib.title} for fast search… " +
                        "%,d / %,d".format(start, total)
                    var page = io {
                        PlexApi.page(s, clientId, "/library/sections/${lib.id}/all?sort=titleSort&includeGuids=1", start, 300)
                    }
                    if (page.isFailure) {          // one retry
                        delay(3_000)
                        page = io {
                            PlexApi.page(s, clientId, "/library/sections/${lib.id}/all?sort=titleSort&includeGuids=1", start, 300)
                        }
                    }
                    val items = page.getOrNull()?.items
                    if (items == null || items.isEmpty()) {
                        ok = false
                        break
                    }
                    io { index.upsert(lib.id, items, stamp) }
                    start += items.size
                    delay(50)                      // be gentle with the server
                }
                if (ok) {
                    io {
                        index.deleteOlder(lib.id, stamp)
                        index.setMeta("synced_${lib.id}", stamp.toString())
                    }
                } else {
                    allDone = false
                }
            }
            val saved = io { index.count() }.getOrNull() ?: 0
            indexReady = allDone && saved > 0
            indexStatus = if (indexReady) {
                "Fast search ready · %,d titles saved on this device".format(saved)
            } else if (saved > 0) {
                "Saved %,d titles so far. The rest will finish next time.".format(saved)
            } else {
                null
            }
        }
    }

    /** Search results come from the saved copy; [open] fetches the full item before showing it. */
    fun openSearchResult(item: PlexItem) = open(item)

    // ------------------------------------------------------------ Opening items and detail page

    /** Collections open as a list of their items; everything else opens its detail page. */
    fun open(item: PlexItem) {
        when {
            item.type == "collection" -> {
                val rk = item.ratingKey ?: return
                openGrid(item.title, "/library/collections/$rk/children")
            }
            item.light -> openFromSavedCopy(item)
            else -> openDetail(item)
        }
    }

    /** Items from search and Trakt rows come from the saved copy (basic details only): fetch the full item first. */
    private fun openFromSavedCopy(item: PlexItem) {
        val s = server
        val rk = item.ratingKey
        if (s == null || rk == null) {
            openDetail(item.copy(light = false))
            return
        }
        viewModelScope.launch {
            val full = io { PlexApi.page(s, clientId, "/library/metadata/$rk", 0, 1).items.firstOrNull() }.getOrNull()
            openDetail(full ?: item.copy(light = false))
        }
    }

    fun openDetail(item: PlexItem) {
        stack.add(PlexScreen.Detail(item))
        notice = null
        loadDetail(item)
    }

    private fun loadDetail(item: PlexItem) {
        seasons = emptyList()
        episodes = emptyList()
        selectedSeason = null
        val s = server ?: return
        val rk = item.ratingKey ?: return
        if (item.type != "show" && item.type != "season") return
        val gen = ++detailGen
        detailLoading = true
        viewModelScope.launch {
            if (item.type == "show") {
                val all = io { PlexApi.children(s, clientId, rk) }.getOrNull().orEmpty()
                    .filter { it.type == "season" }
                if (gen != detailGen) return@launch
                seasons = all
                val first = all.firstOrNull { it.index > 0 && !it.watched }
                    ?: all.firstOrNull { it.index > 0 }
                    ?: all.firstOrNull()
                selectedSeason = first
                val seasonKey = first?.ratingKey
                if (seasonKey != null) {
                    val eps = io { PlexApi.children(s, clientId, seasonKey) }.getOrNull().orEmpty()
                    if (gen != detailGen) return@launch
                    episodes = eps
                }
            } else {
                val eps = io { PlexApi.children(s, clientId, rk) }.getOrNull().orEmpty()
                if (gen != detailGen) return@launch
                episodes = eps
            }
            detailLoading = false
        }
    }

    fun selectSeason(season: PlexItem) {
        val s = server ?: return
        val rk = season.ratingKey ?: return
        selectedSeason = season
        episodes = emptyList()
        val gen = ++detailGen
        detailLoading = true
        viewModelScope.launch {
            val eps = io { PlexApi.children(s, clientId, rk) }.getOrNull().orEmpty()
            if (gen != detailGen) return@launch
            episodes = eps
            detailLoading = false
        }
    }

    /** After playback, refresh watch progress on the page the user returns to. */
    private fun refreshDetail() {
        val s = server ?: return
        val scr = screen as? PlexScreen.Detail ?: return
        val current = scr.item
        viewModelScope.launch {
            if (current.playable) {
                val rk = current.ratingKey ?: return@launch
                val fresh = io { PlexApi.page(s, clientId, "/library/metadata/$rk", 0, 1).items.firstOrNull() }.getOrNull()
                if (fresh != null && screen is PlexScreen.Detail) {
                    stack[stack.lastIndex] = PlexScreen.Detail(fresh)
                }
            } else {
                val parent = if (current.type == "season") current else selectedSeason
                val parentKey = parent?.ratingKey
                if (parentKey != null) {
                    io { PlexApi.children(s, clientId, parentKey) }.getOrNull()?.let { episodes = it }
                }
            }
        }
    }

    // ------------------------------------------------------------ Playback and back

    fun play(item: PlexItem) {
        if (item.playable) playing = item
    }

    fun back() {
        if (playing != null) {
            playing = null
            refreshHome()
            refreshDetail()
            // Refresh the Continue Watching row if we're on a library's Recommended tab.
            val lib = (screen as? PlexScreen.Library)?.lib
            val s = server
            if (lib != null && s != null && libTab == LibTab.RECOMMENDED) loadHubs(lib, s)
            return
        }
        if (stack.isEmpty()) return
        stack.removeAt(stack.lastIndex)
        notice = null
        when (val top = stack.lastOrNull()) {
            is PlexScreen.Library -> if (libTab == LibTab.BROWSE) startGrid(libBrowsePath(top.lib), true, gridOffset)
            is PlexScreen.Grid -> startGrid(top.path, false)
            else -> {}
        }
    }

    fun streamUrl(item: PlexItem): String? =
        server?.let { s -> item.partKey?.let { PlexApi.streamUrl(s, it) } }

    // ------------------------------------------------------------ Pictures

    fun poster(item: PlexItem, width: Int = 300): String? =
        server?.let { s -> (item.posterThumb ?: item.thumb)?.let { PlexApi.imageUrl(s, it, width, width * 3 / 2) } }

    fun landscape(item: PlexItem, width: Int = 480): String? =
        server?.let { s ->
            val path = if (item.type == "episode") item.thumb ?: item.art else item.art ?: item.thumb
            path?.let { PlexApi.imageUrl(s, it, width, width * 9 / 16) }
        }

    fun backdrop(item: PlexItem): String? =
        server?.let { s -> (item.art ?: item.thumb)?.let { PlexApi.imageUrl(s, it, 1280, 720) } }

    fun report(item: PlexItem, state: String, timeMs: Long, durationMs: Long) {
        val s = server ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                PlexApi.reportTimeline(s, clientId, item, state, timeMs, durationMs)
            } catch (_: Throwable) {
            }
        }
    }

    companion object { const val PAGE_SIZE = 60 }
}
