package com.example.tvhub

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(live: LiveViewModel) {
    val ctx = LocalContext.current
    val tv = rememberIsTv()
    val prefs = remember { AppPrefs(ctx) }
    var playlist by remember { mutableStateOf(prefs.playlistUrl) }
    var epg by remember { mutableStateOf(prefs.epgUrl) }
    var trakt by remember { mutableStateOf(prefs.traktClientId) }
    var traktSecret by remember { mutableStateOf(prefs.traktClientSecret) }
    var xcServer by remember { mutableStateOf(prefs.xcServer) }
    var xcUser by remember { mutableStateOf(prefs.xcUser) }
    var xcPass by remember { mutableStateOf(prefs.xcPass) }
    val scope = rememberCoroutineScope()
    var address by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf(false) }

    val server = remember {
        SetupServer { p, e, tk ->
            Handler(Looper.getMainLooper()).post {
                if (p.isNotEmpty()) {
                    prefs.playlistUrl = p
                    prefs.epgUrl = e
                    playlist = p
                    epg = e
                    live.reload()
                }
                if (tk.isNotEmpty()) {
                    prefs.traktClientId = tk
                    trakt = tk
                }
                saved = true
            }
        }
    }
    DisposableEffect(Unit) { onDispose { server.stop() } }

    // The phone-setup web page is only useful on a TV, where typing is slow.
    LaunchedEffect(tv) {
        if (tv) {
            val port = withContext(Dispatchers.IO) { server.start() }
            val ip = withContext(Dispatchers.IO) { SetupServer.localIp() }
            address = if (port > 0 && ip != null) "http://$ip:$port" else null
        }
    }

    Row(
        Modifier.fillMaxSize().padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(32.dp),
    ) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Settings", style = MaterialTheme.typography.headlineMedium)
            OutlinedTextField(
                value = playlist,
                onValueChange = { playlist = it; saved = false },
                label = { Text("Playlist URL (M3U)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = epg,
                onValueChange = { epg = it; saved = false },
                label = { Text("Guide URL (XMLTV, optional)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )
            Text("Or log in with Xtream Codes", style = MaterialTheme.typography.titleSmall)
            Text(
                "Fill these in instead of a playlist URL if your provider gives you a server, username and password. " +
                    "Channels, groups and the guide then come from the provider.",
                style = MaterialTheme.typography.bodySmall,
            )
            OutlinedTextField(
                value = xcServer,
                onValueChange = { xcServer = it; saved = false },
                label = { Text("Server (e.g. http://example.com:8080)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = xcUser,
                onValueChange = { xcUser = it; saved = false },
                label = { Text("Username") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = xcPass,
                onValueChange = { xcPass = it; saved = false },
                label = { Text("Password") },
                singleLine = true,
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = trakt,
                onValueChange = { trakt = it; saved = false },
                label = { Text("Trakt Client ID (optional)") },
                supportingText = { Text("Only needed if none is built into the app. Adds Trending, Popular and Most Watched to each library's Categories tab.") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = traktSecret,
                onValueChange = { traktSecret = it; saved = false },
                label = { Text("Trakt Client Secret (for signing in)") },
                supportingText = { Text("Only needed if none is built into the app. Needed to sign in to your Trakt account.") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Button(
                onClick = {
                    prefs.playlistUrl = playlist.trim()
                    prefs.epgUrl = epg.trim()
                    prefs.traktClientId = trakt.trim()
                    prefs.traktClientSecret = traktSecret.trim()
                    prefs.xcServer = xcServer.trim()
                    prefs.xcUser = xcUser.trim()
                    prefs.xcPass = xcPass
                    live.reload()
                    saved = true
                },
                modifier = Modifier.focusRing(ButtonShape),
            ) { Text(if (saved) "Saved" else "Save and reload") }

            TraktAccountSection(scope)
        }

        if (tv) {
            Column(Modifier.width(300.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Easier: set up from your phone", style = MaterialTheme.typography.titleMedium)
                val a = address
                if (a != null) {
                    val qr = remember(a) { SetupServer.qr(a) }
                    Image(qr, contentDescription = "QR code for $a", modifier = Modifier.size(220.dp))
                    Text(a)
                    Text("Code: ${server.code}", style = MaterialTheme.typography.titleLarge)
                    Text("Scan the QR code, or open the address on any device on your Wi-Fi, then enter the code.")
                } else {
                    Text("Starting phone setup…")
                }
            }
        }
    }
}

/** Sign in to Trakt (enter a code at trakt.tv/activate), scrobbling switch, sign out. */
@Composable
private fun TraktAccountSection(scope: kotlinx.coroutines.CoroutineScope) {
    val ctx = LocalContext.current
    remember { TraktAccount.load(ctx); true }
    Text("Trakt account", style = MaterialTheme.typography.titleMedium)
    val code = TraktAccount.pending
    when {
        code != null -> {
            Text("On your phone or computer, go to ${code.url} and enter this code:")
            Text(code.userCode, style = MaterialTheme.typography.headlineMedium)
            val qr = remember(code.url) { SetupServer.qr(code.url) }
            Image(qr, contentDescription = "QR code for ${code.url}", modifier = Modifier.size(160.dp))
            Text("Waiting for you to approve…", style = MaterialTheme.typography.bodySmall)
            Button(onClick = { TraktAccount.cancelSignIn() }, modifier = Modifier.focusRing(ButtonShape)) { Text("Cancel") }
        }
        TraktAccount.signedIn -> {
            Text("Signed in" + (TraktAccount.username?.let { " as $it" } ?: "") +
                ". Your recommendations and watchlist appear on Library Home, and the Trakt page " +
                "(Library > Trakt) has your calendar, watchlist, recommendations and history.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { TraktAccount.setScrobble(ctx, !TraktAccount.scrobbleOn) },
                    modifier = Modifier.focusRing(ButtonShape),
                ) { Text(if (TraktAccount.scrobbleOn) "Scrobbling: on" else "Scrobbling: off") }
                Button(onClick = { TraktAccount.signOut(ctx) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Sign out") }
            }
            Text(
                "Scrobbling marks what you watch in the Plex player on Trakt (start, pause and stop; " +
                    "it counts as watched past 80%).",
                style = MaterialTheme.typography.bodySmall,
            )
            val appPrefs = remember { AppPrefs(ctx) }
            var live by remember { mutableStateOf(appPrefs.scrobbleLive) }
            Button(
                onClick = { live = !live; appPrefs.scrobbleLive = live },
                modifier = Modifier.focusRing(ButtonShape),
            ) { Text(if (live) "Scrobble Live TV: on" else "Scrobble Live TV: off") }
            Text(
                "Live TV uses the guide to work out what's on. Shows are only scrobbled when the guide has " +
                    "season and episode numbers; movies only when the title matches exactly one Trakt movie. " +
                    "Anything uncertain is skipped.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        else -> {
            Text("Sign in to get your Trakt recommendations, calendar, watchlist and history, and to scrobble what you watch.")
            Button(onClick = { TraktAccount.startSignIn(ctx, scope) }, modifier = Modifier.focusRing(ButtonShape)) {
                Text("Sign in to Trakt")
            }
        }
    }
    TraktAccount.message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
}
