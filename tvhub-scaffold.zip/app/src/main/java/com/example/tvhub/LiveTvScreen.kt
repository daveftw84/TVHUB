package com.example.tvhub

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView

@Composable
fun LiveTvScreen(vm: LiveViewModel) {
    val wide = rememberIsWide()
    val keys = Modifier
        .fillMaxSize()
        .onPreviewKeyEvent { e ->
            if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
            when (e.nativeKeyEvent.keyCode) {
                KeyEvent.KEYCODE_CHANNEL_UP -> { vm.next(); true }
                KeyEvent.KEYCODE_CHANNEL_DOWN -> { vm.previous(); true }
                KeyEvent.KEYCODE_LAST_CHANNEL -> { vm.playLast(); true }
                else -> false
            }
        }

    if (wide) {
        Row(keys) {
            ChannelList(vm, Modifier.width(320.dp).fillMaxHeight())
            Column(Modifier.weight(1f).fillMaxHeight()) {
                VideoArea(vm, Modifier.weight(1f).fillMaxWidth())
                NowPlayingBar(vm)
            }
        }
    } else {
        Column(keys) {
            VideoArea(vm, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
            NowPlayingBar(vm)
            ChannelList(vm, Modifier.weight(1f).fillMaxWidth())
        }
    }
}

@Composable
private fun VideoArea(vm: LiveViewModel, modifier: Modifier) {
    Box(modifier.background(Color.Black), contentAlignment = Alignment.Center) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c -> PlayerView(c).apply { player = vm.player; useController = false } },
        )
        vm.error?.let { Text(it, modifier = Modifier.padding(16.dp)) }
    }
}

@Composable
private fun ChannelList(vm: LiveViewModel, modifier: Modifier) {
    LazyColumn(modifier.padding(horizontal = 8.dp)) {
        item {
            ListRow(
                title = "Group: ${vm.groupName}",
                subtitle = "Select to switch group · long-press a channel to favorite it",
                onClick = { vm.cycleGroup() },
            )
        }
        items(vm.visibleChannels) { ch ->
            val (now, _) = vm.nowNext(ch)
            ListRow(
                title = (if (ch.key in vm.favorites) "★ " else "") + ch.name,
                subtitle = now?.title ?: ch.group,
                selected = ch.url == vm.current?.url,
                onClick = { vm.play(ch) },
                onLongClick = { vm.toggleFavorite(ch) },
            )
        }
    }
}

@Composable
private fun NowPlayingBar(vm: LiveViewModel) {
    val ctx = LocalContext.current
    val cur = vm.current ?: return
    val (now, next) = vm.nowNext(cur)
    val recording = cur.url in Recorder.active
    // Recording copies the raw stream, which only works for plain TS URLs, not HLS playlists.
    val canRecord = !cur.url.substringBefore('?').endsWith(".m3u8")

    Column(Modifier.fillMaxWidth().padding(12.dp)) {
        Text(cur.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        now?.let { Text("Now: ${it.title}", maxLines = 1, overflow = TextOverflow.Ellipsis) }
        next?.let { Text("Next: ${it.title}", maxLines = 1, overflow = TextOverflow.Ellipsis) }

        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { vm.toggleFavorite(cur) },
                modifier = Modifier.focusRing(ButtonShape),
            ) { Text(if (cur.key in vm.favorites) "★ Favorite" else "☆ Favorite") }

            Button(
                enabled = recording || canRecord,
                onClick = {
                    if (recording) {
                        Recorder.stop(ctx, cur.url)
                    } else {
                        // Record to the end of the current programme (+2 min), or 1 hour if unknown.
                        val end = now?.end ?: (System.currentTimeMillis() + LiveViewModel.HOUR)
                        Recorder.start(ctx, cur.url, cur.name, end + 120_000L)
                    }
                },
                modifier = Modifier.focusRing(ButtonShape),
            ) {
                Text(
                    when {
                        recording -> "■ Stop recording"
                        canRecord -> "● Record"
                        else -> "Can't record HLS"
                    }
                )
            }
        }
    }
}
