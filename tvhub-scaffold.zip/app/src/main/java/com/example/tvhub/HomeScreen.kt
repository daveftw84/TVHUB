package com.example.tvhub

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/**
 * The app's Home tab: Continue Watching (Trakt when signed in, otherwise Plex), recently watched
 * Live TV channels, recently played games, what's trending today, and your Trakt recommendations.
 */
@Composable
fun HomeScreen(
    live: LiveViewModel,
    plex: PlexViewModel,
    games: GamesViewModel,
    onWatchChannel: (Channel) -> Unit,
    onPlayPlex: (PlexItem) -> Unit,
    onOpenPlex: (PlexItem) -> Unit,
    onOpenGame: (Game) -> Unit,
) {
    val tv = rememberIsTv()
    var info by remember { mutableStateOf<HubTitle?>(null) }

    // Reload when Home is shown, when Plex comes online, and after signing in or out of Trakt.
    LaunchedEffect(plex.server, TraktAccount.signedIn) { plex.loadHub() }

    val posterW: Dp = if (tv) 130.dp else 110.dp
    val onTitle: (HubTitle) -> Unit = { t ->
        val item = t.item
        when {
            item == null -> info = t
            t.resume -> onPlayPlex(item)
            else -> onOpenPlex(item)
        }
    }

    val recentGames = games.recentGames
    val channels = live.recentChannels
    val nothing = plex.hubContinue.isEmpty() && channels.isEmpty() && recentGames.isEmpty() &&
        plex.hubTrendingMovies.isEmpty() && plex.hubTrendingShows.isEmpty()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Home", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
                if (plex.hubLoading) {
                    Text("Updating…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        if (plex.hubContinue.isNotEmpty()) item {
            HubRow("Continue Watching", "from ${plex.hubContinueFrom}") {
                items(plex.hubContinue) { t ->
                    PosterCard(t, posterW) { onTitle(t) }
                }
            }
        }

        if (channels.isNotEmpty()) item {
            HubRow("Recently Watched Live TV") {
                items(channels, key = { "ch:" + it.key }) { ch ->
                    ChannelCard(ch, live.nowNext(ch).first?.title, tv) { onWatchChannel(ch) }
                }
            }
        }

        if (recentGames.isNotEmpty()) item {
            HubRow("Recently Played Games") {
                items(recentGames, key = { "g:" + it.game.key }) { r ->
                    GameCard(r, games.consoleName(r.game.console), posterW) { onOpenGame(r.game) }
                }
            }
        }

        hubTitles("Trending Today · Movies", plex.hubTrendingMovies, posterW, onTitle)
        hubTitles("Trending Today · Shows", plex.hubTrendingShows, posterW, onTitle)
        hubTitles("Recommended Movies for You", plex.hubRecMovies, posterW, onTitle, "from Trakt")
        hubTitles("Recommended Shows for You", plex.hubRecShows, posterW, onTitle, "from Trakt")

        if (nothing && !plex.hubLoading) item {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Nothing here yet", style = MaterialTheme.typography.titleLarge)
                Text("• Add a playlist or Xtream Codes login in Settings to watch Live TV.")
                Text("• Sign in to Plex on the Library tab for Continue Watching.")
                Text("• Connect your RomM server on the Games tab.")
                Text("• Sign in to Trakt in Settings for your recommendations.")
            }
        }
    }

    info?.let { t -> TitleInfoDialog(t) { info = null } }
}

private fun androidx.compose.foundation.lazy.LazyListScope.hubTitles(
    title: String,
    list: List<HubTitle>,
    posterW: Dp,
    onTitle: (HubTitle) -> Unit,
    note: String? = null,
) {
    if (list.isEmpty()) return
    item {
        HubRow(title, note) {
            items(list) { t -> PosterCard(t, posterW) { onTitle(t) } }
        }
    }
}

@Composable
private fun HubRow(
    title: String,
    note: String? = null,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit,
) {
    Column {
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.Bottom) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (note != null) {
                Text(
                    "  $note",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            content = content,
        )
    }
}

private val CardShape = RoundedCornerShape(8.dp)

@Composable
private fun PosterCard(t: HubTitle, width: Dp, onClick: () -> Unit) {
    Column(Modifier.width(width)) {
        Box(
            Modifier
                .width(width)
                .height(width * 1.5f)
                .focusRing(CardShape, 1.06f)
                .clip(CardShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Text(t.title, textAlign = TextAlign.Center, maxLines = 4, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(6.dp))
            if (t.poster != null) {
                AsyncImage(model = t.poster, contentDescription = t.title, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize())
            }
            if (t.item != null && !t.resume) {
                Text(
                    "✓",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)
                        .clip(RoundedCornerShape(50)).background(Color(0xCC1B5E20)).padding(horizontal = 6.dp, vertical = 1.dp),
                )
            }
            if (t.progress > 0f) {
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(4.dp).background(Color(0x88000000))) {
                    Box(Modifier.fillMaxWidth(t.progress).fillMaxHeight().background(MaterialTheme.colorScheme.primary))
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        if (t.subtitle.isNotEmpty()) {
            Text(t.subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ChannelCard(ch: Channel, now: String?, tv: Boolean, onClick: () -> Unit) {
    val w = if (tv) 200.dp else 160.dp
    Column(Modifier.width(w)) {
        Box(
            Modifier
                .width(w)
                .height(w * 9 / 16)
                .focusRing(CardShape, 1.06f)
                .clip(CardShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Text(ch.name, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(8.dp))
            if (ch.logo != null) {
                AsyncImage(model = ch.logo, contentDescription = ch.name, contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant).padding(14.dp))
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        Text(now ?: ch.group, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun GameCard(r: GamesViewModel.RecentGame, console: String, width: Dp, onClick: () -> Unit) {
    Column(Modifier.width(width)) {
        Box(
            Modifier
                .width(width)
                .height(width * 1.35f)
                .focusRing(CardShape, 1.06f)
                .clip(CardShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Text(r.game.title, textAlign = TextAlign.Center, maxLines = 4, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(6.dp))
            if (r.game.art != null) {
                AsyncImage(model = r.game.art, contentDescription = r.game.title, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(r.game.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        Text("$console · ${ago(r.playedAt)}", maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun ago(ms: Long): String {
    val min = (System.currentTimeMillis() - ms) / 60_000
    return when {
        ms <= 0 -> ""
        min < 1 -> "just now"
        min < 60 -> "${min}m ago"
        min < 24 * 60 -> "${min / 60}h ago"
        min < 14 * 24 * 60 -> "${min / (24 * 60)}d ago"
        else -> java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT).format(java.util.Date(ms))
    }
}

/** For titles that aren't in your Plex library: poster, year and overview. */
@Composable
private fun TitleInfoDialog(t: HubTitle, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(t.title) },
        text = {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (t.poster != null) {
                    AsyncImage(model = t.poster, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.size(100.dp, 150.dp).clip(CardShape))
                }
                Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState())) {
                    if (t.subtitle.isNotEmpty()) Text(t.subtitle, style = MaterialTheme.typography.bodySmall)
                    Text("Not in your Plex library.", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Text(t.overview ?: "No description.")
                }
            }
        },
        confirmButton = {
            Button(onClick = onClose, modifier = Modifier.focusRing(ButtonShape)) { Text("Close") }
        },
        dismissButton = {},
    )
}
