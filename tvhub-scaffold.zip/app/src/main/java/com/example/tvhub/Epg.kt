package com.example.tvhub

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.zip.GZIPInputStream

data class Programme(
    val channelId: String,
    val title: String,
    val desc: String,
    val start: Long,
    val end: Long,
)

object XmltvParser {
    /** Downloads an XMLTV guide (plain or .gz) and keeps only wanted channels within [from, to]. */
    fun fetch(url: String, wantedIds: Set<String>, from: Long, to: Long): Map<String, List<Programme>> {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 60_000
        conn.setRequestProperty("User-Agent", USER_AGENT)
        if (conn.responseCode !in 200..299) throw IOException("Guide returned HTTP ${conn.responseCode}")
        var stream: InputStream = conn.inputStream
        if (url.substringBefore('?').endsWith(".gz")) stream = GZIPInputStream(stream)
        return stream.use { parse(it, wantedIds, from, to) }
    }

    fun parse(stream: InputStream, wantedIds: Set<String>, from: Long, to: Long): Map<String, List<Programme>> {
        val fmt = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)
        fun time(s: String?): Long {
            if (s == null) return 0L
            val t = s.trim()
            return try {
                fmt.parse(if (t.contains(' ')) t else "$t +0000")?.time ?: 0L
            } catch (e: Exception) {
                0L
            }
        }

        val out = mutableMapOf<String, MutableList<Programme>>()
        val p = Xml.newPullParser()
        p.setInput(stream, null)

        var ch: String? = null
        var start = 0L
        var stop = 0L
        var title = ""
        var desc = ""
        var inProg = false

        var event = p.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (p.name) {
                    "programme" -> {
                        inProg = true
                        ch = p.getAttributeValue(null, "channel")
                        start = time(p.getAttributeValue(null, "start"))
                        stop = time(p.getAttributeValue(null, "stop"))
                        title = ""
                        desc = ""
                    }
                    "title" -> if (inProg && title.isEmpty()) title = p.nextText()
                    "desc" -> if (inProg && desc.isEmpty()) desc = p.nextText()
                }
            } else if (event == XmlPullParser.END_TAG && p.name == "programme") {
                inProg = false
                val id = ch
                if (id != null && id in wantedIds && stop > from && start < to) {
                    out.getOrPut(id) { mutableListOf() }.add(Programme(id, title, desc, start, stop))
                }
            }
            event = p.next()
        }
        return out.mapValues { (_, v) -> v.sortedBy { it.start } }
    }
}
