# TV Hub games data

Games come from your RomM server. These files only decide how games are started.
Edit them here and rebuild, or put copies on your own server, set "Data folder URL" in
Games > Settings and press "Update from server".

- consoles.json  One entry per console: id, name, maker, year, description, file types (exts),
                 aliases (RomM folder names / slugs that mean this console, letters and digits only),
                 default launcher id, RetroArch core, post_process ("none" or "unzip"),
                 builtin (core for the built-in player, e.g. "snes9x"; empty = none).
                 Built-in cores: fceumm snes9x genesis_plus_gx gambatte mgba mupen64plus_next_gles3
                 pcsx_rearmed melonds stella handy mednafen_pce_fast fbneo mame2003_plus
                 A RomM platform uses the entry whose id or aliases match its slug or folder name.
- launchers.json How each emulator is started. "builtin" is the player inside this app. Placeholders: {rom} game path, {rom_uri} a content address the emulator may read, {rom_file} file:// address, {core} RetroArch core
                 path, {core_dir}, {core_stem}, {cfg} RetroArch config path. "packages" lists the app
                 package names to try; the first installed one is used. Converted from IAGL's Android
                 launch commands.
- saves.json     Where emulator apps keep save files, for save sync: launcher id, folders under the
                 phone's main storage, and save file types. The save is named after the game file.
                 A folder picked in Games > Settings overrides these. "kind": "psp" syncs PSP SAVEDATA
                 folders (named after the game's serial) as one zip. "bios_paths": where the
                 emulator looks for BIOS files; RomM's BIOS files for the console are copied there.
- settings.json  download_folder (inside Downloads), remote_data_url.
