package com.example.tvhub

import android.content.Context
import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONObject

/**
 * Button Mapper: remote-control buttons to app actions, game-controller buttons to game buttons
 * (and hotkeys), and the on-screen touch controls.
 */
object Buttons {
    /** What a remote button can do anywhere in the app. */
    enum class Action(val label: String) {
        HOME("Go to Home"), LIVE("Go to Live TV"), GUIDE("Go to the Guide"), LIBRARY("Go to Library (Plex)"),
        YOUTUBE("Go to YouTube"), MUSIC("Go to Music"), GAMES("Go to Games"), SETTINGS("Go to Settings"),
        SEARCH("Search everything"), LAST_CHANNEL("Last channel"), CHANNEL_UP("Channel up"), CHANNEL_DOWN("Channel down"),
        FAVORITE("Favorite this channel"), FAVORITES("Show favorite channels"), ADD_CORNER("Add a corner window"),
        LAYOUT("Change the corner layout"), CORNER_SOUND("Move the sound to the next window"), CLOSE_CORNERS("Close corner windows"),
        MUSIC_PLAY_PAUSE("Music: play / pause"), MUSIC_NEXT("Music: next song"), MINI_PLAYER("Live TV mini player on / off"),
        FLOAT("Float over other apps (picture-in-picture)"),
    }

    /** What a controller button does in games: a game button, or a hotkey. */
    enum class GameTarget(val label: String, val retroKey: Int) {
        A("A", KeyEvent.KEYCODE_BUTTON_A), B("B", KeyEvent.KEYCODE_BUTTON_B), X("X", KeyEvent.KEYCODE_BUTTON_X),
        Y("Y", KeyEvent.KEYCODE_BUTTON_Y), L1("L", KeyEvent.KEYCODE_BUTTON_L1), R1("R", KeyEvent.KEYCODE_BUTTON_R1),
        L2("L2", KeyEvent.KEYCODE_BUTTON_L2), R2("R2", KeyEvent.KEYCODE_BUTTON_R2), L3("L3 (left stick press)", KeyEvent.KEYCODE_BUTTON_THUMBL),
        R3("R3 (right stick press)", KeyEvent.KEYCODE_BUTTON_THUMBR), START("Start", KeyEvent.KEYCODE_BUTTON_START),
        SELECT("Select", KeyEvent.KEYCODE_BUTTON_SELECT), UP("D-pad up", KeyEvent.KEYCODE_DPAD_UP), DOWN("D-pad down", KeyEvent.KEYCODE_DPAD_DOWN),
        LEFT("D-pad left", KeyEvent.KEYCODE_DPAD_LEFT), RIGHT("D-pad right", KeyEvent.KEYCODE_DPAD_RIGHT),
        MENU("Hotkey: game menu", -1), FAST("Hotkey: fast-forward on / off", -2), SAVE("Hotkey: save state", -3), LOAD("Hotkey: load state", -4),
    }

    /** Keys that can't be mapped: they're needed to move around the app. */
    private val RESERVED = setOf(KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BACK,
        KeyEvent.KEYCODE_HOME, KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B)

    fun canMapRemote(code: Int) = code !in RESERVED

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)

    private fun readMap(ctx: Context, key: String): Map<Int, String> = try {
        val o = JSONObject(prefs(ctx).getString(key, "{}") ?: "{}")
        o.keys().asSequence().associate { it.toInt() to o.getString(it) }
    } catch (_: Exception) { emptyMap() }

    private fun writeMap(ctx: Context, key: String, map: Map<Int, String>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k.toString(), v) }
        prefs(ctx).edit().putString(key, o.toString()).apply()
    }

    // --- Remote ---

    var remote by mutableStateOf<Map<Int, Action>>(emptyMap())
        private set

    fun load(ctx: Context) {
        remote = readMap(ctx, "remote_map").mapNotNull { (k, v) -> runCatching { k to Action.valueOf(v) }.getOrNull() }.toMap()
        game = readMap(ctx, "pad_map").mapNotNull { (k, v) -> runCatching { k to GameTarget.valueOf(v) }.getOrNull() }.toMap()
    }

    fun mapRemote(ctx: Context, code: Int, action: Action?) {
        remote = if (action == null) remote - code else remote + (code to action)
        writeMap(ctx, "remote_map", remote.mapValues { it.value.name })
    }

    /** The action a remote button press was mapped to; the app carries it out. */
    var pending by mutableStateOf<Pair<Action, Long>?>(null)
        private set

    /** Called for every key the app gets. Returns true when the key was mapped (and is used up). */
    fun onRemoteKey(event: KeyEvent): Boolean {
        if (capturing) return false
        val action = remote[event.keyCode] ?: return false
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) pending = action to System.nanoTime()
        return true
    }

    fun done() { pending = null }

    /** True while Settings is waiting for "press a button", so the press isn't used as an action. */
    var capturing = false

    /** Set by the Search action; Home opens its search and clears it. */
    var searchRequested by mutableStateOf(false)

    // --- Game controller ---

    /** Physical button -> what it does in games. */
    var game by mutableStateOf<Map<Int, GameTarget>>(emptyMap())
        private set

    fun mapGame(ctx: Context, code: Int, target: GameTarget?) {
        // One physical button per target: setting a target again moves it.
        game = (if (target == null) game - code else game.filterValues { it != target } + (code to target))
        writeMap(ctx, "pad_map", game.mapValues { it.value.name })
    }

    fun resetGame(ctx: Context) { game = emptyMap(); writeMap(ctx, "pad_map", emptyMap()) }

    fun keyName(code: Int): String = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_").replace('_', ' ').lowercase()
        .replaceFirstChar { it.uppercase() }

    // --- On-screen controls ---

    fun touchScale(ctx: Context) = prefs(ctx).getFloat("touch_scale", 1f)
    fun touchOpacity(ctx: Context) = prefs(ctx).getFloat("touch_opacity", 0.55f)
    /** "auto" (only when no controller is connected), "always" or "never". */
    fun touchMode(ctx: Context) = prefs(ctx).getString("touch_mode", "auto") ?: "auto"
    /** true = A on the right like Nintendo; false = A on the bottom like Xbox. */
    fun touchNintendo(ctx: Context) = prefs(ctx).getBoolean("touch_nintendo", true)
    fun setTouch(ctx: Context, scale: Float? = null, opacity: Float? = null, mode: String? = null, nintendo: Boolean? = null) {
        prefs(ctx).edit().apply {
            scale?.let { putFloat("touch_scale", it) }
            opacity?.let { putFloat("touch_opacity", it) }
            mode?.let { putString("touch_mode", it) }
            nintendo?.let { putBoolean("touch_nintendo", it) }
        }.apply()
    }
}

/** "Press a button": captures the next key press (Back cancels). */
@Composable
fun KeyCaptureDialog(title: String, onKey: (Int) -> Unit, onCancel: () -> Unit) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Throwable) {} }
    DisposableEffect(Unit) {
        Buttons.capturing = true
        onDispose { Buttons.capturing = false }
    }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = {
            Box(
                Modifier.fillMaxWidth().height(90.dp).clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .focusRequester(focus)
                    .onPreviewKeyEvent { e ->
                        if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent true
                        val code = e.nativeKeyEvent.keyCode
                        if (code == KeyEvent.KEYCODE_BACK) onCancel() else onKey(code)
                        true
                    }
                    .focusable(),
                contentAlignment = Alignment.Center,
            ) { Text("Press the button now… (Back to cancel)") }
        },
        confirmButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}

/** Settings > Button Mapper. */
@Composable
fun ButtonMapperSection() {
    val ctx = LocalContext.current
    remember { Buttons.load(ctx); true }
    var capture by remember { mutableStateOf<String?>(null) }          // "remote" or a GameTarget name
    var pickAction by remember { mutableStateOf<Int?>(null) }          // remote key waiting for an action
    var note by remember { mutableStateOf<String?>(null) }

    Spacer(Modifier.height(8.dp))
    Text("Button Mapper", style = MaterialTheme.typography.titleMedium)

    // Remote control
    Text("Remote control: give any spare button (colour buttons, numbers, app buttons...) an action.", style = MaterialTheme.typography.bodySmall)
    Buttons.remote.forEach { (code, action) ->
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${Buttons.keyName(code)} → ${action.label}", modifier = Modifier.weight(1f))
            TextButton(onClick = { Buttons.mapRemote(ctx, code, null) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Remove") }
        }
    }
    Button(onClick = { capture = "remote" }, modifier = Modifier.focusRing(ButtonShape)) { Text("+ Map a remote button") }

    // Game controller
    Spacer(Modifier.height(8.dp))
    Text("Game controller: choose which button does what in games (built-in player), and hotkeys.", style = MaterialTheme.typography.bodySmall)
    Buttons.GameTarget.values().toList().chunked(2).forEach { pair ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            pair.forEach { t ->
                val bound = Buttons.game.entries.firstOrNull { it.value == t }?.key
                Button(onClick = { capture = t.name }, modifier = Modifier.weight(1f).focusRing(ButtonShape)) {
                    Text("${t.label}: " + (bound?.let { Buttons.keyName(it) } ?: "default"), maxLines = 1)
                }
            }
        }
    }
    TextButton(onClick = { Buttons.resetGame(ctx) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Reset controller buttons") }

    // On-screen controls
    Spacer(Modifier.height(8.dp))
    Text("On-screen controls (touch screens)", style = MaterialTheme.typography.bodySmall)
    var mode by remember { mutableStateOf(Buttons.touchMode(ctx)) }
    var scale by remember { mutableStateOf(Buttons.touchScale(ctx)) }
    var opacity by remember { mutableStateOf(Buttons.touchOpacity(ctx)) }
    var nintendo by remember { mutableStateOf(Buttons.touchNintendo(ctx)) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            mode = when (mode) { "auto" -> "always"; "always" -> "never"; else -> "auto" }
            Buttons.setTouch(ctx, mode = mode)
        }, modifier = Modifier.focusRing(ButtonShape)) {
            Text("Show: " + when (mode) { "always" -> "always"; "never" -> "never"; else -> "when no controller" })
        }
        Button(onClick = {
            val sizes = listOf(0.75f, 1f, 1.25f, 1.5f)
            scale = sizes[(sizes.indexOf(scale) + 1).mod(sizes.size)]
            Buttons.setTouch(ctx, scale = scale)
        }, modifier = Modifier.focusRing(ButtonShape)) { Text("Size: ${(scale * 100).toInt()}%") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            val ops = listOf(0.3f, 0.55f, 0.8f)
            opacity = ops[(ops.indexOf(opacity) + 1).mod(ops.size)]
            Buttons.setTouch(ctx, opacity = opacity)
        }, modifier = Modifier.focusRing(ButtonShape)) { Text("See-through: ${100 - (opacity * 100).toInt()}%") }
        Button(onClick = { nintendo = !nintendo; Buttons.setTouch(ctx, nintendo = nintendo) }, modifier = Modifier.focusRing(ButtonShape)) {
            Text(if (nintendo) "Layout: Nintendo (A right)" else "Layout: Xbox (A bottom)")
        }
    }
    note?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }

    capture?.let { what ->
        KeyCaptureDialog(
            title = if (what == "remote") "Press the remote button to map" else "Press the controller button for ${Buttons.GameTarget.valueOf(what).label}",
            onKey = { code ->
                capture = null
                if (what == "remote") {
                    if (Buttons.canMapRemote(code)) pickAction = code
                    else note = "${Buttons.keyName(code)} is needed to move around the app, so it can't be mapped."
                } else {
                    Buttons.mapGame(ctx, code, Buttons.GameTarget.valueOf(what))
                }
            },
            onCancel = { capture = null },
        )
    }
    pickAction?.let { code ->
        AlertDialog(
            onDismissRequest = { pickAction = null },
            title = { Text("${Buttons.keyName(code)} does…") },
            text = {
                androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(Buttons.Action.values().size) { i ->
                        val a = Buttons.Action.values()[i]
                        ListRow(title = a.label, onClick = { Buttons.mapRemote(ctx, code, a); pickAction = null })
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickAction = null }) { Text("Cancel") } },
        )
    }
}
