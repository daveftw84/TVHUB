package com.example.tvhub

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.Locale

// ---------------------------------------------------------------- Floating navigation bar (phones)

data class NavItem(val label: String, val icon: ImageVector, val selected: Boolean, val onClick: () -> Unit)

/** A rounded bar floating above the bottom of the screen; the selected item gets a pill and its label. */
@Composable
fun FloatingNavBar(items: List<NavItem>, modifier: Modifier = Modifier) {
    Row(
        modifier.padding(horizontal = 20.dp, vertical = 10.dp).fillMaxWidth().height(68.dp)
            .clip(RoundedCornerShape(34.dp)).background(Color(0xFF26272B))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(34.dp)).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items.forEach { it ->
            val color = if (it.selected) Color(0xFF4D8DFF) else Color(0xFFDDDDDD)
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).clickable(onClick = it.onClick).padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(Modifier.clip(RoundedCornerShape(20.dp)).background(if (it.selected) Color(0xFF3A3B40) else Color.Transparent)
                    .padding(horizontal = 18.dp, vertical = 4.dp)) {
                    Icon(it.icon, contentDescription = it.label, tint = color)
                }
                if (it.selected) Text(it.label, color = color, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
        }
    }
}

/** "More" on phones: the sections that don't fit in the bar. */
@Composable
fun MoreSheet(items: List<Pair<String, () -> Unit>>, onClose: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onClose) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 32.dp)) {
            SheetGroup { items.forEach { (label, go) -> SheetItem("›", label) { onClose(); go() } } }
        }
    }
}

// ---------------------------------------------------------------- Live TV list (phones)

/**
 * Live TV on a phone: a list of channel cards (logo, name, what's on and how far along), group chips
 * and a full groups list, search, A-Z, and a long-press menu. Picking a channel opens the player.
 */
@Composable
fun MobileLiveScreen(vm: LiveViewModel, onOpenPlayer: () -> Unit) {
    val ctx = LocalContext.current
    var groups by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(vm.searchRequest != null) }
    var menuFor by remember { mutableStateOf<Channel?>(null) }
    LaunchedEffect(vm.searchRequest) { if (vm.searchRequest != null) searching = true }
    DisposableEffect(Unit) {
        vm.listMode = true
        onDispose { vm.listMode = false }
    }

    if (searching) {
        BackHandler { searching = false; vm.searchRequest = null }
        MobileLiveSearch(vm, vm.searchRequest.orEmpty(), onPick = { ch -> vm.searchRequest = null; searching = false; vm.play(ch); onOpenPlayer() },
            onClose = { searching = false; vm.searchRequest = null })
        return
    }
    if (groups) {
        BackHandler { groups = false }
        GroupsList(vm) { groups = false }
        return
    }

    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val list = if (vm.sortAz) vm.visibleChannels.sortedBy { vm.nameOf(it).lowercase() } else vm.visibleChannels
    Column(Modifier.fillMaxSize()) {
        // Header: group (opens the list of groups), search, A-Z.
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Live TV", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                // More than one playlist: tap to switch.
                if (Playlists.all.size > 1) {
                    var pick by remember { mutableStateOf(false) }
                    Text((Playlists.active?.name ?: "Playlist") + "  ⌄", style = MaterialTheme.typography.labelMedium, color = Color(0xFF7FA6FF),
                        modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable { pick = true }.padding(vertical = 2.dp))
                    androidx.compose.material3.DropdownMenu(expanded = pick, onDismissRequest = { pick = false }) {
                        Playlists.all.forEach { p ->
                            androidx.compose.material3.DropdownMenuItem(text = { Text(p.name + if (p.id == Playlists.active?.id) "  ✓" else "") },
                                onClick = { pick = false; vm.usePlaylist(p.id) })
                        }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.clip(RoundedCornerShape(8.dp)).clickable { groups = true }.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(vm.groupName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 150.dp))
                Text("  ⌄", style = MaterialTheme.typography.titleMedium)
            }
            Text("🔍", style = MaterialTheme.typography.titleLarge, modifier = Modifier.clip(RoundedCornerShape(50)).clickable { searching = true }.padding(8.dp))
            Text(if (vm.sortAz) "A↓Z" else "A Z", style = MaterialTheme.typography.labelLarge,
                color = if (vm.sortAz) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.clip(RoundedCornerShape(50)).clickable { vm.sortAz = !vm.sortAz }.padding(8.dp))
        }
        // Group chips: Favorites, Recently Watched, then your groups.
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { PillChip("Favorites", vm.groupName == "Favorites") { vm.selectGroup(vm.groups.indexOf("Favorites")) } }
            item { PillChip("Recently Watched", vm.recentOnly) { vm.recentOnly = !vm.recentOnly } }
            items(vm.groups.filter { it != "Favorites" && it != "All" }) { g -> PillChip(g, vm.groupName == g && !vm.recentOnly) { vm.recentOnly = false; vm.selectGroup(vm.groups.indexOf(g)) } }
            item { PillChip("All", vm.groupName == "All" && !vm.recentOnly) { vm.recentOnly = false; vm.selectGroup(0) } }
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.surfaceVariant))
        val shown = if (vm.recentOnly) vm.recentChannels else list
        val state = rememberLazyListState()
        LazyColumn(state = state, contentPadding = PaddingValues(start = 10.dp, end = 10.dp, top = 10.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (shown.isEmpty()) item {
                Text(vm.error ?: "No channels here.", modifier = Modifier.padding(16.dp))
            }
            items(shown) { ch ->
                ChannelCard(vm, ch, timeFmt, onClick = { vm.play(ch); onOpenPlayer() }, onLongClick = { menuFor = ch })
            }
        }
    }
    menuFor?.let { ch -> ChannelMenu(vm, ch, onClose = { menuFor = null }, onPlay = { vm.play(ch); onOpenPlayer() }, onOpenOnly = onOpenPlayer) }
}

@Composable
private fun ChannelCard(vm: LiveViewModel, ch: Channel, timeFmt: SimpleDateFormat, onClick: () -> Unit, onLongClick: () -> Unit) {
    val (now, _) = vm.nowNext(ch)
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xFF202124))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(width = 76.dp, height = 52.dp), contentAlignment = Alignment.Center) {
            if (ch.logo != null) {
                AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            } else {
                // No logo: a TV icon, like the screenshot.
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("⌄", color = Color.White, style = MaterialTheme.typography.labelSmall)
                    Text(" TV ", color = Color.Black, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color.White).padding(horizontal = 6.dp))
                }
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text((if (ch.key in vm.favorites) "♥ " else "") + vm.nameOf(ch), style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row {
                if (now != null) {
                    Text(timeFmt.format(java.util.Date(now.start)), color = Color(0xFFAAAAAA), style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.width(14.dp))
                }
                Text(now?.title ?: "No Information", color = Color(0xFFAAAAAA), style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(8.dp))
            val progress = now?.let { ((System.currentTimeMillis() - it.start).toFloat() / (it.end - it.start)).coerceIn(0f, 1f) } ?: 0f
            Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF0E0E10))) {
                Box(Modifier.fillMaxWidth(progress).fillMaxHeight().clip(RoundedCornerShape(3.dp)).background(Color(0xFF3D7BFF)))
            }
        }
    }
}

/** Long-press menu: favorite, picture-in-picture, record, external player, hide, rename, and the group's settings. */
@Composable
private fun ChannelMenu(vm: LiveViewModel, ch: Channel, onClose: () -> Unit, onPlay: () -> Unit, onOpenOnly: () -> Unit) {
    val ctx = LocalContext.current
    var renaming by remember { mutableStateOf(false) }
    var groupEdit by remember { mutableStateOf<String?>(null) }   // "fav" or "hide"
    val now = vm.nowNext(ch).first
    ModalBottomSheet(onDismissRequest = onClose) {
        LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF333438)), contentAlignment = Alignment.Center) {
                        ch.logo?.let { AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.padding(4.dp)) }
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(vm.nameOf(ch), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("✕", style = MaterialTheme.typography.titleLarge, modifier = Modifier.clickable(onClick = onClose).padding(8.dp))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    BigTile(if (ch.key in vm.favorites) "♥" else "♡", if (ch.key in vm.favorites) "Remove from favorites" else "Add to favorites",
                        Modifier.weight(1f)) { vm.toggleFavorite(ch); onClose() }
                    BigTile("⧉", "Play in PiP mode", Modifier.weight(1f)) {
                        // Picture-in-picture: this channel in a corner window over the channel that's playing.
                        onClose()
                        if (vm.current == null || vm.current?.url == ch.url) onPlay()
                        else {
                            Corners.addChannel(ctx, ch)?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() }
                            onOpenOnly()
                        }
                    }
                }
            }
            item {
                SheetGroup {
                    val canRecord = !ch.url.substringBefore('?').endsWith(".m3u8")
                    if (canRecord) SheetItem("⏺", if (now != null) "Record \"${now.title}\"" else "Record (1 hour)") {
                        val end = now?.end ?: (System.currentTimeMillis() + LiveViewModel.HOUR)
                        Recorder.start(ctx, ch.url, vm.nameOf(ch), end + Opt.int(Opt.REC_END, 2) * 60_000L)
                        Toast.makeText(ctx, "Recording…", Toast.LENGTH_SHORT).show()
                        onClose()
                    }
                    SheetItem("▶", "Play in external player") {
                        try {
                            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(ch.url), "video/*")
                                .putExtra("title", vm.nameOf(ch)), "Play with"))
                        } catch (_: Exception) {}
                        onClose()
                    }
                    SheetItem("🚫", "Hide channel") { vm.toggleChannelHidden(ch); onClose() }
                    SheetItem("✏️", "Edit name") { renaming = true }
                }
            }
            item {
                Text(ch.group.uppercase(), style = MaterialTheme.typography.labelLarge, color = Color(0xFFAAAAAA), modifier = Modifier.padding(start = 8.dp))
                Spacer(Modifier.height(8.dp))
                SheetGroup {
                    SheetItem("♡", "Customize group favorites") { groupEdit = "fav" }
                    SheetItem("🚫", "Customize group hidden channels") { groupEdit = "hide" }
                }
            }
        }
    }
    if (renaming) {
        var text by remember { mutableStateOf(vm.nameOf(ch)) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Edit name") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.rename(ch, text); renaming = false; onClose() }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { vm.rename(ch, ch.name); renaming = false; onClose() }) { Text("Reset") } },
        )
    }
    groupEdit?.let { mode ->
        AlertDialog(
            onDismissRequest = { groupEdit = null },
            title = { Text(if (mode == "fav") "Favorites in ${ch.group}" else "Hidden channels in ${ch.group}") },
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(vm.groupChannels(ch.group)) { c ->
                        val on = if (mode == "fav") c.key in vm.favorites else c.key in vm.hiddenChannels
                        Row(Modifier.fillMaxWidth().clickable { if (mode == "fav") vm.toggleFavorite(c) else vm.toggleChannelHidden(c) }
                            .padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (on) "☑" else "☐", modifier = Modifier.width(32.dp))
                            Text(vm.nameOf(c), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { groupEdit = null }) { Text("Done") } },
        )
    }
}

@Composable
private fun BigTile(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.height(120.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
        .clickable(onClick = onClick).padding(18.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Text(icon, style = MaterialTheme.typography.headlineSmall, color = Color(0xFFE5394A))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

/** Every group, as a full-screen list (the "Groups" drawer). */
@Composable
private fun GroupsList(vm: LiveViewModel, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Text("Groups", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(20.dp))
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vm.groups) { g ->
                val sel = g == vm.groupName && !vm.recentOnly
                Text(g, color = if (sel) Color(0xFFE5394A) else Color.White, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(if (sel) Color.White else Color(0xFF202124))
                        .clickable { vm.recentOnly = false; vm.selectGroup(vm.groups.indexOf(g)); onClose() }.padding(horizontal = 20.dp, vertical = 14.dp))
            }
        }
    }
}

/** Search on Live TV (phones): channels and programmes; picking one plays it. */
@Composable
private fun MobileLiveSearch(vm: LiveViewModel, initial: String, onPick: (Channel) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { AppPrefs(ctx) }
    var q by remember { mutableStateOf(initial) }
    var recents by remember { mutableStateOf(prefs.recentSearches("live")) }
    val (chans, progs) = remember(q, vm.channels, vm.epg) { vm.searchLive(q) }
    val fmt = remember { SimpleDateFormat("EEE h:mm a", Locale.getDefault()) }
    val focus = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(Unit) { if (initial.isEmpty()) try { focus.requestFocus() } catch (_: Throwable) {} }
    fun pick(ch: Channel) { prefs.addRecentSearch("live", q); onPick(ch) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 100.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, placeholder = { Text("Search channels and programmes") },
                    modifier = Modifier.weight(1f).focusRequester(focus))
                TextButton(onClick = onClose) { Text("Close") }
            }
        }
        if (q.trim().length < 2 && recents.isNotEmpty()) item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                items(recents) { r -> PillChip(r, false) { q = r } }
                item { PillChip("Clear", false) { prefs.clearRecentSearches("live"); recents = emptyList() } }
            }
        }
        items(chans) { ch -> ListRow(title = vm.nameOf(ch), subtitle = vm.nowNext(ch).first?.title ?: ch.group, onClick = { pick(ch) }) }
        items(progs) { h ->
            val onNow = h.programme.start <= System.currentTimeMillis()
            ListRow(title = h.programme.title, subtitle = (if (onNow) "On now" else fmt.format(java.util.Date(h.programme.start))) + " · " + vm.nameOf(h.channel),
                onClick = { pick(h.channel) })
        }
        if (q.trim().length >= 2 && chans.isEmpty() && progs.isEmpty()) item { Text("Nothing found.", modifier = Modifier.padding(12.dp)) }
    }
}

/** First-launch walk-through: a few pages of tips, Skip any time. */
@Composable
fun Onboarding(tv: Boolean, onDone: () -> Unit) {
    val pages = listOf(
        Triple("📺", "Welcome", "Welcome to TV Hub: Live TV, Plex, Trakt, YouTube, Music, Sports and Games in one app.\n\nThis quick guide shows a few things worth knowing. You can skip it at any moment."),
        Triple("☰", "Groups Access", if (tv) "In Live TV, press Left to open your channel groups, Favorites and Sports." else
            "In Live TV, tap the group name at the top to jump between your playlist groups, Favorites and Sports."),
        Triple("👆", "Long Pressing", "Long press is the way! Long press a channel, group or title for its menu: favorites, hide, rename, record, picture-in-picture and more."),
        Triple("⊞", "MultiView", "Watch up to 9 screens at once. Add a channel, Plex title or game to a corner, then double-tap to swap, swipe up to resize and swipe down to close."),
        Triple("💡", "General Tips", "• Switch playlists by tapping your playlist name at the top of Home or Live TV\n" +
            "• Set reminders for games in the Sports tab\n• Pick past programmes in the Guide to watch them again (catch-up, or from Plex)\n" +
            "• Choose which rows Home shows with the ⚙ next to search"),
    )
    var page by remember { mutableStateOf(0) }
    BackHandler { if (page > 0) page-- else onDone() }
    Box(Modifier.fillMaxSize().background(Color(0xFF141414))) {
        val (icon, title, text) = pages[page]
        Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(40.dp))
            Box(Modifier.size(180.dp).clip(RoundedCornerShape(40.dp)).background(Color(0xFF26272B)), contentAlignment = Alignment.Center) {
                Text(icon, style = MaterialTheme.typography.displayLarge)
            }
            Spacer(Modifier.height(40.dp))
            Text(text, style = MaterialTheme.typography.titleMedium, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
        Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.TextButton(onClick = onDone, modifier = Modifier.focusRing(ButtonShape)) { Text("SKIP", color = Color(0xFFAAAAAA)) }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Center) {
                pages.indices.forEach { i ->
                    Box(Modifier.padding(4.dp).size(10.dp).clip(RoundedCornerShape(50)).background(if (i == page) Color(0xFFE53950) else Color(0xFF552028)))
                }
            }
            androidx.compose.material3.Button(onClick = { if (page < pages.lastIndex) page++ else onDone() }, modifier = Modifier.focusRing(ButtonShape)) {
                Text(if (page < pages.lastIndex) "Next" else "Start")
            }
        }
    }
}
