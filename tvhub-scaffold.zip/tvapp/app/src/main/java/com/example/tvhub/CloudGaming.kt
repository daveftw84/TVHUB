package com.example.tvhub

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Cloud and PC game streaming: Xbox Game Pass (Xbox Cloud Gaming), GeForce NOW and Moonlight.
 * Each opens its own app when installed (they handle sign-in and play); otherwise the app's store
 * page, or the service's web player.
 */
object CloudGaming {
    data class Service(
        val name: String,
        val blurb: String,
        val packages: List<String>,   // first installed one is opened
        val web: String?,             // browser fallback
        val color: Long,
    )

    val services = listOf(
        Service("Xbox Game Pass", "Xbox Cloud Gaming: play Game Pass games streamed from Microsoft",
            listOf("com.gamepass", "com.microsoft.xcloud", "com.microsoft.xboxone.smartglass"), "https://www.xbox.com/play", 0xFF107C10),
        Service("GeForce NOW", "Play your Steam, Epic and other PC games streamed from NVIDIA",
            listOf("com.nvidia.geforcenow"), "https://play.geforcenow.com", 0xFF76B900),
        Service("Moonlight", "Stream games from your own gaming PC (NVIDIA GameStream or Sunshine)",
            listOf("com.limelight", "com.limelight.noir"), null, 0xFF3A4A6B),
    )

    fun installed(ctx: Context, s: Service): String? = s.packages.firstOrNull { pkg ->
        try {
            ctx.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Opens the service. Returns a message when it couldn't be opened. */
    fun open(ctx: Context, s: Service): String? {
        val pm = ctx.packageManager
        installed(ctx, s)?.let { pkg ->
            val launch = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(launch)
                return null
            }
        }
        // Not installed: the store page, then the web player.
        val store = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${s.packages.first()}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(store)
            return "${s.name} isn't installed: opening its store page."
        } catch (_: ActivityNotFoundException) {
        }
        s.web?.let {
            try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return null
            } catch (_: ActivityNotFoundException) {
            }
        }
        return "Install ${s.name} to use it."
    }
}
