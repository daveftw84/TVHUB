package com.example.tvhub

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/**
 * TV Hub profiles (like Plezy's): each has its own settings, favorites, history, Home rows, Trakt account
 * and Plex user, an optional 4-digit PIN, and a Kids mode. Playlists, the game server, VPN and casting are shared.
 *
 * How: every profile's settings live in their own file; switching saves the current one, loads the
 * other into the app's settings, and restarts the app.
 */
object Profiles {
    data class Profile(val id: String, val name: String, val color: Long, val pinHash: String?, val kids: Boolean, val plexUser: String?)

    private const val FILE = "tvhub_profiles"
    private val COLORS = listOf(0xFFE8A0A0, 0xFF7FA6FF, 0xFF8BD17C, 0xFFF2C46D, 0xFFC58BF2, 0xFF6FD6D0)

    /** Settings every profile shares (the rest belong to each profile). */
    private val SHARED = Regex("^(playlists|playlist_active|client_id|romm_.*|vpn_.*|cast_.*|trakt_client_.*|plex_downloads|onboarded|button.*|btn_.*)$")

    var all by mutableStateOf<List<Profile>>(emptyList())
        private set
    var activeId by mutableStateOf("")
        private set
    val active: Profile? get() = all.firstOrNull { it.id == activeId }
    val kids: Boolean get() = active?.kids == true
    /** Picked already this time (after a switch, or "Who's watching?" answered). */
    var chosen = false

    /** Shows "Who's watching?" when the app opens (only with 2+ profiles). */
    var askAtStart: Boolean
        get() = all.size > 1 && store?.getBoolean("ask", true) != false
        set(v) { store?.edit()?.putBoolean("ask", v)?.apply() }

    private var store: android.content.SharedPreferences? = null

    fun load(ctx: Context) {
        val s = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).also { store = it }
        all = try {
            val a = JSONArray(s.getString("list", "[]"))
            (0 until a.length()).map { a.getJSONObject(it) }.map {
                Profile(it.getString("id"), it.optString("name"), it.optLong("color", COLORS[0]), it.optString("pin").ifEmpty { null },
                    it.optBoolean("kids"), it.optString("plexUser").ifEmpty { null })
            }
        } catch (_: Exception) { emptyList() }
        if (all.isEmpty()) {
            // The first profile is everyone's current settings.
            all = listOf(Profile("main", "Me", COLORS[0], null, false, null))
            save()
        }
        activeId = s.getString("active", null)?.takeIf { id -> all.any { it.id == id } } ?: all.first().id
    }

    private fun save() {
        val a = JSONArray()
        all.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("color", it.color).put("pin", it.pinHash ?: "")
                .put("kids", it.kids).put("plexUser", it.plexUser ?: ""))
        }
        store?.edit()?.putString("list", a.toString())?.putString("active", activeId)?.apply()
    }

    fun hash(pin: String): String = MessageDigest.getInstance("SHA-256").digest(("tvhub:$pin").toByteArray()).joinToString("") { "%02x".format(it) }
    fun pinOk(p: Profile, pin: String) = p.pinHash == null || p.pinHash == hash(pin)

    /** Tabs a Kids profile doesn't see. */
    fun blocks(tab: String) = kids && tab in setOf("LIVE", "GUIDE", "SPORTS", "YOUTUBE", "RECORDINGS")

    fun upsert(p: Profile) {
        all = if (all.any { it.id == p.id }) all.map { if (it.id == p.id) p else it } else all + p
        save()
    }

    fun newProfile(name: String, pin: String?, kids: Boolean) =
        Profile("p" + System.currentTimeMillis().toString(36), name.trim(), COLORS[all.size % COLORS.size], pin?.takeIf { it.length == 4 }?.let { hash(it) }, kids, null)

    /** Deletes a profile (not the one in use) and its settings. */
    fun remove(ctx: Context, p: Profile) {
        if (p.id == activeId || all.size <= 1) return
        all = all.filter { it.id != p.id }
        save()
        ctx.getSharedPreferences("tvhub_p_${p.id}", Context.MODE_PRIVATE).edit().clear().apply()
    }

    /** Switches to [to]: saves this profile's settings, loads the other's, and restarts TV Hub. */
    fun switchTo(activity: Activity, to: Profile) {
        if (to.id == activeId) return
        val app = activity.getSharedPreferences("tvhub", Context.MODE_PRIVATE)
        val current = app.all
        // 1. Save this profile.
        activity.getSharedPreferences("tvhub_p_$activeId", Context.MODE_PRIVATE).edit().apply {
            clear(); current.forEach { (k, v) -> put(this, k, v) }
        }.commit()
        // 2. The other profile's settings (a new profile starts fresh, signed in to the same Plex account).
        val saved = activity.getSharedPreferences("tvhub_p_${to.id}", Context.MODE_PRIVATE).all
        val next: Map<String, Any?> = if (saved.isNotEmpty()) saved else buildMap {
            listOf("plex_account_token", "plex_token").forEach { k -> current[k]?.let { put(k, it) } }
            current["plex_account_token"]?.let { put("plex_token", it) }   // the account owner, until a Plex user is picked
            if (to.kids) {
                put(Opt.HOME_HIDDEN, setOf(HomeCategory.LAST_CHANNELS.name, HomeCategory.TOP10_CHANNELS.name, HomeCategory.FAVORITE_CHANNELS.name,
                    HomeCategory.RECENT_LIVE.name, HomeCategory.SPORTS_NOW.name, HomeCategory.FOLLOWED_TEAMS.name))
                put("onboarded", true)
            }
        }
        // 3. Load it, keeping the shared settings.
        app.edit().apply {
            clear()
            next.forEach { (k, v) -> if (!SHARED.matches(k)) put(this, k, v) }
            current.forEach { (k, v) -> if (SHARED.matches(k)) put(this, k, v) }
        }.commit()
        activeId = to.id
        save()
        store?.edit()?.commit()
        // 4. Restart so every screen loads the new profile.
        val i = Intent(activity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            .putExtra("profile_chosen", true)
        activity.startActivity(i)
        activity.finishAffinity()
        Runtime.getRuntime().exit(0)
    }

    @Suppress("UNCHECKED_CAST")
    private fun put(e: android.content.SharedPreferences.Editor, k: String, v: Any?) {
        when (v) {
            is Boolean -> e.putBoolean(k, v)
            is Int -> e.putInt(k, v)
            is Long -> e.putLong(k, v)
            is Float -> e.putFloat(k, v)
            is String -> e.putString(k, v)
            is Set<*> -> e.putStringSet(k, v as Set<String>)
        }
    }
}

@Composable
fun ProfileAvatar(p: Profiles.Profile, size: Int = 56) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Color(p.color)), contentAlignment = Alignment.Center) {
        Text(p.name.take(1).uppercase(), style = if (size > 60) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleLarge,
            color = Color.White, fontWeight = FontWeight.Bold)
    }
}

/** "Who's watching?": pick a profile (asks for its PIN). */
@Composable
fun ProfilePicker(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var pinFor by remember { mutableStateOf<Profiles.Profile?>(null) }
    fun pick(p: Profiles.Profile) {
        if (p.id == Profiles.activeId) onDone()
        else if (p.pinHash != null) pinFor = p
        else (ctx as? Activity)?.let { Profiles.switchTo(it, p) }
    }
    Column(Modifier.fillMaxSize().background(Color.Black).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        Text("Who's watching?", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(32.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            items(Profiles.all.distinctBy { it.id }, key = { it.id }) { p ->
                Column(Modifier.focusRing(RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).clickable { pick(p) }.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    ProfileAvatar(p, 96)
                    Spacer(Modifier.height(10.dp))
                    Text(p.name, style = MaterialTheme.typography.titleMedium)
                    Text(listOfNotNull("🔒".takeIf { p.pinHash != null }, "Kids".takeIf { p.kids }).joinToString(" "),
                        style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA))
                }
            }
        }
    }
    pinFor?.let { p -> PinDialog(p, onCancel = { pinFor = null }) { (ctx as? Activity)?.let { Profiles.switchTo(it, p) } } }
}

@Composable
fun PinDialog(p: Profiles.Profile, onCancel: () -> Unit, onOk: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("PIN for ${p.name}") },
        text = {
            Column {
                OutlinedTextField(value = pin, onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) { pin = it; wrong = false } },
                    singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text("4-digit PIN") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                if (wrong) Text("Wrong PIN.", color = Color(0xFFFF6B6B))
            }
        },
        confirmButton = { TextButton(enabled = pin.length == 4, onClick = { if (Profiles.pinOk(p, pin)) onOk() else wrong = true }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}

/** Settings > Profiles: TV Hub profiles (switch, add, edit, delete). */
@Composable
fun AppProfilesSection() {
    val ctx = LocalContext.current
    var editing by remember { mutableStateOf<Profiles.Profile?>(null) }
    var adding by remember { mutableStateOf(false) }
    var pinFor by remember { mutableStateOf<Profiles.Profile?>(null) }
    SettingsHeader("TV Hub profiles")
    SettingsCard {
        Profiles.all.forEachIndexed { i, p ->
            if (i > 0) SettingsDivider()
            val active = p.id == Profiles.activeId
            Row(Modifier.fillMaxWidth().focusRing().clickable {
                if (!active) { if (p.pinHash != null) pinFor = p else (ctx as? Activity)?.let { Profiles.switchTo(it, p) } }
            }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(p)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (active) Text("  ✔ Active", color = Color(0xFFAAAAAA))
                    }
                    Text(listOfNotNull("Kids".takeIf { p.kids }, "🔒 PIN".takeIf { p.pinHash != null }).joinToString(" · ").ifEmpty { "Tap to switch" },
                        style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA))
                }
                if (!Profiles.kids) TextButton(onClick = { editing = p }, modifier = Modifier.focusRing(ButtonShape)) { Text("⋮") }
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    if (!Profiles.kids) OutlinedButton(onClick = { adding = true }, modifier = Modifier.fillMaxWidth().focusRing(ButtonShape)) { Text("👤+  Add profile") }
    if (Profiles.all.size > 1) {
        var ask by remember { mutableStateOf(Profiles.askAtStart) }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Ask who's watching when TV Hub opens", modifier = Modifier.weight(1f))
            Switch(checked = ask, onCheckedChange = { ask = it; Profiles.askAtStart = it })
        }
    }
    if (adding) ProfileEditor(null, onClose = { adding = false })
    editing?.let { p -> ProfileEditor(p, onClose = { editing = null }) }
    pinFor?.let { p -> PinDialog(p, onCancel = { pinFor = null }) { (ctx as? Activity)?.let { Profiles.switchTo(it, p) } } }
}

@Composable
private fun ProfileEditor(p: Profiles.Profile?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(p?.name ?: "") }
    var kids by remember { mutableStateOf(p?.kids ?: false) }
    var pin by remember { mutableStateOf("") }
    var clearPin by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (p == null) "New profile" else "Edit ${p.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it.take(20) }, singleLine = true, label = { Text("Profile name") },
                    placeholder = { Text("e.g. Guests, Kids, Family Room") })
                Text("PIN protection (optional): a 4-digit PIN is needed to switch to this profile.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = pin, onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pin = it }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), label = { Text(if (p?.pinHash != null) "New PIN (blank keeps it)" else "PIN") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                if (p?.pinHash != null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Remove PIN", modifier = Modifier.weight(1f)); Switch(checked = clearPin, onCheckedChange = { clearPin = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Kids profile")
                        Text("Hides Live TV, Guide, Sports, YouTube and Recordings; Settings stay locked.", style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFAAAAAA))
                    }
                    Switch(checked = kids, onCheckedChange = { kids = it })
                }
                if (p != null && p.id != Profiles.activeId && Profiles.all.size > 1) {
                    TextButton(onClick = { Profiles.remove(ctx, p); onClose() }) { Text("Delete profile", color = Color(0xFFFF6B6B)) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && (pin.isEmpty() || pin.length == 4), onClick = {
                if (p == null) Profiles.upsert(Profiles.newProfile(name, pin.ifEmpty { null }, kids))
                else Profiles.upsert(p.copy(name = name.trim(), kids = kids,
                    pinHash = if (clearPin) null else if (pin.length == 4) Profiles.hash(pin) else p.pinHash))
                onClose()
            }) { Text(if (p == null) "Continue" else "Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
    )
}

/** Settings in a Kids profile: locked, with a way to switch profiles. */
@Composable
fun KidsSettingsLock() {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        var pick by remember { mutableStateOf(false) }
        if (pick) { ProfilePicker { pick = false }; return@Column }
        Text("🔒", style = MaterialTheme.typography.displayMedium)
        Text("Settings are locked in a Kids profile.", style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { pick = true }, modifier = Modifier.focusRing(ButtonShape)) { Text("Switch profile") }
    }
}
