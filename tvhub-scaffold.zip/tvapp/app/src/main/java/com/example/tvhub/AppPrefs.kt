package com.example.tvhub

import android.content.Context

/** Simple settings store (same file the Plex sign-in uses). */
class AppPrefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)

    var playlistUrl: String
        get() = p.getString("playlist_url", "") ?: ""
        set(v) { p.edit().putString("playlist_url", v).apply() }

    var epgUrl: String
        get() = p.getString("epg_url", "") ?: ""
        set(v) { p.edit().putString("epg_url", v).apply() }

    var traktClientId: String
        get() = p.getString("trakt_client_id", "") ?: ""
        set(v) { p.edit().putString("trakt_client_id", v).apply() }

    var traktClientSecret: String
        get() = p.getString("trakt_client_secret", "") ?: ""
        set(v) { p.edit().putString("trakt_client_secret", v).apply() }

    // Xtream Codes login (used instead of the playlist URL when filled in)
    var xcServer: String
        get() = p.getString("xc_server", "") ?: ""
        set(v) { p.edit().putString("xc_server", v).apply() }
    var xcUser: String
        get() = p.getString("xc_user", "") ?: ""
        set(v) { p.edit().putString("xc_user", v).apply() }
    var xcPass: String
        get() = p.getString("xc_pass", "") ?: ""
        set(v) { p.edit().putString("xc_pass", v).apply() }

    /** Scrobble Live TV programmes to Trakt (off by default: guides can be unreliable). */
    var scrobbleLive: Boolean
        get() = p.getBoolean("trakt_scrobble_live", false)
        set(v) { p.edit().putBoolean("trakt_scrobble_live", v).apply() }

    /** Subtitles in the Plex player: "always", "forced" (only forced/foreign parts) or "off". */
    var subtitleMode: String
        get() = p.getString("sub_mode", "forced") ?: "forced"
        set(v) { p.edit().putString("sub_mode", v).apply() }

    /** Subtitle language (ISO code like "en", "es"). */
    var subtitleLang: String
        get() = p.getString("sub_lang", "en") ?: "en"
        set(v) { p.edit().putString("sub_lang", v).apply() }

    /** Preferred audio language ("" = the file's default). */
    var audioLang: String
        get() = p.getString("audio_lang", "") ?: ""
        set(v) { p.edit().putString("audio_lang", v).apply() }

    /** Go into picture-in-picture when you press Home while something plays. */
    var autoPip: Boolean
        get() = p.getBoolean("auto_pip", true)
        set(v) { p.edit().putBoolean("auto_pip", v).apply() }

    /** Keep Live TV playing in a small window while you use other tabs. */
    var miniPlayer: Boolean
        get() = p.getBoolean("mini_player", false)
        set(v) { p.edit().putBoolean("mini_player", v).apply() }

    /** Play the next episode automatically when one ends. */
    var autoPlayNext: Boolean
        get() = p.getBoolean("auto_next", true)
        set(v) { p.edit().putBoolean("auto_next", v).apply() }

    /** Recent searches for one search box ("all", "plex", "live", "games"), newest first. */
    fun recentSearches(scope: String): List<String> =
        (p.getString("recent_search_$scope", "") ?: "").split('\n').filter { it.isNotBlank() }

    fun addRecentSearch(scope: String, q: String) {
        val t = q.trim()
        if (t.length < 2) return
        val list = (listOf(t) + recentSearches(scope).filter { !it.equals(t, true) }).take(12)
        p.edit().putString("recent_search_$scope", list.joinToString("\n")).apply()
    }

    fun clearRecentSearches(scope: String) {
        p.edit().remove("recent_search_$scope").apply()
    }

    private fun list(key: String) = (p.getString(key, "") ?: "").split('\n').filter { it.isNotEmpty() }
    private fun putList(key: String, v: Collection<String>) { p.edit().putString(key, v.joinToString("\n")).apply() }

    /** Live TV lineup: your group order, channel order (keys), hidden groups and hidden channels. */
    var groupOrder: List<String>
        get() = list("group_order")
        set(v) = putList("group_order", v)
    var channelOrder: List<String>
        get() = list("channel_order")
        set(v) = putList("channel_order", v)
    var hiddenGroups: Set<String>
        get() = list("hidden_groups").toSet()
        set(v) = putList("hidden_groups", v)
    var hiddenChannels: Set<String>
        get() = list("hidden_channels").toSet()
        set(v) = putList("hidden_channels", v)

    /** TheSportsDB API key for TV sports listings (Patreon key; the free key returns too little). */
    var sportsDbKey: String
        get() = p.getString("sportsdb_key", "") ?: ""
        set(v) { p.edit().putString("sportsdb_key", v).apply() }
    /** Country for sports listings, e.g. "United States". */
    var sportsCountry: String
        get() = p.getString("sports_country", "United States") ?: "United States"
        set(v) { p.edit().putString("sports_country", v).apply() }
    /** Teams and leagues you follow (one per line), shown first in Sports. */
    var sportsFavorites: List<String>
        get() = list("sports_favorites")
        set(v) = putList("sports_favorites", v)

    /** Channels you watched, newest first (channel keys). */
    var recentChannels: List<String>
        get() = (p.getString("recent_channels", "") ?: "").split('\n').filter { it.isNotEmpty() }
        set(v) { p.edit().putString("recent_channels", v.joinToString("\n")).apply() }

    var favorites: Set<String>
        get() = p.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
        set(v) { p.edit().putStringSet("favorites", v.toSet()).apply() }
}
