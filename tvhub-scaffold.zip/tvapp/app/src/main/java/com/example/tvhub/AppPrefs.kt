package com.example.tvhub

import android.content.Context

/** Simple settings store (same file the Plex sign-in uses). */
class AppPrefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)

    var playlistUrl: String
        get() = p.getString("playlist_url", "") ?: ""
        set(v) { p.edit().putString("playlist_url", v).apply() }

    var epgUrl: String
        get() = p.getString("epg_url", "") ?: ""
        set(v) { p.edit().putString("epg_url", v).apply() }

    var favorites: Set<String>
        get() = p.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
        set(v) { p.edit().putStringSet("favorites", v.toSet()).apply() }
}
