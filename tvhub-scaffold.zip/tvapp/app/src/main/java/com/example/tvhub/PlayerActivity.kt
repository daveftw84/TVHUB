package com.example.tvhub

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.view.InputDevice
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Full-screen game player built on LibretroDroid. Back (or the controller's menu button) opens a menu
 * with Resume, Save state, Load state, Restart and Quit. In-game saves are kept between sessions.
 */
class PlayerActivity : ComponentActivity() {
    companion object {
        const val EXTRA_CORE = "core"        // full path of the core file
        const val EXTRA_ROM = "rom"          // full path of the game file
        const val EXTRA_TITLE = "title"
        const val EXTRA_OPEN_ROOM = "open_room"
        const val EXTRA_KEY = "key"          // stable name for this game's save files
    }

    private lateinit var retroView: GLRetroView
    private lateinit var sramFile: File
    private lateinit var stateFile: File
    private var menu: AlertDialog? = null
    private lateinit var pipLifecycle: PipAwareLifecycle
    private val pipShown = androidx.compose.runtime.mutableStateOf(false)
    private lateinit var gameBox: FrameLayout

    private fun placeGame(frame: View, r: Corners.Region?) {
        frame.post {
            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            if (r != null && frame.width > 0) {
                lp.width = (frame.width * r.w).toInt()
                lp.height = (frame.height * r.h).toInt()
                lp.leftMargin = (frame.width * r.x).toInt()
                lp.topMargin = (frame.height * r.y).toInt()
                lp.gravity = Gravity.TOP or Gravity.START
            }
            gameBox.layoutParams = lp
        }
    }
    private var title = ""
    private var touchPad: View? = null
    private val prefs by lazy { getSharedPreferences("tvhub", Context.MODE_PRIVATE) }
    private var fast = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Opt.init(this)
        Buttons.load(this)
        val core = intent.getStringExtra(EXTRA_CORE)
        val rom = intent.getStringExtra(EXTRA_ROM)
        if (core == null || rom == null || !File(rom).exists()) {
            Toast.makeText(this, "The game file is missing. Download it again.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        title = intent.getStringExtra(EXTRA_TITLE) ?: File(rom).nameWithoutExtension
        val key = (intent.getStringExtra(EXTRA_KEY) ?: File(rom).nameWithoutExtension)
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
        val coreName = File(core).name.removePrefix("lib").removeSuffix("_libretro_android.so")

        sramFile = RommSaves.sramFile(this, coreName, key)
        stateFile = RommSaves.stateFile(this, coreName, key)
        val saves = sramFile.parentFile ?: filesDir

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val data = GLRetroViewData(this).apply {
            coreFilePath = core
            gameFilePath = rom
            systemDirectory = BuiltinCores.systemDir(this@PlayerActivity).absolutePath
            savesDirectory = saves.absolutePath
            saveRAMState = if (sramFile.exists()) sramFile.readBytes() else null
            shader = shaderFor(prefs.getString("player_picture", "Default") ?: "Default")
            preferLowLatencyAudio = true
            rumbleEventsEnabled = false
        }
        retroView = GLRetroView(this, data)
        // The emulator follows its own lifecycle, which keeps running in picture-in-picture.
        pipLifecycle = PipAwareLifecycle(this, lifecycle)
        pipLifecycle.lifecycle.addObserver(retroView)

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        // The game sits in its own box, so a split-screen layout can shrink it to its share of the screen.
        gameBox = FrameLayout(this)
        gameBox.addView(
            retroView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER),
        )
        frame.addView(gameBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(frame)
        // Corner windows (Live TV or Plex) drawn over the game; they never take the controller.
        frame.addView(
            androidx.compose.ui.platform.ComposeView(this).apply {
                isFocusable = false
                setContent {
                    androidx.compose.material3.MaterialTheme(colorScheme = androidx.compose.material3.darkColorScheme()) {
                        if (!pipShown.value) CornerWindows(focusable = false)
                        // Split layouts: move the game into the main picture's place.
                        val region = if (pipShown.value) null else Corners.regions()?.getOrNull(0)
                        androidx.compose.runtime.LaunchedEffect(region) { placeGame(frame, region) }
                        androidx.compose.runtime.LaunchedEffect(Corners.mainMuted) { retroView.audioEnabled = !Corners.mainMuted }
                    }
                }
            },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        retroView.isFocusable = true
        retroView.requestFocus()
        // Multiplayer: buttons from friends' phones go to their player number.
        GameRoom.sink = { port, key, down -> retroView.post { netInput(port, key, down) } }
        if (intent.getBooleanExtra(EXTRA_OPEN_ROOM, false)) {
            GameRoom.reservedPorts = (0 until gamepadCount()).toSet()
            GameRoom.open(title)
        }

        // On-screen buttons for touch screens, shown when no game controller is connected.
        val pad = buildTouchPad()
        frame.addView(pad, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        touchPad = pad
        pad.visibility = if (wantTouchPad()) View.VISIBLE else View.GONE

        lifecycleScope.launch {
            retroView.getGLRetroErrors().collect { code ->
                val msg = when (code) {
                    GLRetroView.ERROR_LOAD_LIBRARY -> "The emulator couldn't start on this device."
                    GLRetroView.ERROR_LOAD_GAME -> "The emulator couldn't open this game. It may need a BIOS file, " +
                        "or (for arcade) a ROM set made for this emulator."
                    GLRetroView.ERROR_GL_NOT_COMPATIBLE -> "This device's graphics aren't supported by the emulator."
                    else -> "The emulator stopped with an error."
                }
                Toast.makeText(this@PlayerActivity, msg, Toast.LENGTH_LONG).show()
                finish()
            }
        }

        onBackPressedDispatcher.addCallback(this) { showMenu() }

        // Keep the game's own save safe even if the app is closed without using Quit.
        lifecycleScope.launch {
            while (true) {
                delay(60_000)
                withContext(Dispatchers.IO) { saveSram(true) }
            }
        }
    }

    // Controller buttons go to the game; Back / Menu / the controller's home-style button open our menu.
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (menu?.isShowing == true || !::retroView.isInitialized) return super.dispatchKeyEvent(event)
        val code = event.keyCode
        if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_BUTTON_MODE || code == KeyEvent.KEYCODE_MENU) {
            if (event.action == KeyEvent.ACTION_UP) showMenu()
            return true
        }
        // Button Mapper: a remapped button acts as another button, or runs a hotkey.
        val target = Buttons.game[code]
        if (target != null && target.retroKey < 0) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                when (target) {
                    Buttons.GameTarget.MENU -> showMenu()
                    Buttons.GameTarget.FAST -> { fast = !fast; retroView.frameSpeed = if (fast) 2 else 1 }
                    Buttons.GameTarget.SAVE -> saveState()
                    Buttons.GameTarget.LOAD -> loadState()
                    else -> {}
                }
            }
            return true
        }
        val mapped = target?.retroKey ?: code
        val ev = if (mapped == code) event else KeyEvent(event.downTime, event.eventTime, event.action, mapped, event.repeatCount,
            event.metaState, event.deviceId, event.scanCode, event.flags, event.source)
        val handled = when (event.action) {
            KeyEvent.ACTION_DOWN -> retroView.onKeyDown(mapped, ev)
            KeyEvent.ACTION_UP -> retroView.onKeyUp(mapped, ev)
            else -> false
        }
        return handled || super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (menu?.isShowing != true && ::retroView.isInitialized) {
            retroView.onGenericMotionEvent(event)
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    // --- Picture-in-picture: the game keeps running in a small window ---

    private fun enterPip() {
        menu?.dismiss()
        Pip.enter(this, 4, 3)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (::retroView.isInitialized && AppPrefs(this).autoPip) enterPip()
    }

    private var padWasVisible = false

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pipShown.value = isInPictureInPictureMode
        if (isInPictureInPictureMode) {
            padWasVisible = touchPad?.visibility == View.VISIBLE
            touchPad?.visibility = View.GONE
            menu?.dismiss()
        } else if (padWasVisible) {
            touchPad?.visibility = View.VISIBLE
        }
        if (::pipLifecycle.isInitialized) pipLifecycle.update()
    }

    // --- Multiplayer ---

    private val netPad = HashMap<Int, FloatArray>()   // player -> d-pad x, y

    /** Controllers plugged into this device keep players 1, 2...; friends get the next free numbers. */
    private fun gamepadCount(): Int = InputDevice.getDeviceIds().count { id ->
        val d = InputDevice.getDevice(id) ?: return@count false
        (d.sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD && !d.isVirtual
    }

    private fun netInput(port: Int, key: String, down: Boolean) {
        val dir = when (key) { "up" -> 0f to -1f; "down" -> 0f to 1f; "left" -> -1f to 0f; "right" -> 1f to 0f; else -> null }
        if (dir != null) {
            val xy = netPad.getOrPut(port) { floatArrayOf(0f, 0f) }
            if (dir.first != 0f) xy[0] = if (down) dir.first else 0f
            if (dir.second != 0f) xy[1] = if (down) dir.second else 0f
            retroView.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD, xy[0], xy[1], port)
            return
        }
        val code = when (key) {
            "a" -> KeyEvent.KEYCODE_BUTTON_A; "b" -> KeyEvent.KEYCODE_BUTTON_B; "x" -> KeyEvent.KEYCODE_BUTTON_X; "y" -> KeyEvent.KEYCODE_BUTTON_Y
            "l" -> KeyEvent.KEYCODE_BUTTON_L1; "r" -> KeyEvent.KEYCODE_BUTTON_R1; "l2" -> KeyEvent.KEYCODE_BUTTON_L2; "r2" -> KeyEvent.KEYCODE_BUTTON_R2
            "start" -> KeyEvent.KEYCODE_BUTTON_START; "select" -> KeyEvent.KEYCODE_BUTTON_SELECT
            else -> return
        }
        retroView.sendKeyEvent(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, port)
    }

    /** Opens the room (a code friends type to join) and shows how to invite them. */
    private fun showRoom() {
        // Controllers plugged into this TV keep players 1, 2...; friends get the next free numbers.
        GameRoom.reservedPorts = (0 until gamepadCount()).toSet()
        val code = GameRoom.open(title)
        val link = "http://${SetupServer.localIp() ?: "?"}:${CastHub.port}/pad?code=$code"
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(40, 20, 40, 0)
            gravity = Gravity.CENTER_VERTICAL
        }
        val qr = android.widget.ImageView(this).apply {
            setImageBitmap(SetupServer.qr(link, 360).asAndroidBitmap())
        }
        box.addView(qr, LinearLayout.LayoutParams(360, 360))
        val players = if (GameRoom.guests.isEmpty()) "No one has joined yet." else
            GameRoom.guests.joinToString("\n") { "Player ${it.port + 1}: ${it.name}" }
        box.addView(TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(30, 0, 0, 0)
            text = "Code: $code\n\nFriends join with TV Hub on their phone (Games > Join a game), or by scanning this / opening:\n$link\n\n$players\n\n" +
                "Everyone uses the same Wi-Fi as this TV. Each player gets the next free player number."
        })
        menu = AlertDialog.Builder(this)
            .setTitle("Multiplayer · $title")
            .setView(box)
            .setPositiveButton("Share invite") { _, _ -> shareInvite(this, GameRoom.inviteText()) }
            .setNeutralButton("Close room") { _, _ -> GameRoom.close() }
            .setNegativeButton("Back to game", null)
            .show()
    }

    /** Pick a Live TV channel for a corner window (recent and favorite channels first). */
    private fun pickCornerChannel() {
        val list = Corners.channelChoices.take(200)
        if (list.isEmpty()) {
            Toast.makeText(this, "Open Live TV once so your channels are loaded.", Toast.LENGTH_LONG).show()
            return
        }
        menu = AlertDialog.Builder(this)
            .setTitle("Channel for a corner window")
            .setItems(list.map { it.name }.toTypedArray()) { _, i ->
                Corners.addChannel(this, list[i])?.let { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
            }
            .show()
    }

    private fun showMenu() {
        if (menu?.isShowing == true) return
        val disks = try { retroView.getAvailableDisks() } catch (_: Exception) { 0 }
        val actions = ArrayList<Pair<String, () -> Unit>>()
        actions += "Resume" to {}
        actions += "Save state" to { saveState() }
        actions += "Load state" to { loadState() }
        if (disks > 1) actions += "Change disc" to { pickDisc(disks) }
        actions += (if (fast) "Fast-forward: on" else "Fast-forward: off") to {
            fast = !fast
            retroView.frameSpeed = if (fast) 2 else 1
        }
        actions += "Picture: ${prefs.getString("player_picture", "Default")}" to { pickPicture() }
        if (packageManager.hasSystemFeature("android.hardware.touchscreen")) {
            actions += (if (touchPad?.visibility == View.VISIBLE) "Hide touch controls" else "Show touch controls") to {
                val show = touchPad?.visibility != View.VISIBLE
                touchPad?.visibility = if (show) View.VISIBLE else View.GONE
                prefs.edit().putBoolean("player_touch", show).apply()
            }
        }
        actions += (if (GameRoom.code == null) "Multiplayer: invite players" else "Multiplayer: ${GameRoom.guests.size} joined (invite / manage)") to { showRoom() }
        if (!Corners.full) actions += "TV in a corner (${Corners.slots.size}/${Corners.MAX})" to { pickCornerChannel() }
        if (Corners.slots.isNotEmpty()) {
            val who = Corners.slots.firstOrNull { it.id == Corners.soundId }?.title ?: "the game"
            actions += "Sound: $who (change)" to { Corners.cycleSound() }
            actions += "Layout: ${Corners.layout.label} (change)" to { Corners.cycleLayout() }
            if (Corners.slots.size > 1) actions += "Rotate windows" to { Corners.rotateWindows() }
            actions += "Close corner windows" to { Corners.closeAll() }
        }
        if (Pip.supported(this)) actions += "Float over other apps" to { enterPip() }
        actions += "Restart" to { retroView.reset() }
        actions += "Quit" to { quit() }
        menu = AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions[which].second() }
            .create()
        menu?.show()
    }

    private fun pickDisc(count: Int) {
        val current = try { retroView.getCurrentDisk() } catch (_: Exception) { -1 }
        val names = (0 until count).map { i -> "Disc ${i + 1}" + if (i == current) " (in use)" else "" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Change disc").setItems(names) { _, which ->
            try {
                retroView.changeDisk(which)
                toast("Disc ${which + 1} inserted.")
            } catch (_: Exception) {
                toast("Couldn't change the disc.")
            }
        }.show()
    }

    private fun shaderFor(name: String): ShaderConfig = when (name) {
        "CRT" -> ShaderConfig.CRT
        "LCD" -> ShaderConfig.LCD
        "Sharp" -> ShaderConfig.Sharp
        else -> ShaderConfig.Default
    }

    private fun pickPicture() {
        val names = arrayOf("Default", "Sharp", "CRT", "LCD")
        AlertDialog.Builder(this).setTitle("Picture").setItems(names) { _, which ->
            prefs.edit().putString("player_picture", names[which]).apply()
            retroView.shader = shaderFor(names[which])
        }.show()
    }

    // ---------------------------------------------------------------- Touch controls

    private fun hasGamepad(): Boolean = InputDevice.getDeviceIds().any { id ->
        val d = InputDevice.getDevice(id) ?: return@any false
        val s = d.sources
        (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
    }

    private fun wantTouchPad(): Boolean {
        if (!packageManager.hasSystemFeature("android.hardware.touchscreen")) return false
        return when (Buttons.touchMode(this)) {
            "always" -> true
            "never" -> false
            else -> prefs.getBoolean("player_touch", !hasGamepad())
        }
    }

    private var padX = 0f
    private var padY = 0f

    private fun sendDpad() = retroView.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD, padX, padY, 0)

    @SuppressLint("ClickableViewAccessibility")
    private val touchScale by lazy { Buttons.touchScale(this) }
    private val touchAlpha by lazy { Buttons.touchOpacity(this) }

    private fun button(label: String, size: Int, onDown: () -> Unit, onUp: () -> Unit): TextView {
        val px = (size * touchScale * resources.displayMetrics.density).toInt()
        return TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 14f
            alpha = touchAlpha
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.DKGRAY)
            }
            layoutParams = LinearLayout.LayoutParams(px, px).apply { setMargins(6, 6, 6, 6) }
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { v.alpha = (touchAlpha + 0.35f).coerceAtMost(1f); onDown() }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.alpha = touchAlpha; onUp() }
                }
                true
            }
        }
    }

    private fun key(label: String, code: Int, size: Int = 64) = button(
        label, size,
        { retroView.sendKeyEvent(KeyEvent.ACTION_DOWN, code, 0) },
        { retroView.sendKeyEvent(KeyEvent.ACTION_UP, code, 0) },
    )

    private fun dir(label: String, x: Float, y: Float) = button(
        label, 58,
        { if (x != 0f) padX = x; if (y != 0f) padY = y; sendDpad() },
        { if (x != 0f) padX = 0f; if (y != 0f) padY = 0f; sendDpad() },
    )

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        views.forEach { addView(it) }
    }

    private fun spacer() = View(this).apply {
        val px = (58 * touchScale * resources.displayMetrics.density).toInt()
        layoutParams = LinearLayout.LayoutParams(px, px).apply { setMargins(6, 6, 6, 6) }
    }

    private fun buildTouchPad(): View {
        val root = FrameLayout(this)
        // D-pad, bottom left
        val dpad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(spacer(), dir("▲", 0f, -1f), spacer()))
            addView(row(dir("◀", -1f, 0f), spacer(), dir("▶", 1f, 0f)))
            addView(row(spacer(), dir("▼", 0f, 1f), spacer()))
        }
        root.addView(dpad, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.START).apply { setMargins(24, 24, 24, 24) })
        // Face buttons, bottom right (Nintendo-style layout)
        val face = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (Buttons.touchNintendo(this@PlayerActivity)) {
                addView(row(spacer(), key("X", KeyEvent.KEYCODE_BUTTON_X), spacer()))
                addView(row(key("Y", KeyEvent.KEYCODE_BUTTON_Y), spacer(), key("A", KeyEvent.KEYCODE_BUTTON_A)))
                addView(row(spacer(), key("B", KeyEvent.KEYCODE_BUTTON_B), spacer()))
            } else {
                // Xbox-style labels: the same buttons, named by their place (A bottom, B right, X left, Y top).
                addView(row(spacer(), key("Y", KeyEvent.KEYCODE_BUTTON_X), spacer()))
                addView(row(key("X", KeyEvent.KEYCODE_BUTTON_Y), spacer(), key("B", KeyEvent.KEYCODE_BUTTON_A)))
                addView(row(spacer(), key("A", KeyEvent.KEYCODE_BUTTON_B), spacer()))
            }
        }
        root.addView(face, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END).apply { setMargins(24, 24, 24, 24) })
        // Shoulders, top corners
        root.addView(row(key("L", KeyEvent.KEYCODE_BUTTON_L1, 56), key("L2", KeyEvent.KEYCODE_BUTTON_L2, 48)),
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START).apply { setMargins(24, 24, 24, 24) })
        root.addView(row(key("R2", KeyEvent.KEYCODE_BUTTON_R2, 48), key("R", KeyEvent.KEYCODE_BUTTON_R1, 56)),
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END).apply { setMargins(24, 24, 24, 24) })
        // Select / Start / Menu, bottom centre
        root.addView(
            row(
                key("Select", KeyEvent.KEYCODE_BUTTON_SELECT, 52),
                button("☰", 44, {}, { showMenu() }),
                key("Start", KeyEvent.KEYCODE_BUTTON_START, 52),
            ),
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { setMargins(24, 24, 24, 16) },
        )
        return root
    }

    private fun saveState() {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val bytes = retroView.serializeState()
                    if (bytes.isNotEmpty()) stateFile.writeBytes(bytes)
                    bytes.isNotEmpty()
                } catch (_: Exception) {
                    false
                }
            }
            toast(if (ok) "State saved." else "This game can't save a state.")
        }
    }

    private fun loadState() {
        if (!stateFile.exists()) {
            toast("No saved state yet.")
            return
        }
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    retroView.unserializeState(stateFile.readBytes())
                } catch (_: Exception) {
                    false
                }
            }
            toast(if (ok) "State loaded." else "Couldn't load the state.")
        }
    }

    /** Keeps the game's own save (battery save / memory card) for next time. */
    private fun saveSram(useEmulationThread: Boolean) {
        try {
            val bytes = retroView.serializeSRAM(useEmulationThread)
            if (bytes.isNotEmpty()) sramFile.writeBytes(bytes)
        } catch (_: Exception) {
        }
    }

    private fun quit() {
        GameRoom.close()
        GameRoom.sink = null
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { saveSram(true) }
            finish()
        }
    }


    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
