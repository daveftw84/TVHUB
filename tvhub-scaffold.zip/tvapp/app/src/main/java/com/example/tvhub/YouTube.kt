package com.example.tvhub

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.ChannelInfoItem
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabs
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.services.youtube.YoutubeParsingHelper
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.zip.GZIPInputStream

/** A YouTube video in a list. */
data class TubeVideo(
    val url: String,
    val title: String,
    val channel: String,
    val channelUrl: String?,
    val thumb: String?,
    val durationSec: Long,
    val views: Long,
    val ago: String?,
    val isShort: Boolean,
    val isLive: Boolean,
    val published: Long = 0,   // when it was uploaded (ms), when known
)

/** A YouTube channel. */
data class TubeChannel(val url: String, val name: String, val avatar: String?, val subscribers: Long = -1)

/**
 * YouTube, the way NewPipe and PipePipe do it: the open-source NewPipe Extractor reads YouTube's own
 * pages (no Google account or API key), plus SponsorBlock and Return YouTube Dislike.
 */
object YouTube {
    private const val DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
    @Volatile private var ready = false

    /** NewPipe Extractor's way of downloading pages. */
    private object Net : Downloader() {
        override fun execute(request: Request): Response {
            val c = URL(request.url()).openConnection() as HttpURLConnection
            c.requestMethod = request.httpMethod()
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.instanceFollowRedirects = true
            var hasUa = false
            for ((k, values) in request.headers()) {
                if (k.equals("User-Agent", true)) hasUa = true
                values.forEachIndexed { i, v -> if (i == 0) c.setRequestProperty(k, v) else c.addRequestProperty(k, v) }
            }
            if (!hasUa) c.setRequestProperty("User-Agent", DESKTOP_UA)
            request.dataToSend()?.let { data ->
                c.doOutput = true
                c.outputStream.use { it.write(data) }
            }
            val code = c.responseCode
            if (code == 429) throw ReCaptchaException("reCaptcha Challenge requested", request.url())
            val raw = (if (code >= 400) c.errorStream else c.inputStream)
            val stream = if (raw != null && c.contentEncoding.equals("gzip", true)) GZIPInputStream(raw) else raw
            val body = stream?.bufferedReader()?.use { it.readText() }
            val headers = c.headerFields.filterKeys { it != null }
            return Response(code, c.responseMessage, headers, body, c.url.toString())
        }
    }

    fun init() {
        if (ready) return
        synchronized(this) {
            if (ready) return
            val loc = Locale.getDefault()
            NewPipe.init(Net, Localization.fromLocale(loc), ContentCountry(loc.country.ifEmpty { "US" }))
            ready = true
        }
    }

    private val yt get() = ServiceList.YouTube

    private fun best(images: List<org.schabi.newpipe.extractor.Image>): String? =
        images.maxByOrNull { it.height }?.url

    fun toVideo(item: InfoItem): TubeVideo? {
        val s = item as? StreamInfoItem ?: return null
        return TubeVideo(
            url = s.url,
            title = s.name,
            channel = s.uploaderName.orEmpty(),
            channelUrl = s.uploaderUrl,
            thumb = best(s.thumbnails),
            durationSec = s.duration,
            views = s.viewCount,
            ago = s.textualUploadDate,
            isShort = s.isShortFormContent || s.url.contains("/shorts/"),
            isLive = s.streamType == StreamType.LIVE_STREAM,
            published = try { s.uploadDate?.offsetDateTime()?.toInstant()?.toEpochMilli() ?: 0 } catch (_: Throwable) { 0 },
        )
    }

    private fun toChannel(item: InfoItem): TubeChannel? {
        val c = item as? ChannelInfoItem ?: return null
        return TubeChannel(c.url, c.name, best(c.thumbnails), c.subscriberCount)
    }

    /** Videos and channels for a search. */
    fun search(q: String): Pair<List<TubeVideo>, List<TubeChannel>> {
        init()
        val ex = yt.getSearchExtractor(q)
        ex.fetchPage()
        val items = ex.initialPage.items
        return items.mapNotNull { toVideo(it) } to items.mapNotNull { toChannel(it) }
    }

    fun suggestions(q: String): List<String> {
        init()
        return try { yt.suggestionExtractor.suggestionList(q) } catch (_: Exception) { emptyList() }
    }

    /** YouTube's own lists (Trending, Live, Music, Gaming, ...), each with its videos. */
    fun kiosks(): List<Pair<String, List<TubeVideo>>> {
        init()
        val list = yt.kioskList
        return list.availableKiosks.mapNotNull { id ->
            try {
                val ex = list.getExtractorById(id, null)
                ex.fetchPage()
                val vids = ex.initialPage.items.mapNotNull { toVideo(it) }
                if (vids.isEmpty()) null else ex.name to vids
            } catch (_: Exception) {
                null
            }
        }
    }

    /** A channel's newest videos, from its light-weight feed. */
    fun feed(channelUrl: String): List<TubeVideo> {
        init()
        val ex = yt.getFeedExtractor(channelUrl) ?: return emptyList()
        ex.fetchPage()
        return ex.initialPage.items.mapNotNull { toVideo(it) }
    }

    data class ChannelPage(val channel: TubeChannel, val banner: String?, val description: String?, val videos: List<TubeVideo>)

    fun channel(url: String): ChannelPage {
        init()
        val info = ChannelInfo.getInfo(yt, url)
        val tab = info.tabs.firstOrNull { ChannelTabs.VIDEOS in it.contentFilters }
        val videos = tab?.let {
            try { ChannelTabInfo.getInfo(yt, it).relatedItems.mapNotNull { i -> toVideo(i) } } catch (_: Exception) { null }
        } ?: emptyList()
        return ChannelPage(TubeChannel(info.url, info.name, best(info.avatars), info.subscriberCount),
            best(info.banners), info.description, videos)
    }

    fun stream(url: String): StreamInfo {
        init()
        return StreamInfo.getInfo(yt, url)
    }

    fun videoId(url: String): String? = try { init(); yt.streamLHFactory.getId(url) } catch (_: Exception) { null }

    // --- Playback ---

    private var rn = 0

    /**
     * Requests to YouTube's video servers need the headers of the client the stream came from
     * (as NewPipe's YoutubeHttpDataSource does): Origin/Referer for WEB, the visionOS user agent for visionOS.
     */
    fun dataSourceFactory(): ResolvingDataSource.Factory {
        val http = DefaultHttpDataSource.Factory().setUserAgent(DESKTOP_UA).setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20_000).setReadTimeoutMs(30_000)
        return ResolvingDataSource.Factory(http, ResolvingDataSource.Resolver { spec -> withYoutubeHeaders(spec) })
    }

    private fun withYoutubeHeaders(spec: androidx.media3.datasource.DataSpec): androidx.media3.datasource.DataSpec {
        val u = spec.uri.toString()
        if (!u.contains("googlevideo.com")) return spec
        val headers = HashMap(spec.httpRequestHeaders)
        if (YoutubeParsingHelper.isWebStreamingUrl(u)) {
            headers["Origin"] = "https://www.youtube.com"
            headers["Referer"] = "https://www.youtube.com/"
        }
        if (YoutubeParsingHelper.isVisionOsStreamingUrl(u)) headers["User-Agent"] = YoutubeParsingHelper.getVisionOsUserAgent(null)
        return spec.buildUpon().setUri(Uri.parse("$u&rn=${rn++}")).setHttpRequestHeaders(headers).build()
    }

    /** Qualities you can pick, from the video's streams. */
    fun qualities(info: StreamInfo): List<Int> =
        (info.videoOnlyStreams + info.videoStreams).filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.height > 0 }
            .map { it.height }.distinct().sortedDescending()

    /**
     * The best picture up to [maxHeight] plus the best audio (merged), like NewPipe. Live streams use
     * HLS. AV1 is skipped, since many TVs can't decode it in hardware.
     */
    fun mediaSource(info: StreamInfo, maxHeight: Int): MediaSource {
        val df = dataSourceFactory()
        val live = info.streamType == StreamType.LIVE_STREAM || info.streamType == StreamType.AUDIO_LIVE_STREAM
        if (live && !info.hlsUrl.isNullOrEmpty()) return HlsMediaSource.Factory(df).createMediaSource(MediaItem.fromUri(info.hlsUrl))
        fun codecRank(c: String?): Int = when {
            c == null -> 1
            c.startsWith("avc") -> 0
            c.startsWith("vp9") || c.startsWith("vp09") -> 1
            else -> 5
        }
        val video = info.videoOnlyStreams
            .filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.height in 1..maxHeight && !(it.codec ?: "").startsWith("av01") }
            .sortedWith(compareByDescending<org.schabi.newpipe.extractor.stream.VideoStream> { it.height }.thenBy { codecRank(it.codec) })
            .firstOrNull()
        val audio = info.audioStreams
            .filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
            .sortedWith(compareBy<org.schabi.newpipe.extractor.stream.AudioStream> {
                // the original language first (not dubbed or descriptive tracks)
                if (it.audioTrackType == null || it.audioTrackType.name == "ORIGINAL") 0 else 1
            }.thenByDescending { it.averageBitrate })
            .firstOrNull()
        val pf = ProgressiveMediaSource.Factory(df)
        if (video != null && audio != null) {
            return MergingMediaSource(true, pf.createMediaSource(MediaItem.fromUri(video.content)),
                pf.createMediaSource(MediaItem.fromUri(audio.content)))
        }
        val muxed = info.videoStreams.filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
            .sortedByDescending { it.height }.firstOrNull { it.height <= maxHeight } ?: info.videoStreams.firstOrNull()
        if (muxed != null) return pf.createMediaSource(MediaItem.fromUri(muxed.content))
        if (!info.dashMpdUrl.isNullOrEmpty()) return DashMediaSource.Factory(df).createMediaSource(MediaItem.fromUri(info.dashMpdUrl))
        if (!info.hlsUrl.isNullOrEmpty()) return HlsMediaSource.Factory(df).createMediaSource(MediaItem.fromUri(info.hlsUrl))
        if (audio != null) return pf.createMediaSource(MediaItem.fromUri(audio.content))
        throw IOException("No playable stream for this video.")
    }

    // --- SponsorBlock and Return YouTube Dislike (as in PipePipe) ---

    data class Segment(val startMs: Long, val endMs: Long, val category: String)

    private fun getJson(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 10_000
        c.setRequestProperty("User-Agent", "TVHub")
        if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Sponsor, self-promotion, interaction reminders, intros and outros, from sponsor.ajay.app. */
    fun sponsorSegments(videoId: String, categories: List<String>): List<Segment> = try {
        val cats = java.net.URLEncoder.encode(JSONArray(categories).toString(), "UTF-8")
        val a = JSONArray(getJson("https://sponsor.ajay.app/api/skipSegments?videoID=$videoId&categories=$cats"))
        (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            val seg = o.optJSONArray("segment") ?: return@mapNotNull null
            Segment((seg.optDouble(0) * 1000).toLong(), (seg.optDouble(1) * 1000).toLong(), o.optString("category"))
        }
    } catch (_: Exception) {
        emptyList()   // 404 = no segments for this video
    }

    /** (likes, dislikes) estimated by returnyoutubedislike.com. */
    fun votes(videoId: String): Pair<Long, Long>? = try {
        val o = JSONObject(getJson("https://returnyoutubedislikeapi.com/votes?videoId=$videoId"))
        o.optLong("likes") to o.optLong("dislikes")
    } catch (_: Exception) {
        null
    }

    fun compact(n: Long): String = when {
        n < 0 -> ""
        n >= 1_000_000_000 -> String.format(Locale.US, "%.1fB", n / 1e9)
        n >= 1_000_000 -> String.format(Locale.US, "%.1fM", n / 1e6)
        n >= 1_000 -> String.format(Locale.US, "%.1fK", n / 1e3)
        else -> n.toString()
    }

    fun duration(sec: Long): String =
        if (sec <= 0) "" else if (sec >= 3600) String.format(Locale.US, "%d:%02d:%02d", sec / 3600, sec / 60 % 60, sec % 60)
        else String.format(Locale.US, "%d:%02d", sec / 60, sec % 60)
}
