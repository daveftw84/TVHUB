package com.example.tvhub

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Xtream Codes ("XC") API login: server address, username and password, like TiviMate's
 * "Xtream Codes" option. Channels and categories come from player_api.php; the guide from xmltv.php.
 */
object XtreamApi {
    data class Account(val server: String, val user: String, val pass: String)
    data class Info(val status: String, val expires: Long?, val maxConnections: Int, val formats: List<String>,
                    val activeConnections: Int = 0, val created: Long? = null, val timezone: String? = null, val trial: Boolean = false)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** For the username and password inside stream links (/live/user/pass/id.ts): kept as typed, like other IPTV apps,
     *  only escaping what would break the link. (Form-encoding them turned "@" into "%40" and broke some logins.) */
    private fun seg(s: String) = s.replace("%", "%25").replace(" ", "%20").replace("#", "%23").replace("?", "%3F").replace("/", "%2F")

    /** "example.com:8080" or "http://example.com:8080/" becomes "http://example.com:8080". */
    fun normalize(server: String): String {
        var s = server.trim().trimEnd('/')
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
        return s.removeSuffix("/player_api.php").removeSuffix("/get.php")
    }

    private fun api(a: Account, action: String?): String {
        var url = "${normalize(a.server)}/player_api.php?username=${enc(a.user)}&password=${enc(a.pass)}"
        if (action != null) url += "&action=$action"
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 60_000
        c.setRequestProperty("User-Agent", USER_AGENT)
        if (c.responseCode !in 200..299) throw IOException("The provider returned HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Checks the login. Throws with a readable message when it's wrong or expired. */
    fun login(a: Account): Info {
        val o = try {
            JSONObject(api(a, null))
        } catch (e: org.json.JSONException) {
            throw IOException("That doesn't look like an Xtream Codes server. Check the address.")
        }
        val u = o.optJSONObject("user_info") ?: throw IOException("The provider didn't accept the login.")
        if (u.optInt("auth", 0) != 1) throw IOException("Wrong username or password.")
        val status = u.optString("status")
        if (status.isNotEmpty() && !status.equals("Active", ignoreCase = true)) throw IOException("The account is $status.")
        val formats = u.optJSONArray("allowed_output_formats")?.let { f -> (0 until f.length()).map { f.optString(it) } } ?: emptyList()
        return Info(
            status = status,
            expires = u.optString("exp_date").toLongOrNull()?.let { it * 1000 },
            maxConnections = u.optString("max_connections").toIntOrNull() ?: 0,
            formats = formats,
            activeConnections = u.optString("active_cons").toIntOrNull() ?: 0,
            created = u.optString("created_at").toLongOrNull()?.let { it * 1000 },
            timezone = o.optJSONObject("server_info")?.optString("timezone")?.ifEmpty { null },
            trial = u.optString("is_trial") == "1",
        )
    }

    /** All live channels, grouped by the provider's categories, in the provider's order. */
    fun liveChannels(a: Account, forceHls: Boolean = false): List<Channel> {
        val info = login(a)
        val base = normalize(a.server)
        // The raw stream (.ts), or HLS (.m3u8) when asked for (Settings > Force HLS) or it's the only one offered.
        val ext = if (forceHls && ("m3u8" in info.formats || info.formats.isEmpty())) "m3u8"
            else if (info.formats.isEmpty() || "ts" in info.formats) "ts" else "m3u8"
        Catchup.xcTimezone = info.timezone
        val cats = JSONArray(api(a, "get_live_categories")).let { arr ->
            (0 until arr.length()).map { arr.getJSONObject(it) }
                .associate { it.optString("category_id") to it.optString("category_name") }
        }
        // The provider's own order: its category list, then its channel numbers.
        val catOrder = cats.keys.withIndex().associate { it.value to it.index }
        val arr = JSONArray(api(a, "get_live_streams"))
        return (0 until arr.length()).map { arr.getJSONObject(it) }
            .withIndex().sortedWith(compareBy<IndexedValue<JSONObject>>({ catOrder[it.value.optString("category_id")] ?: Int.MAX_VALUE },
                { it.value.optString("num").toIntOrNull() ?: Int.MAX_VALUE }, { it.index })).map { it.value }
            .mapNotNull { o ->
            val id = o.optString("stream_id").ifEmpty { return@mapNotNull null }
            Channel(
                name = o.optString("name").trim(),
                url = "$base/live/${seg(a.user)}/${seg(a.pass)}/$id.$ext",
                group = cats[o.optString("category_id")] ?: "Other",
                logo = o.optString("stream_icon").ifEmpty { null },
                tvgId = o.optString("epg_channel_id").ifEmpty { null },
                archiveDays = if (o.optString("tv_archive") == "1") o.optString("tv_archive_duration").toIntOrNull() ?: 1 else 0,
                // Xtream Codes catch-up: /timeshift/user/pass/minutes/start/stream.ts
                catchupSource = "$base/timeshift/${seg(a.user)}/${seg(a.pass)}/{duration}/{xcstart}/$id.ts",
            )
        }
    }

    /** The provider's guide for its channels. */
    fun guideUrl(a: Account) = "${normalize(a.server)}/xmltv.php?username=${enc(a.user)}&password=${enc(a.pass)}"
}
