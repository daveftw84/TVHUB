package com.example.tvhub

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

/** "Set reminder": a notification when a game or programme starts. */
object Reminders {
    private const val CHANNEL = "reminders"

    data class Item(val id: String, val title: String, val text: String, val at: Long)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)

    /** Upcoming reminders (Settings > Recordings, Reminders and Downloads). */
    fun list(ctx: Context): List<Item> = try {
        val a = org.json.JSONArray(prefs(ctx).getString("reminders", "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }.map { Item(it.getString("id"), it.optString("title"), it.optString("text"), it.optLong("at")) }
            .filter { it.at > System.currentTimeMillis() - 3_600_000L }.sortedBy { it.at }
    } catch (_: Exception) { emptyList() }

    private fun saveList(ctx: Context, items: List<Item>) {
        val a = org.json.JSONArray()
        items.forEach { a.put(org.json.JSONObject().put("id", it.id).put("title", it.title).put("text", it.text).put("at", it.at)) }
        prefs(ctx).edit().putString("reminders", a.toString()).apply()
    }

    private fun schedule(ctx: Context, name: String, nid: Int, title: String, text: String, atMs: Long) {
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay((atMs - System.currentTimeMillis()).coerceAtLeast(0), TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("title" to title, "text" to text, "id" to nid))
            .addTag("reminder")
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(name, androidx.work.ExistingWorkPolicy.REPLACE, req)
    }

    /** A reminder [atMs] (when it starts), shown early by the default offset, plus an optional second one. */
    fun set(ctx: Context, id: String, title: String, text: String, atMs: Long) {
        Opt.init(ctx)
        val first = Opt.int(Opt.REMIND, 1)
        schedule(ctx, "reminder-$id", id.hashCode(), title, if (first > 0) "Starts in $first min" + text.removePrefix("Starting now") else text, atMs - first * 60_000L)
        if (Opt.bool(Opt.REMIND2, false)) {
            val second = Opt.int(Opt.REMIND2_OFFSET, 10)
            schedule(ctx, "reminder2-$id", id.hashCode() + 1, title, "Starts in $second min" + text.removePrefix("Starting now"), atMs - second * 60_000L)
        }
        prefs(ctx).edit().putLong("reminder-$id", atMs).apply()
        saveList(ctx, list(ctx).filter { it.id != id } + Item(id, title, text, atMs))
    }

    fun cancel(ctx: Context, id: String) {
        WorkManager.getInstance(ctx).cancelUniqueWork("reminder-$id")
        WorkManager.getInstance(ctx).cancelUniqueWork("reminder2-$id")
        prefs(ctx).edit().remove("reminder-$id").apply()
        saveList(ctx, list(ctx).filter { it.id != id })
    }

    fun isSet(ctx: Context, id: String): Boolean = prefs(ctx).getLong("reminder-$id", 0) > System.currentTimeMillis()

    fun notify(ctx: Context, nid: Int, title: String, text: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(ctx, nid, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title).setContentText(text)
            .setContentIntent(open).setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try { nm.notify(nid, n) } catch (_: SecurityException) {}
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        Reminders.notify(applicationContext, inputData.getInt("id", 1), inputData.getString("title").orEmpty(), inputData.getString("text").orEmpty())
        return Result.success()
    }
}
