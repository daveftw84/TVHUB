package com.example.tvhub

import android.app.Application
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class LiveViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = AppPrefs(app)
    val player: ExoPlayer = buildPlayer(app)

    /** The Live TV player, built with Settings > Playback: buffer size, real-time streams, user agent, captions. */
    private fun buildPlayer(app: Application): ExoPlayer {
        Opt.init(app)
        val buffer = Opt.str("buffer_size", "default")
        val realtime = Opt.bool("realtime_live", false)
        val (minMs, maxMs, startMs) = when {
            realtime -> Triple(1_000, 8_000, 500)
            buffer == "xs" -> Triple(2_000, 10_000, 1_000)
            buffer == "s" -> Triple(8_000, 25_000, 1_500)
            buffer == "big" -> Triple(30_000, 90_000, 3_000)
            buffer == "xl" -> Triple(60_000, 180_000, 5_000)
            else -> Triple(15_000, 50_000, 2_500)
        }
        val load = androidx.media3.exoplayer.DefaultLoadControl.Builder()
            .setBufferDurationsMs(minMs, maxMs, startMs, startMs * 2).build()
        val ua = Opt.str("user_agent", "").ifBlank { USER_AGENT }
        val http = androidx.media3.datasource.DefaultHttpDataSource.Factory().setUserAgent(ua).setAllowCrossProtocolRedirects(true)
        val sources = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(app).setDataSourceFactory(http)
        if (realtime) sources.setLiveTargetOffsetMs(2_000)
        val renderers = androidx.media3.exoplayer.DefaultRenderersFactory(app).setEnableDecoderFallback(true)
            .setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        return ExoPlayer.Builder(app, renderers).setLoadControl(load).setMediaSourceFactory(sources).build().apply {
            if (Opt.bool(Opt.ALWAYS_CC, false)) {
                trackSelectionParameters = trackSelectionParameters.buildUpon().setSelectUndeterminedTextLanguage(true)
                    .setPreferredTextLanguage(java.util.Locale.getDefault().language).build()
            }
            addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlaybackStateChanged(state: Int) { onState(state) }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    // Xtream Codes .ts stream refused? Try the same channel as HLS (.m3u8) once before giving up.
                    val cur = current
                    if (cur != null && !triedHls && cur.url.endsWith(".ts") && "/live/" in cur.url) {
                        triedHls = true
                        player.setMediaItem(MediaItem.fromUri(cur.url.removeSuffix(".ts") + ".m3u8"))
                        player.prepare()
                        player.playWhenReady = playbackAllowed
                        return
                    }
                    playError = describe(error)
                    if (Opt.bool(Opt.LIVE_RECONNECT, false)) reconnect()
                }
                override fun onIsPlayingChanged(isPlaying: Boolean) { if (isPlaying) playError = null }
            })
        }
    }

    // --- Auto stream reconnect: reload after 5 seconds of buffering ---
    private var stallJob: Job? = null
    private fun onState(state: Int) {
        connecting = state == androidx.media3.common.Player.STATE_BUFFERING
        stallJob?.cancel()
        if (state == androidx.media3.common.Player.STATE_BUFFERING && Opt.bool(Opt.LIVE_RECONNECT, false)) {
            stallJob = viewModelScope.launch { delay(5_000); if (player.playbackState == androidx.media3.common.Player.STATE_BUFFERING) reconnect() }
        }
    }
    private fun reconnect() {
        viewModelScope.launch {
            delay(1_000)
            val cur = current ?: return@launch
            player.setMediaItem(MediaItem.fromUri(cur.url))
            player.prepare()
            player.playWhenReady = playbackAllowed
        }
    }

    // --- Catch-up ---
    /** Plays a programme that already aired, from the provider's archive. Returns false if it doesn't have it. */
    fun playCatchup(ch: Channel, p: Programme): Boolean {
        if (!Catchup.providerHas(ch, p, Opt.str(Opt.CATCHUP, "auto"))) return false
        val u = Catchup.url(ch, p) ?: return false
        if (current?.url != ch.url) last = current
        current = ch
        catchupOf = p
        player.setMediaItem(MediaItem.fromUri(u))
        player.prepare()
        player.playWhenReady = true
        return true
    }
    /** The programme being watched from the archive (null when live). */
    var catchupOf by mutableStateOf<Programme?>(null)
        private set

    // --- Watch time per channel (Home's Top 10 Watched Channels) ---
    var watchTime by mutableStateOf(loadWatch())
        private set
    private fun loadWatch(): Map<String, Long> = try {
        val o = org.json.JSONObject(getApplication<Application>().getSharedPreferences("tvhub", android.content.Context.MODE_PRIVATE).getString("watch_time", "{}") ?: "{}")
        o.keys().asSequence().associateWith { o.getLong(it) }
    } catch (_: Exception) { emptyMap() }
    private fun saveWatch() {
        val o = org.json.JSONObject()
        watchTime.forEach { (k, v) -> o.put(k, v) }
        getApplication<Application>().getSharedPreferences("tvhub", android.content.Context.MODE_PRIVATE).edit().putString("watch_time", o.toString()).apply()
    }
    val topWatched: List<Pair<Channel, Long>> by derivedStateOf {
        val byKey = channels.associateBy { it.key }
        watchTime.entries.sortedByDescending { it.value }.mapNotNull { (k, v) -> byKey[k]?.let { it to v } }.take(10)
    }

    // --- Recently added channels (new since earlier loads) ---
    var recentlyAdded by mutableStateOf<List<Channel>>(emptyList())
        private set
    private fun markNew(list: List<Channel>) {
        val p = getApplication<Application>().getSharedPreferences("tvhub", android.content.Context.MODE_PRIVATE)
        val key = "seen_" + (Playlists.active?.id ?: "x")
        val seen = try { org.json.JSONObject(p.getString(key, "{}") ?: "{}") } catch (_: Exception) { org.json.JSONObject() }
        val first = seen.length() == 0
        val now = System.currentTimeMillis()
        for (c in list) if (!seen.has(c.key)) seen.put(c.key, if (first) 0L else now)
        p.edit().putString(key, seen.toString()).apply()
        val week = now - 7 * 86_400_000L
        recentlyAdded = list.filter { seen.optLong(it.key) > week }.distinctBy { it.key }.sortedByDescending { seen.optLong(it.key) }.take(30)
    }

    /** Every channel from the playlist, before your order and hidden choices. */
    var allChannels by mutableStateOf<List<Channel>>(emptyList())
        private set
    var epg by mutableStateOf<Map<String, List<Programme>>>(emptyMap())
        private set
    /** Guide channel ids by normalized channel name, for channels whose tvg-id doesn't match. */
    private var guideIdsByName by mutableStateOf<Map<String, String>>(emptyMap())
    var guideUpdatedAt by mutableStateOf(0L)
        private set

    // --- Your lineup: group order, channel order, hidden groups and channels ---
    var groupOrder by mutableStateOf(prefs.groupOrder)
        private set
    var channelOrder by mutableStateOf(prefs.channelOrder)
        private set
    var hiddenGroups by mutableStateOf(prefs.hiddenGroups)
        private set
    var hiddenChannels by mutableStateOf(prefs.hiddenChannels)
        private set

    /** Groups in your order (new groups at the end, in playlist order). */
    val allGroups: List<String> by derivedStateOf {
        val raw = allChannels.map { it.group }.distinct()
        val pos = groupOrder.withIndex().associate { it.value to it.index }
        raw.withIndex().sortedBy { pos[it.value] ?: (100_000 + it.index) }.map { it.value }
    }

    /** Your channels: grouped in your group order, each group in your channel order, hidden ones left out. */
    val channels: List<Channel> by derivedStateOf {
        val pos = channelOrder.withIndex().associate { it.value to it.index }
        val gpos = allGroups.withIndex().associate { it.value to it.index }
        allChannels.withIndex()
            .filter { it.value.group !in hiddenGroups && it.value.key !in hiddenChannels }
            .sortedWith(compareBy({ gpos[it.value.group] ?: 0 }, { pos[it.value.key] ?: (100_000 + it.index) }))
            .map { it.value }
    }
    var current by mutableStateOf<Channel?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var favorites by mutableStateOf(prefs.favorites)
        private set
    var groupIndex by mutableIntStateOf(0)
        private set

    /** Keep Live TV playing in a small window while you use other tabs. */
    var miniPlayer by mutableStateOf(prefs.miniPlayer)
        private set

    fun toggleMiniPlayer() {
        miniPlayer = !miniPlayer
        prefs.miniPlayer = miniPlayer
    }

    /** False while another tab is showing, so channel changes from Home don't start sound there. */
    var playbackAllowed = true

    /** Channels you watched, newest first (for Home). */
    private var recentKeys by mutableStateOf(prefs.recentChannels)
    val recentChannels: List<Channel> by derivedStateOf {
        val byKey = channels.associateBy { it.key }
        recentKeys.mapNotNull { byKey[it] }
    }

    private var last: Channel? = null
    private var loadJob: Job? = null

    val groups: List<String> by derivedStateOf {
        listOf("All", "Favorites", "Sports") + allGroups.filter { it !in hiddenGroups }
    }
    val groupName: String by derivedStateOf { groups.getOrElse(groupIndex) { "All" } }
    val visibleChannels: List<Channel> by derivedStateOf {
        when (groupName) {
            "All" -> channels
            "Favorites" -> channels.filter { it.key in favorites }
            "Sports" -> channels.filter { Sports.isSportsChannel(it.name) || Sports.isSportsChannel(it.group) }
            else -> channels.filter { it.group == groupName }
        }
    }

    /** What the last load did, step by step (shown after adding a playlist). Ends with "done" or "failed". */
    var loadLog by mutableStateOf<List<String>>(emptyList())
        private set
    var loadState by mutableStateOf("")      // loading, done, failed
        private set
    private fun log(line: String) { loadLog = loadLog + line }

    /** (Re)loads playlist and guide from the saved settings. */
    fun reload() {
        loadJob?.cancel()
        val app = getApplication<Application>()
        Playlists.load(app)
        val pl = Playlists.active
        error = null
        if (pl == null) {
            allChannels = emptyList()
            epg = emptyMap()
            error = "No playlist yet. Open Settings > Manage Playlists to add one."
            return
        }
        val xc = XtreamApi.Account(pl.server.trim(), pl.user.trim(), pl.pass)
        // With an Xtream Codes login the provider's own guide is used, unless a custom guide is set.
        val guide = pl.epgCustom.trim().ifEmpty { if (pl.type == "xc") XtreamApi.guideUrl(xc) else "" }
        loadLog = emptyList(); loadState = "loading"
        log("Starting playlist download…")
        loadJob = viewModelScope.launch {
            try {
                log("Getting channels…")
                allChannels = withContext(Dispatchers.IO) {
                    if (pl.type == "xc") XtreamApi.liveChannels(xc, Opt.bool(Opt.FORCE_HLS, false)) else M3uParser.fetch(pl.url.trim())
                }
                groupIndex = if (Opt.bool("live_favorites_default", false) && favorites.isNotEmpty()) 1 else 0   // 1 = Favorites
                log("Found ${allChannels.size} channels")
                Playlists.touched(app, pl.id)
                markNew(allChannels)
                (recentChannels.firstOrNull() ?: channels.firstOrNull())?.let { play(it, remember = false) }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                error = (if (pl.type == "xc") "Xtream Codes: " else "") + (e.message ?: "couldn't load channels")
                log("Couldn't load the playlist: ${e.message ?: "unknown error"}")
                loadState = "failed"
                return@launch
            }
            if (guide.isNotEmpty()) log("Downloading EPG content…") else log("No TV guide link for this playlist")
            loadGuide(guide)
            if (guide.isNotEmpty()) log("Found EPG for ${allChannels.count { programmesFor(it).isNotEmpty() }} channels")
            log("Almost done, finishing last things…")
            log("Playlist was added successfully!")
            loadState = "done"
        }
        // Playlist update interval (Settings > General).
        refreshPlaylistJob?.cancel()
        val hours = Opt.int("playlist_interval", 24)
        if (hours > 0) refreshPlaylistJob = viewModelScope.launch { delay(hours * HOUR); reload() }
    }
    private var refreshPlaylistJob: Job? = null

    /** Switches Live TV to another playlist. */
    fun usePlaylist(id: String) {
        Playlists.select(getApplication(), id)
        reload()
    }

    private var guideUrl = ""
    private var refreshJob: Job? = null

    private suspend fun loadGuide(guide: String) {
        guideUrl = guide
        if (guide.isEmpty()) {
            epg = emptyMap()
            loadSports()
            return
        }
        // The guide is optional: failures just leave it empty.
        try {
            val ids = allChannels.mapNotNull { it.tvgId }.toSet()
            val names = allChannels.map { normalizeChannelName(it.name) }.filter { it.isNotEmpty() }.toSet()
            val now = System.currentTimeMillis()
            val g = withContext(Dispatchers.IO) {
                XmltvParser.fetch(guide, ids, names, now - 24 * HOUR, now + 30 * HOUR)
            }
            // Settings > General > EPG offset (hours), for guides in the wrong time zone.
            val shift = Opt.int("epg_offset", 0) * HOUR
            epg = if (shift == 0L) g.programmes else g.programmes.mapValues { (_, l) -> l.map { it.copy(start = it.start + shift, end = it.end + shift) } }
            guideIdsByName = g.idsByName
            guideUpdatedAt = System.currentTimeMillis()
        } catch (_: Exception) {
        }
        loadSports()
        // Keep the guide fresh while the app runs (it's always downloaded again at start-up).
        if (refreshJob?.isActive != true) {
            refreshJob = viewModelScope.launch {
                while (true) {
                    delay(4 * HOUR)
                    if (guideUrl.isNotEmpty()) loadGuide(guideUrl)
                }
            }
        }
    }

    // ------------------------------------------------------------ Sports

    var sportsEvents by mutableStateOf<List<SportsEvent>>(emptyList())
        private set
    var sportsMessage by mutableStateOf<String?>(null)
        private set
    var sportsFavorites by mutableStateOf(prefs.sportsFavorites)
        private set
    private var sportsJob: Job? = null

    /** Rebuilds the Sports section from the guide (and TheSportsDB, when a key is set). */
    fun loadSports() {
        sportsJob?.cancel()
        sportsJob = viewModelScope.launch {
            val guideEvents = withContext(Dispatchers.Default) { Sports.fromGuide(this@LiveViewModel) }
            sportsEvents = guideEvents
            val key = prefs.sportsDbKey.trim()
            sportsMessage = null
            if (key.isNotEmpty()) {
                val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("UTC")
                }
                val now = System.currentTimeMillis()
                // UTC today and tomorrow, so evening games in the Americas are included.
                val listings = try {
                    withContext(Dispatchers.IO) {
                        listOf(now, now + 24 * HOUR).flatMap { Sports.fromListings(key, prefs.sportsCountry, day.format(java.util.Date(it)), this@LiveViewModel) }
                    }
                } catch (e: Exception) {
                    sportsMessage = "Sports listings: ${e.message}"
                    emptyList()
                }
                val soon = listings.filter { it.end > now && it.start < now + 30 * HOUR }
                sportsEvents = Sports.merge(guideEvents, soon)
            }
        }
    }

    fun updateSportsFavorites(list: List<String>) {
        sportsFavorites = list
        prefs.sportsFavorites = list
    }

    /** Downloads the guide again now. */
    fun refreshGuide() {
        if (guideUrl.isNotEmpty()) viewModelScope.launch { loadGuide(guideUrl) }
    }

    /** This channel's guide: by its tvg-id, or else by its name. */
    fun programmesFor(ch: Channel): List<Programme> {
        ch.tvgId?.let { id -> epg[id]?.let { return it } }
        val id = guideIdsByName[normalizeChannelName(ch.name)] ?: return emptyList()
        return epg[id].orEmpty()
    }

    // ------------------------------------------------------------ Managing the lineup

    fun moveGroup(g: String, delta: Int) {
        val list = allGroups.toMutableList()
        val i = list.indexOf(g)
        val j = i + delta
        if (i < 0 || j !in list.indices) return
        list.removeAt(i)
        list.add(j, g)
        groupOrder = list
        prefs.groupOrder = list
    }

    fun toggleGroupHidden(g: String) {
        hiddenGroups = if (g in hiddenGroups) hiddenGroups - g else hiddenGroups + g
        prefs.hiddenGroups = hiddenGroups
    }

    /** All channels of a group in your order, hidden ones included (for the manager). */
    fun groupChannels(g: String): List<Channel> {
        val pos = channelOrder.withIndex().associate { it.value to it.index }
        return allChannels.withIndex().filter { it.value.group == g }
            .sortedBy { pos[it.value.key] ?: (100_000 + it.index) }.map { it.value }.distinctBy { it.key }
    }

    fun moveChannel(ch: Channel, delta: Int) {
        val inGroup = groupChannels(ch.group).toMutableList()
        val i = inGroup.indexOfFirst { it.key == ch.key }
        val j = i + delta
        if (i < 0 || j !in inGroup.indices) return
        inGroup.removeAt(i)
        inGroup.add(j, ch)
        // Store the whole lineup's order so every group keeps its place.
        val order = allGroups.flatMap { g -> if (g == ch.group) inGroup else groupChannels(g) }.map { it.key }
        channelOrder = order
        prefs.channelOrder = order
    }

    fun toggleChannelHidden(ch: Channel) {
        hiddenChannels = if (ch.key in hiddenChannels) hiddenChannels - ch.key else hiddenChannels + ch.key
        prefs.hiddenChannels = hiddenChannels
    }

    fun resetLineup() {
        groupOrder = emptyList(); channelOrder = emptyList(); hiddenGroups = emptySet(); hiddenChannels = emptySet()
        prefs.groupOrder = emptyList(); prefs.channelOrder = emptyList(); prefs.hiddenGroups = emptySet(); prefs.hiddenChannels = emptySet()
    }

    // ------------------------------------------------------------ Artwork from Trakt for the guide

    /** Poster for a programme title (from the guide itself, or looked up on Trakt). Null until found. */
    val artwork = androidx.compose.runtime.mutableStateMapOf<String, String>()
    private val artworkAsked = HashSet<String>()

    fun artworkFor(p: Programme): String? {
        p.icon?.let { return it }
        val key = p.title.trim().lowercase()
        artwork[key]?.let { return it }
        if (Sports.isSportsProgramme(p)) return null    // Trakt has no sports
        val id = TraktAccount.clientId(getApplication())
        if (id.isEmpty() || key.length < 2) return null
        synchronized(artworkAsked) { if (!artworkAsked.add(key)) return null }
        viewModelScope.launch {
            val url = try { withContext(Dispatchers.IO) { TraktApi.lookupArtwork(id, p.title) } } catch (_: Exception) { null }
            if (url != null) artwork[key] = url
        }
        return null
    }

    // ------------------------------------------------------------ Trakt scrobbling for Live TV

    private data class LiveSession(val key: String, val media: JSONObject, val start: Long, val end: Long)

    private var liveSession: LiveSession? = null
    private val matchCache = HashMap<String, JSONObject?>()

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9]"), "")

    /**
     * Finds the guide programme on Trakt. Episodes need season and episode numbers in the guide;
     * movies need an exact, unambiguous title match. Anything uncertain is skipped, not guessed.
     */
    private fun matchOnTrakt(p: Programme): JSONObject? {
        val ctx = getApplication<Application>()
        val id = TraktAccount.clientId(ctx).ifEmpty { return null }
        val title = p.title.replace(Regex("(?i)^(new|movie|film|premiere)\\s*:\\s*"), "").trim()
        if (title.isEmpty()) return null
        val cacheKey = "${norm(title)}|${p.season}|${p.episode}|${p.year}"
        synchronized(matchCache) { if (matchCache.containsKey(cacheKey)) return matchCache[cacheKey] }
        val result: JSONObject? = try {
            if (p.season > 0 && p.episode > 0) {
                val hit = TraktApi.search(id, "show", title).firstOrNull { norm(it.title) == norm(title) }
                hit?.let {
                    JSONObject()
                        .put("show", JSONObject().put("ids", JSONObject().put("trakt", it.traktId)))
                        .put("episode", JSONObject().put("season", p.season).put("number", p.episode))
                }
            } else if (p.end - p.start >= 70 * 60_000L) {
                val hits = TraktApi.search(id, "movie", title).filter { norm(it.title) == norm(title) }
                val hit = if (p.year > 0) hits.firstOrNull { it.year == p.year } ?: hits.singleOrNull() else hits.singleOrNull()
                hit?.let { JSONObject().put("movie", JSONObject().put("ids", JSONObject().put("trakt", it.traktId))) }
            } else {
                null
            }
        } catch (_: Exception) {
            return null   // network trouble: try again next time, don't cache
        }
        synchronized(matchCache) { matchCache[cacheKey] = result }
        return result
    }

    private fun progress(s: LiveSession, now: Long) =
        ((now - s.start) * 100.0 / (s.end - s.start).coerceAtLeast(1)).coerceIn(0.0, 100.0)

    /** Checks what's playing and tells Trakt (start / pause / stop), at most once a minute. */
    private suspend fun checkLiveScrobble() {
        val ctx = getApplication<Application>()
        if (!prefs.scrobbleLive || !TraktAccount.signedIn || !TraktAccount.scrobbleOn) {
            liveSession = null
            return
        }
        val now = System.currentTimeMillis()
        val ch = current
        val playing = player.isPlaying
        val prog = ch?.let { nowNext(it, now).first }
        val key = if (ch != null && prog != null) "live:${ch.key}:${prog.start}" else null
        val s = liveSession
        if (s != null && s.key != key) {
            withContext(Dispatchers.IO) { TraktAccount.scrobble(ctx, s.key, "stopped", progress(s, now), s.media) }
            liveSession = null
        } else if (s != null) {
            withContext(Dispatchers.IO) {
                TraktAccount.scrobble(ctx, s.key, if (playing) "playing" else "paused", progress(s, now), s.media)
            }
        }
        if (key != null && prog != null && playing && liveSession == null) {
            val media = withContext(Dispatchers.IO) { matchOnTrakt(prog) } ?: return
            val n = LiveSession(key, media, prog.start, prog.end)
            liveSession = n
            withContext(Dispatchers.IO) { TraktAccount.scrobble(ctx, key, "playing", progress(n, now), media) }
        }
    }

    private val scrobbleLoop = viewModelScope.launch {
        TraktAccount.load(app)
        while (true) {
            delay(15_000)
            try {
                checkLiveScrobble()
            } catch (_: Exception) {
            }
            delay(45_000)
        }
    }

    val favoriteChannels: List<Channel> by derivedStateOf { channels.filter { it.key in favorites }.distinctBy { it.key } }

    // --- Mobile list ---

    /** True while the phone shows the channel list (nothing plays until you pick a channel). */
    var listMode by mutableStateOf(false)

    /** A search to open on Live TV (from Sports: "Search \"Denver Broncos\""). */
    var searchRequest by mutableStateOf<String?>(null)

    /** Names you gave channels ("Edit name"). */
    var customNames by mutableStateOf(loadNames())
        private set

    private fun loadNames(): Map<String, String> = try {
        val o = org.json.JSONObject(getApplication<Application>().getSharedPreferences("tvhub", android.content.Context.MODE_PRIVATE)
            .getString("channel_names", "{}") ?: "{}")
        o.keys().asSequence().associateWith { o.getString(it) }
    } catch (_: Exception) { emptyMap() }

    fun nameOf(ch: Channel): String = customNames[ch.key] ?: ch.name

    fun rename(ch: Channel, name: String) {
        customNames = if (name.isBlank() || name == ch.name) customNames - ch.key else customNames + (ch.key to name.trim())
        val o = org.json.JSONObject()
        customNames.forEach { (k, v) -> o.put(k, v) }
        getApplication<Application>().getSharedPreferences("tvhub", android.content.Context.MODE_PRIVATE).edit()
            .putString("channel_names", o.toString()).apply()
    }

    /** The "Recently Watched" chip on phones. */
    var recentOnly by mutableStateOf(false)

    /** Sort the list A to Z (else your order). */
    var sortAz by mutableStateOf(false)

    /** A programme in the guide that matched a search. */
    data class ProgrammeHit(val channel: Channel, val programme: Programme)

    /** Channels whose name matches, and guide programmes (on now or later) whose title matches. */
    fun searchLive(q: String): Pair<List<Channel>, List<ProgrammeHit>> {
        // "A | B | C" finds any of them (used for "Search all known channels").
        if (q.contains(" | ")) {
            val parts = q.split(" | ").map { searchLive(it) }
            return parts.flatMap { it.first }.distinctBy { it.key }.take(60) to parts.flatMap { it.second }.distinctBy { it.channel.key + it.programme.start }.sortedBy { it.programme.start }.take(80)
        }
        val t = q.trim().lowercase()
        if (t.length < 2) return emptyList<Channel>() to emptyList()
        val words = t.split(Regex("\\s+"))
        fun hit(s: String) = s.lowercase().let { low -> words.all { low.contains(it) } }
        val chans = channels.filter { hit(nameOf(it)) || hit(it.name) }.take(40)
        val now = System.currentTimeMillis()
        val progs = ArrayList<ProgrammeHit>()
        for (ch in channels.distinctBy { it.key }) {
            for (p in programmesFor(ch)) if (p.end > now && (hit(p.title) || hit(p.subTitle))) progs += ProgrammeHit(ch, p)
        }
        return chans to progs.sortedBy { it.programme.start }.take(60)
    }

    /** Why the channel won't play (shown over the video), or null. */
    var playError by mutableStateOf<String?>(null)

    private fun describe(e: androidx.media3.common.PlaybackException): String {
        var c: Throwable? = e
        while (c != null) {
            if (c is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
                return when (c.responseCode) {
                    401, 403 -> "Your provider refused this stream (HTTP ${c.responseCode}). Often: too many devices using your account at once (close other IPTV apps), or the login expired."
                    404 -> "This channel is offline (HTTP 404)."
                    458, 509, 429 -> "Too many connections on your account (HTTP ${c.responseCode}). Close other IPTV apps and try again."
                    else -> "The stream failed (HTTP ${c.responseCode})."
                }
            }
            if (c is java.net.UnknownHostException) return "Can't reach your provider's server (no internet, or a VPN/DNS is blocking it)."
            c = c.cause
        }
        return when (e.errorCode) {
            androidx.media3.common.PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            androidx.media3.common.PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ->
                "This stream's format isn't supported. Try Settings → Playback → Force HLS format (then reload channels), or another player."
            androidx.media3.common.PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            androidx.media3.common.PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> "Couldn't connect to the stream."
            androidx.media3.common.PlaybackException.ERROR_CODE_DECODING_FAILED,
            androidx.media3.common.PlaybackException.ERROR_CODE_DECODER_INIT_FAILED -> "This device can't decode this channel's video."
            else -> "Can't play this channel: ${e.errorCodeName}"
        }
    }

    fun retry() { current?.let { play(it, remember = false) } }

    private var triedHls = false
    /** True while a channel is loading (shown as "Connecting…"). */
    var connecting by mutableStateOf(false)
        private set

    fun play(ch: Channel, remember: Boolean = true) {
        playError = null
        triedHls = false
        updateCornerChoices()
        catchupOf = null
        if (current?.url != ch.url) last = current
        current = ch
        player.setMediaItem(MediaItem.fromUri(ch.url))
        player.prepare()
        player.playWhenReady = playbackAllowed
        if (remember) {
            recentKeys = (listOf(ch.key) + recentKeys.filter { it != ch.key }).take(20)
            prefs.recentChannels = recentKeys
        }
        viewModelScope.launch {
            delay(5_000)   // let it start, then tell Trakt about the channel change
            try { checkLiveScrobble() } catch (_: Exception) {}
        }
    }

    private fun step(delta: Int) {
        val list = visibleChannels
        if (list.isEmpty()) return
        val i = list.indexOfFirst { it.url == current?.url }
        play(list[(if (i < 0) 0 else i + delta).mod(list.size)])
    }

    fun next() = step(1)
    fun previous() = step(-1)
    fun playLast() { last?.let { play(it) } }

    fun cycleGroup() { groupIndex = (groupIndex + 1) % groups.size }
    fun selectGroup(i: Int) { if (i in groups.indices) groupIndex = i }

    fun toggleFavorite(ch: Channel) {
        favorites = if (ch.key in favorites) favorites - ch.key else favorites + ch.key
        prefs.favorites = favorites
    }

    /** Current and next programme for a channel, if guide data exists. */
    fun nowNext(ch: Channel, now: Long = System.currentTimeMillis()): Pair<Programme?, Programme?> {
        val list = programmesFor(ch).ifEmpty { return null to null }
        val idx = list.indexOfFirst { now >= it.start && now < it.end }
        return if (idx >= 0) list[idx] to list.getOrNull(idx + 1)
        else null to list.firstOrNull { it.start > now }
    }

    // ------------------------------------------------------------ Corner windows (picture-in-picture)

    /** A channel tapped while choosing a corner window goes there; otherwise it plays as usual. */
    fun choose(ch: Channel) {
        if (Corners.picking) Corners.addChannel(getApplication(), ch)?.let { error = it } else play(ch)
    }

    /** A corner channel becomes the main picture, and the main channel takes its corner. */
    fun swapCorner(slot: Corners.Slot) {
        val ch = slot.channel ?: return Corners.toggleSound(slot.id)
        val main = current
        Corners.close(slot.id)
        play(ch)
        if (main != null) Corners.addChannel(getApplication(), main)
        // "Unmute fullscreen": the picture that becomes main gets the sound.
        if (Opt.bool("mv_unmute_full", true)) Corners.giveSoundToMain()
    }

    /**
     * Every picture moves one place: the main channel goes to the first window, each window moves along,
     * and the last window's channel becomes the main picture. (Plex windows just move along.)
     */
    fun rotateScreens() {
        val last = Corners.slots.lastOrNull() ?: return
        val ch = last.channel ?: return Corners.rotateWindows()
        val main = current
        Corners.close(last.id)
        play(ch)
        if (main != null && Corners.addChannel(getApplication(), main) == null) {
            Corners.slots.lastOrNull()?.let { Corners.moveToFront(it.id) }
        }
    }

    /** Channels offered when adding a corner window from a game: recent and favorites first. */
    private fun updateCornerChoices() {
        Corners.channelChoices = (recentChannels + favoriteChannels + channels).distinctBy { it.key }.take(400)
    }

    override fun onCleared() { player.release() }

    companion object { const val HOUR = 3_600_000L }

    // Last, so every property above is ready before the first load (it uses several of them).
    init {
        reload()
        // Count watching time per channel (only while it plays).
        viewModelScope.launch {
            while (true) {
                delay(30_000)
                val c = current
                if (c != null && player.isPlaying && catchupOf == null) {
                    watchTime = watchTime + (c.key to ((watchTime[c.key] ?: 0L) + 30_000L))
                    saveWatch()
                }
            }
        }
    }
}
