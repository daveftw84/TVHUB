package com.example.tvhub

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL
import java.util.concurrent.Executors

/** Sending to a TV running TV Hub: finding it on the network, casting, and being its game controller. */
object CastSend {
    data class Tv(val name: String, val base: String, val room: String?, val game: String?)

    private fun get(url: String, timeout: Int = 2500): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeout
        c.readTimeout = timeout
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun post(url: String, body: JSONObject, timeout: Int = 4000): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = timeout
        c.readTimeout = timeout
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    }

    private fun probe(base: String): Tv? = try {
        val o = JSONObject(get("$base/tvhub"))
        if (o.optString("app") != "TV Hub") null
        else Tv(o.optString("name", "TV"), base, o.optString("room").takeIf { it.isNotEmpty() && it != "null" },
            o.optString("game").takeIf { it.isNotEmpty() && it != "null" })
    } catch (_: Exception) { null }

    /** Finds TVs running TV Hub on this network (by the same discovery casting apps use), plus a saved address. */
    fun discover(ctx: Context): List<Tv> {
        val bases = LinkedHashSet<String>()
        savedAddress(ctx)?.let { bases += it }
        try {
            val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? android.net.wifi.WifiManager
            val lock = wifi?.createMulticastLock("tvhub-find")?.apply { acquire() }
            DatagramSocket().use { s ->
                s.soTimeout = 600
                val msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\n" +
                    "ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n"
                repeat(2) { s.send(DatagramPacket(msg.toByteArray(), msg.length, InetAddress.getByName("239.255.255.250"), 1900)) }
                val end = System.currentTimeMillis() + 2500
                val buf = ByteArray(2048)
                while (System.currentTimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val loc = Regex("(?im)^LOCATION:\\s*(\\S+)").find(String(p.data, 0, p.length))?.groupValues?.get(1) ?: continue
                        val u = URL(loc)
                        if (loc.contains("/dlna/desc.xml")) bases += "http://${u.host}:${u.port}"
                    } catch (_: SocketTimeoutException) {
                    }
                }
            }
            lock?.release()
        } catch (_: Exception) {
        }
        return bases.mapNotNull { probe(it) }.distinctBy { it.base }
    }

    /** Tries an address typed by hand ("192.168.1.20", or with a port). */
    fun connect(ctx: Context, address: String): Tv? {
        val a = address.trim().removePrefix("http://").trimEnd('/')
        val candidates = if (a.contains(':')) listOf("http://$a") else (CastHub.FIRST_PORT..CastHub.FIRST_PORT + 9).map { "http://$a:$it" }
        for (b in candidates) probe(b)?.let { tv -> saveAddress(ctx, tv.base); return tv }
        return null
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)
    fun savedAddress(ctx: Context): String? = prefs(ctx).getString("cast_tv", null)
    fun saveAddress(ctx: Context, base: String) = prefs(ctx).edit().putString("cast_tv", base).apply()

    fun cast(tv: Tv, req: CastRequest) {
        post("${tv.base}/cast", JSONObject().put("type", req.type).put("url", req.url).put("title", req.title).put("startMs", req.startMs)
            .put("ratingKey", req.ratingKey).put("channelKey", req.channelKey).put("rommId", req.rommId)
            .put("artist", req.artist).put("art", req.art))
    }

    // --- Being a game controller ---

    private val sender = Executors.newSingleThreadExecutor()

    fun press(base: String, token: String, key: String, down: Boolean) {
        sender.execute { runCatching { post("$base/room/input", JSONObject().put("token", token).put("key", key).put("down", down), 2000) } }
    }
}

/** "Cast to TV": finds TVs with TV Hub and sends [request] to the one you pick. */
@Composable
fun CastDialog(request: CastRequest, onDismiss: () -> Unit, onCast: ((CastSend.Tv) -> Unit)? = null) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tvs by remember { mutableStateOf<List<CastSend.Tv>?>(null) }
    var address by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { tvs = withContext(Dispatchers.IO) { CastSend.discover(ctx) } }
    fun send(tv: CastSend.Tv) {
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { CastSend.cast(tv, request) } }
            if (r.isSuccess) {
                CastSend.saveAddress(ctx, tv.base)
                Toast.makeText(ctx, "Sent to ${tv.name}", Toast.LENGTH_SHORT).show()
                onCast?.invoke(tv)
                onDismiss()
            } else status = "Couldn't send: ${r.exceptionOrNull()?.message}"
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cast to TV") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(request.title.ifEmpty { "This" } + " will play on the TV you pick.", style = MaterialTheme.typography.bodySmall)
                when (val list = tvs) {
                    null -> Text("Looking for TVs with TV Hub on your network…")
                    else -> {
                        if (list.isEmpty()) Text("No TVs found. Open TV Hub on the TV (same Wi-Fi), or type its address.")
                        list.forEach { tv -> ListRow(title = "📺 ${tv.name}", subtitle = tv.base.removePrefix("http://"), onClick = { send(tv) }) }
                    }
                }
                OutlinedTextField(value = address, onValueChange = { address = it }, singleLine = true,
                    label = { Text("TV address (Settings > Casting on the TV)") }, modifier = Modifier.fillMaxWidth())
                status?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    val tv = withContext(Dispatchers.IO) { CastSend.connect(ctx, address) }
                    if (tv == null) status = "No TV Hub at that address." else send(tv)
                }
            }, enabled = address.isNotBlank()) { Text("Connect") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** A small "Cast" button for phones (hidden on TVs). */
@Composable
fun CastButton(request: () -> CastRequest?, label: String = "📺 Cast", onCast: ((CastSend.Tv) -> Unit)? = null) {
    if (rememberIsTv()) return
    var req by remember { mutableStateOf<CastRequest?>(null) }
    OutlinedButton(onClick = { req = request() }, modifier = Modifier.focusRing(ButtonShape)) { Text(label) }
    req?.let { r -> CastDialog(r, onDismiss = { req = null }, onCast = onCast) }
}

/** Join a game on a TV by its code, then use this phone as the controller. */
@Composable
fun JoinGameDialog(onDismiss: () -> Unit, presetTv: CastSend.Tv? = null) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tvs by remember { mutableStateOf<List<CastSend.Tv>?>(presetTv?.let { listOf(it) }) }
    var tv by remember { mutableStateOf(presetTv) }
    var code by remember { mutableStateOf(presetTv?.room ?: "") }
    var name by remember { mutableStateOf(android.os.Build.MODEL) }
    var address by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    var joined by remember { mutableStateOf<Triple<String, String, String>?>(null) }   // base, token, title
    LaunchedEffect(Unit) { if (presetTv == null) tvs = withContext(Dispatchers.IO) { CastSend.discover(ctx) } }

    joined?.let { (base, token, title) ->
        PhonePad(base, token, title) {
            scope.launch(Dispatchers.IO) { runCatching { CastSend.post("$base/room/leave", JSONObject().put("token", token)) } }
            joined = null
            onDismiss()
        }
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Join a game") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Pick the TV (on your network) and type the code shown on it.", style = MaterialTheme.typography.bodySmall)
                when (val list = tvs) {
                    null -> Text("Looking for TVs…")
                    else -> list.forEach { t ->
                        ListRow(title = (if (t == tv) "✓ " else "") + "📺 ${t.name}", subtitle = t.game?.let { "Playing $it" } ?: "No game open",
                            selected = t == tv, onClick = { tv = t; if (code.isEmpty()) code = t.room ?: "" })
                    }
                }
                OutlinedTextField(value = address, onValueChange = { address = it }, singleLine = true, label = { Text("…or the TV's address") },
                    modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = code, onValueChange = { code = it.uppercase().take(6) }, singleLine = true, label = { Text("Game code") },
                    modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Your name") }, modifier = Modifier.fillMaxWidth())
                status?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    val target = tv ?: withContext(Dispatchers.IO) { CastSend.connect(ctx, address) }
                    if (target == null) { status = "Pick a TV or type its address."; return@launch }
                    val r = withContext(Dispatchers.IO) {
                        runCatching { CastSend.post("${target.base}/room/join", JSONObject().put("code", code).put("name", name)) }
                    }
                    val o = r.getOrNull()
                    if (o == null || !o.optBoolean("ok")) status = o?.optString("error") ?: "Couldn't reach the TV."
                    else joined = Triple(target.base, o.getString("token"), "Player ${o.optInt("player")} · ${o.optString("game")}")
                }
            }, enabled = code.length == 6) { Text("Join") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** This phone as a game controller for the TV (full screen). */
@Composable
fun PhonePad(base: String, token: String, title: String, onLeave: () -> Unit) {
    Dialog(onDismissRequest = onLeave, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF111111))) {
            val view = androidx.compose.ui.platform.LocalView.current
            @Composable
            fun pad(key: String, label: String, x: androidx.compose.ui.unit.Dp, y: androidx.compose.ui.unit.Dp, w: androidx.compose.ui.unit.Dp = 70.dp,
                    h: androidx.compose.ui.unit.Dp = 70.dp, round: Boolean = true) {
                var down by remember { mutableStateOf(false) }
                Box(
                    Modifier.offset(x, y).size(w, h).clip(if (round) CircleShape else RoundedCornerShape(20.dp))
                        .background(if (down) Color(0xFF666666) else Color(0xFF333333))
                        .pointerInput(key) {
                            detectTapGestures(onPress = {
                                down = true
                                view.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                                CastSend.press(base, token, key, true)
                                tryAwaitRelease()
                                down = false
                                CastSend.press(base, token, key, false)
                            })
                        },
                    contentAlignment = Alignment.Center,
                ) { Text(label, color = Color.White) }
            }
            val w = maxWidth
            val h = maxHeight
            val cy = h * 0.5f
            pad("up", "▲", 90.dp, cy - 80.dp); pad("down", "▼", 90.dp, cy + 60.dp)
            pad("left", "◀", 20.dp, cy - 10.dp); pad("right", "▶", 160.dp, cy - 10.dp)
            pad("x", "X", w - 170.dp, cy - 90.dp); pad("y", "Y", w - 245.dp, cy - 15.dp)
            pad("a", "A", w - 95.dp, cy - 15.dp); pad("b", "B", w - 170.dp, cy + 60.dp)
            pad("l", "L", 20.dp, 40.dp, 84.dp, 40.dp, false); pad("l2", "L2", 115.dp, 40.dp, 84.dp, 40.dp, false)
            pad("r2", "R2", w - 200.dp, 40.dp, 84.dp, 40.dp, false); pad("r", "R", w - 105.dp, 40.dp, 84.dp, 40.dp, false)
            pad("select", "Select", w / 2 - 95.dp, h - 70.dp, 84.dp, 40.dp, false); pad("start", "Start", w / 2 + 10.dp, h - 70.dp, 84.dp, 40.dp, false)
            Text(title, color = Color.White, modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp))
            TextButton(onClick = onLeave, modifier = Modifier.align(Alignment.BottomEnd)) { Text("Leave") }
        }
    }
}

/** Share an invite by text message (or any app). */
fun shareInvite(ctx: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
    ctx.startActivity(Intent.createChooser(i, "Invite players").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
