package com.example.tvhub

import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

// ---------------------------------------------------------------- Playlists Manager

@Composable
fun PlaylistsManager(live: LiveViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var actionsFor by remember { mutableStateOf<Playlist?>(null) }
    var editing by remember { mutableStateOf<Playlist?>(null) }
    var adding by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }
    var progress by remember { mutableStateOf(false) }
    // A new playlist becomes the one Live TV uses, and you see it load step by step.
    fun added(p: Playlist) { Playlists.upsert(ctx, p); live.usePlaylist(p.id); progress = true }
    val fmt = remember { SimpleDateFormat("HH:mm:ss dd/MM/yyyy", Locale.getDefault()) }

    // Local M3U file: copied into the app so it keeps working.
    val pickFile = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        val id = Playlists.newId()
        val dir = java.io.File(ctx.filesDir, "playlists").apply { mkdirs() }
        val file = java.io.File(dir, "$id.m3u")
        val ok = runCatching { ctx.contentResolver.openInputStream(uri)!!.use { i -> file.outputStream().use { i.copyTo(it) } } }.isSuccess
        if (ok) {
            added(Playlist(id, uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Local playlist", "file", url = file.path))
        } else Toast.makeText(ctx, "Couldn't read that file.", Toast.LENGTH_SHORT).show()
    }

    Spacer(Modifier.height(8.dp))
    Playlists.all.forEach { p ->
        val active = p.id == Playlists.active?.id
        Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF1F1F22))
            .border(1.dp, if (active) Color(0xFF3D7BFF) else Color(0xFF333336), RoundedCornerShape(22.dp))
            .focusRing(RoundedCornerShape(22.dp)).clickable { actionsFor = p }.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(when (p.type) { "xc" -> "API"; "file" -> "📄"; else -> "🔗" }, color = Color(0xFF7FA6FF), fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xFF2E3442)).padding(horizontal = 12.dp, vertical = 14.dp))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.name + if (active) "  ✓" else "", style = MaterialTheme.typography.titleLarge)
                    Text(p.subtitle, color = Color(0xFFAAAAAA))
                }
                Text("⋮", style = MaterialTheme.typography.titleLarge)
            }
            if (p.updatedAt > 0) {
                Box(Modifier.padding(vertical = 10.dp).fillMaxWidth().height(1.dp).background(Color(0xFF333336)))
                Text("Last updated at ${fmt.format(java.util.Date(p.updatedAt))}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF999999))
            }
        }
    }
    if (Playlists.all.isEmpty()) Text("No playlists yet. Add your Xtream Codes login or M3U link.", modifier = Modifier.padding(8.dp))
    Spacer(Modifier.height(12.dp))
    Button(onClick = { adding = true }, modifier = Modifier.focusRing(ButtonShape)) { Text("+  Add Playlist") }
    if (rememberIsTv()) PhoneSetup(live)

    actionsFor?.let { p ->
        ModalBottomSheet(onDismissRequest = { actionsFor = null }) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(p.name, style = MaterialTheme.typography.headlineSmall)
                SheetGroup {
                    if (p.id != Playlists.active?.id) SheetItem("✓", "Use for Live TV") { actionsFor = null; live.usePlaylist(p.id) }
                    SheetItem("⟳", "Force Update") { actionsFor = null; if (p.id == Playlists.active?.id) live.reload() else live.usePlaylist(p.id) }
                    SheetItem("✏️", "Edit Playlist") { actionsFor = null; editing = p }
                    if (p.type == "xc") SheetItem("ⓘ", "Subscription Info") {
                        actionsFor = null
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { runCatching { XtreamApi.login(XtreamApi.Account(p.server, p.user, p.pass)) } }
                            val d = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
                            info = r.getOrNull()?.let { i ->
                                "Status: ${i.status.ifEmpty { "Active" }}\n" +
                                    "Expires: ${i.expires?.let { d.format(java.util.Date(it)) } ?: "Never"}\n" +
                                    "Connections: ${i.activeConnections} of ${i.maxConnections} in use\n" +
                                    (i.created?.let { "Created: ${d.format(java.util.Date(it))}\n" } ?: "") +
                                    (if (i.trial) "Trial account\n" else "") +
                                    "Formats: ${i.formats.joinToString(", ").ifEmpty { "ts" }}"
                            } ?: "Couldn't check: ${r.exceptionOrNull()?.message}"
                        }
                    }
                }
                SheetGroup { SheetItem("🗑", "Remove Playlist") { actionsFor = null; Playlists.remove(ctx, p.id); live.reload() } }
            }
        }
    }
    if (adding) {
        ModalBottomSheet(onDismissRequest = { adding = false }) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 32.dp)) {
                Text("Add playlist", style = MaterialTheme.typography.headlineSmall)
                Text("Choose your playlist source.", color = Color(0xFFAAAAAA))
                SettingsHeader("Live TV")
                SheetGroup {
                    SheetItem("🗄", "Xtream Codes  ·  Server, username & password") { adding = false; editing = Playlist(Playlists.newId(), "", "xc") }
                    SheetItem("🔗", "M3U & EPG  ·  Playlist URL & optional EPG") { adding = false; editing = Playlist(Playlists.newId(), "", "m3u") }
                    SheetItem("📄", "Local M3U file  ·  Choose a file from your device") {
                        adding = false
                        try { pickFile.launch("*/*") } catch (_: Exception) { Toast.makeText(ctx, "No file picker on this device.", Toast.LENGTH_SHORT).show() }
                    }
                }
                SettingsHeader("Movies & TV shows")
                SheetGroup {
                    SheetItem("▷", "Plex  ·  Connect your Plex account on the Library tab") {
                        adding = false
                        Toast.makeText(ctx, "Open the Library tab to sign in to Plex.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }
    editing?.let { p ->
        EditPlaylist(p, onClose = { editing = null }) { saved ->
            val isNew = Playlists.all.none { it.id == saved.id }
            editing = null
            if (isNew) added(saved) else { Playlists.upsert(ctx, saved); if (saved.id == Playlists.active?.id) { live.reload(); progress = true } }
        }
    }
    if (progress) LoadProgress(live) { progress = false }
    info?.let { text ->
        AlertDialog(onDismissRequest = { info = null }, title = { Text("Subscription Info") }, text = { Text(text) },
            confirmButton = { TextButton(onClick = { info = null }) { Text("Close") } })
    }
}

@Composable
private fun EditPlaylist(p: Playlist, onClose: () -> Unit, onSave: (Playlist) -> Unit) {
    var name by remember { mutableStateOf(p.name) }
    var server by remember { mutableStateOf(p.server) }
    var user by remember { mutableStateOf(p.user) }
    var pass by remember { mutableStateOf(p.pass) }
    var url by remember { mutableStateOf(p.url) }
    var customEpg by remember { mutableStateOf(p.epgCustom.isNotEmpty()) }
    var epg by remember { mutableStateOf(p.epgCustom) }
    ModalBottomSheet(onDismissRequest = onClose) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(if (p.name.isEmpty()) "Add Playlist" else "Edit Playlist", style = MaterialTheme.typography.headlineSmall)
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            SettingsHeader("Connection")
            if (p.type == "xc") {
                OutlinedTextField(value = server, onValueChange = { server = it }, label = { Text("Portal") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = user, onValueChange = { user = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = pass, onValueChange = { pass = it }, label = { Text("Password") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            } else if (p.type == "m3u") {
                OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Playlist URL (M3U)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            SettingsHeader("TV guide")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillChip(if (p.type == "xc") "Provider" else "None", !customEpg) { customEpg = false }
                PillChip("Custom", customEpg) { customEpg = true }
            }
            if (customEpg) OutlinedTextField(value = epg, onValueChange = { epg = it }, label = { Text("Guide URL (XMLTV)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Select Custom to use a different guide link than your playlist's own.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA))
            Button(onClick = {
                onSave(p.copy(name = name.trim().ifEmpty { if (p.type == "xc") user.ifEmpty { "Playlist" } else "Playlist" }, server = server.trim(),
                    user = user.trim(), pass = pass, url = if (p.type == "file") p.url else url.trim(), epgCustom = if (customEpg) epg.trim() else ""))
            }, modifier = Modifier.fillMaxWidth().focusRing(ButtonShape)) { Text("Save") }
        }
    }
}

/** On a TV: type the playlist on your phone instead (QR code + a 4-digit code). */
@Composable
private fun PhoneSetup(live: LiveViewModel) {
    val ctx = LocalContext.current
    var address by remember { mutableStateOf<String?>(null) }
    val server = remember {
        SetupServer { p, e, tk ->
            Handler(Looper.getMainLooper()).post {
                if (p.isNotEmpty()) {
                    Playlists.upsert(ctx, Playlist(Playlists.newId(), "Playlist from phone", "m3u", url = p, epgCustom = e))
                    live.reload()
                }
                if (tk.isNotEmpty()) AppPrefs(ctx).traktClientId = tk
            }
        }
    }
    DisposableEffect(Unit) { onDispose { server.stop() } }
    LaunchedEffect(Unit) {
        val port = withContext(Dispatchers.IO) { server.start() }
        val ip = withContext(Dispatchers.IO) { SetupServer.localIp() }
        address = if (port > 0 && ip != null) "http://$ip:$port" else null
    }
    SettingsHeader("Easier: add a playlist from your phone")
    address?.let { a ->
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(remember(a) { SetupServer.qr(a) }, contentDescription = null, modifier = Modifier.size(180.dp))
            Column {
                Text(a)
                Text("Code: ${server.code}", style = MaterialTheme.typography.titleLarge)
                Text("Scan it or open the address on a device on your Wi-Fi, then enter the code.", style = MaterialTheme.typography.bodySmall)
            }
        }
    } ?: Text("Starting…")
}

// ---------------------------------------------------------------- Recordings, Reminders and Downloads

@Composable
fun RecordingsRemindersPage() {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var reminders by remember { mutableStateOf(Reminders.list(ctx)) }
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Recordings", "Reminders", "Downloads").forEachIndexed { i, t -> PillChip(t, tab == i) { tab = i; reminders = Reminders.list(ctx) } }
    }
    when (tab) {
        0 -> Box(Modifier.fillMaxWidth().height(560.dp)) { RecordingsScreen() }
        1 -> {
            if (reminders.isEmpty()) Text("No reminders. Set one from a sports game (Sports tab).", modifier = Modifier.padding(16.dp))
            val fmt = remember { SimpleDateFormat("EEE d MMM, h:mm a", Locale.getDefault()) }
            reminders.forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF2A2A2D)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.title, style = MaterialTheme.typography.titleMedium)
                        Text(fmt.format(java.util.Date(r.at)), color = Color(0xFFAAAAAA))
                    }
                    TextButton(onClick = { Reminders.cancel(ctx, r.id); reminders = Reminders.list(ctx) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Remove") }
                }
            }
        }
        else -> {
            DownloadsList()
            Text("Games you download are on the Games tab, under Downloaded.", style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFAAAAAA), modifier = Modifier.padding(8.dp))
        }
    }
}

// ---------------------------------------------------------------- Playlists Modifications

@Composable
fun PlaylistMods(live: LiveViewModel) {
    val ctx = LocalContext.current
    var page by remember { mutableStateOf(0) }
    SettingsHeader("Playlist preferences")
    SettingsCard {
        listOf("Groups Customizations · Hide, reorder & rename", "Un-Hide Channels · Restore hidden channels", "Un-Hide Sports Leagues").forEachIndexed { i, t ->
            if (i > 0) SettingsDivider()
            Row(Modifier.fillMaxWidth().focusRing().clickable { page = i }.padding(18.dp)) {
                Text(t, style = MaterialTheme.typography.titleMedium, color = if (page == i) Color(0xFF7FA6FF) else Color.Unspecified, modifier = Modifier.weight(1f))
                Text("›")
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    when (page) {
        0 -> Box(Modifier.fillMaxWidth().height(560.dp)) { ManagePanel(live) }
        1 -> {
            val hidden = live.allChannels.filter { it.key in live.hiddenChannels }.distinctBy { it.key }
            if (hidden.isEmpty()) Text("No hidden channels.", modifier = Modifier.padding(8.dp))
            hidden.forEach { ch ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(live.nameOf(ch), modifier = Modifier.weight(1f))
                    TextButton(onClick = { live.toggleChannelHidden(ch) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Show") }
                }
            }
            if (live.hiddenGroups.isNotEmpty()) {
                SettingsHeader("Hidden groups")
                live.hiddenGroups.forEach { g ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(g, modifier = Modifier.weight(1f))
                        TextButton(onClick = { live.toggleGroupHidden(g) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Show") }
                    }
                }
            }
        }
        else -> {
            val prefs = ctx.getSharedPreferences("tvhub", android.content.Context.MODE_PRIVATE)
            var hidden by remember { mutableStateOf(prefs.getStringSet("hidden_leagues", emptySet())!!.toSet()) }
            if (hidden.isEmpty()) Text("No hidden leagues.", modifier = Modifier.padding(8.dp))
            hidden.forEach { l ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(l, modifier = Modifier.weight(1f))
                    TextButton(onClick = { hidden = hidden - l; prefs.edit().putStringSet("hidden_leagues", hidden).apply() },
                        modifier = Modifier.focusRing(ButtonShape)) { Text("Show") }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- General

@Composable
fun GeneralSettings(live: LiveViewModel) {
    SettingsHeader("Playlists")
    SettingsCard {
        ChoiceRow("Playlist update interval (hours)", "playlist_interval_s", "24",
            listOf("0" to "Only when the app starts", "6" to "6 Hours", "12" to "12 Hours", "24" to "24 Hours", "48" to "48 Hours")) {
            Opt.set("playlist_interval", it.toInt())
        }
        SettingsDivider()
        ChoiceRow("Set EPG offset", "epg_offset_s", "0", (-12..12).map { h -> h.toString() to if (h == 0) "None" else (if (h > 0) "+$h" else "$h") + " hours" }) {
            Opt.set("epg_offset", it.toInt())
            live.refreshGuide()
        }
    }
    Spacer(Modifier.height(12.dp))
    Button(onClick = { live.reload() }, modifier = Modifier.focusRing(ButtonShape)) { Text("Reload playlist and guide now") }
}


/** "Keep the app open until the download finishes": each step of loading the playlist and guide. */
@Composable
private fun LoadProgress(live: LiveViewModel, onClose: () -> Unit) {
    val busy = live.loadState == "loading"
    androidx.compose.ui.window.Dialog(onDismissRequest = { if (!busy) onClose() },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color.Black).padding(16.dp)) {
            Text(if (busy) "Keep the app open until the download finishes." else if (live.loadState == "failed") "Something went wrong." else "All set.",
                color = Color(0xFFBBBBBB), modifier = Modifier.padding(vertical = 12.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                live.loadLog.forEach { line ->
                    Text(line, color = Color(0xFFCCCCCC), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(Color(0xFF1F1F22)).padding(12.dp))
                }
                if (busy) androidx.compose.material3.LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            }
            Row(Modifier.fillMaxWidth()) {
                Spacer(Modifier.weight(1f))
                Button(onClick = onClose, enabled = !busy, modifier = Modifier.focusRing(ButtonShape)) { Text("Finish") }
            }
        }
    }
}
