package com.example.tvhub

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings
import android.service.notification.NotificationListenerService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Spotify, Apple Music, Amazon Music and the YouTube Music app. Their music can only be played by their
 * own apps, so TV Hub opens them, and (with notification access) shows what they're playing with
 * play / pause / skip controls, while they keep playing in the background.
 */
object MusicApps {
    data class App(val name: String, val packages: List<String>, val color: Long)

    val apps = listOf(
        App("Spotify", listOf("com.spotify.tv.android", "com.spotify.music"), 0xFF1DB954),
        App("Apple Music", listOf("com.apple.android.music"), 0xFFFA243C),
        App("Amazon Music", listOf("com.amazon.music.tv", "com.amazon.mp3"), 0xFF25D1DA),
        App("YouTube Music", listOf("com.google.android.apps.youtube.music", "com.google.android.youtube.tvmusic"), 0xFFFF0000),
    )

    fun installed(ctx: Context, a: App): String? = a.packages.firstOrNull {
        try { ctx.packageManager.getPackageInfo(it, 0); true } catch (_: Exception) { false }
    }

    /** Opens the app (or its store page when it isn't installed). */
    fun open(ctx: Context, a: App): String? {
        val pm = ctx.packageManager
        installed(ctx, a)?.let { pkg ->
            (pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg))?.let {
                ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return null
            }
        }
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("market://details?id=${a.packages.last()}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "${a.name} isn't installed: opening its store page."
        } catch (_: Exception) {
            "Install ${a.name} to use it."
        }
    }

    // --- What other music apps are playing (needs notification access) ---

    data class NowPlaying(val app: String, val title: String, val artist: String, val art: Bitmap?, val playing: Boolean, val controller: MediaController)

    var nowPlaying by mutableStateOf<List<NowPlaying>>(emptyList())
        private set

    fun hasAccess(ctx: Context): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(ctx.packageName)
    }

    fun openAccessSettings(ctx: Context): Boolean = try {
        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (_: Exception) {
        false   // some TVs hide this screen
    }

    /** Reads the media sessions of other apps (Spotify, Apple Music, ...). */
    fun refresh(ctx: Context) {
        if (!hasAccess(ctx)) { nowPlaying = emptyList(); return }
        try {
            val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
            nowPlaying = sessions.filter { it.packageName != ctx.packageName }.mapNotNull { c ->
                val m = c.metadata ?: return@mapNotNull null
                val label = apps.firstOrNull { c.packageName in it.packages }?.name
                    ?: try { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(c.packageName, 0)).toString() } catch (_: Exception) { c.packageName }
                NowPlaying(label, m.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty(),
                    m.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST).orEmpty(),
                    m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART),
                    c.playbackState?.state == PlaybackState.STATE_PLAYING, c)
            }
        } catch (_: SecurityException) {
            nowPlaying = emptyList()
        }
    }
}

/** Only here so TV Hub may read other apps' media sessions once you allow notification access. */
class MediaListener : NotificationListenerService()
