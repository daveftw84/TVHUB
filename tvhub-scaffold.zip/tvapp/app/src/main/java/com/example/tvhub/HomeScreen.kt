package com.example.tvhub

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.focus.focusRequester
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

/**
 * The app's Home tab: Continue Watching (Trakt when signed in, otherwise Plex), recently watched
 * Live TV channels, recently played games, what's trending today, and your Trakt recommendations.
 */
@Composable
fun HomeScreen(
    live: LiveViewModel,
    plex: PlexViewModel,
    games: GamesViewModel,
    onWatchChannel: (Channel) -> Unit,
    onPlayPlex: (PlexItem) -> Unit,
    onOpenPlex: (PlexItem) -> Unit,
    onOpenGame: (Game) -> Unit,
    extraRows: androidx.compose.foundation.lazy.LazyListScope.() -> Unit = {},
    tube: YouTubeViewModel? = null,
    onOpenTube: (TubeVideo, Boolean) -> Unit = { _, _ -> },
    onGoTab: (String) -> Unit = {},
    onSearchLive: (String) -> Unit = {},
) {
    val tv = rememberIsTv()
    var info by remember { mutableStateOf<HubTitle?>(null) }
    var searching by remember { mutableStateOf(false) }
    var categories by remember { mutableStateOf(false) }
    var whoIs by remember { mutableStateOf(false) }
    // Section chips (All Sections / V.O.D / Live TV / Sports) and the rows you chose to show.
    var section by remember { mutableStateOf(0) }
    val hidden = Opt.set(Opt.HOME_HIDDEN)
    fun show(c: HomeCategory) = c.name !in hidden
    val vod = section == 0 || section == 1
    val liveOn = section == 0 || section == 2
    val sportsOn = section == 0 || section == 3

    // Reload when Home is shown, when Plex comes online, and after signing in or out of Trakt.
    LaunchedEffect(plex.server, TraktAccount.signedIn, plex.libraries) { plex.loadHub() }
    LaunchedEffect(tube) { if (tube != null && tube.subscriptions.isNotEmpty() && tube.feed.isEmpty()) tube.loadFeed() }

    val posterW: Dp = if (tv) 130.dp else 110.dp
    val onTitle: (HubTitle) -> Unit = { t ->
        val item = t.item
        when {
            item == null -> info = t
            t.resume && Opt.str("continue_action", "play") == "play" -> onPlayPlex(item)
            else -> onOpenPlex(item)
        }
    }

    LaunchedEffect(Buttons.searchRequested) { if (Buttons.searchRequested) { searching = true; Buttons.searchRequested = false } }
    if (searching) {
        androidx.activity.compose.BackHandler { searching = false }
        UniversalSearch(live, plex, games, posterW, onClose = { searching = false },
            onWatchChannel = onWatchChannel, onOpenPlex = onOpenPlex, onOpenGame = onOpenGame, tube = tube, onOpenTube = onOpenTube)
        return
    }

    // First run: nothing set up yet.
    var setup by remember { mutableStateOf(false) }
    if (setup) {
        androidx.activity.compose.BackHandler { setup = false }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("←", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.focusRing(RoundedCornerShape(50))
                    .clip(RoundedCornerShape(50)).clickable { setup = false }.padding(8.dp))
                Text("Manage Playlists", style = MaterialTheme.typography.headlineSmall)
            }
            PlaylistsManager(live)
        }
        return
    }
    if (Playlists.all.isEmpty() && plex.server == null && !plex.hubLoading) {
        Welcome(onAdd = { setup = true }, onPlex = { onGoTab("LIBRARY") }, onGames = { onGoTab("GAMES") })
        return
    }

    val recentGames = games.recentGames
    val channels = live.recentChannels
    val favs = live.favoriteChannels
    val nothing = plex.hubContinue.isEmpty() && channels.isEmpty() && recentGames.isEmpty() && plex.hubSections.isEmpty()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column {
                    Text("Home", style = MaterialTheme.typography.headlineMedium)
                    if (Playlists.all.size > 1) {
                        var pick by remember { mutableStateOf(false) }
                        Text((Playlists.active?.name ?: "Playlist") + "  ⌄", style = MaterialTheme.typography.labelMedium, color = Color(0xFF7FA6FF),
                            modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable { pick = true }.padding(vertical = 2.dp))
                        androidx.compose.material3.DropdownMenu(expanded = pick, onDismissRequest = { pick = false }) {
                            Playlists.all.forEach { p ->
                                androidx.compose.material3.DropdownMenuItem(text = { Text(p.name + if (p.id == Playlists.active?.id) "  ✓" else "") },
                                    onClick = { pick = false; live.usePlaylist(p.id) })
                            }
                        }
                    }
                }
                Box(
                    Modifier.weight(1f).height(44.dp)
                        .focusRing(RoundedCornerShape(50))
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { searching = true }
                        .padding(horizontal = 18.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    Text("🔍  Search movies, shows, Live TV and games", color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (plex.hubLoading) {
                    Text("Updating…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("⚙", style = MaterialTheme.typography.titleLarge, modifier = Modifier.focusRing(RoundedCornerShape(50))
                    .clip(RoundedCornerShape(50)).clickable { categories = true }.padding(8.dp))
                // Profile: tap to switch (Who's watching?).
                Profiles.active?.takeIf { Profiles.all.size > 1 }?.let { p ->
                    Box(Modifier.focusRing(RoundedCornerShape(50)).clip(RoundedCornerShape(50)).clickable { whoIs = true }) { ProfileAvatar(p, 36) }
                }
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(horizontal = 20.dp)) {
                val names = listOf("All Sections", "V.O.D", "Live TV", "Sports")
                items(names.size) { i -> PillChip(names[i], section == i) { section = i } }
            }
        }

        // Hero carousel: what's trending (Trakt), swipe or scroll through.
        val trending = plex.hubSections.flatMap { it.rows }.filter { it.title.startsWith("Trending") }.flatMap { it.cards }
            .filter { it.poster != null }.distinctBy { it.title }.take(10)
        if (vod && show(HomeCategory.TRENDING) && Opt.bool("show_hero", true) && trending.isNotEmpty()) item {
            val pager = androidx.compose.foundation.pager.rememberPagerState { trending.size }
            Column {
                SectionTitle("Trending V.O.D", note = "Trakt")
                Spacer(Modifier.height(10.dp))
                androidx.compose.foundation.pager.HorizontalPager(pager, contentPadding = PaddingValues(horizontal = 20.dp),
                    pageSpacing = 12.dp) { i ->
                    val t = trending[i]
                    Box(Modifier.fillMaxWidth().height(if (tv) 260.dp else 200.dp).focusRing(RoundedCornerShape(18.dp))
                        .clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant).clickable { onTitle(t) }) {
                        AsyncImage(model = t.item?.let { plex.backdrop(it) } ?: t.poster, contentDescription = null,
                            contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.verticalGradient(
                            listOf(Color.Transparent, Color(0xDD000000)))))
                        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                            Text(if (t.item?.type == "movie") "Movie  🎬" else "TV Show  📺", style = MaterialTheme.typography.labelMedium,
                                color = Color.White, modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(0x99000000))
                                    .padding(horizontal = 10.dp, vertical = 3.dp))
                            Text(t.title, style = MaterialTheme.typography.headlineSmall, color = Color.White, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            Text(t.subtitle + if (t.item != null) " · In your library" else "", color = Color(0xFFCCCCCC),
                                style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center) {
                    repeat(trending.size) { i ->
                        Box(Modifier.padding(3.dp).size(if (i == pager.currentPage) 8.dp else 6.dp).clip(RoundedCornerShape(50))
                            .background(if (i == pager.currentPage) Color.White else Color(0xFF666666)))
                    }
                }
            }
        }

        val contMovies = plex.hubContinue.filter { it.item?.type == "movie" }
        val contShows = plex.hubContinue.filter { it.item?.type != "movie" }
        val empties = section != 0      // a chosen section shows its empty rows too, with a way to fill them
        val goVod = listOf("Go to Movies" to { onGoTab("LIBRARY") }, "Go to TV Shows" to { onGoTab("LIBRARY") })
        if (vod && show(HomeCategory.CONTINUE_MOVIES) && (contMovies.isNotEmpty() || empties)) item {
            if (contMovies.isEmpty()) EmptyRow("Continue Watching Movies", "Watch your first movie to populate this category", goVod)
            else HubRow("Continue Watching Movies", "from ${plex.hubContinueFrom}", contMovies.size) {
                items(contMovies) { t -> PosterCard(t, posterW) { onTitle(t) } }
            }
        }
        if (vod && show(HomeCategory.CONTINUE_SHOWS) && (contShows.isNotEmpty() || empties)) item {
            if (contShows.isEmpty()) EmptyRow("Continue Watching TV Shows", "Watch your first episode to populate this category", goVod)
            else HubRow("Continue Watching TV Shows", "from ${plex.hubContinueFrom}", contShows.size) {
                items(contShows) { t -> PosterCard(t, posterW) { onTitle(t) } }
            }
        }

        if (vod && show(HomeCategory.UP_NEXT) && plex.hubCalendar.isNotEmpty()) item {
            HubRow("On TV This Week", "your shows on Trakt") {
                items(plex.hubCalendar) { t -> PosterCard(t, posterW) { onTitle(t) } }
            }
        }

        val goLive = listOf("Go to Live TV" to { onGoTab("LIVE") })
        if (liveOn && show(HomeCategory.LAST_CHANNELS) && channels.isEmpty() && empties) item {
            EmptyRow("Last Watched Channels", "Watch your first channel to populate this category", goLive)
        }
        if (liveOn && show(HomeCategory.LAST_CHANNELS) && channels.isNotEmpty()) item {
            HubRow("Last Watched Channels", count = channels.size) {
                items(channels.distinctBy { it.key }, key = { "ch:" + it.key }) { ch ->
                    ChannelCard(ch, live.nowNext(ch).first?.title, tv, live.nowNext(ch).first?.let { live.artworkFor(it) }) { onWatchChannel(ch) }
                }
            }
        }

        val top = live.topWatched
        if (liveOn && show(HomeCategory.TOP10_CHANNELS) && top.isEmpty() && empties) item {
            EmptyRow("Top 10 Watched Channels", "Watch Live TV to populate this category", goLive)
        }
        if (liveOn && show(HomeCategory.TOP10_CHANNELS) && top.isNotEmpty()) item {
            HubRow("Top 10 Watched Channels", count = top.size) {
                items(top.distinctBy { it.first.key }, key = { "top:" + it.first.key }) { (ch, ms) ->
                    Box {
                        ChannelCard(ch, live.nowNext(ch).first?.title, tv) { onWatchChannel(ch) }
                        Text(watched(ms), style = MaterialTheme.typography.labelSmall, color = Color.White,
                            modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).clip(RoundedCornerShape(8.dp))
                                .background(Color(0xCC3D7BFF)).padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
            }
        }
        if (liveOn && show(HomeCategory.FAVORITE_CHANNELS) && favs.isNotEmpty()) item {
            HubRow("Favorite Channels") {
                items(favs.distinctBy { it.key }, key = { "fav:" + it.key }) { ch ->
                    ChannelCard(ch, live.nowNext(ch).first?.title, tv) { onWatchChannel(ch) }
                }
            }
        }

        val added = live.recentlyAdded
        if (liveOn && show(HomeCategory.RECENT_LIVE) && added.isNotEmpty()) item {
            HubRow("Recently Added Live TV", "new in your playlist", added.size) {
                items(added.distinctBy { it.key }, key = { "new:" + it.key }) { ch -> ChannelCard(ch, live.nowNext(ch).first?.title, tv) { onWatchChannel(ch) } }
            }
        }

        if (sportsOn && show(HomeCategory.FOLLOWED_TEAMS)) item {
            FollowedTeams(onSearchLive)
        }

        // Sports from your guide (and TheSportsDB listings): what's on now, then your teams.
        val sportsNow = live.sportsEvents.filter { it.live && it.channels.isNotEmpty() }
        if (sportsOn && show(HomeCategory.SPORTS_NOW) && sportsNow.isNotEmpty()) item {
            HubRow("Sports on Now", "on your channels") {
                items(sportsNow) { e -> SportsCard(e, tv) { onWatchChannel(e.channels.first()) } }
            }
        }
        val teams = live.sportsEvents.filter { !it.live && it.channels.isNotEmpty() && Sports.isFavorite(it, live.sportsFavorites) }
        if (sportsOn && show(HomeCategory.FOLLOWED_TEAMS) && teams.isNotEmpty()) item {
            HubRow("Your Teams on TV") {
                items(teams) { e -> SportsCard(e, tv) { onWatchChannel(e.channels.first()) } }
            }
        }
        val later = live.sportsEvents.filter { !it.live && it.channels.isNotEmpty() && it.start < System.currentTimeMillis() + 12 * 3_600_000L }
        if (sportsOn && show(HomeCategory.SPORTS_NOW) && later.isNotEmpty()) item {
            HubRow("Sports Later Today") {
                items(later.take(30)) { e -> SportsCard(e, tv) { onWatchChannel(e.channels.first()) } }
            }
        }

        if (section == 0) extraRows()

        // YouTube: what you were watching, and new videos from your subscriptions.
        if (tube != null && vod) {
            val cont = tube.continueWatching
            if (cont.isNotEmpty()) item {
                val w = if (tv) 240.dp else 190.dp
                HubRow("Continue Watching on YouTube") {
                    items(cont) { h ->
                        val p = if (h.durationMs > 0) (h.positionMs.toFloat() / h.durationMs).coerceIn(0f, 1f) else 0f
                        TubeCard(h.video, w, p) { onOpenTube(h.video, true) }
                    }
                }
            }
            if (tube.feed.isNotEmpty()) item {
                val w = if (tv) 240.dp else 190.dp
                HubRow("New on YouTube", "your subscriptions") {
                    items(tube.feed.take(30)) { v -> TubeCard(v, w) { onOpenTube(v, false) } }
                }
            }
        }

        if (section == 0 && show(HomeCategory.GAMES) && recentGames.isNotEmpty()) item {
            HubRow("Recently Played Games") {
                items(recentGames.distinctBy { it.game.key }, key = { "g:" + it.game.key }) { r ->
                    GameCard(r, games.consoleName(r.game.console), posterW) { onOpenGame(r.game) }
                }
            }
        }

        if (section == 0 && show(HomeCategory.GAMES)) item {
            Column {
                Text("Cloud Gaming", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 20.dp))
                Spacer(Modifier.height(8.dp))
                CloudGamingRow(Modifier)
            }
        }

        for (hs in plex.hubSections) {
            if (!vod) break
            val isShows = hs.title.contains("TV", true) || hs.title.contains("Show", true)
            if (!show(if (isShows) HomeCategory.SHOWS else HomeCategory.MOVIES)) continue
            item {
                Text(hs.title, style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(start = 20.dp, top = 12.dp))
            }
            for (row in hs.rows) {
                item {
                    HubRow(row.title, row.source) {
                        items(row.cards) { t -> PosterCard(t, posterW) { onTitle(t) } }
                    }
                }
            }
        }

        if (nothing && !plex.hubLoading) item {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Nothing here yet", style = MaterialTheme.typography.titleLarge)
                Text("• Add a playlist or Xtream Codes login in Settings to watch Live TV.")
                Text("• Sign in to Plex on the Library tab for your movies and shows.")
                Text("• Connect your RomM server on the Games tab.")
                Text("• Sign in to Trakt in Settings for your recommendations, watchlist and calendar.")
            }
        }
    }

    info?.let { t -> TitleInfoDialog(t) { info = null } }
    if (categories) HomeCategoriesDialog { categories = false }
    if (whoIs) androidx.compose.ui.window.Dialog(onDismissRequest = { whoIs = false },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) { ProfilePicker { whoIs = false } }
}

/** A row heading like iMPlayer's: bold title, count, a short blue underline. */
@Composable
private fun SectionTitle(title: String, count: Int? = null, note: String? = null, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(title + (count?.let { " ($it)" } ?: ""), style = MaterialTheme.typography.titleLarge,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (note != null) Text("  $note", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box(Modifier.padding(top = 4.dp).width(44.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF3D7BFF)))
        }
        action?.invoke()
    }
}

/** An empty row: what fills it, and where to go to fill it. */
@Composable
private fun EmptyRow(title: String, text: String, links: List<Pair<String, () -> Unit>>) {
    Column {
        SectionTitle(title, 0)
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp, start = 20.dp, end = 20.dp))
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.Center) {
            links.forEach { (label, go) ->
                Text(label, color = Color(0xFF4D8DFF), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    modifier = Modifier.focusRing(RoundedCornerShape(6.dp)).clip(RoundedCornerShape(6.dp)).clickable(onClick = go)
                        .padding(horizontal = 10.dp, vertical = 6.dp))
            }
        }
    }
}

/** Nothing set up yet: add a playlist, or sign in to Plex. */
@Composable
private fun Welcome(onAdd: () -> Unit, onPlex: () -> Unit, onGames: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Spacer(Modifier.height(40.dp))
        Text("Welcome to TV Hub", style = MaterialTheme.typography.headlineSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("Before using the app, add a playlist for Live TV", textAlign = TextAlign.Center)
        Text("Add a Playlist", color = Color(0xFF4D8DFF), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            modifier = Modifier.focusRing(RoundedCornerShape(6.dp)).clickable(onClick = onAdd).padding(8.dp))
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f).height(1.dp).background(Color(0xFF444444)))
            Text("  or  ", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Box(Modifier.weight(1f).height(1.dp).background(Color(0xFF444444)))
        }
        Text("Sign in to Plex for your movies and shows, or connect your RomM server for games.", textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onPlex, modifier = Modifier.focusRing(ButtonShape)) { Text("Sign in to Plex") }
            androidx.compose.material3.OutlinedButton(onClick = onGames, modifier = Modifier.focusRing(ButtonShape)) { Text("Games") }
        }
        Spacer(Modifier.height(24.dp))
        Text("TV Hub is just a player: it doesn't provide any channels or videos. Use your own playlist, Plex server and game library.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onAdd, modifier = Modifier.focusRing(ButtonShape)) { Text("+  Add Playlist") }
    }
}

/** Followed Sport Teams: each team's next game (ESPN); tap to find it on your channels. */
@Composable
private fun FollowedTeams(onSearchLive: (String) -> Unit) {
    val teams = Opt.set("followed_teams").mapNotNull { Espn.TeamInfo.decode(it) }.sortedBy { it.name }
    var adding by remember { mutableStateOf(false) }
    var games by remember { mutableStateOf<Map<String, Espn.Match?>>(emptyMap()) }
    LaunchedEffect(teams.map { it.id + it.path }) {
        games = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            teams.associate { t -> (t.path + t.id) to runCatching { Espn.nextGame(t) }.getOrNull() }
        }
    }
    val fmt = remember { java.text.SimpleDateFormat("EEE d MMM, h:mm a", java.util.Locale.getDefault()) }
    Column {
        SectionTitle("Followed Sport Teams", teams.size) {
            Button(onClick = { adding = true }, modifier = Modifier.focusRing(ButtonShape)) { Text("Add") }
        }
        if (teams.isEmpty()) {
            Text("Follow your first team to stay on top of their fixtures", color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            Text("Add a Team", color = Color(0xFF4D8DFF), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().clickable { adding = true }.padding(8.dp))
        } else {
            Spacer(Modifier.height(10.dp))
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(teams.distinctBy { it.path + it.id }, key = { it.path + it.id }) { t ->
                    val g = games[t.path + t.id]
                    Column(Modifier.width(220.dp).focusRing(RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { onSearchLive(t.name.split(" ").last()) }.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(model = t.logo, contentDescription = null, modifier = Modifier.size(36.dp))
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(t.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                                Text(t.league, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        when {
                            g == null -> Text("No upcoming game", style = MaterialTheme.typography.bodySmall)
                            else -> {
                                Text(g.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                Text(if (g.live) "🔴 Live · ${g.status}" else fmt.format(java.util.Date(g.start)),
                                    style = MaterialTheme.typography.labelMedium, color = if (g.live) Color(0xFFFF5A5A) else Color(0xFF7FA6FF))
                                if (g.channels.isNotEmpty()) Text("📺 " + g.channels.joinToString(", "), style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
    if (adding) FollowTeamSheet { adding = false }
}

@Composable
private fun FollowTeamSheet(onClose: () -> Unit) {
    var sport by remember { mutableStateOf(Espn.SPORTS.first()) }
    var league by remember { mutableStateOf(Espn.SPORTS.first().leagues.first()) }
    var list by remember { mutableStateOf<List<Espn.TeamInfo>?>(null) }
    var q by remember { mutableStateOf("") }
    var followed by remember { mutableStateOf(Opt.set("followed_teams")) }
    LaunchedEffect(league) {
        list = null
        list = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { runCatching { Espn.teams(league) }.getOrDefault(emptyList()) }
    }
    androidx.compose.material3.ModalBottomSheet(onDismissRequest = onClose) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 24.dp).heightIn(max = 640.dp)) {
            Text("Follow a Team", style = MaterialTheme.typography.headlineSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Text("Select a team you would like to follow and show up in your home section", textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Espn.SPORTS.filter { it.name !in setOf("Motorsport", "Golf", "Tennis", "Fighting") }) { s ->
                    PillChip("${s.emoji} ${s.name}", s == sport) { sport = s; league = s.leagues.first() }
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sport.leagues) { l -> PillChip(l.name, l == league) { league = l } }
            }
            androidx.compose.material3.OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true,
                placeholder = { Text("Search teams") }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
            val shown = list?.filter { q.isBlank() || it.name.contains(q.trim(), true) }
            if (shown == null) Text("Loading teams…", modifier = Modifier.padding(12.dp))
            else LazyColumn {
                items(shown.distinctBy { it.path + it.id }, key = { it.path + it.id }) { t ->
                    val on = followed.any { it.startsWith("${t.league}|${t.path}|${t.id}|") }
                    Row(Modifier.fillMaxWidth().focusRing().clickable {
                        followed = if (on) followed.filterNot { it.startsWith("${t.league}|${t.path}|${t.id}|") }.toSet() else followed + t.encode()
                        Opt.set("followed_teams", followed)
                    }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(model = t.logo, contentDescription = null, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(t.name, modifier = Modifier.weight(1f))
                        Text(if (on) "✓ Following" else "+ Follow", color = if (on) Color(0xFF4CAF50) else Color(0xFF4D8DFF))
                    }
                }
            }
        }
    }
}

private fun watched(ms: Long): String {
    val m = ms / 60_000
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
}

/** One search for everything: your Plex libraries, Live TV channels and guide, and your games. */
@Composable
private fun UniversalSearch(
    live: LiveViewModel,
    plex: PlexViewModel,
    games: GamesViewModel,
    posterW: Dp,
    onClose: () -> Unit,
    onWatchChannel: (Channel) -> Unit,
    onOpenPlex: (PlexItem) -> Unit,
    onOpenGame: (Game) -> Unit,
    tube: YouTubeViewModel? = null,
    onOpenTube: (TubeVideo, Boolean) -> Unit = { _, _ -> },
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { AppPrefs(ctx) }
    var q by remember { mutableStateOf("") }
    var recents by remember { mutableStateOf(prefs.recentSearches("all")) }
    var plexHits by remember { mutableStateOf<List<PlexItem>>(emptyList()) }
    var liveHits by remember { mutableStateOf<Pair<List<Channel>, List<LiveViewModel.ProgrammeHit>>>(emptyList<Channel>() to emptyList()) }
    var gameHits by remember { mutableStateOf<List<Game>>(emptyList()) }
    var tubeHits by remember { mutableStateOf<List<TubeVideo>>(emptyList()) }
    val focus = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Throwable) {} }
    LaunchedEffect(q) {
        kotlinx.coroutines.delay(300)
        if (q.trim().length < 2) {
            plexHits = emptyList(); liveHits = emptyList<Channel>() to emptyList(); gameHits = emptyList(); tubeHits = emptyList()
            return@LaunchedEffect
        }
        plexHits = plex.quickSearch(q)
        liveHits = live.searchLive(q)
        gameHits = games.searchAll(q)
        tubeHits = tube?.quickSearch(q).orEmpty()
    }
    fun saveTerm(term: String) {
        prefs.addRecentSearch("all", term)
        recents = prefs.recentSearches("all")
    }
    val fmt = remember { java.text.SimpleDateFormat("EEE h:mm a", java.util.Locale.getDefault()) }
    val voice = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { r ->
        r.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { q = it }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            // Back, the search box (with clear) and voice search.
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("←", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.focusRing(RoundedCornerShape(50))
                    .clip(RoundedCornerShape(50)).clickable(onClick = onClose).padding(8.dp))
                androidx.compose.material3.TextField(
                    value = q, onValueChange = { q = it }, singleLine = true,
                    placeholder = { Text("Search everything") },
                    shape = RoundedCornerShape(50),
                    colors = androidx.compose.material3.TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                    trailingIcon = { if (q.isNotEmpty()) Text("✕", modifier = Modifier.clickable { q = "" }.padding(8.dp)) },
                    modifier = Modifier.weight(1f).focusRequester(focus),
                )
                Text("🎙", style = MaterialTheme.typography.titleLarge, modifier = Modifier.focusRing(RoundedCornerShape(50))
                    .clip(RoundedCornerShape(50)).clickable {
                        try { voice.launch(android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            .putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Search TV Hub"))
                        } catch (_: Exception) {
                            android.widget.Toast.makeText(ctx, "Voice search isn't available on this device.", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }.padding(8.dp))
            }
        }
        if (q.trim().length < 2 && recents.isNotEmpty()) item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text("Recent searches", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(recents) { r -> SmallChip(r) { q = r } }
                    item { SmallChip("Clear") { prefs.clearRecentSearches("all"); recents = emptyList() } }
                }
            }
        }
        if (plexHits.isNotEmpty()) item {
            HubRow("Movies & Shows", "Plex") {
                items(plexHits) { it ->
                    val t = HubTitle(it.displayTitle, it.displaySubtitle.orEmpty(), plex.poster(it), it)
                    PosterCard(t, posterW) { saveTerm(q); onOpenPlex(it) }
                }
            }
        }
        if (liveHits.first.isNotEmpty()) item {
            HubRow("Live TV Results", count = liveHits.first.size) {
                items(liveHits.first) { ch -> WatchCard(live, ch) { saveTerm(q); onWatchChannel(ch) } }
            }
        }
        if (liveHits.second.isNotEmpty()) {
            item { Text("On Live TV", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 20.dp)) }
            items(liveHits.second.size) { i ->
                val h = liveHits.second[i]
                val onNow = h.programme.start <= System.currentTimeMillis()
                ListRow(
                    title = h.programme.title + (h.programme.subTitle.takeIf { it.isNotEmpty() }?.let { " · $it" } ?: ""),
                    subtitle = (if (onNow) "On now" else fmt.format(java.util.Date(h.programme.start))) + " · " + h.channel.name,
                    onClick = { saveTerm(q); onWatchChannel(h.channel) },
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
            }
        }
        if (gameHits.isNotEmpty()) item {
            HubRow("Games", "RomM") {
                items(gameHits) { g ->
                    GameCard(GamesViewModel.RecentGame(g, 0), games.consoleName(g.console), posterW) { saveTerm(q); onOpenGame(g) }
                }
            }
        }
        if (tubeHits.isNotEmpty()) item {
            HubRow("YouTube") {
                items(tubeHits) { v -> TubeCard(v, posterW * 1.8f) { saveTerm(q); onOpenTube(v, false) } }
            }
        }
        if (q.trim().length >= 2 && tubeHits.isEmpty() && plexHits.isEmpty() && liveHits.first.isEmpty() && liveHits.second.isEmpty() && gameHits.isEmpty()) item {
            Text("No results for \"${q.trim()}\".", modifier = Modifier.padding(horizontal = 20.dp))
        }
    }
}

/** A search result channel: logo, name, what's on with progress, and a Watch button (⋯ adds it to favorites). */
@Composable
private fun WatchCard(live: LiveViewModel, ch: Channel, onWatch: () -> Unit) {
    val now = live.nowNext(ch).first
    val t = System.currentTimeMillis()
    Column(Modifier.width(220.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF232325))
        .border(1.dp, Color(0xFF3A3A3D), RoundedCornerShape(20.dp)).padding(16.dp)) {
        Box(Modifier.fillMaxWidth().height(56.dp), contentAlignment = Alignment.Center) {
            if (ch.logo != null) AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            else Text("📺", style = MaterialTheme.typography.headlineMedium)
        }
        Spacer(Modifier.height(10.dp))
        Text(live.nameOf(ch), style = MaterialTheme.typography.labelLarge, color = Color(0xFFBBBBBB), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(now?.title ?: " ", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(10.dp))
        val p = now?.let { ((t - it.start).toFloat() / (it.end - it.start).coerceAtLeast(1)).coerceIn(0f, 1f) } ?: 0f
        Box(Modifier.fillMaxWidth().height(3.dp).background(Color(0xFF444444))) {
            Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(Color.White))
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.Button(onClick = onWatch, modifier = Modifier.focusRing(ButtonShape),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
                Text("▶  Watch", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            }
            Spacer(Modifier.weight(1f))
            val fav = ch.key in live.favorites
            Text(if (fav) "♥" else "⋯", color = if (fav) Color(0xFFFF5A7A) else Color.White, style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.focusRing(RoundedCornerShape(50)).clip(RoundedCornerShape(50)).background(Color(0xFF444446))
                    .clickable { live.toggleFavorite(ch) }.padding(horizontal = 12.dp, vertical = 6.dp))
        }
    }
}

@Composable
private fun SmallChip(label: String, onClick: () -> Unit) {
    Text(
        label,
        modifier = Modifier.focusRing(RoundedCornerShape(50)).clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

private fun androidx.compose.foundation.lazy.LazyListScope.hubTitles(
    title: String,
    list: List<HubTitle>,
    posterW: Dp,
    onTitle: (HubTitle) -> Unit,
    note: String? = null,
) {
    if (list.isEmpty()) return
    item {
        HubRow(title, note) {
            items(list) { t -> PosterCard(t, posterW) { onTitle(t) } }
        }
    }
}

@Composable
private fun HubRow(
    title: String,
    note: String? = null,
    count: Int? = null,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit,
) {
    Column {
        SectionTitle(title, count, note)
        Spacer(Modifier.height(10.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            content = content,
        )
    }
}

private val CardShape = RoundedCornerShape(8.dp)

@Composable
private fun PosterCard(t: HubTitle, width: Dp, onClick: () -> Unit) {
    Column(Modifier.width(width)) {
        Box(
            Modifier
                .width(width)
                .height(width * 1.5f)
                .focusRing(CardShape, 1.06f)
                .clip(CardShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Text(t.title, textAlign = TextAlign.Center, maxLines = 4, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(6.dp))
            if (t.poster != null) {
                AsyncImage(model = t.poster, contentDescription = t.title, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize())
            }
            if (t.item != null && !t.resume) {
                Text(
                    "✓",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)
                        .clip(RoundedCornerShape(50)).background(Color(0xCC1B5E20)).padding(horizontal = 6.dp, vertical = 1.dp),
                )
            }
            if (t.progress > 0f) {
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(4.dp).background(Color(0x88000000))) {
                    Box(Modifier.fillMaxWidth(t.progress).fillMaxHeight().background(MaterialTheme.colorScheme.primary))
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        if (t.subtitle.isNotEmpty()) {
            Text(t.subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ChannelCard(ch: Channel, now: String?, tv: Boolean, art: String? = null, onClick: () -> Unit) {
    val w = if (tv) 200.dp else 160.dp
    Column(Modifier.width(w)) {
        Box(
            Modifier
                .width(w)
                .height(w * 9 / 16)
                .focusRing(CardShape, 1.06f)
                .clip(CardShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Text(ch.name, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(8.dp))
            if (art != null) {
                // What's on now (artwork from the guide or Trakt), with the channel's logo in the corner.
                AsyncImage(model = art, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                if (ch.logo != null) {
                    AsyncImage(model = ch.logo, contentDescription = ch.name, contentScale = ContentScale.Fit,
                        modifier = Modifier.align(Alignment.TopStart).padding(6.dp).size(40.dp, 28.dp)
                            .clip(RoundedCornerShape(4.dp)).background(Color(0xAA000000)).padding(2.dp))
                }
            } else if (ch.logo != null) {
                AsyncImage(model = ch.logo, contentDescription = ch.name, contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant).padding(14.dp))
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        Text(now ?: ch.group, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun GameCard(r: GamesViewModel.RecentGame, console: String, width: Dp, onClick: () -> Unit) {
    Column(Modifier.width(width)) {
        Box(
            Modifier
                .width(width)
                .height(width * 1.35f)
                .focusRing(CardShape, 1.06f)
                .clip(CardShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Text(r.game.title, textAlign = TextAlign.Center, maxLines = 4, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(6.dp))
            if (r.game.art != null) {
                AsyncImage(model = r.game.art, contentDescription = r.game.title, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(r.game.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        Text(listOf(console, ago(r.playedAt)).filter { it.isNotEmpty() }.joinToString(" · "), maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SportsCard(e: SportsEvent, tv: Boolean, onClick: () -> Unit) {
    val w = if (tv) 220.dp else 180.dp
    val fmt = remember { java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault()) }
    Column(Modifier.width(w)) {
        Box(
            Modifier.width(w).height(w * 9 / 16).focusRing(CardShape, 1.06f).clip(CardShape)
                .background(Color(0xFF1E3A2A)).clickable(onClick = onClick).padding(10.dp),
        ) {
            if (e.image != null) {
                AsyncImage(model = e.image, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Text(e.title, style = MaterialTheme.typography.titleSmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
            Text(
                if (e.live) "● LIVE" else fmt.format(java.util.Date(e.start)),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.align(Alignment.BottomStart).clip(RoundedCornerShape(50))
                    .background(if (e.live) Color(0xCCB71C1C) else Color(0xAA000000)).padding(horizontal = 6.dp, vertical = 1.dp),
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(e.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        Text(e.channels.joinToString(", ") { it.name }, maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Xbox Game Pass, GeForce NOW and Moonlight: opens each one's app (or its store page / web player). */
@Composable
fun CloudGamingRow(modifier: Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val tv = rememberIsTv()
    val w = if (tv) 220.dp else 170.dp
    LazyRow(modifier, contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(CloudGaming.services) { s ->
            val installed = remember(s.name) { CloudGaming.installed(ctx, s) != null }
            Column(Modifier.width(w)) {
                Box(
                    Modifier.width(w).height(w * 9 / 16).focusRing(CardShape, 1.06f).clip(CardShape)
                        .background(Color(s.color)).clickable {
                            CloudGaming.open(ctx, s)?.let { msg -> android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_SHORT).show() }
                        }.padding(12.dp),
                    contentAlignment = Alignment.BottomStart,
                ) {
                    Text(s.name, style = MaterialTheme.typography.titleMedium, color = Color.White)
                }
                Spacer(Modifier.height(4.dp))
                Text(s.blurb, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(if (installed) "Installed" else "Not installed: opens its store page", style = MaterialTheme.typography.labelSmall,
                    color = if (installed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun ago(ms: Long): String {
    val min = (System.currentTimeMillis() - ms) / 60_000
    return when {
        ms <= 0 -> ""
        min < 1 -> "just now"
        min < 60 -> "${min}m ago"
        min < 24 * 60 -> "${min / 60}h ago"
        min < 14 * 24 * 60 -> "${min / (24 * 60)}d ago"
        else -> java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT).format(java.util.Date(ms))
    }
}

/** For titles that aren't in your Plex library: poster, year and overview. */
@Composable
private fun TitleInfoDialog(t: HubTitle, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(t.title) },
        text = {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (t.poster != null) {
                    AsyncImage(model = t.poster, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.size(100.dp, 150.dp).clip(CardShape))
                }
                Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState())) {
                    if (t.subtitle.isNotEmpty()) Text(t.subtitle, style = MaterialTheme.typography.bodySmall)
                    Text("Not in your Plex library.", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Text(t.overview ?: "No description.")
                }
            }
        },
        confirmButton = {
            Button(onClick = onClose, modifier = Modifier.focusRing(ButtonShape)) { Text("Close") }
        },
        dismissButton = {
            // Seerr (Settings > Services): ask your server to get it.
            if (Seerr.configured) {
                val scope = androidx.compose.runtime.rememberCoroutineScope()
                var state by remember { mutableStateOf("Request") }
                androidx.compose.material3.OutlinedButton(enabled = state == "Request", modifier = Modifier.focusRing(ButtonShape), onClick = {
                    state = "Requesting…"
                    scope.launch {
                        state = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                            runCatching {
                                val r = Seerr.find(t.title, t.subtitle.take(4).toIntOrNull() ?: 0, null) ?: return@runCatching "Not found on Seerr"
                                r.statusLabel ?: run { Seerr.request(r); "Requested ✓" }
                            }.getOrElse { it.message ?: "Couldn't request" }
                        }
                    }
                }) { Text(state) }
            }
        },
    )
}
