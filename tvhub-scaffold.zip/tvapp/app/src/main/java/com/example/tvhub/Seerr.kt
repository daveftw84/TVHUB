package com.example.tvhub

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Overseerr / Jellyseerr ("Seerr"): request titles that aren't in your library yet.
 * Uses your server's address and API key (Seerr > Settings > General > API Key).
 */
object Seerr {
    val url: String get() = Opt.str("seerr_url", "").trim().trimEnd('/')
    val key: String get() = Opt.str("seerr_key", "").trim()
    val configured: Boolean get() = url.isNotEmpty() && key.isNotEmpty()

    data class Result(val id: Int, val mediaType: String, val title: String, val year: String, val status: Int) {
        /** Seerr media status: 2 pending, 3 processing, 4 partly available, 5 available. */
        val statusLabel: String? get() = when (status) {
            2 -> "Requested"; 3 -> "Processing"; 4 -> "Partly available"; 5 -> "Available"; else -> null
        }
    }

    private fun call(path: String, method: String = "GET", body: String? = null): String {
        val c = URL(url + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 10_000
        c.readTimeout = 20_000
        c.setRequestProperty("X-Api-Key", key)
        c.setRequestProperty("Accept", "application/json")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        if (c.responseCode !in 200..299) {
            val err = runCatching { c.errorStream?.bufferedReader()?.readText() }.getOrNull().orEmpty()
            throw IOException("Seerr returned HTTP ${c.responseCode} ${JSONObject(err.ifEmpty { "{}" }).optString("message")}".trim())
        }
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Checks the address and key. Returns the server's version. */
    fun test(): String = JSONObject(call("/api/v1/status")).optString("version", "OK")

    /** Finds a movie or show by title (and year when known). */
    fun find(title: String, year: Int, movie: Boolean?): Result? {
        val q = URLEncoder.encode(title, "UTF-8").replace("+", "%20")
        val results = JSONObject(call("/api/v1/search?query=$q&page=1")).optJSONArray("results") ?: return null
        val list = (0 until results.length()).mapNotNull { results.optJSONObject(it) }.filter { it.optString("mediaType") in setOf("movie", "tv") }
            .map { o ->
                Result(o.optInt("id"), o.optString("mediaType"), o.optString("title").ifEmpty { o.optString("name") },
                    o.optString("releaseDate").ifEmpty { o.optString("firstAirDate") }.take(4),
                    o.optJSONObject("mediaInfo")?.optInt("status") ?: 0)
            }
        return list.firstOrNull { (movie == null || (it.mediaType == "movie") == movie) && (year == 0 || it.year == year.toString()) && it.title.equals(title, true) }
            ?: list.firstOrNull { (movie == null || (it.mediaType == "movie") == movie) && (year == 0 || it.year == year.toString()) }
            ?: list.firstOrNull()
    }

    /** Requests it (all seasons for a show). */
    fun request(r: Result) {
        val body = JSONObject().put("mediaType", r.mediaType).put("mediaId", r.id)
        if (r.mediaType == "tv") body.put("seasons", "all")
        call("/api/v1/request", "POST", body.toString())
    }
}

/** MDBList: ratings from IMDb, Rotten Tomatoes, Metacritic, Letterboxd... for any title (needs your free API key). */
object MdbList {
    val key: String get() = Opt.str("mdblist_key", "").trim()

    fun ratings(imdb: String): List<PlexRating> {
        if (key.isEmpty()) return emptyList()
        val c = URL("https://mdblist.com/api/?apikey=${URLEncoder.encode(key, "UTF-8")}&i=$imdb").openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        val arr = o.optJSONArray("ratings") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.mapNotNull { r ->
            val v = r.optDouble("value", -1.0).takeIf { it > 0 } ?: return@mapNotNull null
            when (r.optString("source")) {
                "imdb" -> PlexRating("imdb", v)
                "tomatoes" -> PlexRating("rt", v)
                "popcorn", "audience" -> PlexRating("rt-audience", v)
                "tmdb" -> PlexRating("tmdb", v)
                "metacritic" -> PlexRating("other-mc", v)
                "letterboxd" -> PlexRating("other-lb", v)
                else -> null
            }
        }
    }
}
