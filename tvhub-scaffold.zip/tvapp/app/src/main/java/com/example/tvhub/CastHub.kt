package com.example.tvhub

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.UUID
import kotlin.concurrent.thread

/** Something sent to this TV: a video link, a YouTube video, a Plex title, a channel, a game or a song. */
data class CastRequest(
    val type: String,            // video, youtube, plex, channel, game, song
    val url: String = "",
    val title: String = "",
    val startMs: Long = 0,
    val ratingKey: String = "",
    val channelKey: String = "",
    val rommId: Int = 0,
    val artist: String = "",
    val art: String = "",
    val at: Long = System.nanoTime(),
)

/**
 * Receiving casts, and multiplayer rooms. One small server on the local network:
 *  - TV Hub on a phone casts here (videos, YouTube, Plex, channels, songs, games) and can be a game controller.
 *  - DLNA / UPnP "media renderer", the open casting standard, so phone apps such as BubbleUPnP, Web Video
 *    Caster, VLC or LocalCast can send videos and music here. (Google Cast / Chromecast can't be received by
 *    an app: Google only allows its own registered receivers.)
 *  - Game rooms: friends join a game by its code from TV Hub or any phone browser, each as another player.
 * Only devices on your local network can reach it.
 */
object CastHub {
    const val FIRST_PORT = 8765
    var port by mutableStateOf(-1)
        private set
    var running by mutableStateOf(false)
        private set
    /** The latest thing cast here; the app plays it. */
    var incoming by mutableStateOf<CastRequest?>(null)
        private set
    private val uuid by lazy { "uuid:" + UUID.nameUUIDFromBytes(("tvhub-" + Build.MODEL).toByteArray()) }
    private val main = Handler(Looper.getMainLooper())
    private lateinit var app: Context
    private var multicastLock: WifiManager.MulticastLock? = null

    val deviceName: String get() = try {
        android.provider.Settings.Global.getString(app.contentResolver, "device_name") ?: Build.MODEL
    } catch (_: Exception) { Build.MODEL }

    fun consumed() { incoming = null }

    fun start(ctx: Context) {
        if (running) return
        app = ctx.applicationContext
        for (p in FIRST_PORT..FIRST_PORT + 9) {
            val s = try { ServerSocket(p) } catch (_: Exception) { continue }
            port = p
            running = true
            thread(isDaemon = true, name = "cast-http") {
                while (!s.isClosed) {
                    val sock = try { s.accept() } catch (_: Exception) { break }
                    thread(isDaemon = true) { try { handle(sock) } catch (_: Exception) {} finally { runCatching { sock.close() } } }
                }
            }
            startSsdp()
            return
        }
    }

    private fun localOnly(sock: Socket): Boolean {
        val a = sock.inetAddress
        return a.isSiteLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress
    }

    // ------------------------------------------------------------ HTTP

    private class Req(val method: String, val path: String, val query: Map<String, String>, val headers: Map<String, String>, val body: String)

    private fun readReq(input: InputStream): Req? {
        val buf = BufferedInputStream(input)
        fun line(): String? {
            val sb = StringBuilder()
            while (true) {
                val c = buf.read()
                if (c == -1) return if (sb.isEmpty()) null else sb.toString()
                if (c == '\n'.code) return sb.toString().trimEnd('\r')
                sb.append(c.toChar())
            }
        }
        val first = line() ?: return null
        val parts = first.split(' ')
        if (parts.size < 2) return null
        val headers = HashMap<String, String>()
        while (true) {
            val l = line() ?: break
            if (l.isEmpty()) break
            val i = l.indexOf(':')
            if (i > 0) headers[l.substring(0, i).trim().lowercase()] = l.substring(i + 1).trim()
        }
        val len = headers["content-length"]?.toIntOrNull() ?: 0
        val out = ByteArrayOutputStream()
        var left = len.coerceAtMost(2_000_000)
        val chunk = ByteArray(8192)
        while (left > 0) {
            val n = buf.read(chunk, 0, minOf(chunk.size, left))
            if (n <= 0) break
            out.write(chunk, 0, n)
            left -= n
        }
        val full = parts[1]
        val path = full.substringBefore('?')
        val query = full.substringAfter('?', "").split('&').filter { it.contains('=') }.associate {
            java.net.URLDecoder.decode(it.substringBefore('='), "UTF-8") to java.net.URLDecoder.decode(it.substringAfter('='), "UTF-8")
        }
        return Req(parts[0].uppercase(), path, query, headers, out.toString("UTF-8"))
    }

    private fun send(out: OutputStream, status: String, type: String, body: String, extra: Map<String, String> = emptyMap()) {
        val bytes = body.toByteArray()
        val head = StringBuilder("HTTP/1.1 $status\r\nContent-Type: $type\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n" +
            "Access-Control-Allow-Origin: *\r\n")
        extra.forEach { (k, v) -> head.append("$k: $v\r\n") }
        head.append("\r\n")
        out.write(head.toString().toByteArray())
        out.write(bytes)
        out.flush()
    }

    private fun json(out: OutputStream, o: JSONObject, status: String = "200 OK") = send(out, status, "application/json", o.toString())

    /** The screen in front (TV Hub's main screen or a game), for the Companion Remote. */
    @Volatile var activity: java.lang.ref.WeakReference<android.app.Activity>? = null

    /** Companion Remote: a phone presses a button (or types text) on this TV. */
    private fun remote(key: String, text: String) {
        val a = activity?.get() ?: return
        if (text.isNotEmpty()) {
            android.view.KeyCharacterMap.load(android.view.KeyCharacterMap.VIRTUAL_KEYBOARD).getEvents(text.toCharArray())
                ?.forEach { a.dispatchKeyEvent(it) }
            return
        }
        val am = a.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        when (key) {
            "volup" -> { am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_RAISE, android.media.AudioManager.FLAG_SHOW_UI); return }
            "voldown" -> { am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_LOWER, android.media.AudioManager.FLAG_SHOW_UI); return }
            "mute" -> { am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_TOGGLE_MUTE, android.media.AudioManager.FLAG_SHOW_UI); return }
        }
        val code = when (key) {
            "up" -> android.view.KeyEvent.KEYCODE_DPAD_UP
            "down" -> android.view.KeyEvent.KEYCODE_DPAD_DOWN
            "left" -> android.view.KeyEvent.KEYCODE_DPAD_LEFT
            "right" -> android.view.KeyEvent.KEYCODE_DPAD_RIGHT
            "ok" -> android.view.KeyEvent.KEYCODE_DPAD_CENTER
            "back" -> android.view.KeyEvent.KEYCODE_BACK
            "play" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "rew" -> android.view.KeyEvent.KEYCODE_MEDIA_REWIND
            "ff" -> android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD
            "chup" -> android.view.KeyEvent.KEYCODE_CHANNEL_UP
            "chdown" -> android.view.KeyEvent.KEYCODE_CHANNEL_DOWN
            "menu" -> android.view.KeyEvent.KEYCODE_MENU
            "guide" -> android.view.KeyEvent.KEYCODE_GUIDE
            "info" -> android.view.KeyEvent.KEYCODE_INFO
            "search" -> android.view.KeyEvent.KEYCODE_SEARCH
            "del" -> android.view.KeyEvent.KEYCODE_DEL
            else -> key.toIntOrNull()?.takeIf { it in 0..9 }?.let { android.view.KeyEvent.KEYCODE_0 + it } ?: return
        }
        val t = android.os.SystemClock.uptimeMillis()
        a.dispatchKeyEvent(android.view.KeyEvent(t, t, android.view.KeyEvent.ACTION_DOWN, code, 0))
        a.dispatchKeyEvent(android.view.KeyEvent(t, t + 50, android.view.KeyEvent.ACTION_UP, code, 0))
    }

    private fun handle(sock: Socket) {
        sock.soTimeout = 15_000
        val out = sock.getOutputStream()
        if (!localOnly(sock)) { send(out, "403 Forbidden", "text/plain", "Local network only"); return }
        val r = readReq(sock.getInputStream()) ?: return
        when {
            r.method == "OPTIONS" -> send(out, "204 No Content", "text/plain", "",
                mapOf("Access-Control-Allow-Methods" to "GET, POST", "Access-Control-Allow-Headers" to "Content-Type"))
            r.path == "/tvhub" -> json(out, JSONObject().put("app", "TV Hub").put("name", deviceName).put("port", port)
                .put("room", GameRoom.code ?: JSONObject.NULL).put("game", GameRoom.title ?: JSONObject.NULL))
            r.path == "/cast" && r.method == "POST" -> {
                val o = JSONObject(r.body.ifEmpty { "{}" })
                val req = CastRequest(o.optString("type", "video"), o.optString("url"), o.optString("title"), o.optLong("startMs"),
                    o.optString("ratingKey"), o.optString("channelKey"), o.optInt("rommId"), o.optString("artist"), o.optString("art"))
                main.post { incoming = req }
                json(out, JSONObject().put("ok", true))
            }
            r.path == "/pad" -> send(out, "200 OK", "text/html; charset=utf-8", PAD_PAGE)
            r.path == "/remote" && r.method == "POST" -> {
                val o = JSONObject(r.body.ifEmpty { "{}" })
                main.post { remote(o.optString("key"), o.optString("text")) }
                json(out, JSONObject().put("ok", true))
            }
            r.path.startsWith("/room/") -> room(r, out)
            r.path.startsWith("/dlna/") -> dlna(r, out)
            else -> send(out, "404 Not Found", "text/plain", "Not found")
        }
    }

    // ------------------------------------------------------------ Game rooms (multiplayer)

    private fun room(r: Req, out: OutputStream) {
        val o = runCatching { JSONObject(r.body.ifEmpty { "{}" }) }.getOrDefault(JSONObject())
        when (r.path) {
            "/room/join" -> {
                val res = GameRoom.join(o.optString("code"), o.optString("name").ifEmpty { "Player" })
                if (res == null) json(out, JSONObject().put("ok", false).put("error", GameRoom.lastError), "200 OK")
                else json(out, JSONObject().put("ok", true).put("token", res.first).put("player", res.second + 1).put("game", GameRoom.title ?: ""))
            }
            "/room/input" -> {
                GameRoom.input(o.optString("token"), o.optString("key"), o.optBoolean("down"))
                json(out, JSONObject().put("ok", true))
            }
            "/room/leave" -> { GameRoom.leave(o.optString("token")); json(out, JSONObject().put("ok", true)) }
            "/room/info" -> json(out, JSONObject().put("open", GameRoom.code != null).put("game", GameRoom.title ?: ""))
            else -> send(out, "404 Not Found", "text/plain", "Not found")
        }
    }

    // ------------------------------------------------------------ DLNA / UPnP media renderer

    /** The player for videos and music cast from other apps. */
    var castPlayer: ExoPlayer? = null
        private set
    var castTitle by mutableStateOf<String?>(null)
        private set
    private var castUri = ""
    private var castMeta = ""
    private var volume = 100

    private fun onMain(block: () -> Unit) = main.post(block)

    private fun <T> onMainWait(block: () -> T): T? {
        var result: T? = null
        val lock = Object()
        var done = false
        main.post {
            try { result = block() } finally { synchronized(lock) { done = true; lock.notifyAll() } }
        }
        synchronized(lock) { val end = System.currentTimeMillis() + 3000; while (!done && System.currentTimeMillis() < end) lock.wait(200) }
        return result
    }

    /** Plays a video full screen over the app (downloads, offline files), even if receiving casts is off. */
    fun playLocal(ctx: Context, url: String, title: String) {
        if (!::app.isInitialized) app = ctx.applicationContext
        playCast(url, title)
    }

    fun playCast(url: String, title: String, startMs: Long = 0) {
        val p = castPlayer ?: ExoPlayer.Builder(app).build().also { castPlayer = it }
        p.setMediaItem(MediaItem.Builder().setUri(url).setMediaMetadata(MediaMetadata.Builder().setTitle(title).build()).build())
        p.prepare()
        if (startMs > 0) p.seekTo(startMs)
        p.playWhenReady = true
        castUri = url
        castTitle = title.ifEmpty { "Cast video" }
    }

    fun stopCast() {
        castPlayer?.stop()
        castTitle = null
    }

    private fun arg(body: String, name: String): String =
        Regex("<(?:\\w+:)?$name[^>]*>([\\s\\S]*?)</(?:\\w+:)?$name>").find(body)?.groupValues?.get(1)?.let { unescape(it) } ?: ""

    private fun unescape(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun hms(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, s / 60 % 60, s % 60)
    }

    private fun parseHms(t: String): Long {
        val p = t.split(':').map { it.toDoubleOrNull() ?: 0.0 }
        return when (p.size) { 3 -> ((p[0] * 3600 + p[1] * 60 + p[2]) * 1000).toLong(); 2 -> ((p[0] * 60 + p[1]) * 1000).toLong(); else -> 0 }
    }

    private fun soap(service: String, action: String, values: Map<String, String>): String {
        val inner = values.entries.joinToString("") { "<${it.key}>${esc(it.value)}</${it.key}>" }
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><u:${action}Response " +
            "xmlns:u=\"urn:schemas-upnp-org:service:$service:1\">$inner</u:${action}Response></s:Body></s:Envelope>"
    }

    private fun dlna(r: Req, out: OutputStream) {
        val xml = "text/xml; charset=\"utf-8\""
        when {
            r.path == "/dlna/desc.xml" -> send(out, "200 OK", xml, description())
            r.path.endsWith("/scpd.xml") -> send(out, "200 OK", xml, scpd(r.path.removePrefix("/dlna/").substringBefore('/')))
            r.method == "SUBSCRIBE" -> send(out, "200 OK", "text/plain", "", mapOf("SID" to "uuid:" + UUID.randomUUID(), "TIMEOUT" to "Second-1800"))
            r.method == "UNSUBSCRIBE" -> send(out, "200 OK", "text/plain", "")
            r.path.endsWith("/control") -> {
                val service = r.path.removePrefix("/dlna/").substringBefore('/')
                val action = (r.headers["soapaction"] ?: "").trim('"').substringAfter('#')
                send(out, "200 OK", xml, control(service, action, r.body))
            }
            else -> send(out, "404 Not Found", "text/plain", "")
        }
    }

    private fun control(service: String, action: String, body: String): String = when (service) {
        "AVTransport" -> when (action) {
            "SetAVTransportURI" -> {
                val uri = arg(body, "CurrentURI")
                castMeta = arg(body, "CurrentURIMetaData")
                val title = Regex("<dc:title>([\\s\\S]*?)</dc:title>").find(unescape(castMeta))?.groupValues?.get(1)?.let { unescape(it) } ?: "Cast video"
                onMain { playCast(uri, title); castPlayer?.playWhenReady = false; incoming = CastRequest("video", uri, title) }
                soap(service, action, emptyMap())
            }
            "Play" -> { onMain { castPlayer?.play() }; soap(service, action, emptyMap()) }
            "Pause" -> { onMain { castPlayer?.pause() }; soap(service, action, emptyMap()) }
            "Stop" -> { onMain { stopCast() }; soap(service, action, emptyMap()) }
            "Seek" -> { val t = parseHms(arg(body, "Target")); onMain { castPlayer?.seekTo(t) }; soap(service, action, emptyMap()) }
            "GetTransportInfo" -> {
                val st = onMainWait {
                    val p = castPlayer
                    when {
                        p == null || castTitle == null -> "NO_MEDIA_PRESENT"
                        p.playbackState == Player.STATE_BUFFERING -> "TRANSITIONING"
                        p.isPlaying -> "PLAYING"
                        p.playbackState == Player.STATE_ENDED || p.playbackState == Player.STATE_IDLE -> "STOPPED"
                        else -> "PAUSED_PLAYBACK"
                    }
                } ?: "STOPPED"
                soap(service, action, mapOf("CurrentTransportState" to st, "CurrentTransportStatus" to "OK", "CurrentSpeed" to "1"))
            }
            "GetPositionInfo" -> {
                val (pos, dur) = onMainWait { (castPlayer?.currentPosition ?: 0L) to (castPlayer?.duration?.coerceAtLeast(0) ?: 0L) } ?: (0L to 0L)
                soap(service, action, mapOf("Track" to "1", "TrackDuration" to hms(dur), "TrackMetaData" to castMeta, "TrackURI" to castUri,
                    "RelTime" to hms(pos), "AbsTime" to hms(pos), "RelCount" to "2147483647", "AbsCount" to "2147483647"))
            }
            "GetMediaInfo" -> soap(service, action, mapOf("NrTracks" to "1", "MediaDuration" to "0:00:00", "CurrentURI" to castUri,
                "CurrentURIMetaData" to castMeta, "NextURI" to "", "NextURIMetaData" to "", "PlayMedium" to "NETWORK",
                "RecordMedium" to "NOT_IMPLEMENTED", "WriteStatus" to "NOT_IMPLEMENTED"))
            "GetTransportSettings" -> soap(service, action, mapOf("PlayMode" to "NORMAL", "RecQualityMode" to "NOT_IMPLEMENTED"))
            "GetCurrentTransportActions" -> soap(service, action, mapOf("Actions" to "Play,Pause,Stop,Seek"))
            "GetDeviceCapabilities" -> soap(service, action, mapOf("PlayMedia" to "NETWORK", "RecMedia" to "NOT_IMPLEMENTED", "RecQualityModes" to "NOT_IMPLEMENTED"))
            else -> soap(service, action, emptyMap())
        }
        "RenderingControl" -> when (action) {
            "GetVolume" -> soap(service, action, mapOf("CurrentVolume" to volume.toString()))
            "SetVolume" -> {
                volume = arg(body, "DesiredVolume").toIntOrNull()?.coerceIn(0, 100) ?: volume
                onMain { castPlayer?.volume = volume / 100f }
                soap(service, action, emptyMap())
            }
            "GetMute" -> soap(service, action, mapOf("CurrentMute" to if (volume == 0) "1" else "0"))
            "SetMute" -> { val m = arg(body, "DesiredMute") == "1"; onMain { castPlayer?.volume = if (m) 0f else volume / 100f }; soap(service, action, emptyMap()) }
            else -> soap(service, action, emptyMap())
        }
        else -> when (action) {   // ConnectionManager
            "GetProtocolInfo" -> soap(service, action, mapOf("Source" to "", "Sink" to SINK))
            "GetCurrentConnectionIDs" -> soap(service, action, mapOf("ConnectionIDs" to "0"))
            "GetCurrentConnectionInfo" -> soap(service, action, mapOf("RcsID" to "0", "AVTransportID" to "0", "ProtocolInfo" to "",
                "PeerConnectionManager" to "", "PeerConnectionID" to "-1", "Direction" to "Input", "Status" to "OK"))
            else -> soap(service, action, emptyMap())
        }
    }

    private const val SINK = "http-get:*:video/mp4:*,http-get:*:video/x-matroska:*,http-get:*:video/webm:*,http-get:*:video/mpeg:*," +
        "http-get:*:video/mp2t:*,http-get:*:application/vnd.apple.mpegurl:*,http-get:*:application/x-mpegURL:*,http-get:*:video/x-msvideo:*," +
        "http-get:*:audio/mpeg:*,http-get:*:audio/mp4:*,http-get:*:audio/aac:*,http-get:*:audio/flac:*,http-get:*:audio/ogg:*," +
        "http-get:*:audio/x-wav:*,http-get:*:image/jpeg:*,http-get:*:image/png:*,http-get:*:*:*"

    private fun description(): String =
        "<?xml version=\"1.0\"?><root xmlns=\"urn:schemas-upnp-org:device-1-0\"><specVersion><major>1</major><minor>0</minor></specVersion>" +
            "<device><deviceType>urn:schemas-upnp-org:device:MediaRenderer:1</deviceType><friendlyName>${esc(deviceName)} (TV Hub)</friendlyName>" +
            "<manufacturer>TV Hub</manufacturer><modelName>TV Hub</modelName><modelDescription>TV Hub media renderer</modelDescription>" +
            "<UDN>$uuid</UDN><serviceList>" +
            listOf("AVTransport", "RenderingControl", "ConnectionManager").joinToString("") { s ->
                "<service><serviceType>urn:schemas-upnp-org:service:$s:1</serviceType><serviceId>urn:upnp-org:serviceId:$s</serviceId>" +
                    "<SCPDURL>/dlna/$s/scpd.xml</SCPDURL><controlURL>/dlna/$s/control</controlURL><eventSubURL>/dlna/$s/event</eventSubURL></service>"
            } + "</serviceList></device></root>"

    /** Service descriptions: the actions above and their arguments. */
    private fun scpd(service: String): String {
        val iid = "in:InstanceID:A_ARG_TYPE_InstanceID"
        val actions: Map<String, List<String>> = when (service) {
            "AVTransport" -> mapOf(
                "SetAVTransportURI" to listOf(iid, "in:CurrentURI:AVTransportURI", "in:CurrentURIMetaData:AVTransportURIMetaData"),
                "Play" to listOf(iid, "in:Speed:TransportPlaySpeed"), "Pause" to listOf(iid), "Stop" to listOf(iid),
                "Seek" to listOf(iid, "in:Unit:A_ARG_TYPE_SeekMode", "in:Target:A_ARG_TYPE_SeekTarget"),
                "GetTransportInfo" to listOf(iid, "out:CurrentTransportState:TransportState", "out:CurrentTransportStatus:TransportStatus", "out:CurrentSpeed:TransportPlaySpeed"),
                "GetPositionInfo" to listOf(iid, "out:Track:CurrentTrack", "out:TrackDuration:CurrentTrackDuration", "out:TrackMetaData:CurrentTrackMetaData",
                    "out:TrackURI:CurrentTrackURI", "out:RelTime:RelativeTimePosition", "out:AbsTime:AbsoluteTimePosition",
                    "out:RelCount:RelativeCounterPosition", "out:AbsCount:AbsoluteCounterPosition"),
                "GetMediaInfo" to listOf(iid, "out:NrTracks:NumberOfTracks", "out:MediaDuration:CurrentMediaDuration", "out:CurrentURI:AVTransportURI",
                    "out:CurrentURIMetaData:AVTransportURIMetaData", "out:NextURI:NextAVTransportURI", "out:NextURIMetaData:NextAVTransportURIMetaData",
                    "out:PlayMedium:PlaybackStorageMedium", "out:RecordMedium:RecordStorageMedium", "out:WriteStatus:RecordMediumWriteStatus"),
                "GetTransportSettings" to listOf(iid, "out:PlayMode:CurrentPlayMode", "out:RecQualityMode:CurrentRecordQualityMode"),
                "GetCurrentTransportActions" to listOf(iid, "out:Actions:CurrentTransportActions"),
                "GetDeviceCapabilities" to listOf(iid, "out:PlayMedia:PossiblePlaybackStorageMedia", "out:RecMedia:PossibleRecordStorageMedia",
                    "out:RecQualityModes:PossibleRecordQualityModes"),
            )
            "RenderingControl" -> mapOf(
                "GetVolume" to listOf(iid, "in:Channel:A_ARG_TYPE_Channel", "out:CurrentVolume:Volume"),
                "SetVolume" to listOf(iid, "in:Channel:A_ARG_TYPE_Channel", "in:DesiredVolume:Volume"),
                "GetMute" to listOf(iid, "in:Channel:A_ARG_TYPE_Channel", "out:CurrentMute:Mute"),
                "SetMute" to listOf(iid, "in:Channel:A_ARG_TYPE_Channel", "in:DesiredMute:Mute"),
            )
            else -> mapOf(
                "GetProtocolInfo" to listOf("out:Source:SourceProtocolInfo", "out:Sink:SinkProtocolInfo"),
                "GetCurrentConnectionIDs" to listOf("out:ConnectionIDs:CurrentConnectionIDs"),
                "GetCurrentConnectionInfo" to listOf("in:ConnectionID:A_ARG_TYPE_ConnectionID", "out:RcsID:A_ARG_TYPE_RcsID",
                    "out:AVTransportID:A_ARG_TYPE_AVTransportID", "out:ProtocolInfo:A_ARG_TYPE_ProtocolInfo",
                    "out:PeerConnectionManager:A_ARG_TYPE_ConnectionManager", "out:PeerConnectionID:A_ARG_TYPE_ConnectionID",
                    "out:Direction:A_ARG_TYPE_Direction", "out:Status:A_ARG_TYPE_ConnectionStatus"),
            )
        }
        val vars = actions.values.flatten().map { it.split(':')[2] }.toSet()
        val a = actions.entries.joinToString("") { (name, args) ->
            "<action><name>$name</name><argumentList>" + args.joinToString("") {
                val (dir, arg, v) = it.split(':')
                "<argument><name>$arg</name><direction>$dir</direction><relatedStateVariable>$v</relatedStateVariable></argument>"
            } + "</argumentList></action>"
        }
        val numeric = setOf("Volume", "A_ARG_TYPE_InstanceID", "NumberOfTracks", "CurrentTrack", "RelativeCounterPosition",
            "AbsoluteCounterPosition", "A_ARG_TYPE_ConnectionID", "A_ARG_TYPE_RcsID", "A_ARG_TYPE_AVTransportID")
        val v = vars.joinToString("") { name ->
            val type = when { name in numeric -> "i4"; name == "Mute" -> "boolean"; else -> "string" }
            "<stateVariable sendEvents=\"${if (name == "LastChange") "yes" else "no"}\"><name>$name</name><dataType>$type</dataType></stateVariable>"
        } + "<stateVariable sendEvents=\"yes\"><name>LastChange</name><dataType>string</dataType></stateVariable>"
        return "<?xml version=\"1.0\"?><scpd xmlns=\"urn:schemas-upnp-org:service-1-0\"><specVersion><major>1</major><minor>0</minor></specVersion>" +
            "<actionList>$a</actionList><serviceStateTable>$v</serviceStateTable></scpd>"
    }

    // ------------------------------------------------------------ SSDP (how phones find this TV)

    private val SSDP_ADDR = "239.255.255.250"
    private val TYPES by lazy {
        listOf("upnp:rootdevice", uuid, "urn:schemas-upnp-org:device:MediaRenderer:1", "urn:schemas-upnp-org:service:AVTransport:1",
            "urn:schemas-upnp-org:service:RenderingControl:1", "urn:schemas-upnp-org:service:ConnectionManager:1")
    }

    private fun location(): String = "http://${SetupServer.localIp() ?: "127.0.0.1"}:$port/dlna/desc.xml"

    private fun startSsdp() {
        try {
            val wifi = app.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            multicastLock = wifi?.createMulticastLock("tvhub-cast")?.apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) {}
        thread(isDaemon = true, name = "ssdp") {
            try {
                val sock = MulticastSocket(null).apply { reuseAddress = true; bind(InetSocketAddress(1900)) }
                @Suppress("DEPRECATION") sock.joinGroup(InetAddress.getByName(SSDP_ADDR))
                // Announce ourselves now and every few minutes.
                thread(isDaemon = true) {
                    while (true) {
                        TYPES.forEach { nt ->
                            val usn = if (nt == uuid) uuid else "$uuid::$nt"
                            val msg = "NOTIFY * HTTP/1.1\r\nHOST: $SSDP_ADDR:1900\r\nCACHE-CONTROL: max-age=1800\r\nLOCATION: ${location()}\r\n" +
                                "NT: $nt\r\nNTS: ssdp:alive\r\nSERVER: Android/${Build.VERSION.RELEASE} UPnP/1.0 TVHub/1.0\r\nUSN: $usn\r\n\r\n"
                            runCatching { sock.send(DatagramPacket(msg.toByteArray(), msg.length, InetAddress.getByName(SSDP_ADDR), 1900)) }
                        }
                        Thread.sleep(180_000)
                    }
                }
                val buf = ByteArray(2048)
                while (true) {
                    val pkt = DatagramPacket(buf, buf.size)
                    sock.receive(pkt)
                    val text = String(pkt.data, 0, pkt.length)
                    if (!text.startsWith("M-SEARCH")) continue
                    val st = Regex("(?im)^ST:\\s*(.+)$").find(text)?.groupValues?.get(1)?.trim() ?: continue
                    val matches = if (st == "ssdp:all") TYPES else TYPES.filter { it.equals(st, true) }
                    for (t in matches) {
                        val usn = if (t == uuid) uuid else "$uuid::$t"
                        val reply = "HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=1800\r\nEXT:\r\nLOCATION: ${location()}\r\n" +
                            "SERVER: Android/${Build.VERSION.RELEASE} UPnP/1.0 TVHub/1.0\r\nST: $t\r\nUSN: $usn\r\n\r\n"
                        runCatching { sock.send(DatagramPacket(reply.toByteArray(), reply.length, pkt.address, pkt.port)) }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    // ------------------------------------------------------------ The phone-browser controller page

    private val PAD_PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><title>TV Hub controller</title>
<style>
:root{color-scheme:dark}*{box-sizing:border-box;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
body{margin:0;background:#111;color:#eee;font:16px system-ui,sans-serif;height:100vh;overflow:hidden;touch-action:none}
#join{padding:24px;max-width:420px;margin:auto}input,button.j{font-size:20px;padding:12px;width:100%;margin:8px 0;border-radius:10px;border:1px solid #444;background:#222;color:#eee}
#pad{display:none;height:100vh;position:relative}#info{position:absolute;top:8px;left:0;right:0;text-align:center;opacity:.7}
.b{position:absolute;border-radius:50%;background:#333;border:2px solid #555;color:#fff;font-weight:600;display:flex;align-items:center;justify-content:center}
.b.on{background:#666}.d{width:64px;height:64px}.f{width:70px;height:70px}.s{width:84px;height:40px;border-radius:20px;font-size:14px}
</style></head><body>
<div id="join"><h2>Join a TV Hub game</h2><p>Enter the code shown on the TV.</p>
<input id="code" placeholder="Code" autocapitalize="characters" maxlength="6"><input id="name" placeholder="Your name">
<button class="j" onclick="join()">Join</button><p id="err" style="color:#f77"></p></div>
<div id="pad"><div id="info"></div></div>
<script>
let token=null;const q=new URLSearchParams(location.search);if(q.get('code'))document.getElementById('code').value=q.get('code');
async function post(p,o){const r=await fetch(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o),keepalive:true});return r.json()}
async function join(){const r=await post('/room/join',{code:document.getElementById('code').value.trim().toUpperCase(),name:document.getElementById('name').value||'Player'});
if(!r.ok){document.getElementById('err').textContent=r.error||'Could not join';return}token=r.token;
document.getElementById('join').style.display='none';document.getElementById('pad').style.display='block';
document.getElementById('info').textContent='Player '+r.player+' · '+r.game;build()}
function send(k,d){if(token)post('/room/input',{token:token,key:k,down:d})}
function btn(k,l,c,x,y){const e=document.createElement('div');e.className='b '+c;e.textContent=l;e.style.left=x;e.style.top=y;
const on=ev=>{ev.preventDefault();e.classList.add('on');send(k,true);if(navigator.vibrate)navigator.vibrate(15)};
const off=ev=>{ev.preventDefault();e.classList.remove('on');send(k,false)};
e.addEventListener('pointerdown',on);e.addEventListener('pointerup',off);e.addEventListener('pointercancel',off);e.addEventListener('pointerleave',off);
document.getElementById('pad').appendChild(e)}
function build(){const w=innerWidth,h=innerHeight,cy=h*0.55;
btn('up','▲','d',(90)+'px',(cy-80)+'px');btn('down','▼','d',(90)+'px',(cy+60)+'px');btn('left','◀','d',(20)+'px',(cy-10)+'px');btn('right','▶','d',(160)+'px',(cy-10)+'px');
btn('x','X','f',(w-170)+'px',(cy-90)+'px');btn('y','Y','f',(w-245)+'px',(cy-15)+'px');btn('a','A','f',(w-95)+'px',(cy-15)+'px');btn('b','B','f',(w-170)+'px',(cy+60)+'px');
btn('l','L','s','20px','40px');btn('l2','L2','s','115px','40px');btn('r2','R2','s',(w-200)+'px','40px');btn('r','R','s',(w-105)+'px','40px');
btn('select','Select','s',(w/2-95)+'px',(h-70)+'px');btn('start','Start','s',(w/2+10)+'px',(h-70)+'px')}
addEventListener('pagehide',()=>{if(token)navigator.sendBeacon('/room/leave',JSON.stringify({token:token}))});
</script></body></html>"""
}

/**
 * A multiplayer room for the game playing on this TV: a 6-character code; each player who joins (from TV Hub
 * on a phone, or any phone browser) gets the next free player number.
 */
object GameRoom {
    var code by mutableStateOf<String?>(null)
        private set
    var title by mutableStateOf<String?>(null)
        private set
    data class Guest(val token: String, val name: String, val port: Int)
    val guests = mutableStateListOf<Guest>()
    var lastError = ""
        private set
    /** Player numbers taken by controllers plugged into the TV (player 1 = 0). */
    var reservedPorts: Set<Int> = setOf(0)
    /** The game player sets this to receive guests' buttons: (player 0-3, key, pressed). */
    var sink: ((Int, String, Boolean) -> Unit)? = null

    fun open(gameTitle: String): String {
        val alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
        val r = SecureRandom()
        code = code ?: (1..6).map { alphabet[r.nextInt(alphabet.length)] }.joinToString("")
        title = gameTitle
        return code!!
    }

    @Synchronized
    fun close() {
        code = null
        title = null
        guests.clear()
        ports.clear()
    }

    private val ports = HashMap<String, Int>()   // token -> player (kept here too, so joins can't race)

    @Synchronized
    fun join(c: String, name: String): Pair<String, Int>? {
        if (code == null) { lastError = "No game is open for players right now."; return null }
        if (!c.equals(code, true)) { lastError = "That code isn't right."; return null }
        val free = (0..3).firstOrNull { p -> p !in reservedPorts && p !in ports.values }
            ?: run { lastError = "The game is full (4 players)."; return null }
        val g = Guest(java.util.UUID.randomUUID().toString(), name.take(20), free)
        ports[g.token] = free
        Handler(Looper.getMainLooper()).post { guests += g }
        return g.token to free
    }

    @Synchronized
    fun leave(token: String) {
        ports.remove(token)
        Handler(Looper.getMainLooper()).post { guests.removeAll { it.token == token } }
    }

    fun input(token: String, key: String, down: Boolean) {
        val port = synchronized(this) { ports[token] } ?: return
        sink?.invoke(port, key, down)
    }

    /** The link and message to send friends. */
    fun inviteText(): String {
        val c = code ?: return ""
        val link = "http://${SetupServer.localIp() ?: "your-tv"}:${CastHub.port}/pad?code=$c"
        return "Join my game ${title ?: ""} on TV Hub! Code: $c\nOn TV Hub: Games > Join a game. Or open on your phone: $link"
    }
}
