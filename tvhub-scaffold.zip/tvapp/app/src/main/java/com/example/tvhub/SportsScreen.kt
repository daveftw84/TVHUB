package com.example.tvhub

import android.app.Application
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class SportsViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("tvhub", Context.MODE_PRIVATE)
    var sport by mutableStateOf(Espn.SPORTS.first { it.name == "American Football" })
        private set
    /** Days from today (-3 .. +3). */
    var dayOffset by mutableStateOf(0)
        private set
    var leagues by mutableStateOf<List<Pair<Espn.League, List<Espn.Match>>>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var hidden by mutableStateOf(prefs.getStringSet("hidden_leagues", emptySet())!!.toSet())
        private set
    /** Leagues opened (closed ones show only their name). */
    var open by mutableStateOf(setOf<String>())
        private set
    private val cache = HashMap<String, List<Pair<Espn.League, List<Espn.Match>>>>()

    fun dayKey(offset: Int = dayOffset): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, offset)
        return SimpleDateFormat("yyyyMMdd", Locale.US).format(c.time)
    }

    fun pickSport(s: Espn.Sport) { sport = s; load() }
    fun pickDay(o: Int) { dayOffset = o; load() }
    fun toggle(league: String) { open = if (league in open) open - league else open + league }

    fun hide(league: String) {
        hidden = hidden + league
        prefs.edit().putStringSet("hidden_leagues", hidden).apply()
    }

    fun unhideAll() {
        hidden = emptySet()
        prefs.edit().putStringSet("hidden_leagues", hidden).apply()
    }

    fun load(force: Boolean = false) {
        val key = sport.name + dayKey()
        val today = dayOffset == 0
        if (!force && !today) cache[key]?.let { leagues = it; return }
        viewModelScope.launch {
            loading = true
            val s = sport
            val d = dayKey()
            val r = withContext(Dispatchers.IO) { Espn.sportDay(s, d) }
            if (s == sport && d == dayKey()) {
                leagues = r
                cache[key] = r
                // Leagues with games live or still to come start opened.
                if (open.isEmpty()) open = r.filter { (_, m) -> m.any { !it.ended } }.map { it.first.name }.take(2).toSet().ifEmpty { r.take(1).map { it.first.name }.toSet() }
            }
            loading = false
        }
    }
}

/** Your channels that show a game: by the networks ESPN lists, by channels named after the teams, and by the guide. */
fun knownChannels(live: LiveViewModel, m: Espn.Match): List<Channel> {
    val lineup = live.channels.distinctBy { it.key }
    val out = LinkedHashSet<Channel>()
    for (net in m.channels) {
        val n = normalizeChannelName(net)
        if (n.length < 2) continue
        lineup.filter { normalizeChannelName(it.name).let { c -> c == n || (c.startsWith(n) && c.length - n.length <= 3) } }.forEach { out += it }
    }
    // Event channels from IPTV providers are often named after the game ("NFL 04: Chiefs vs Bills").
    val teams = listOfNotNull(m.away?.name, m.home?.name).map { it.substringAfterLast(' ') }.filter { it.length > 2 }
    if (teams.size == 2) lineup.filter { ch -> teams.all { ch.name.contains(it, true) } }.forEach { out += it }
    // And the guide.
    if (teams.isNotEmpty()) {
        val (_, progs) = live.searchLive(teams.joinToString(" "))
        progs.filter { kotlin.math.abs(it.programme.start - m.start) < 3 * 3_600_000L }.forEach { out += it.channel }
    }
    return out.toList()
}

@Composable
fun SportsScreen(vm: SportsViewModel, live: LiveViewModel, onWatch: (Channel) -> Unit, onSearch: (String) -> Unit) {
    LaunchedEffect(Unit) { if (vm.leagues.isEmpty()) vm.load() }
    var sheet by remember { mutableStateOf<Espn.Match?>(null) }
    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Sports", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("⟳", style = MaterialTheme.typography.titleLarge, modifier = Modifier.focusRing(CircleShape).clip(CircleShape)
                .clickable { vm.load(true) }.padding(8.dp))
        }
        // Sports
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Espn.SPORTS) { s -> PillChip("${s.emoji}  ${s.name}", vm.sport == s) { vm.pickSport(s) } }
        }
        // Days
        val dayFmt = remember { SimpleDateFormat("EEE, d", Locale.getDefault()) }
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            items((-3..3).toList()) { o ->
                val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, o) }
                val sel = vm.dayOffset == o
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.focusRing(RoundedCornerShape(6.dp)).clickable { vm.pickDay(o) }.padding(4.dp)) {
                    Text(dayFmt.format(c.time), color = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                    Box(Modifier.padding(top = 4.dp).width(48.dp).height(3.dp).background(if (sel) MaterialTheme.colorScheme.primary else Color.Transparent))
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.surfaceVariant))
        val shown = vm.leagues.filter { it.first.name !in vm.hidden }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (vm.loading && shown.isEmpty()) item { Text("Loading…", modifier = Modifier.padding(12.dp)) }
            if (!vm.loading && shown.isEmpty()) item { Text("No ${vm.sport.name.lowercase()} on this day.", modifier = Modifier.padding(12.dp)) }
            shown.forEach { (league, matches) ->
                item(key = league.name) {
                    val isOpen = league.name in vm.open
                    Column(Modifier.clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))) {
                        Row(Modifier.fillMaxWidth().focusRing(RoundedCornerShape(24.dp)).clickable { vm.toggle(league.name) }
                            .padding(horizontal = 24.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(league.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f).padding(start = 72.dp))
                            if (matches.any { it.live }) Text("● LIVE  ", color = Color(0xFFE53935), style = MaterialTheme.typography.labelMedium)
                            Text(if (isOpen) "▲" else "▼")
                        }
                        if (isOpen) matches.forEachIndexed { i, m ->
                            if (i > 0) Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(1.dp).background(MaterialTheme.colorScheme.outlineVariant))
                            MatchRow(m, timeFmt) { sheet = m }
                        }
                    }
                }
            }
            if (vm.hidden.isNotEmpty()) item {
                Text("Show ${vm.hidden.size} hidden league(s)", color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.focusRing().clickable { vm.unhideAll() }.padding(12.dp))
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
    sheet?.let { m -> MatchSheet(m, vm, live, onWatch, onSearch) { sheet = null } }
}

@Composable
fun PillChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        label, maxLines = 1,
        color = if (selected) Color(0xFFE5394A) else MaterialTheme.colorScheme.onSurface,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        modifier = Modifier.focusRing(shape).clip(shape)
            .background(if (selected) Color.White else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), shape)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
    )
}

@Composable
private fun MatchRow(m: Espn.Match, timeFmt: SimpleDateFormat, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().focusRing().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Column(Modifier.width(86.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(timeFmt.format(java.util.Date(m.start)), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            when {
                m.ended -> Badge("Ended", Color(0xFF7A1F1F))
                m.live -> Badge(m.status.ifEmpty { "Live" }, Color(0xFFC62828))
            }
        }
        Column(Modifier.weight(1f)) {
            if (m.away != null && m.home != null) {
                TeamLine(m.away, m.ended || m.live)
                TeamLine(m.home, m.ended || m.live)
            } else {
                Text(m.title, style = MaterialTheme.typography.bodyLarge)
                if (m.status.isNotEmpty() && !m.ended) Text(m.status, style = MaterialTheme.typography.bodySmall)
            }
            if (m.channels.isNotEmpty()) {
                Text(m.channels.joinToString(", "), color = Color(0xFF5B8DEF), style = MaterialTheme.typography.labelSmall,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

@Composable
private fun Badge(text: String, color: Color) {
    Text(text, color = Color.White, style = MaterialTheme.typography.labelSmall,
        modifier = Modifier.padding(top = 2.dp).clip(RoundedCornerShape(4.dp)).background(color).padding(horizontal = 4.dp))
}

@Composable
private fun TeamLine(t: Espn.Team, showScore: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        if (t.logo != null) {
            AsyncImage(model = t.logo, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(t.name, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (showScore && t.score != null) Text(t.score, style = MaterialTheme.typography.bodyLarge)
    }
}

/** What you can do with a game: watch it on your channels, search for it, get a reminder, hide its league. */
@Composable
private fun MatchSheet(m: Espn.Match, vm: SportsViewModel, live: LiveViewModel, onWatch: (Channel) -> Unit,
                       onSearch: (String) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var known by remember { mutableStateOf<List<Channel>?>(null) }
    var reminder by remember { mutableStateOf(Reminders.isSet(ctx, m.id)) }
    val notifyPermission = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }
    ModalBottomSheet(onDismissRequest = onClose) {
        LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
            item {
                Text(m.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
            item {
                SheetGroup {
                    SheetItem("📺", "Show known channels") { known = knownChannels(live, m) }
                    known?.let { list ->
                        if (list.isEmpty()) Text("None of your channels match. Try searching.", style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(start = 56.dp, bottom = 8.dp))
                        list.forEach { ch -> SheetItem("▶", ch.name) { onClose(); onWatch(ch) } }
                    }
                    m.away?.let { SheetItem("🔍", "Search \"${it.name}\"") { onClose(); onSearch(it.name) } }
                    m.home?.let { SheetItem("🔍", "Search \"${it.name}\"") { onClose(); onSearch(it.name) } }
                    SheetItem("🔍", "Search \"${m.title}\"") { onClose(); onSearch(m.title) }
                    if (m.channels.isNotEmpty()) SheetItem("🔍", "Search all known channels") { onClose(); onSearch(m.channels.joinToString(" | ")) }
                    if (!m.ended) SheetItem("🔔", if (reminder) "Remove reminder" else "Set reminder") {
                        if (reminder) { Reminders.cancel(ctx, m.id); reminder = false }
                        else {
                            if (android.os.Build.VERSION.SDK_INT >= 33) notifyPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                            Reminders.set(ctx, m.id, m.title, "Starting now" + (m.channels.firstOrNull()?.let { " on $it" } ?: ""), m.start)
                            reminder = true
                            Toast.makeText(ctx, "You'll be reminded when it starts.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            item {
                Text(m.league, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                SheetGroup { SheetItem("🚫", "Hide league") { vm.hide(m.league); onClose() } }
            }
        }
    }
}

@Composable
fun SheetGroup(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
        .padding(vertical = 4.dp), content = content)
}

@Composable
fun SheetItem(icon: String, label: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().focusRing().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(icon, modifier = Modifier.width(40.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
