package com.example.tvhub

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.tv.material3.*
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun RecordingsScreen() {
    val ctx = LocalContext.current
    val dir = remember { Recorder.dir(ctx) }
    var files by remember { mutableStateOf(listOf<File>()) }
    var playing by remember { mutableStateOf<File?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            files = dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }.orEmpty()
            delay(3_000)
        }
    }

    val p = playing
    if (p != null) {
        BackHandler { playing = null }
        SimplePlayer(Uri.fromFile(p))
        return
    }

    Column(Modifier.fillMaxSize().padding(start = 72.dp, top = 16.dp, end = 24.dp)) {
        Text("Recordings", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))

        Recorder.active.forEach { (url, name) ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("● Recording: $name")
                Button(onClick = { Recorder.stop(ctx, url) }) { Text("Stop") }
            }
            Spacer(Modifier.height(8.dp))
        }

        if (files.isEmpty()) {
            Text("Nothing recorded yet. Press Record on the Live TV screen.")
        } else {
            Text("OK to play, hold OK to delete")
            LazyColumn {
                items(files) { f ->
                    ListItem(
                        selected = false,
                        onClick = { playing = f },
                        onLongClick = {
                            f.delete()
                            files = files - f
                        },
                        headlineContent = { Text(f.nameWithoutExtension) },
                        supportingContent = { Text("%.0f MB".format(f.length() / 1_000_000.0)) },
                    )
                }
            }
        }
    }
}

@Composable
fun SimplePlayer(uri: Uri) {
    val context = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
    )
}
