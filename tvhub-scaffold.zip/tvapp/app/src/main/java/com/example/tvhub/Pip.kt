package com.example.tvhub

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.os.Build
import android.util.Rational
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry

/** Picture-in-picture: a small floating window while you use other apps (Android 8 and newer). */
object Pip {
    /** True while the main app is shown as a picture-in-picture window. */
    var active by mutableStateOf(false)

    /** Set by the app: true when something is playing that can go into picture-in-picture. */
    var canEnter: () -> Boolean = { false }

    fun supported(a: Activity): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            a.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

    /** Shrinks [a] into a floating window. Returns false when the device can't. */
    fun enter(a: Activity, width: Int = 16, height: Int = 9): Boolean {
        if (!supported(a)) return false
        return try {
            val params = PictureInPictureParams.Builder().setAspectRatio(Rational(width, height)).build()
            a.enterPictureInPictureMode(params)
        } catch (_: Exception) {
            false
        }
    }
}

/**
 * The game player's lifecycle, as seen by the emulator: it follows the screen's, except that it stays
 * "resumed" while the screen is in picture-in-picture, so the game keeps running in the small window.
 */
class PipAwareLifecycle(private val activity: Activity, host: Lifecycle) : LifecycleOwner {
    private val registry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = registry

    init {
        host.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) = sync(owner)
            override fun onStart(owner: LifecycleOwner) = sync(owner)
            override fun onResume(owner: LifecycleOwner) = sync(owner)
            override fun onPause(owner: LifecycleOwner) = sync(owner)
            override fun onStop(owner: LifecycleOwner) = sync(owner)
            override fun onDestroy(owner: LifecycleOwner) = sync(owner)
        })
    }

    private var hostState: Lifecycle.State = Lifecycle.State.INITIALIZED

    private fun sync(owner: LifecycleOwner) {
        hostState = owner.lifecycle.currentState
        update()
    }

    /** Call when picture-in-picture starts or ends. */
    fun update() {
        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && activity.isInPictureInPictureMode
        val target = if (inPip && hostState == Lifecycle.State.STARTED) Lifecycle.State.RESUMED else hostState
        if (target == Lifecycle.State.INITIALIZED) return
        registry.currentState = target
    }
}
