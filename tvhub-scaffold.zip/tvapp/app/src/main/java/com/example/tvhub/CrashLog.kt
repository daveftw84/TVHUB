package com.example.tvhub

import android.content.Context
import android.util.Log
import java.io.File

/**
 * Saves the error text if the app crashes, so the next launch can show it.
 * That makes it possible to report problems from a phone without any developer tools.
 */
object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "last_crash.txt")

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            val trace = "TV Hub ${runCatching { app.packageManager.getPackageInfo(app.packageName, 0).versionName }.getOrNull()} · Android ${android.os.Build.VERSION.RELEASE} · ${android.os.Build.MODEL}\n\n" +
                Log.getStackTraceString(error).take(12_000)
            try {
                file(app).writeText(trace)
            } catch (_: Throwable) {
            }
            // Show the error on screen (in a separate process), then end this one.
            val shown = try {
                app.startActivity(android.content.Intent(app, CrashActivity::class.java).putExtra("trace", trace)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK))
                true
            } catch (_: Throwable) { false }
            if (shown) {
                android.os.Process.killProcess(android.os.Process.myPid())
                kotlin.system.exitProcess(10)
            } else previous?.uncaughtException(thread, error)
        }
    }

    fun read(ctx: Context): String? = try {
        file(ctx).takeIf { it.exists() }?.readText()
    } catch (_: Throwable) {
        null
    }

    fun clear(ctx: Context) {
        try {
            file(ctx).delete()
        } catch (_: Throwable) {
        }
    }
}
