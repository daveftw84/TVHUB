package com.example.tvhub

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class PlexServer(val name: String, val url: String, val token: String)

data class PlexItem(
    val title: String,
    val type: String,                 // library, movie, show, season, episode
    val subtitle: String? = null,
    val path: String? = null,         // where to browse next (libraries, shows, seasons)
    val ratingKey: String? = null,
    val thumb: String? = null,
    val partKey: String? = null,      // set for playable items
    val viewOffset: Long = 0,
    val duration: Long = 0,
) {
    val playable get() = partKey != null
}

data class PlexPage(val title: String, val items: List<PlexItem>)
data class PlexPin(val id: Long, val code: String)

/** Minimal Plex client. All functions block, so call them off the main thread. */
object PlexApi {
    private fun request(
        url: String, token: String?, clientId: String,
        method: String = "GET", timeout: Int = 15_000,
    ): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = timeout
        c.readTimeout = timeout
        c.setRequestProperty("Accept", "application/json")
        c.setRequestProperty("X-Plex-Product", "TV Hub")
        c.setRequestProperty("X-Plex-Version", "0.1")
        c.setRequestProperty("X-Plex-Platform", "Android")
        c.setRequestProperty("X-Plex-Client-Identifier", clientId)
        if (token != null) c.setRequestProperty("X-Plex-Token", token)
        if (method == "POST") {
            c.doOutput = true
            c.setFixedLengthStreamingMode(0)
            c.outputStream.close()
        }
        if (c.responseCode !in 200..299) throw IOException("Plex returned HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    // --- Sign-in: the user enters the code at plex.tv/link ---

    fun createPin(clientId: String): PlexPin {
        val o = JSONObject(request("https://plex.tv/api/v2/pins?strong=false", null, clientId, "POST"))
        return PlexPin(o.getLong("id"), o.getString("code"))
    }

    /** Returns the auth token once the user has entered the code, else null. */
    fun checkPin(pin: PlexPin, clientId: String): String? {
        val o = JSONObject(request("https://plex.tv/api/v2/pins/${pin.id}", null, clientId))
        return if (o.isNull("authToken")) null else o.getString("authToken").ifEmpty { null }
    }

    // --- Server discovery ---

    fun findServer(token: String, clientId: String): PlexServer {
        val resources = JSONArray(
            request("https://plex.tv/api/v2/resources?includeHttps=1&includeRelay=1", token, clientId)
        )
        for (i in 0 until resources.length()) {
            val r = resources.getJSONObject(i)
            if (!r.optString("provides").contains("server")) continue
            val accessToken = r.optString("accessToken").ifEmpty { token }
            val conns = r.optJSONArray("connections") ?: continue
            // Prefer local direct connections, relay last.
            val sorted = (0 until conns.length()).map { conns.getJSONObject(it) }
                .sortedWith(compareBy({ it.optBoolean("relay") }, { !it.optBoolean("local") }))
            for (c in sorted) {
                val base = c.optString("uri").trimEnd('/')
                try {
                    request("$base/identity", accessToken, clientId, timeout = 4_000)
                    return PlexServer(r.optString("name", "Plex"), base, accessToken)
                } catch (_: Exception) {
                    // try next connection
                }
            }
        }
        throw IOException("No reachable Plex server found")
    }

    // --- Browsing ---

    fun libraries(s: PlexServer, clientId: String): List<PlexItem> {
        val dirs = JSONObject(request("${s.url}/library/sections", s.token, clientId))
            .getJSONObject("MediaContainer").optJSONArray("Directory") ?: return emptyList()
        return (0 until dirs.length()).map { dirs.getJSONObject(it) }
            .filter { it.optString("type") in setOf("movie", "show") }
            .map { PlexItem(it.getString("title"), "library", path = "/library/sections/${it.getString("key")}/all") }
    }

    fun browse(s: PlexServer, clientId: String, path: String): List<PlexItem> {
        val container = JSONObject(request(s.url + path, s.token, clientId)).getJSONObject("MediaContainer")
        val arr = container.optJSONArray("Metadata") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it) }.map { o ->
            val type = o.optString("type")
            val rk = o.optString("ratingKey")
            val part = o.optJSONArray("Media")?.optJSONObject(0)
                ?.optJSONArray("Part")?.optJSONObject(0)?.optString("key")?.ifEmpty { null }
            PlexItem(
                title = if (type == "episode") "E${o.optInt("index")} · ${o.optString("title")}" else o.optString("title"),
                type = type,
                subtitle = o.optInt("year").takeIf { it > 0 }?.toString(),
                path = if (type == "show" || type == "season") "/library/metadata/$rk/children" else null,
                ratingKey = rk,
                thumb = o.optString("thumb").ifEmpty { null },
                partKey = part,
                viewOffset = o.optLong("viewOffset"),
                duration = o.optLong("duration"),
            )
        }
    }

    fun imageUrl(s: PlexServer, thumb: String) = "${s.url}$thumb?X-Plex-Token=${s.token}"
    fun streamUrl(s: PlexServer, partKey: String) = "${s.url}$partKey?X-Plex-Token=${s.token}"

    // --- Watch progress (also marks items watched when you finish them) ---

    fun reportTimeline(s: PlexServer, clientId: String, item: PlexItem, state: String, timeMs: Long, durationMs: Long) {
        val rk = item.ratingKey ?: return
        val key = URLEncoder.encode("/library/metadata/$rk", "UTF-8")
        request(
            "${s.url}/:/timeline?ratingKey=$rk&key=$key&state=$state&time=$timeMs&duration=$durationMs",
            s.token, clientId,
        )
    }
}
