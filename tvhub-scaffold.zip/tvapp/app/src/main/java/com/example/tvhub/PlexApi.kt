package com.example.tvhub

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class PlexServer(val name: String, val url: String, val token: String)

data class PlexLibrary(val id: String, val title: String, val type: String)

data class PlexGenre(val title: String, val path: String)

/** One entry of the A–Z jump bar: its label and where it starts in an A–Z sorted library. */
data class PlexLetter(val label: String, val index: Int)

data class PlexHub(val id: String, val title: String, val key: String?, val items: List<PlexItem>)

data class PlexItem(
    val title: String,
    val type: String,                 // movie, show, season, episode, collection
    val ratingKey: String? = null,
    val showTitle: String? = null,    // for episodes: the show's name
    val season: Int = 0,              // for episodes: season number
    val index: Int = 0,               // episode or season number
    val year: Int = 0,
    val summary: String? = null,
    val contentRating: String? = null,
    val rating: Double = 0.0,
    val thumb: String? = null,        // the item's own picture
    val posterThumb: String? = null,  // portrait poster (an episode uses its show's poster)
    val art: String? = null,
    val partKey: String? = null,      // set for playable items
    val viewOffset: Long = 0,
    val duration: Long = 0,
    val viewCount: Int = 0,
    val leafCount: Int = 0,           // for shows/seasons: number of episodes
    val viewedLeafCount: Int = 0,
    val childCount: Int = 0,          // for collections: number of items
    val released: String? = null,     // release date, like "2026-03-23"
    val imdb: String? = null,         // IMDb number like "tt0118375", when the server includes it
    val guid: String? = null,         // Plex's own ID like "plex://movie/5d77...", when the server includes it
    val tmdb: String? = null,         // The Movie Database number, when the server includes it
    val tvdb: String? = null,         // TheTVDB number, when the server includes it
    val light: Boolean = false,       // true when read from the saved copy: basic details only
    val sectionId: String? = null,    // which library it's in
    val resolution: String? = null,   // "4k", "1080", ...
    val subtitles: List<PlexSubtitle> = emptyList(),  // subtitle files beside the video (srt, ass, ...)
    val showKey: String? = null,      // for episodes: the show's ratingKey
    val markers: List<PlexMarker> = emptyList(),   // intro / credits, when Plex detected them
    val genres: List<String> = emptyList(),
    val cast: List<PlexPerson> = emptyList(),
    val ratings: List<PlexRating> = emptyList(),   // IMDb, Rotten Tomatoes, TMDB (whatever the server's agent added)
    val clearLogo: String? = null,    // the title as a logo picture
    val audio: String? = null,        // "EAC3 5.1"
    val userRating: Double = 0.0,     // your own rating (0-10)
) {
    val is4k: Boolean get() = resolution.equals("4k", true) || resolution == "2160"
    val playable: Boolean get() = partKey != null
    val unwatched: Int get() = (leafCount - viewedLeafCount).coerceAtLeast(0)
    val watched: Boolean get() = if (leafCount > 0) viewedLeafCount >= leafCount else viewCount > 0
    val progress: Float
        get() = if (duration > 0 && viewOffset > 0) (viewOffset.toFloat() / duration).coerceIn(0f, 1f) else 0f
    val displayTitle: String get() = if (type == "episode") showTitle ?: title else title
    val displaySubtitle: String?
        get() = when (type) {
            "episode" -> "S$season • E$index"
            "movie", "show" -> year.takeIf { it > 0 }?.toString()
            "collection" -> childCount.takeIf { it > 0 }?.let { "$it items" }
            else -> null
        }
}

/** An actor: name, character and photo (the id finds their other titles). */
data class PlexPerson(val id: String, val name: String, val role: String?, val thumb: String?)

/** A rating from a source: "imdb" (0-10), "rt" critics / "rt-audience" (percent), "tmdb" (percent). */
data class PlexRating(val source: String, val value: Double) {
    val label: String get() = when (source) {
        "imdb" -> "IMDb %.1f".format(value)
        "rt" -> "🍅 ${value.toInt()}%"
        "rt-audience" -> "🍿 ${value.toInt()}%"
        "tmdb" -> "TMDB ${value.toInt()}%"
        "other-mc" -> "Metacritic ${value.toInt()}"
        "other-lb" -> "Letterboxd %.1f".format(value)
        else -> "★ %.1f".format(value)
    }
}

/** A Plex Home user (profile). */
data class PlexHomeUser(val id: String, val uuid: String, val title: String, val thumb: String?, val protected: Boolean,
                        val admin: Boolean, val restricted: Boolean)

/** An intro or credits section Plex detected (milliseconds). */
data class PlexMarker(val type: String, val start: Long, val end: Long)

/** A subtitle file stored beside the video on the server. */
data class PlexSubtitle(val key: String, val language: String?, val codec: String?, val title: String?)

data class PlexPageResult(val items: List<PlexItem>, val total: Int)
data class PlexPin(val id: Long, val code: String)

/** Minimal Plex client. All functions block, so call them off the main thread. */
object PlexApi {
    const val SEARCH_TIMEOUT_MS = 60_000
    private val MEDIA_TYPES = setOf("movie", "show", "season", "episode", "collection")

    private fun request(
        url: String, token: String?, clientId: String,
        method: String = "GET", timeout: Int = 15_000,
    ): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = timeout
        c.readTimeout = timeout
        c.setRequestProperty("Accept", "application/json")
        c.setRequestProperty("X-Plex-Product", "TV Hub")
        c.setRequestProperty("X-Plex-Version", "1.3")
        c.setRequestProperty("X-Plex-Platform", "Android")
        c.setRequestProperty("X-Plex-Client-Identifier", clientId)
        if (token != null) c.setRequestProperty("X-Plex-Token", token)
        if (method == "POST") {
            c.doOutput = true
            c.setFixedLengthStreamingMode(0)
            c.outputStream.close()
        }
        if (c.responseCode !in 200..299) throw IOException("Plex returned HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    // --- Sign-in: the user enters the code at plex.tv/link ---

    fun createPin(clientId: String): PlexPin {
        val o = JSONObject(request("https://plex.tv/api/v2/pins?strong=false", null, clientId, "POST"))
        return PlexPin(o.getLong("id"), o.getString("code"))
    }

    /** Returns the auth token once the user has entered the code, else null. */
    fun checkPin(pin: PlexPin, clientId: String): String? {
        val o = JSONObject(request("https://plex.tv/api/v2/pins/${pin.id}", null, clientId))
        return if (o.isNull("authToken")) null else o.getString("authToken").ifEmpty { null }
    }

    // --- Server discovery ---

    fun findServer(token: String, clientId: String): PlexServer {
        val resources = JSONArray(
            request("https://plex.tv/api/v2/resources?includeHttps=1&includeRelay=1", token, clientId)
        )
        for (i in 0 until resources.length()) {
            val r = resources.getJSONObject(i)
            if (!r.optString("provides").contains("server")) continue
            val accessToken = r.optString("accessToken").ifEmpty { token }
            val conns = r.optJSONArray("connections") ?: continue
            // Prefer local direct connections, relay last.
            val sorted = (0 until conns.length()).map { conns.getJSONObject(it) }
                .sortedWith(compareBy({ it.optBoolean("relay") }, { !it.optBoolean("local") }))
            for (c in sorted) {
                val base = c.optString("uri").trimEnd('/')
                try {
                    request("$base/identity", accessToken, clientId, timeout = 4_000)
                    return PlexServer(r.optString("name", "Plex"), base, accessToken)
                } catch (_: Exception) {
                    // try next connection
                }
            }
        }
        throw IOException("No reachable Plex server found")
    }

    // --- Browsing (always in small pages, so big libraries don't use up the phone's memory) ---

    fun libraries(s: PlexServer, clientId: String): List<PlexLibrary> {
        val dirs = JSONObject(request("${s.url}/library/sections", s.token, clientId))
            .getJSONObject("MediaContainer").optJSONArray("Directory") ?: return emptyList()
        return (0 until dirs.length()).map { dirs.getJSONObject(it) }
            .filter { it.optString("type") in setOf("movie", "show") }
            .map { PlexLibrary(it.getString("key"), it.getString("title"), it.getString("type")) }
    }

    fun page(s: PlexServer, clientId: String, path: String, start: Int, size: Int): PlexPageResult {
        val sep = if (path.contains('?')) '&' else '?'
        val url = "${s.url}$path${sep}X-Plex-Container-Start=$start&X-Plex-Container-Size=$size"
        val container = JSONObject(request(url, s.token, clientId)).getJSONObject("MediaContainer")
        val arr = container.optJSONArray("Metadata")
        val items = if (arr == null) emptyList() else (0 until arr.length()).map { parseItem(arr.getJSONObject(it)) }
        return PlexPageResult(items, container.optInt("totalSize", start + items.size))
    }

    fun children(s: PlexServer, clientId: String, ratingKey: String): List<PlexItem> =
        page(s, clientId, "/library/metadata/$ratingKey/children", 0, 500).items

    /** A list of "hubs": titled rows such as Continue Watching, Recently Added, Top Movies in Thriller. */
    fun hubs(s: PlexServer, clientId: String, path: String, timeout: Int = 15_000): List<PlexHub> {
        val container = JSONObject(request(s.url + path, s.token, clientId, timeout = timeout)).getJSONObject("MediaContainer")
        val arr = container.optJSONArray("Hub") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it) }.mapNotNull { h ->
            val meta = h.optJSONArray("Metadata") ?: return@mapNotNull null
            val items = (0 until meta.length()).map { parseItem(meta.getJSONObject(it)) }
                .filter { it.type in MEDIA_TYPES }
            if (items.isEmpty()) {
                null
            } else {
                PlexHub(
                    id = h.optString("hubIdentifier"),
                    title = h.optString("title"),
                    key = h.optString("key").ifEmpty { null },
                    items = items,
                )
            }
        }
    }

    /**
     * Search one library (or the whole server when [sectionId] is null). Searching a big library for a
     * common word can take the server 15-30+ seconds, so this waits up to [SEARCH_TIMEOUT_MS] instead of
     * giving up early. Searching library by library keeps each request smaller and lets results show up
     * as soon as each one answers.
     */
    fun search(s: PlexServer, clientId: String, query: String, sectionId: String? = null): List<PlexItem> {
        val q = URLEncoder.encode(query, "UTF-8")
        val section = if (sectionId != null) "&sectionId=$sectionId" else ""
        return hubs(s, clientId, "/hubs/search?query=$q&limit=20$section", SEARCH_TIMEOUT_MS)
            .flatMap { it.items }
            .filter { it.type == "movie" || it.type == "show" || it.type == "episode" }
            .distinctBy { it.ratingKey }
    }

    /** IDs found by Plex's online catalog: IMDb numbers and Plex IDs (what the catalog calls its "guid"). */
    data class DiscoverIds(val imdb: List<String>, val guids: List<String>)

    /**
     * Asks Plex's online catalog (Discover) to search by name. It does not look at your server at all,
     * so it is quick, and it only returns IDs, which the app then looks up in its saved copy.
     * Needs the Plex account token (not the server token). Any failure just means "no extra results".
     */
    fun discoverSearch(accountToken: String, clientId: String, query: String): DiscoverIds {
        val q = URLEncoder.encode(query, "UTF-8")
        val url = "https://discover.provider.plex.tv/library/search?query=$q&limit=30" +
            "&searchTypes=movies,tv&includeMetadata=1&searchProviders=discover&includeGuids=1"
        val root = JSONObject(request(url, accountToken, clientId, timeout = 10_000))
        val imdb = LinkedHashSet<String>()
        val guids = LinkedHashSet<String>()
        // The reply is nested; rather than depend on exact nesting, collect IDs wherever they appear.
        fun walk(node: Any?) {
            when (node) {
                is JSONObject -> {
                    val g = node.optString("guid")
                    if (g.startsWith("plex://")) guids += g
                    if (g.startsWith("imdb://")) imdb += g.removePrefix("imdb://").substringBefore('?')
                    val id = node.optString("id")
                    if (id.startsWith("imdb://")) imdb += id.removePrefix("imdb://").substringBefore('?')
                    val keys = node.keys()
                    while (keys.hasNext()) walk(node.opt(keys.next()))
                }
                is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i))
            }
        }
        walk(root)
        return DiscoverIds(imdb.toList(), guids.toList())
    }

    fun genres(s: PlexServer, clientId: String, libId: String): List<PlexGenre> {
        val dirs = JSONObject(request("${s.url}/library/sections/$libId/genre", s.token, clientId))
            .getJSONObject("MediaContainer").optJSONArray("Directory") ?: return emptyList()
        return (0 until dirs.length()).map { dirs.getJSONObject(it) }.mapNotNull { d ->
            val title = d.optString("title")
            var path = d.optString("fastKey")
            if (path.isEmpty()) {
                val key = d.optString("key")
                if (key.isNotEmpty()) {
                    path = "/library/sections/$libId/all?genre=" + URLEncoder.encode(key, "UTF-8")
                }
            }
            if (title.isEmpty() || path.isEmpty()) null else PlexGenre(title, path)
        }
    }

    /** How many items start with each letter, turned into start positions for an A–Z sorted list. */
    fun firstCharacters(s: PlexServer, clientId: String, libId: String): List<PlexLetter> {
        val dirs = JSONObject(request("${s.url}/library/sections/$libId/firstCharacter", s.token, clientId))
            .getJSONObject("MediaContainer").optJSONArray("Directory") ?: return emptyList()
        val out = mutableListOf<PlexLetter>()
        var running = 0
        for (i in 0 until dirs.length()) {
            val d = dirs.getJSONObject(i)
            val label = d.optString("title").ifEmpty { d.optString("key") }
            if (label.isNotEmpty()) out += PlexLetter(label, running)
            running += d.optInt("size")
        }
        return out
    }

    private fun parseItem(o: JSONObject): PlexItem {
        fun str(vararg keys: String): String? {
            for (k in keys) {
                val v = o.optString(k)
                if (v.isNotEmpty()) return v
            }
            return null
        }

        val type = o.optString("type")
        // External IDs: new-style "Guid": [{"id": "imdb://tt123"}], or the older single "guid" string.
        var imdb: String? = null
        var tmdb: String? = null
        var tvdb: String? = null
        val guids = o.optJSONArray("Guid")
        if (guids != null) {
            for (i in 0 until guids.length()) {
                val id = guids.optJSONObject(i)?.optString("id").orEmpty()
                if (id.startsWith("imdb://")) imdb = id.removePrefix("imdb://").substringBefore('?')
                if (id.startsWith("tmdb://")) tmdb = id.removePrefix("tmdb://").substringBefore('?')
                if (id.startsWith("tvdb://")) tvdb = id.removePrefix("tvdb://").substringBefore('?')
            }
        }
        val old = o.optString("guid")
        fun legacy(marker: String): String? =
            if (old.contains(marker)) old.substringAfter(marker).substringBefore('?').substringBefore('/') else null
        if (imdb == null) imdb = legacy("imdb://")
        if (tmdb == null) tmdb = legacy("themoviedb://")
        if (tvdb == null) tvdb = legacy("thetvdb://")
        val media0 = o.optJSONArray("Media")?.optJSONObject(0)
        val part0 = media0?.optJSONArray("Part")?.optJSONObject(0)
        val part = part0?.optString("key")?.ifEmpty { null }
        val subs = ArrayList<PlexSubtitle>()
        part0?.optJSONArray("Stream")?.let { streams ->
            for (i in 0 until streams.length()) {
                val st = streams.optJSONObject(i) ?: continue
                val key = st.optString("key")
                if (st.optInt("streamType") == 3 && key.isNotEmpty()) {
                    subs += PlexSubtitle(key, st.optString("languageCode").ifEmpty { null },
                        st.optString("codec").ifEmpty { null }, st.optString("displayTitle").ifEmpty { null })
                }
            }
        }
        fun tags(name: String) = o.optJSONArray(name)?.let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it)?.optString("tag")?.ifEmpty { null } } }.orEmpty()
        val cast = o.optJSONArray("Role")?.let { a ->
            (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map {
                PlexPerson(it.optString("id"), it.optString("tag"), it.optString("role").ifEmpty { null }, it.optString("thumb").ifEmpty { null })
            }
        }.orEmpty()
        val ratings = ArrayList<PlexRating>()
        fun addRating(image: String, value: Double) {
            if (value <= 0) return
            val src = when {
                image.startsWith("imdb") -> "imdb"
                image.startsWith("rottentomatoes") && (image.contains("upright") || image.contains("spilled")) -> "rt-audience"
                image.startsWith("rottentomatoes") -> "rt"
                image.startsWith("themoviedb") -> "tmdb"
                else -> return
            }
            if (ratings.none { it.source == src }) ratings += PlexRating(src, if (src == "imdb") value else value * 10)
        }
        o.optJSONArray("Rating")?.let { a ->
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { addRating(it.optString("image"), it.optDouble("value", 0.0)) }
        }
        addRating(o.optString("ratingImage"), o.optDouble("rating", 0.0))
        addRating(o.optString("audienceRatingImage"), o.optDouble("audienceRating", 0.0))
        val logo = o.optJSONArray("Image")?.let { a ->
            (0 until a.length()).mapNotNull { a.optJSONObject(it) }.firstOrNull { it.optString("type") == "clearLogo" }?.optString("url")
        }?.ifEmpty { null }
        val audio = media0?.optString("audioCodec")?.ifEmpty { null }?.let { c ->
            val ch = media0.optInt("audioChannels")
            c.uppercase() + when (ch) { 0 -> ""; 1 -> " Mono"; 2 -> " Stereo"; 6 -> " 5.1"; 8 -> " 7.1"; else -> " ${ch}ch" }
        }
        return PlexItem(
            genres = tags("Genre"),
            cast = cast,
            ratings = ratings,
            clearLogo = logo,
            audio = audio,
            userRating = o.optDouble("userRating", 0.0),
            title = o.optString("title"),
            type = type,
            ratingKey = str("ratingKey"),
            showTitle = str("grandparentTitle"),
            season = o.optInt("parentIndex"),
            index = o.optInt("index"),
            year = o.optInt("year"),
            summary = str("summary"),
            contentRating = str("contentRating"),
            rating = o.optDouble("audienceRating", o.optDouble("rating", 0.0)),
            thumb = str("thumb", "parentThumb", "grandparentThumb"),
            posterThumb = if (type == "episode") str("grandparentThumb", "parentThumb", "thumb")
            else str("thumb", "parentThumb", "grandparentThumb"),
            art = str("art", "grandparentArt"),
            partKey = part,
            viewOffset = o.optLong("viewOffset"),
            duration = o.optLong("duration"),
            viewCount = o.optInt("viewCount"),
            leafCount = o.optInt("leafCount"),
            viewedLeafCount = o.optInt("viewedLeafCount"),
            childCount = o.optInt("childCount"),
            released = str("originallyAvailableAt"),
            imdb = imdb,
            guid = o.optString("guid").takeIf { it.startsWith("plex://") },
            tmdb = tmdb,
            tvdb = tvdb,
            sectionId = str("librarySectionID"),
            resolution = media0?.optString("videoResolution")?.ifEmpty { null },
            subtitles = subs,
            showKey = str("grandparentRatingKey"),
            markers = o.optJSONArray("Marker")?.let { a ->
                (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map {
                    PlexMarker(it.optString("type"), it.optLong("startTimeOffset"), it.optLong("endTimeOffset"))
                }
            }.orEmpty(),
        )
    }

    /** Small, resized pictures via the server's photo transcoder (much lighter than the originals). */
    fun imageUrl(s: PlexServer, path: String, width: Int, height: Int): String {
        val inner = URLEncoder.encode(path, "UTF-8")
        return "${s.url}/photo/:/transcode?width=$width&height=$height&minSize=1&upscale=1" +
            "&url=$inner&X-Plex-Token=${s.token}"
    }

    fun streamUrl(s: PlexServer, partKey: String) = "${s.url}$partKey?X-Plex-Token=${s.token}"

    /** Address of a subtitle file stored on the server. */
    fun subtitleUrl(s: PlexServer, key: String) = "${s.url}$key?X-Plex-Token=${s.token}"

    /** Libraries' items with a filter, e.g. 4K movies: "/library/sections/1/all?resolution=4k". */
    fun filtered(s: PlexServer, clientId: String, path: String, size: Int = 30) = page(s, clientId, path, 0, size).items

    // --- Watch progress ---

    fun reportTimeline(s: PlexServer, clientId: String, item: PlexItem, state: String, timeMs: Long, durationMs: Long) {
        val rk = item.ratingKey ?: return
        val key = URLEncoder.encode("/library/metadata/$rk", "UTF-8")
        request(
            "${s.url}/:/timeline?ratingKey=$rk&key=$key&state=$state&time=$timeMs&duration=$durationMs",
            s.token, clientId,
        )
    }

    // --- Actions on titles ---

    fun setWatched(s: PlexServer, clientId: String, ratingKey: String, watched: Boolean) {
        request("${s.url}/:/${if (watched) "scrobble" else "unscrobble"}?identifier=com.plexapp.plugins.library&key=$ratingKey", s.token, clientId)
    }

    /** Your rating, 0-10 (0 clears it). */
    fun rate(s: PlexServer, clientId: String, ratingKey: String, rating: Int) {
        request("${s.url}/:/rate?identifier=com.plexapp.plugins.library&key=$ratingKey&rating=${if (rating <= 0) -1 else rating}",
            s.token, clientId, method = "PUT")
    }

    /** Full details: cast, genres, ratings, logo, markers. */
    fun details(s: PlexServer, clientId: String, ratingKey: String): PlexItem? =
        page(s, clientId, "/library/metadata/$ratingKey?includeMarkers=1&includeExtras=1", 0, 1).items.firstOrNull()

    /** Trailers and extras. */
    fun extras(s: PlexServer, clientId: String, ratingKey: String): List<PlexItem> {
        val container = JSONObject(request("${s.url}/library/metadata/$ratingKey/extras", s.token, clientId)).getJSONObject("MediaContainer")
        val arr = container.optJSONArray("Metadata") ?: return emptyList()
        return (0 until arr.length()).map { parseItem(arr.getJSONObject(it)) }.filter { it.partKey != null }
    }

    /** "Related" rows from the server (similar titles). */
    fun related(s: PlexServer, clientId: String, ratingKey: String): List<PlexHub> =
        runCatching { hubs(s, clientId, "/hubs/metadata/$ratingKey/related") }.getOrDefault(emptyList())

    /** Titles in a library with this actor. */
    fun byActor(s: PlexServer, clientId: String, sectionId: String, actorId: String): List<PlexItem> =
        page(s, clientId, "/library/sections/$sectionId/all?actor=$actorId&sort=year:desc", 0, 30).items

    /** Library maintenance (server owners): scan, analyze, refresh metadata, empty trash. */
    fun libraryAction(s: PlexServer, clientId: String, sectionId: String, action: String) {
        when (action) {
            "scan" -> request("${s.url}/library/sections/$sectionId/refresh", s.token, clientId)
            "refresh" -> request("${s.url}/library/sections/$sectionId/refresh?force=1", s.token, clientId)
            "analyze" -> request("${s.url}/library/sections/$sectionId/analyze", s.token, clientId, method = "PUT")
            "trash" -> request("${s.url}/library/sections/$sectionId/emptyTrash", s.token, clientId, method = "PUT")
        }
    }

    // --- Plex Home profiles ---

    fun homeUsers(token: String, clientId: String): List<PlexHomeUser> {
        val body = request("https://plex.tv/api/v2/home/users", token, clientId)
        val arr = if (body.trimStart().startsWith("[")) JSONArray(body) else JSONObject(body).optJSONArray("users") ?: JSONArray()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.map { u ->
            PlexHomeUser(u.optString("id"), u.optString("uuid"), u.optString("title").ifEmpty { u.optString("username") },
                u.optString("thumb").ifEmpty { null }, u.optBoolean("protected"), u.optBoolean("admin"), u.optBoolean("restricted"))
        }
    }

    /** Switches to a Home user; returns that user's token (wrong PIN throws). */
    fun switchUser(token: String, clientId: String, uuid: String, pin: String?): String {
        val p = if (pin.isNullOrEmpty()) "" else "?pin=" + URLEncoder.encode(pin, "UTF-8")
        val o = JSONObject(request("https://plex.tv/api/v2/home/users/$uuid/switch$p", token, clientId, "POST"))
        return o.optString("authToken").ifEmpty { throw IOException("Plex didn't return a token") }
    }

    // --- Plex Watchlist (your account's, from Plex Discover) ---

    fun watchlist(token: String, clientId: String): List<PlexItem> {
        val container = JSONObject(request("https://discover.provider.plex.tv/library/sections/watchlist/all?includeMeta=1&X-Plex-Container-Size=100",
            token, clientId)).getJSONObject("MediaContainer")
        val arr = container.optJSONArray("Metadata") ?: return emptyList()
        return (0 until arr.length()).map { parseItem(arr.getJSONObject(it)) }
    }

    /** Adds or removes a title (by its plex:// guid) on your Plex Watchlist. */
    fun setWatchlist(token: String, clientId: String, guid: String, on: Boolean) {
        val id = guid.substringAfterLast('/')
        request("https://discover.provider.plex.tv/actions/${if (on) "addToWatchlist" else "removeFromWatchlist"}?ratingKey=$id",
            token, clientId, method = "PUT")
    }
}
