package com.example.tvhub

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.blur
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun LibraryScreen(vm: PlexViewModel) {
    val tv = rememberIsTv()
    val playing = vm.playing
    val url = playing?.let { vm.streamUrl(it) }
    if (playing != null && url != null) {
        androidx.compose.runtime.key(playing.ratingKey) { PlexPlayerScreen(vm, playing, url) }
        return
    }

    BackHandler(enabled = vm.canGoBack) { vm.back() }

    Box(Modifier.fillMaxSize()) {
        when (val s = vm.state) {
            PlexState.SignedOut -> CenterColumn {
                Text("Sign in to Plex", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { vm.signIn() }, modifier = Modifier.focusRing(ButtonShape)) {
                    Text("Get sign-in code")
                }
            }
            is PlexState.WaitingForCode -> CenterColumn {
                Text("On your phone or computer, go to")
                Text("plex.tv/link", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(16.dp))
                Text("and enter this code:")
                Text(s.code, style = MaterialTheme.typography.displayMedium)
            }
            PlexState.Loading -> CenterColumn { Text("Connecting to your Plex server…") }
            is PlexState.Failed -> CenterColumn {
                Text(s.message)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { vm.retry() }, modifier = Modifier.focusRing(ButtonShape)) {
                    Text("Try again")
                }
            }
            PlexState.Ready -> Browser(vm)
        }
        if (tv && vm.state == PlexState.Ready) {
            TvClock(Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 16.dp))
        }
    }
}

@Composable
private fun CenterColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content,
    )
}

// ---------------------------------------------------------------- Pages

@Composable
private fun Browser(vm: PlexViewModel) {
    val tv = rememberIsTv()
    when (val scr = vm.screen) {
        PlexScreen.Home ->
            if (tv) TvHome(vm) else TopLevel(vm, onHome = true) { HomeContent(vm) }
        PlexScreen.Libraries ->
            if (tv) {
                Column(Modifier.fillMaxSize()) {
                    TvTopBar(vm, onHome = false)
                    Notice(vm)
                    Box(Modifier.weight(1f).fillMaxWidth()) { LibrariesContent(vm) }
                }
            } else {
                TopLevel(vm, onHome = false) { LibrariesContent(vm) }
            }
        is PlexScreen.Library -> LibraryPage(vm, scr.lib)
        is PlexScreen.Grid -> Column(Modifier.fillMaxSize()) {
            TopBar(scr.title, vm.server?.name, onBack = { vm.back() }, onSearch = { vm.openSearch() })
            Notice(vm)
            PagedGrid(vm, Modifier.weight(1f))
        }
        is PlexScreen.Detail -> DetailScreen(vm, scr.item)
        PlexScreen.Search -> SearchPage(vm)
        PlexScreen.Trakt -> TraktPage(vm)
    }
}

/** Phone: Home and Libraries share a header with a Home / Libraries switch underneath. */
@Composable
private fun TopLevel(vm: PlexViewModel, onHome: Boolean, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar("TV Hub", vm.server?.name, onBack = null, onSearch = { vm.openSearch() })
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Chip("Home", onHome) { vm.goHome() }
            Chip("Libraries", !onHome) { vm.goLibraries() }
            if (TraktAccount.signedIn) Chip("Trakt", false) { vm.openTrakt() }
        }
        Notice(vm)
        Box(Modifier.weight(1f).fillMaxWidth()) { content() }
    }
}

@Composable
private fun TopBar(title: String, subtitle: String?, onBack: (() -> Unit)?, onSearch: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            TextButton(onClick = onBack, modifier = Modifier.focusRing(ButtonShape)) {
                Text("←", style = MaterialTheme.typography.headlineSmall)
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (onSearch != null) {
            IconButton(onClick = onSearch, modifier = Modifier.focusRing(CircleShape)) {
                Icon(Icons.Default.Search, contentDescription = "Search")
            }
        }
    }
}

@Composable
private fun Notice(vm: PlexViewModel) {
    vm.notice?.let {
        Text(
            it,
            color = MaterialTheme.colorScheme.error,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        modifier = Modifier.focusRing(RoundedCornerShape(8.dp)),
    )
}

/** Tabs in a rounded dark pill, like the Plex library tabs. */
@Composable
private fun PillTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.clip(CircleShape).background(Color(0x33FFFFFF)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        labels.forEachIndexed { i, label ->
            Text(
                label,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier
                    .focusRing(CircleShape)
                    .clip(CircleShape)
                    .then(if (i == selected) Modifier.border(1.dp, Color(0x99FFFFFF), CircleShape) else Modifier)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }
    }
}

// ---------------------------------------------------------------- TV home

@Composable
private fun TvClock(modifier: Modifier) {
    val fmt = remember { java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(15_000)
        }
    }
    Text(fmt.format(java.util.Date(now)), style = MaterialTheme.typography.titleMedium, modifier = modifier)
}

@Composable
private fun TvTopBar(vm: PlexViewModel, onHome: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, top = 10.dp, end = 120.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Chip("Home", onHome) { vm.goHome() }
        Chip("Libraries", !onHome) { vm.goLibraries() }
        if (TraktAccount.signedIn) Chip("Trakt", false) { vm.openTrakt() }
        IconButton(onClick = { vm.openSearch() }, modifier = Modifier.focusRing(CircleShape)) {
            Icon(Icons.Default.Search, contentDescription = "Search")
        }
    }
}

private fun formatDate(iso: String?): String? {
    if (iso.isNullOrEmpty()) return null
    return try {
        val d = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(iso) ?: return null
        java.text.SimpleDateFormat("MMM d, yyyy", java.util.Locale.getDefault()).format(d)
    } catch (_: Exception) {
        null
    }
}

/** Title, episode name, date, length, rating and summary of whatever poster is focused. */
@Composable
private fun HeroInfo(media: PlexItem?, modifier: Modifier) {
    Column(modifier.padding(horizontal = 24.dp)) {
        if (media != null) {
            Text(
                media.displayTitle,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (media.type == "episode") {
                Text(
                    media.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            val meta = listOfNotNull(
                if (media.type == "episode") "S${media.season} • E${media.index}" else null,
                formatDate(media.released) ?: media.year.takeIf { it > 0 }?.toString(),
                media.duration.takeIf { it > 0 }?.let { "${it / 60000}m" },
            ).joinToString("    ")
            Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                if (meta.isNotEmpty()) Text(meta, style = MaterialTheme.typography.bodyMedium)
                media.contentRating?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier
                            .padding(start = 12.dp)
                            .border(1.dp, Color(0xAAFFFFFF), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                }
            }
            media.summary?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
    }
}

/** TV home: a big backdrop that follows the focused poster, with the rows underneath. */
@Composable
private fun TvHome(vm: PlexViewModel) {
    var focused by remember { mutableStateOf<PlexItem?>(null) }
    val hero = focused ?: vm.homeRows.firstOrNull()?.items?.firstOrNull()
    val bg = MaterialTheme.colorScheme.background

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().fillMaxHeight(0.7f)) {
            val art = hero?.let { vm.backdrop(it) }
            if (art != null) {
                AsyncImage(
                    model = art,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.horizontalGradient(listOf(bg, bg.copy(alpha = 0.7f), Color.Transparent)))
            )
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, bg)))
            )
        }

        Column(Modifier.fillMaxSize()) {
            TvTopBar(vm, onHome = true)
            HeroInfo(hero, Modifier.fillMaxWidth(0.55f).height(150.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(bottom = 16.dp)) {
                if (vm.homeRows.isEmpty()) {
                    item {
                        Text(
                            if (vm.homeLoading) "Loading…" else "Nothing to show yet. Open Libraries to browse.",
                            modifier = Modifier.padding(24.dp),
                        )
                    }
                }
                items(vm.homeRows) { row ->
                    TvMediaRow(vm, row, vm.server?.name, onFocused = { focused = it })
                }
                item {
                    OutlinedButton(
                        onClick = { vm.signOut() },
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp).focusRing(ButtonShape),
                    ) { Text("Sign out of Plex") }
                }
            }
        }
    }
}

@Composable
private fun TvMediaRow(vm: PlexViewModel, row: HomeRow, subtitle: String?, onFocused: (PlexItem) -> Unit) {
    val isContinue = row.title.startsWith("Continue")
    Column {
        Row(Modifier.padding(start = 24.dp, top = 8.dp, bottom = 2.dp), verticalAlignment = Alignment.Bottom) {
            Text(row.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (subtitle != null) {
                Text(
                    "  ·  $subtitle",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(row.items) { entry ->
                MediaCard(vm, entry, Modifier.width(120.dp), onFocused = onFocused) {
                    // Continue Watching resumes right away; everything else opens its page.
                    if (isContinue && entry.playable) vm.play(entry) else vm.open(entry)
                }
            }
            row.seeAll?.let { path ->
                item { SeeAllCard(Modifier.width(120.dp)) { vm.openGrid(row.title, path) } }
            }
        }
    }
}

@Composable
private fun SeeAllCard(modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier
            .aspectRatio(2f / 3f)
            .focusRing(shape, 1.08f)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text("See all ›", style = MaterialTheme.typography.bodyLarge)
    }
}

// ---------------------------------------------------------------- Phone home and Libraries

@Composable
private fun HomeContent(vm: PlexViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        if (vm.homeRows.isEmpty()) {
            item {
                Text(
                    if (vm.homeLoading) "Loading…" else "Nothing to show yet. Open Libraries to browse.",
                    modifier = Modifier.padding(16.dp),
                )
            }
        }
        items(vm.homeRows) { row -> MediaRow(vm, row, vm.server?.name) }
        item {
            Spacer(Modifier.height(16.dp))
            OutlinedButton(
                onClick = { vm.signOut() },
                modifier = Modifier.padding(horizontal = 16.dp).focusRing(ButtonShape),
            ) { Text("Sign out of Plex") }
        }
    }
}

@Composable
private fun LibrariesContent(vm: PlexViewModel) {
    if (vm.libraries.isEmpty()) {
        Text("No movie or TV libraries found on this server.", modifier = Modifier.padding(16.dp))
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(vm.libraries) { lib ->
            val shape = RoundedCornerShape(12.dp)
            Column(
                Modifier
                    .fillMaxWidth()
                    .focusRing(shape)
                    .clip(shape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { vm.openLibrary(lib) }
                    .padding(20.dp)
            ) {
                Text(lib.title, style = MaterialTheme.typography.titleLarge)
                Text(
                    if (lib.type == "movie") "Movies" else "TV Shows",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Library page

@Composable
private fun LibraryPage(vm: PlexViewModel, lib: PlexLibrary) {
    val tv = rememberIsTv()
    val tabs = LibTab.values()
    Column(Modifier.fillMaxSize()) {
        // On TV the Back key goes up a level, so no back arrow is needed.
        if (!tv) TopBar(lib.title, vm.server?.name, onBack = { vm.back() }, onSearch = { vm.openSearch() })
        Row(
            Modifier.horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = if (tv) 12.dp else 4.dp),
        ) {
            PillTabs(tabs.map { it.label }, tabs.indexOf(vm.libTab)) { i -> vm.selectLibTab(tabs[i]) }
        }
        Notice(vm)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (vm.libTab) {
                LibTab.RECOMMENDED -> RecommendedTab(vm)
                LibTab.BROWSE -> BrowseTab(vm, lib)
                LibTab.COLLECTIONS -> CollectionsTab(vm)
                LibTab.CATEGORIES -> CategoriesTab(vm)
            }
        }
    }
}

@Composable
private fun RecommendedTab(vm: PlexViewModel) {
    val tv = rememberIsTv()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        if (vm.libHubs.isEmpty()) {
            item {
                Text(
                    if (vm.libLoading) "Loading…" else "Nothing recommended yet.",
                    modifier = Modifier.padding(16.dp),
                )
            }
        }
        items(vm.libHubs) { row ->
            if (tv) TvMediaRow(vm, row, null, onFocused = {}) else MediaRow(vm, row, null)
        }
    }
}

@Composable
private fun BrowseTab(vm: PlexViewModel, lib: PlexLibrary) {
    val tv = rememberIsTv()
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Chip("All", !vm.gridUnwatched) { vm.setUnwatched(false) }
            Chip("Unwatched", vm.gridUnwatched) { vm.setUnwatched(true) }
            Text("by", style = MaterialTheme.typography.bodyMedium)
            GridSort.values().forEach { sort -> Chip(sort.label, vm.gridSort == sort) { vm.setSort(sort) } }
            if (vm.gridTotalItems > 0) {
                Text(
                    "%,d items".format(vm.gridTotalItems),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Row(Modifier.weight(1f).fillMaxWidth()) {
            PagedGrid(vm, Modifier.weight(1f))
            // A–Z jump bar down the right edge (TV only, and only while sorted A–Z).
            if (tv && vm.gridSort == GridSort.TITLE && !vm.gridUnwatched && vm.letters.isNotEmpty()) {
                JumpBar(vm)
            }
        }
    }
}

@Composable
private fun JumpBar(vm: PlexViewModel) {
    LazyColumn(
        Modifier.width(44.dp).fillMaxHeight().padding(top = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        items(vm.letters) { letter ->
            val shape = RoundedCornerShape(6.dp)
            Text(
                letter.label,
                style = MaterialTheme.typography.labelLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRing(shape)
                    .clip(shape)
                    .clickable { vm.jumpTo(letter.index) }
                    .padding(vertical = 3.dp),
            )
        }
    }
}

@Composable
private fun CollectionsTab(vm: PlexViewModel) {
    val tv = rememberIsTv()
    if (vm.libCollections.isEmpty()) {
        Text(
            if (vm.libLoading) "Loading…" else "No collections in this library.",
            modifier = Modifier.padding(16.dp),
        )
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(if (tv) 130.dp else 110.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        itemsIndexed(vm.libCollections) { _, c ->
            MediaCard(vm, c, Modifier.fillMaxWidth()) { vm.open(c) }
        }
    }
}

private val tileColors = listOf(
    0xFF2E7D9A, 0xFF3B7A57, 0xFF9C3B5B, 0xFF8A5A2B,
    0xFF5B4B9A, 0xFF2F6F6A, 0xFF9A7B2E, 0xFF6A3B7A,
)

private fun tileColor(title: String): Color =
    Color(tileColors[(title.hashCode() and 0x7fffffff) % tileColors.size])

@Composable
private fun CategoriesTab(vm: PlexViewModel) {
    val tv = rememberIsTv()
    if (vm.libGenres.isEmpty()) {
        Text(
            if (vm.libLoading) "Loading…" else "No categories in this library.",
            modifier = Modifier.padding(16.dp),
        )
        return
    }
    LazyVerticalGrid(
        columns = if (tv) GridCells.Adaptive(190.dp) else GridCells.Fixed(2),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        itemsIndexed(vm.libGenres) { _, g ->
            val shape = RoundedCornerShape(10.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(if (tv) 96.dp else 84.dp)
                    .focusRing(shape, if (tv) 1.05f else 1f)
                    .clip(shape)
                    .background(tileColor(g.title))
                    .clickable { vm.openGrid(g.title, g.path) }
                    .padding(8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    g.title,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Search

@Composable
private fun SearchPage(vm: PlexViewModel) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        try {
            focus.requestFocus()
        } catch (_: Throwable) {
        }
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("Search", vm.server?.name, onBack = { vm.back() }, onSearch = null)
        OutlinedTextField(
            value = vm.searchQuery,
            onValueChange = { vm.updateSearch(it) },
            singleLine = true,
            placeholder = { Text("Movies and shows") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).focusRequester(focus),
        )
        vm.indexStatus?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }
        val q = vm.searchQuery.trim()
        val ctx = LocalContext.current
        val prefs = remember { AppPrefs(ctx) }
        var recents by remember { mutableStateOf(prefs.recentSearches("plex")) }
        if (q.length < 2 && recents.isNotEmpty()) {
            Text("Recent searches", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(start = 16.dp, top = 8.dp))
            androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(recents.size) { i -> Chip(recents[i], false) { vm.updateSearch(recents[i]) } }
                item { Chip("Clear", false) { prefs.clearRecentSearches("plex"); recents = emptyList() } }
            }
        }
        when {
            q.length < 2 -> Text("Type at least two letters.", modifier = Modifier.padding(16.dp))
            vm.searching && vm.searchResults.isEmpty() -> Text("Searching…", modifier = Modifier.padding(16.dp))
            vm.searchResults.isEmpty() && vm.searchProblem == null ->
                Text("No results for \"$q\".", modifier = Modifier.padding(16.dp))
        }
        if (vm.searching && vm.searchResults.isNotEmpty()) {
            Text("Still searching…", modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                style = MaterialTheme.typography.bodySmall)
        }
        vm.searchProblem?.let { problem ->
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(problem, modifier = Modifier.weight(1f))
                Chip("Try again", false) { vm.retrySearch() }
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(110.dp),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            itemsIndexed(vm.searchResults) { _, result ->
                MediaCard(vm, result, Modifier.fillMaxWidth()) {
                    prefs.addRecentSearch("plex", vm.searchQuery)
                    vm.openSearchResult(result)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Rows, grid, cards

@Composable
private fun RowHeader(title: String, subtitle: String?, onClick: (() -> Unit)?) {
    val shape = RoundedCornerShape(8.dp)
    val base = Modifier.padding(start = 12.dp, top = 14.dp, bottom = 6.dp, end = 12.dp).focusRing(shape).clip(shape)
    val clickable = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(clickable.padding(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (onClick != null) Text("  ›", style = MaterialTheme.typography.titleMedium)
        }
        if (subtitle != null) {
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun MediaRow(vm: PlexViewModel, row: HomeRow, subtitle: String?) {
    val seeAll: (() -> Unit)? = row.seeAll?.let { path -> { vm.openGrid(row.title, path) } }
    val isContinue = row.title.startsWith("Continue")
    Column {
        RowHeader(row.title, subtitle, seeAll)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(row.items) { entry ->
                MediaCard(vm, entry, Modifier.width(112.dp)) {
                    // Continue Watching resumes right away; everything else opens its page.
                    if (isContinue && entry.playable) vm.play(entry) else vm.open(entry)
                }
            }
        }
    }
}

@Composable
private fun PagedGrid(vm: PlexViewModel, modifier: Modifier) {
    val tv = rememberIsTv()
    LazyVerticalGrid(
        state = vm.gridState,
        columns = GridCells.Adaptive(if (tv) 130.dp else 110.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier.fillMaxWidth(),
    ) {
        itemsIndexed(vm.gridItems) { index, entry ->
            // Near the end of what's loaded? Fetch the next page.
            if (index >= vm.gridItems.size - 15) {
                LaunchedEffect(vm.gridItems.size) { vm.loadMore() }
            }
            MediaCard(vm, entry, Modifier.fillMaxWidth()) { vm.open(entry) }
        }
        if (vm.gridLoading) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("Loading…", modifier = Modifier.padding(16.dp))
            }
        } else if (vm.gridItems.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("Nothing here.", modifier = Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
private fun MediaCard(
    vm: PlexViewModel,
    media: PlexItem,
    modifier: Modifier,
    onFocused: ((PlexItem) -> Unit)? = null,
    onClick: () -> Unit,
) {
    val tv = rememberIsTv()
    val shape = RoundedCornerShape(10.dp)
    Column(
        modifier
            .onFocusChanged { if (it.hasFocus) onFocused?.invoke(media) }
            .focusRing(shape, if (tv) 1.08f else 1f)
            .clip(shape)
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            val img = vm.poster(media)
            if (img != null) {
                AsyncImage(
                    model = img,
                    contentDescription = media.displayTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Badges(media)
        }
        Text(
            media.displayTitle,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 6.dp),
        )
        media.displaySubtitle?.let {
            Text(
                it,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * Bottom of the picture: a progress bar if partly watched, otherwise the rating.
 * Top corner: a tick for watched items, or the unwatched count for shows.
 */
@Composable
private fun BoxScope.Badges(media: PlexItem) {
    val inProgress = media.progress > 0f && media.progress < 0.97f
    if (inProgress) {
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .height(4.dp)
                .background(Color(0x99000000))
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(media.progress)
                    .background(MaterialTheme.colorScheme.primary)
            )
        }
    } else if (media.ratings.isNotEmpty() && Opt.bool("card_ratings", true) && media.type != "episode") {
        // IMDb / Rotten Tomatoes / TMDB, like Plezy's cards.
        Row(
            Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Color(0xCC000000)).padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            media.ratings.take(3).forEach {
                Text(if (it.source == "imdb") "IMDb %.1f".format(it.value) else it.label, style = MaterialTheme.typography.labelSmall,
                    maxLines = 1, color = Color.White)
            }
        }
    } else if (media.rating > 0 && media.type != "episode" && media.type != "collection") {
        Text(
            "★ %.1f".format(media.rating),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(4.dp)
                .background(Color(0xCC000000), RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp),
        )
    }
    val corner: String? = when {
        media.type == "show" || media.type == "season" ->
            if (media.leafCount > 0) (if (media.unwatched > 0) media.unwatched.toString().takeIf { Opt.bool("show_unwatched", true) }
                else "✓".takeIf { Opt.bool("show_watched", true) }) else null
        media.type == "collection" -> null
        media.watched && Opt.bool("show_watched", true) -> "✓"
        else -> null
    }
    if (corner != null) {
        Text(
            corner,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(4.dp)
                .background(Color(0xCC000000), RoundedCornerShape(10.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp),
        )
    }
}

// ---------------------------------------------------------------- Detail page

private fun formatTime(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

private fun playTarget(vm: PlexViewModel, media: PlexItem): PlexItem? =
    if (media.playable) media
    else vm.episodes.firstOrNull { it.viewOffset > 0 }
        ?: vm.episodes.firstOrNull { !it.watched }
        ?: vm.episodes.firstOrNull()

@Composable
private fun DetailScreen(vm: PlexViewModel, media: PlexItem) {
    val background = MaterialTheme.colorScheme.background
    val isSeries = media.type == "show" || media.type == "season"

    val ctx = LocalContext.current
    val full = vm.detailFull?.takeIf { it.ratingKey == media.ratingKey } ?: media
    val target = playTarget(vm, media)
    var more by remember { mutableStateOf(false) }
    var rate by remember { mutableStateOf(false) }
    fun playTrailer() {
        val t = vm.detailExtras.firstOrNull { it.title.contains("trailer", true) } ?: vm.detailExtras.firstOrNull()
        if (t != null) vm.play(t) else vm.showNotice("No trailer on your server for this title.")
    }
    fun download() {
        val t = target ?: return vm.showNotice(if (isSeries) "Open an episode to download it." else "Nothing to download.")
        val u = vm.streamUrl(t) ?: return
        vm.showNotice(Downloads.start(ctx, t, u, vm.poster(t)))
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            // Backdrop, the title's logo (or name), facts, ratings and genres.
            Box(Modifier.fillMaxWidth().height(if (rememberIsTv()) 340.dp else 430.dp)) {
                vm.backdrop(full)?.let { art ->
                    AsyncImage(model = art, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000000), Color(0x66000000), background))))
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val logo = full.clearLogo?.let { vm.image(it, 600, 240) }
                    if (logo != null) AsyncImage(model = logo, contentDescription = full.displayTitle, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth(0.8f).height(110.dp))
                    else Text(full.displayTitle, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (full.type == "episode") Text("S${full.season} · E${full.index} · ${full.title}", color = Color(0xFFCCCCCC))
                    val facts = listOfNotNull(
                        full.year.takeIf { it > 0 }?.toString(), full.contentRating,
                        full.duration.takeIf { it > 0 && !isSeries }?.let { d -> val m = d / 60000; if (m >= 60) "${m / 60}h ${m % 60}min" else "${m}min" },
                        full.resolution?.let { r -> if (full.is4k) "4K" else if (r.all { it.isDigit() }) "${r}p" else r.uppercase() },
                        full.audio,
                        if (isSeries && full.leafCount > 0) "${full.leafCount} episodes" else null,
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        facts.forEach { DetailPill(it) }
                        DetailPill(if (full.userRating > 0) "★ ${full.userRating.toInt()}/10" else "☆ Rate") { rate = true }
                    }
                    if (full.ratings.isNotEmpty()) Row(Modifier.clip(RoundedCornerShape(50)).background(Color(0x66000000))
                        .padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        full.ratings.forEach { Text(it.label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium) }
                    }
                    if (full.genres.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        full.genres.take(5).forEach { DetailPill(it) }
                    }
                }
                Text("←", style = MaterialTheme.typography.titleLarge, color = Color.White,
                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp).focusRing(RoundedCornerShape(50)).clip(RoundedCornerShape(50))
                        .background(Color(0x88555555)).clickable { vm.back() }.padding(horizontal = 16.dp, vertical = 10.dp))
            }
        }

        item {
            // Play, trailer, download, watched, watchlist, more.
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                if (target != null) {
                    Button(onClick = { vm.play(target) }, modifier = Modifier.height(52.dp).focusRing(ButtonShape),
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFFEEEEEE), contentColor = Color.Black)) {
                        Text(if (target.viewOffset > 0) "▶  ${formatTime(target.viewOffset)}" else if (isSeries) "▶  S${target.season} E${target.index}" else "▶  Play",
                            fontWeight = FontWeight.Bold)
                    }
                }
                RoundAction("🎞", "Trailer") { playTrailer() }
                if (!isSeries) RoundAction(if (Downloads.isDownloaded(media.ratingKey)) "✔" else "⤓", "Download") { download() }
                RoundAction(if (full.watched) "✓" else "○", if (full.watched) "Mark unwatched" else "Mark watched") { vm.setWatched(full, !full.watched) }
                RoundAction(if (vm.onPlexWatchlist == true) "🔖" else "＋", "Watchlist") { vm.togglePlexWatchlist(full) }
                RoundAction("⋮", "More") { more = true }
            }
        }
        if (target != null && target.viewOffset > 0) item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.play(target.copy(viewOffset = 0)) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Start over") }
                CastButton({
                    CastRequest("plex", url = vm.streamUrl(target).orEmpty(), title = target.displayTitle,
                        ratingKey = target.ratingKey.orEmpty(), startMs = target.viewOffset)
                })
            }
        }
        item { Notice(vm) }

        // Trakt: rating and your actions (actions only when signed in).
        vm.detailTrakt?.let { dt ->
            item {
                var rating by remember { mutableStateOf(false) }
                Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    dt.rating?.takeIf { it.votes > 0 }?.let {
                        Text("Trakt ${(it.rating * 10).toInt()}%  ·  ${it.votes} votes", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (TraktAccount.signedIn) {
                        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(vertical = 6.dp)) {
                            item { Chip(if (vm.onWatchlist == true) "✓ On watchlist" else "+ Watchlist", vm.onWatchlist == true) { vm.toggleWatchlist() } }
                            item { Chip("♥ Favorite", false) { vm.traktFavorite() } }
                            item { Chip("✓ Mark watched", false) { vm.traktMarkWatched() } }
                            item { Chip("★ Rate", rating) { rating = !rating } }
                            if (rating) {
                                items(10) { i -> Chip("${10 - i}", false) { vm.traktRate(10 - i); rating = false } }
                                item { Chip("Clear", false) { vm.traktRate(0); rating = false } }
                            }
                        }
                    }
                }
            }
        }

        (full.summary ?: media.summary)?.let { summary ->
            item {
                Text("Overview", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, top = 8.dp))
            }
            item {
                val hide = Opt.bool("hide_spoilers", false) && media.type == "episode" && !media.watched
                Text(
                    if (hide) "Description hidden until you watch it." else summary,
                    maxLines = 8,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
        }

        if (media.type == "show" && vm.seasons.isNotEmpty()) {
            item {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    vm.seasons.forEach { season ->
                        Chip(season.title, vm.selectedSeason?.ratingKey == season.ratingKey) {
                            vm.selectSeason(season)
                        }
                    }
                }
            }
        }

        if (isSeries) {
            if (vm.detailLoading && vm.episodes.isEmpty()) {
                item { Text("Loading…", modifier = Modifier.padding(16.dp)) }
            }
            items(vm.episodes) { ep -> EpisodeRow(vm, ep) }
        }

        if (full.cast.isNotEmpty()) item {
            Column(Modifier.padding(top = 12.dp)) {
                Text("Cast", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp))
                androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(full.cast.take(30).size) { i ->
                        val p = full.cast[i]
                        Column(Modifier.width(120.dp).focusRing(RoundedCornerShape(12.dp)).clip(RoundedCornerShape(12.dp))
                            .clickable { vm.openActor(p, full.sectionId ?: media.sectionId) }) {
                            Box(Modifier.fillMaxWidth().aspectRatio(0.8f).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center) {
                                val ph = p.thumb?.let { vm.image(it, 240, 300) }
                                if (ph != null) AsyncImage(model = ph, contentDescription = p.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                else Text(p.name.take(1), style = MaterialTheme.typography.headlineLarge)
                            }
                            Text(p.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                            p.role?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA), maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        }
                    }
                }
            }
        }
        if (vm.detailExtras.isNotEmpty()) item {
            Column(Modifier.padding(top = 8.dp)) {
                Text("Trailers & Extras", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp))
                androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(vm.detailExtras.size) { i ->
                        val x = vm.detailExtras[i]
                        Column(Modifier.width(200.dp).focusRing(RoundedCornerShape(10.dp)).clickable { vm.play(x) }) {
                            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                                vm.landscape(x)?.let { AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                            }
                            Text(x.title, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
        }
        vm.detailRelated.forEach { hub ->
            item {
                Column(Modifier.padding(top = 8.dp)) {
                    Text(hub.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp))
                    androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(hub.items.size) { i -> val it = hub.items[i]; MediaCard(vm, it, Modifier.width(110.dp)) { vm.open(it) } }
                    }
                }
            }
        }
        vm.actorRow?.let { (name, titles) ->
            item {
                Column(Modifier.padding(top = 8.dp)) {
                    Text("More with $name", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp))
                    androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(titles.size) { i -> val it = titles[i]; MediaCard(vm, it, Modifier.width(110.dp)) { vm.open(it) } }
                    }
                }
            }
        }

        // More like this (from Trakt), only titles in your library.
        vm.detailTrakt?.related?.takeIf { it.isNotEmpty() }?.let { rel ->
            item {
                Column(Modifier.padding(top = 12.dp)) {
                    Text("More Like This", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 16.dp))
                    androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(rel.size) { i ->
                            val it = rel[i].item ?: return@items
                            MediaCard(vm, it, Modifier.width(110.dp)) { vm.open(it) }
                        }
                    }
                }
            }
        }
    }
    if (rate) androidx.compose.material3.AlertDialog(
        onDismissRequest = { rate = false },
        title = { Text("Rate ${full.displayTitle}") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    (1..5).forEach { n -> Text("★", style = MaterialTheme.typography.headlineMedium,
                        color = if (full.userRating >= n * 2) Color(0xFFFFC107) else Color(0xFF666666),
                        modifier = Modifier.focusRing(RoundedCornerShape(50)).clickable { vm.ratePlex(full, n * 2); rate = false }.padding(6.dp)) }
                }
                Text("Saved on Plex.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { androidx.compose.material3.TextButton(onClick = { vm.ratePlex(full, 0); rate = false }) { Text("Clear") } },
        dismissButton = { androidx.compose.material3.TextButton(onClick = { rate = false }) { Text("Cancel") } },
    )
    if (more) androidx.compose.material3.ModalBottomSheet(onDismissRequest = { more = false }) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text(full.displayTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
            @Composable fun Item(icon: String, label: String, go: () -> Unit) {
                Row(Modifier.fillMaxWidth().focusRing().clickable { more = false; go() }.padding(horizontal = 24.dp, vertical = 14.dp)) {
                    Text(icon, modifier = Modifier.width(36.dp)); Text(label)
                }
            }
            Item("🎞", "Play trailer") { playTrailer() }
            Item(if (full.watched) "○" else "✓", if (full.watched) "Mark as Unwatched" else "Mark as Watched") { vm.setWatched(full, !full.watched) }
            Item("★", "Rate") { rate = true }
            if (target != null) {
                Item("⤓", "Download") { download() }
                Item("↗", "Play in External Player") {
                    val u = vm.streamUrl(target) ?: return@Item
                    val i = android.content.Intent(android.content.Intent.ACTION_VIEW).setDataAndType(android.net.Uri.parse(u), "video/*")
                        .putExtra("position", target.viewOffset.toInt()).putExtra("title", target.displayTitle)
                    try { ctx.startActivity(android.content.Intent.createChooser(i, "Play with")) } catch (_: Exception) {}
                }
                Item("⧉", "Play in corner") {
                    val u = vm.streamUrl(target) ?: return@Item
                    vm.showNotice(Corners.addPlex(ctx, target, u) ?: "Playing in a corner window.")
                }
            }
            Item("🔖", if (vm.onPlexWatchlist == true) "Remove from Watchlist" else "Add to Watchlist") { vm.togglePlexWatchlist(full) }
            Item("ⓘ", "File Info") {
                vm.showNotice(listOfNotNull(full.resolution?.let { "Video: $it" }, full.audio?.let { "Audio: $it" },
                    full.partKey?.substringAfterLast('.')?.let { "Container: ${it.uppercase()}" }, full.sectionId?.let { "Library #$it" }).joinToString(" · ").ifEmpty { "No file details." })
            }
        }
    }
}

@Composable
private fun EpisodeRow(vm: PlexViewModel, ep: PlexItem) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .focusRing(shape)
            .clip(shape)
            .clickable { vm.play(ep) }
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier
                .width(140.dp)
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            val img = vm.landscape(ep, 320)
            val spoiler = Opt.bool("hide_spoilers", false) && !ep.watched
            if (img != null) {
                AsyncImage(
                    model = img,
                    contentDescription = ep.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().then(if (spoiler) Modifier.blur(24.dp) else Modifier),
                )
            }
            Badges(ep)
        }
        Column(Modifier.weight(1f)) {
            Text(
                "${ep.index}. ${ep.title}",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge,
            )
            if (ep.duration > 0) {
                Text(
                    "${ep.duration / 60000} min",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            ep.summary?.takeIf { !(Opt.bool("hide_spoilers", false) && !ep.watched) }?.let {
                Text(
                    it,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Player

@Composable
private fun PlexPlayerScreen(vm: PlexViewModel, media: PlexItem, url: String) {
    val context = LocalContext.current
    val prefs = remember { AppPrefs(context) }
    val spanish = remember(media.ratingKey) { vm.isSpanish(media) }
    val player = remember {
        // Subtitle files stored beside the video on the server.
        val subs = media.subtitles.mapNotNull { sub ->
            val u = vm.subtitleUrl(sub) ?: return@mapNotNull null
            val mime = when (sub.codec?.lowercase()) {
                "srt", "subrip" -> androidx.media3.common.MimeTypes.APPLICATION_SUBRIP
                "ass", "ssa" -> androidx.media3.common.MimeTypes.TEXT_SSA
                "vtt", "webvtt" -> androidx.media3.common.MimeTypes.TEXT_VTT
                else -> return@mapNotNull null
            }
            MediaItem.SubtitleConfiguration.Builder(android.net.Uri.parse(u))
                .setMimeType(mime)
                .setLanguage(sub.language)
                .setLabel(sub.title)
                .build()
        }
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.Builder().setUri(url).setSubtitleConfigurations(subs).build())
            // Subtitle and audio language from Settings; Spanish libraries always play in Spanish.
            val mode = prefs.subtitleMode
            val subLang = if (spanish) "es" else prefs.subtitleLang.ifBlank { "en" }
            val audio = if (spanish) "es" else prefs.audioLang.ifBlank { null }
            trackSelectionParameters = trackSelectionParameters.buildUpon().apply {
                setPreferredAudioLanguage(audio)
                when (mode) {
                    "off" -> setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                    "always" -> {
                        setPreferredTextLanguage(subLang)
                        setSelectUndeterminedTextLanguage(true)
                    }
                    else -> {
                        // Forced only: just the subtitles for foreign-language parts.
                        setPreferredTextLanguage(null)
                        setIgnoredTextSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                    }
                }
            }.build()
            // Resume (Settings > V.O.D): automatically, after asking, or never.
            val resumable = media.viewOffset > 0 && (media.duration == 0L || media.viewOffset < media.duration * 0.95)
            val mode = Opt.str(Opt.VOD_RESUME, "dialog")
            if (resumable && mode == "auto") seekTo(media.viewOffset)
            prepare()
            playWhenReady = !(resumable && mode == "dialog")
        }
    }
    fun duration() = if (player.duration > 0) player.duration else media.duration
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var nextUp by remember { mutableStateOf<PlexItem?>(null) }
    var speed by remember { mutableStateOf(1f) }
    var sleepAt by remember { mutableStateOf(0L) }
    var showTools by remember { mutableStateOf(false) }
    var cornerPicker by remember { mutableStateOf(false) }
    var resize by remember { mutableStateOf(0) }          // fit, fill, zoom
    var locked by remember { mutableStateOf(false) }      // screen lock: touches ignored
    var rotationLocked by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0) }            // redraws the clock
    LaunchedEffect(Unit) { while (true) { delay(15_000); tick++ } }

    DisposableEffect(Unit) {
        // Auto-play the next episode when this one ends.
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == androidx.media3.common.Player.STATE_ENDED && prefs.autoPlayNext && media.type == "episode") {
                    scope.launch {
                        val next = vm.nextEpisode(media)
                        if (next != null) vm.playNow(next) else vm.back()
                    }
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            vm.report(media, "stopped", player.currentPosition, duration())
            player.release()
        }
    }
    LaunchedEffect(Unit) {
        // Look up the next episode so "Next episode" can be shown near the end.
        if (media.type == "episode") nextUp = vm.nextEpisode(media)
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            vm.report(media, if (player.isPlaying) "playing" else "paused", player.currentPosition, duration())
            if (sleepAt > 0 && System.currentTimeMillis() >= sleepAt) {
                player.pause()
                sleepAt = 0
            }
        }
    }

    // Resume dialog.
    var askResume by remember {
        mutableStateOf(media.viewOffset > 0 && (media.duration == 0L || media.viewOffset < media.duration * 0.95) &&
            Opt.str(Opt.VOD_RESUME, "dialog") == "dialog")
    }
    // Skip intro / credits (markers Plex detected).
    var skipFor by remember { mutableStateOf<PlexMarker?>(null) }
    val autoSkipped = remember { HashSet<Long>() }
    LaunchedEffect(Unit) {
        val mode = Opt.str(Opt.SKIP_INTRO, "button")
        if (mode == "off" || media.markers.isEmpty()) return@LaunchedEffect
        while (true) {
            delay(500)
            val pos = player.currentPosition
            val m = media.markers.firstOrNull { pos >= it.start && pos < it.end - 1000 }
            if (m != null && mode == "auto" && m.type == "intro" && autoSkipped.add(m.start)) {
                player.seekTo(m.end)
                skipFor = null
            } else skipFor = m
        }
    }
    BackHandler {
        if (showTools) showTools = false else vm.back()
    }
    if (askResume) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { askResume = false; player.play() },
            title = { Text("Resume?") },
            text = { Text("You stopped at ${formatTime(media.viewOffset)}.") },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { askResume = false; player.seekTo(media.viewOffset); player.play() },
                    modifier = Modifier.focusRing(ButtonShape)) { Text("Resume from ${formatTime(media.viewOffset)}") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { askResume = false; player.seekTo(0); player.play() },
                    modifier = Modifier.focusRing(ButtonShape)) { Text("Start from the beginning") }
            },
        )
    }
    Box(Modifier.fillMaxSize()) {
        // The video, plus corner windows (Live TV channels or other Plex videos) in the chosen layout.
        MultiView(enabled = !Pip.active) { m ->
            AndroidView(
                modifier = m,
                factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true }.applyOptions() },
                update = {
                    it.useController = !Pip.active && !locked   // no controls in the small window or when locked
                    it.resizeMode = when (resize) {
                        1 -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
                        2 -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        else -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                },
            )
        }
        LaunchedEffect(Corners.mainMuted) { player.volume = if (Corners.mainMuted) 0f else 1f }
        if (cornerPicker) CornerPickerDialog { cornerPicker = false }
        skipFor?.let { m ->
            if (!Pip.active) {
                androidx.compose.material3.Button(
                    onClick = {
                        val n = nextUp
                        if (m.type == "credits" && n != null) vm.playNow(n) else player.seekTo(m.end)
                        skipFor = null
                    },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(bottom = 90.dp, end = 24.dp).focusRing(ButtonShape),
                ) { Text(if (m.type == "credits") (if (nextUp != null) "Next episode ▶" else "Skip credits") else "Skip intro") }
            }
        }
        // Player tools: speed, sleep timer, next episode, picture-in-picture.
        if (!Pip.active) Row(
            Modifier.align(Alignment.TopEnd).padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (showTools) {
                Chip("Speed ${if (speed % 1f == 0f) speed.toInt().toString() else speed.toString()}x", false) {
                    val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
                    speed = speeds[(speeds.indexOf(speed) + 1) % speeds.size]
                    player.setPlaybackSpeed(speed)
                }
                val sleepLabel = if (sleepAt == 0L) "Sleep: off" else "Sleep: ${((sleepAt - System.currentTimeMillis()) / 60_000).coerceAtLeast(0)} min"
                Chip(sleepLabel, false) {
                    sleepAt = when {
                        sleepAt == 0L -> System.currentTimeMillis() + 30 * 60_000
                        sleepAt - System.currentTimeMillis() < 31 * 60_000 -> System.currentTimeMillis() + 60 * 60_000
                        sleepAt - System.currentTimeMillis() < 61 * 60_000 -> System.currentTimeMillis() + 90 * 60_000
                        else -> 0L
                    }
                }
                Chip("Skip +90s", false) { player.seekTo(player.currentPosition + 90_000) }
                Chip("▭ " + listOf("Fit", "Fill", "Zoom")[resize], false) { resize = (resize + 1) % 3 }
                Chip("🔒 Lock screen", false) { showTools = false; locked = true }
                (context as? android.app.Activity)?.let { a ->
                    Chip(if (rotationLocked) "⟲ Rotation locked" else "⟲ Lock rotation", rotationLocked) {
                        rotationLocked = !rotationLocked
                        a.requestedOrientation = if (rotationLocked) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LOCKED
                            else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    }
                }
                nextUp?.let { n -> Chip("Next: S${n.season} E${n.index}", false) { vm.playNow(n) } }
                if (!Corners.full) Chip("⧉ TV in corner", false) { showTools = false; cornerPicker = true }
                if (Corners.slots.isNotEmpty()) {
                    Chip("🔊 " + (Corners.slots.firstOrNull { it.id == Corners.soundId }?.title ?: "this video"), false) { Corners.cycleSound() }
                    Chip("▦ ${Corners.layout.label}", false) { Corners.cycleLayout() }
                    if (Corners.slots.size > 1) Chip("⟳ Rotate windows", false) { Corners.rotateWindows() }
                    if (Corners.layout == Corners.Layout.CORNERS) {
                        Chip(if (Corners.large) "Smaller corners" else "Bigger corners", false) { Corners.toggleSize() }
                    }
                    Chip("✕ Close corners", false) { Corners.closeAll() }
                }
                (context as? android.app.Activity)?.takeIf { Pip.supported(it) }?.let { a ->
                    Chip("⧉ PiP", false) { showTools = false; Pip.enter(a) }
                }
                Chip("Other player", false) {
                    // VLC, MX Player, Kodi...: hands over the stream at the current position.
                    val i = android.content.Intent(android.content.Intent.ACTION_VIEW)
                        .setDataAndType(android.net.Uri.parse(url), "video/*")
                        .putExtra("position", player.currentPosition.toInt())
                        .putExtra("title", media.displayTitle)
                    try {
                        player.pause()
                        context.startActivity(android.content.Intent.createChooser(i, "Play with"))
                    } catch (_: Exception) {
                    }
                }
            }
            if (!locked) {
                // The time now and when this ends.
                val clockTick = tick; if (clockTick < 0) return@Row
                val left = (duration() - player.currentPosition).coerceAtLeast(0)
                val fmt = remember { java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault()) }
                Text("${fmt.format(java.util.Date())} · ends ${fmt.format(java.util.Date(System.currentTimeMillis() + left))}",
                    color = Color.White, style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(0x88000000)).padding(horizontal = 10.dp, vertical = 6.dp))
                Chip(if (showTools) "Close" else "⋯", showTools) { showTools = !showTools }
            }
        }
        if (locked) {
            // Screen lock: swallows touches; long-press the lock to unlock.
            Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }) {
                Text("🔒 Hold to unlock", color = Color.White,
                    modifier = Modifier.align(Alignment.TopEnd).padding(16.dp).clip(RoundedCornerShape(50)).background(Color(0x88000000))
                        .pointerInput(Unit) { detectTapGestures(onLongPress = { locked = false }) }.padding(horizontal = 14.dp, vertical = 8.dp))
            }
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            (context as? android.app.Activity)?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
}

/** Your Trakt calendar, watchlist, recommendations and history, linked to what's in your library. */
@Composable
private fun TraktPage(vm: PlexViewModel) {
    val ctx = LocalContext.current
    remember { TraktAccount.load(ctx); true }
    Column(Modifier.fillMaxSize()) {
        TopBar("Trakt", TraktAccount.username, onBack = { vm.back() }, onSearch = { vm.openSearch() })
        androidx.compose.foundation.lazy.LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(TraktTab.values().size) { i ->
                val t = TraktTab.values()[i]
                Chip(t.label, vm.traktTab == t) { vm.selectTraktTab(t) }
            }
        }
        vm.traktListOpen?.let { l ->
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(l.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Chip("All lists", false) { vm.openTraktList(null) }
            }
        }
        Notice(vm)
        if (vm.traktLoading) Text("Loading from Trakt…", modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(8.dp)) {
            if (vm.traktListOpen == null) {
                items(vm.traktLists.size) { i ->
                    val l = vm.traktLists[i]
                    ListRow(title = l.name, subtitle = "${l.count} titles", onClick = { vm.openTraktList(l) })
                }
            }
            items(vm.traktEntries.size) { i ->
                val (entry, item) = vm.traktEntries[i]
                ListRow(
                    title = entry.title,
                    subtitle = entry.subtitle,
                    onClick = { if (item != null) vm.open(item) },
                )
            }
        }
    }
}


@Composable
private fun DetailPill(text: String, onClick: (() -> Unit)? = null) {
    val m = Modifier.clip(RoundedCornerShape(50)).background(Color(0x99000000))
    Text(text, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = Color.White,
        modifier = (if (onClick != null) m.focusRing(RoundedCornerShape(50)).clickable(onClick = onClick) else m).padding(horizontal = 12.dp, vertical = 6.dp))
}

@Composable
private fun RoundAction(icon: String, label: String, onClick: () -> Unit) {
    Box(Modifier.size(52.dp).focusRing(RoundedCornerShape(50)).clip(RoundedCornerShape(50)).background(Color(0xFF26272B))
        .clickable(onClick = onClick).semantics { contentDescription = label }, contentAlignment = Alignment.Center) {
        Text(icon, style = MaterialTheme.typography.titleLarge)
    }
}
