package com.example.tvhub

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.tv.material3.*
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

@Composable
fun LibraryScreen(vm: PlexViewModel) {
    val playing = vm.playing
    val url = playing?.let { vm.streamUrl(it) }
    if (playing != null && url != null) {
        PlexPlayerScreen(vm, playing, url)
        return
    }

    BackHandler(enabled = vm.canGoBack) { vm.back() }

    Box(Modifier.fillMaxSize().padding(start = 72.dp, top = 16.dp, end = 16.dp)) {
        when (val s = vm.state) {
            PlexState.SignedOut -> CenterColumn {
                Text("Sign in to Plex", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { vm.signIn() }) { Text("Get sign-in code") }
            }
            is PlexState.WaitingForCode -> CenterColumn {
                Text("On your phone or computer, go to")
                Text("plex.tv/link", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(16.dp))
                Text("and enter this code:")
                Text(s.code, style = MaterialTheme.typography.displayMedium)
            }
            PlexState.Loading -> CenterColumn { Text("Connecting to your Plex server…") }
            is PlexState.Failed -> CenterColumn {
                Text(s.message)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { vm.retry() }) { Text("Try again") }
            }
            PlexState.Ready -> {
                val page = vm.page
                Column(Modifier.fillMaxSize()) {
                    Text(
                        page?.title ?: vm.server?.name ?: "Plex",
                        style = MaterialTheme.typography.headlineMedium,
                        modifier = Modifier.padding(bottom = 12.dp),
                    )
                    if (vm.busy) Text("Loading…")
                    PosterGrid(vm, page?.items ?: vm.libraries)
                    if (page == null) {
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { vm.signOut() }) { Text("Sign out of Plex") }
                    }
                }
            }
        }
    }
}

@Composable
private fun CenterColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content,
    )
}

@Composable
private fun PosterGrid(vm: PlexViewModel, items: List<PlexItem>) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth().heightIn(max = 900.dp),
    ) {
        items(items) { item ->
            Card(onClick = { vm.open(item) }) {
                val img = vm.imageUrl(item)
                if (img != null) {
                    AsyncImage(
                        model = img,
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f),
                    )
                }
                Text(
                    item.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(8.dp),
                )
                item.subtitle?.let { Text(it, modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)) }
            }
        }
    }
}

@Composable
private fun PlexPlayerScreen(vm: PlexViewModel, item: PlexItem, url: String) {
    val context = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            // Resume where you left off, unless you were nearly finished.
            if (item.viewOffset > 0 && (item.duration == 0L || item.viewOffset < item.duration * 0.95)) {
                seekTo(item.viewOffset)
            }
            prepare()
            playWhenReady = true
        }
    }
    fun duration() = if (player.duration > 0) player.duration else item.duration

    DisposableEffect(Unit) {
        onDispose {
            vm.report(item, "stopped", player.currentPosition, duration())
            player.release()
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            vm.report(item, if (player.isPlaying) "playing" else "paused", player.currentPosition, duration())
        }
    }

    BackHandler { vm.back() }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
    )
}
