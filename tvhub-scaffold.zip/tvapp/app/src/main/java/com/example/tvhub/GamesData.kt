package com.example.tvhub

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

// ======================================================================= Data model

data class Console(
    val id: String,
    val name: String,
    val maker: String,
    val year: Int,
    val libretro: String,          // system name used by the libretro box-art library
    val exts: Set<String>,
    val aliases: List<String>,
    val launcher: String,          // default launcher id (launchers.json)
    val core: String,              // default RetroArch core file
    val postProcess: String,       // "none" or "unzip"
    val description: String,
    val logo: String,
    val builtin: String = "",      // core for the built-in player (Lemuroid core name), empty = none
)

data class LaunchExtra(val type: String, val key: String, val value: String)

data class Launcher(
    val id: String,
    val name: String,
    val packages: List<String>,
    val activity: String,
    val action: String,
    val categories: List<String>,
    val extras: List<LaunchExtra>,
    val flags: List<String>,
    val data: String,
)

data class GameSettings(val downloadFolder: String, val thumbnailBase: String, val remoteDataUrl: String)

data class Catalog(
    val consoles: List<Console>,
    val launchers: List<Launcher>,
    val settings: GameSettings,
    val saveProfiles: List<SaveProfile> = emptyList(),
)

data class Game(
    val title: String,
    val console: String,              // console id
    val key: String,                  // unique: where the game comes from
    val identifier: String? = null,   // Internet Archive item
    val file: String? = null,         // file inside that item
    val size: Long = 0,
    val url: String? = null,          // direct download address
    val path: String? = null,         // file on this device
    val uri: String? = null,          // content address of that file
    val art: String? = null,
    val year: String? = null,
    val genre: String? = null,
    val players: String? = null,
    val summary: String? = null,
    val bundle: Boolean = false,      // arrives as a zip of several files that must be unpacked
    val rommId: Int = 0,
    val manual: String? = null,       // manual (usually a PDF) address
    val screenshots: List<String> = emptyList(),
    val playInBrowser: String? = null, // RomM's own in-browser player page
    val myRating: Int = 0,             // your rating in RomM, 1-10 (0 = none)
    val raId: Int = 0,                 // RetroAchievements game id
    val achievements: List<Achievement> = emptyList(),
    val titleId: String? = null,       // the game's own serial (e.g. ULUS-10041), used to find PSP saves
    val trailer: String? = null,       // YouTube video id
    val status: String? = null,        // your play status in RomM (finished, completed_100, ...)
)

data class Achievement(val raId: Int, val title: String, val description: String, val points: Int, val badge: String?)

/** A downloaded game: where its launch file is, and every file that belongs to it (for Delete). */
data class Downloaded(
    val title: String,
    val console: String,
    val sourceKey: String,
    val path: String,
    val uri: String?,
    val files: List<String>,
)

// ======================================================================= Data folder

/**
 * The editable data folder: app/src/main/assets/games in the build, or copies fetched from the
 * user's server (kept in the app's private storage, and used first when present).
 */
object GameCatalog {
    val FILES = listOf("consoles.json", "launchers.json", "settings.json", "saves.json")

    private fun saved(ctx: Context, name: String) = File(ctx.filesDir, "gamedata/$name")
    private fun asset(ctx: Context, name: String): String =
        ctx.assets.open("games/$name").bufferedReader().use { it.readText() }

    /** Parses the server copy if there is one; if it is missing or broken, the built-in copy. */
    private fun <T> readParsed(ctx: Context, name: String, parse: (String) -> T): T {
        val f = saved(ctx, name)
        if (f.exists()) {
            try {
                return parse(f.readText())
            } catch (_: Exception) {
            }
        }
        return parse(asset(ctx, name))
    }

    fun load(ctx: Context): Catalog = Catalog(
        consoles = readParsed(ctx, "consoles.json", ::parseConsoles),
        launchers = readParsed(ctx, "launchers.json", ::parseLaunchers),
        settings = readParsed(ctx, "settings.json", ::parseSettings),
        saveProfiles = readParsed(ctx, "saves.json", SaveLocator::parseProfiles),
    )

    fun usingServerCopy(ctx: Context) = FILES.any { saved(ctx, it).exists() }

    /** Fetches each data file from [base]; files the server doesn't have are left as they are. */
    fun updateFromServer(ctx: Context, base: String): Int {
        val root = base.trim().trimEnd('/')
        var n = 0
        for (name in FILES) {
            val text = try {
                httpText("$root/$name")
            } catch (_: Exception) {
                null
            } ?: continue
            // Only keep a file that parses, so a typo can't break the app.
            when (name) {
                "consoles.json" -> parseConsoles(text)
                "launchers.json" -> parseLaunchers(text)
                "settings.json" -> parseSettings(text)
                "saves.json" -> SaveLocator.parseProfiles(text)
            }
            val f = saved(ctx, name)
            f.parentFile?.mkdirs()
            f.writeText(text)
            n++
        }
        return n
    }

    fun useBuiltIn(ctx: Context) {
        File(ctx.filesDir, "gamedata").deleteRecursively()
    }

    // --- parsers ---

    private fun strings(a: JSONArray?): List<String> =
        if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }.filter { it.isNotEmpty() }

    fun parseConsoles(text: String): List<Console> {
        val a = JSONArray(text)
        return (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
            Console(
                id = o.getString("id"),
                name = o.optString("name", o.getString("id")),
                maker = o.optString("maker"),
                year = o.optInt("year"),
                libretro = o.optString("libretro"),
                exts = strings(o.optJSONArray("exts")).map { it.lowercase() }.toSet(),
                aliases = strings(o.optJSONArray("aliases")).map { it.lowercase() },
                launcher = o.optString("launcher", "retroarch"),
                core = o.optString("core"),
                postProcess = o.optString("post_process", "none"),
                description = o.optString("description"),
                logo = o.optString("logo"),
                builtin = o.optString("builtin"),
            )
        }
    }

    fun parseLaunchers(text: String): List<Launcher> {
        val a = JSONArray(text)
        return (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
            val ex = o.optJSONArray("extras") ?: JSONArray()
            Launcher(
                id = o.getString("id"),
                name = o.optString("name", o.getString("id")),
                packages = strings(o.optJSONArray("packages")),
                activity = o.optString("activity"),
                action = o.optString("action"),
                categories = strings(o.optJSONArray("categories")),
                extras = (0 until ex.length()).map { ex.getJSONObject(it) }.map {
                    LaunchExtra(it.optString("type", "string"), it.getString("key"), it.optString("value"))
                },
                flags = strings(o.optJSONArray("flags")),
                data = o.optString("data"),
            )
        }
    }

    fun parseSettings(text: String): GameSettings {
        val o = JSONObject(text)
        return GameSettings(
            downloadFolder = o.optString("download_folder", "TVHubGames").ifEmpty { "TVHubGames" },
            thumbnailBase = o.optString("thumbnail_base", "https://thumbnails.libretro.com").trimEnd('/'),
            remoteDataUrl = o.optString("remote_data_url"),
        )
    }

}

fun httpText(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 20_000
    c.readTimeout = 40_000
    c.setRequestProperty("User-Agent", "TVHub/1.4")
    if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
    return c.inputStream.bufferedReader().use { it.readText() }
}

// ======================================================================= Saving files

private class CountingInputStream(input: InputStream) : FilterInputStream(input) {
    var count = 0L
    override fun read(): Int = super.read().also { if (it >= 0) count++ }
    override fun read(b: ByteArray, off: Int, len: Int): Int = super.read(b, off, len).also { if (it > 0) count += it }
}

/** Saves games under Downloads/<folder>/<console>/ where emulators can read them. */
object GameFiles {
    data class Saved(val path: String, val uri: String?)

    private fun safe(s: String) = s.replace(Regex("[\\\\:*?\"<>|]"), "_").trim().ifEmpty { "game" }

    private fun saveOne(ctx: Context, relDir: String, name: String, privateRoot: File?, write: (OutputStream) -> Unit): Saved {
        val fileName = safe(name.substringAfterLast('/'))
        if (privateRoot != null) {
            // The app's own storage: no permission needed, and the built-in player can open it directly.
            val dir = File(privateRoot, relDir).apply { mkdirs() }
            val f = File(dir, fileName)
            val tmp = File(dir, "$fileName.part")
            try {
                FileOutputStream(tmp).use(write)
                f.delete()
                if (!tmp.renameTo(f)) throw IOException("Couldn't save $fileName")
            } catch (t: Throwable) {
                tmp.delete()
                throw t
            }
            return Saved(f.absolutePath, null)
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/$relDir")
                put(MediaStore.MediaColumns.IS_PENDING, 1)   // hidden until complete; Android cleans up if we die
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Couldn't create $fileName")
            try {
                val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("Couldn't write $fileName")
                out.use(write)
                ctx.contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (t: Throwable) {
                try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) {}
                throw t
            }
            val path = ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
                ?: "/storage/emulated/0/Download/$relDir/$fileName"
            return Saved(path, uri.toString())
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), relDir)
        dir.mkdirs()
        val f = File(dir, fileName)
        try {
            FileOutputStream(f).use(write)
        } catch (t: Throwable) {
            f.delete()
            throw t
        }
        return Saved(f.absolutePath, null)
    }

    private fun copy(input: InputStream, out: OutputStream, onBytes: () -> Unit) {
        val buf = ByteArray(64 * 1024)
        var since = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            since += n
            if (since > 256 * 1024) {
                since = 0
                onBytes()
            }
        }
    }

    /** Saves the stream as one file. */
    fun save(
        ctx: Context, relDir: String, name: String, input: InputStream, total: Long,
        privateRoot: File? = null, progress: (Float) -> Unit,
    ): List<Saved> {
        val counter = CountingInputStream(input)
        val s = saveOne(ctx, relDir, name, privateRoot) { out ->
            copy(counter, out) { if (total > 0) progress((counter.count.toFloat() / total).coerceIn(0f, 1f)) }
        }
        return listOf(s)
    }

    /** Unzips the stream into its own folder. Returns every file written. */
    fun saveUnzipped(
        ctx: Context, relDir: String, folder: String, input: InputStream, total: Long,
        privateRoot: File? = null, progress: (Float) -> Unit,
    ): List<Saved> {
        val counter = CountingInputStream(input)
        val out = ArrayList<Saved>()
        ZipInputStream(counter).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (e.isDirectory) continue
                val inner = e.name.replace('\\', '/').split('/').filter { it.isNotEmpty() && it != ".." }
                if (inner.isEmpty()) continue
                val sub = (listOf(relDir, safe(folder)) + inner.dropLast(1).map { safe(it) }).joinToString("/")
                out += saveOne(ctx, sub, inner.last(), privateRoot) { o ->
                    copy(zip, o) { if (total > 0) progress((counter.count.toFloat() / total).coerceIn(0f, 1f)) }
                }
            }
        }
        if (out.isEmpty()) throw IOException("The zip file was empty")
        return out
    }

    /** Which of several unpacked files to start: a disc sheet first, then the console's own file types. */
    fun launchFile(files: List<Saved>, c: Console?): Saved {
        fun ext(s: Saved) = s.path.substringAfterLast('.', "").lowercase()
        return files.firstOrNull { ext(it) == "m3u" }
            ?: files.firstOrNull { ext(it) in setOf("cue", "gdi", "ccd") }
            ?: files.firstOrNull { c != null && ext(it) in c.exts }
            ?: files.filter { ext(it) !in setOf("txt", "nfo", "jpg", "png", "sav", "srm") }.maxByOrNull { it.path.length }
            ?: files.first()
    }

    fun delete(ctx: Context, d: Downloaded) {
        for (f in d.files.ifEmpty { listOfNotNull(d.uri ?: d.path) }) {
            try {
                if (f.startsWith("content://")) ctx.contentResolver.delete(Uri.parse(f), null, null)
                else File(f).delete()
            } catch (_: Exception) {
            }
        }
    }
}

// ======================================================================= Launching

object GameLauncher {
    fun installed(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: Exception) {
        false
    }

    fun installedPackage(ctx: Context, l: Launcher): String? = l.packages.firstOrNull { installed(ctx, it) }

    /** Starts [path] with [launcher]. Returns a message when it can't. */
    fun launch(ctx: Context, launcher: Launcher, core: String, path: String?, uri: String?): String? {
        if (launcher.id == "open_with" || launcher.packages.isEmpty()) return openWith(ctx, path, uri)
        if (path == null) return openWith(ctx, null, uri)
        val pkg = installedPackage(ctx, launcher)
            ?: return "${launcher.name} isn't installed. Install it, or pick another launcher in Manage."
        // A content address for the game that the emulator is allowed to read (like Argosy's FileProvider URIs).
        val needsUri = launcher.data.contains("{rom_uri}") || launcher.extras.any { it.value.contains("{rom_uri}") }
        val contentUri: Uri? = if (needsUri) {
            uri?.let { Uri.parse(it) } ?: try {
                FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(path))
            } catch (_: Exception) {
                null
            }
        } else null
        fun fill(v: String) = v
            .replace("{rom_uri}", contentUri?.toString() ?: "file://$path")
            .replace("{rom_file}", "file://$path")
            .replace("{rom}", path)
            .replace("{core}", "/data/data/$pkg/cores/$core")
            .replace("{core_dir}", "/data/data/$pkg/cores")
            .replace("{core_stem}", core.removeSuffix("_android.so"))
            .replace("{cfg}", "/storage/emulated/0/Android/data/$pkg/files/retroarch.cfg")
        val i = Intent()
        if (launcher.activity.isNotEmpty()) i.component = ComponentName(pkg, launcher.activity.replace("{pkg}", pkg)) else i.setPackage(pkg)
        if (launcher.action.isNotEmpty()) i.action = launcher.action
        launcher.categories.forEach { i.addCategory(it) }
        if (launcher.data.isNotEmpty()) i.data = Uri.parse(fill(launcher.data))
        for (e in launcher.extras) {
            val v = fill(e.value)
            when (e.type) {
                "uri" -> i.putExtra(e.key, Uri.parse(v))
                "bool" -> i.putExtra(e.key, v.toBoolean())
                "int" -> i.putExtra(e.key, v.toIntOrNull() ?: 0)
                else -> i.putExtra(e.key, v)
            }
        }
        if (contentUri != null) {
            i.clipData = ClipData.newRawUri("", contentUri)
            if (launcher.data.contains("{rom_uri}")) i.setDataAndType(contentUri, "application/octet-stream")
        }
        var flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        for (f in launcher.flags) {
            flags = flags or when (f) {
                "clear_top" -> Intent.FLAG_ACTIVITY_CLEAR_TOP
                "clear_task" -> Intent.FLAG_ACTIVITY_CLEAR_TASK
                "no_history" -> Intent.FLAG_ACTIVITY_NO_HISTORY
                else -> 0
            }
        }
        i.addFlags(flags)
        return try {
            ctx.startActivity(i)
            null
        } catch (e: Exception) {
            "Couldn't start ${launcher.name}: ${e.message}"
        }
    }

    fun openWith(ctx: Context, path: String?, uri: String?): String? {
        val data: Uri = try {
            uri?.let { Uri.parse(it) }
                ?: path?.let { FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(it)) }
                ?: return "This game's file location is unknown."
        } catch (e: Exception) {
            return "Couldn't share this file: ${e.message}"
        }
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(data, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return try {
            ctx.startActivity(Intent.createChooser(view, "Open with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            null
        } catch (_: ActivityNotFoundException) {
            "No app on this device can open this game."
        } catch (e: Exception) {
            "Couldn't start the game: ${e.message}"
        }
    }
}
