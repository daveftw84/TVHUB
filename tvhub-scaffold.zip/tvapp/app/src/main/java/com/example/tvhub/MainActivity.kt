package com.example.tvhub

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)
        Opt.init(this)
        Profiles.load(this)
        if (intent?.getBooleanExtra("profile_chosen", false) == true) Profiles.chosen = true
        Downloads.load(this)
        MusicPlayer.init(this)
        Buttons.load(this)
        // Receive casts (TV Hub on phones, and DLNA apps) and host game rooms, on the local network.
        if (getSharedPreferences("tvhub", MODE_PRIVATE).getBoolean("cast_receive", true)) CastHub.start(this)
        Vpn.autoStart(this)
        setContent { App() }
    }

    override fun onResume() {
        super.onResume()
        CastHub.activity = java.lang.ref.WeakReference(this)
    }

    // Button Mapper: remote buttons mapped to actions.
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean =
        Buttons.onRemoteKey(event) || super.dispatchKeyEvent(event)

    // Pressing Home while Live TV or a Plex video plays shrinks it to picture-in-picture.
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Pip.canEnter() && AppPrefs(this).autoPip) Pip.enter(this)
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        Pip.active = isInPictureInPictureMode
    }
}
