package com.example.tvhub

import android.content.Context
import android.os.Build
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Emulator cores for the built-in player. They're the prebuilt libretro cores published for Lemuroid
 * (github.com/Swordfish90/LemuroidCores), downloaded the first time a console is played.
 */
object BuiltinCores {
    private const val VERSION = "1.17.0"

    fun libName(core: String) = "lib${core}_libretro_android.so"

    fun coresDir(ctx: Context) = File(ctx.filesDir, "cores/$VERSION")
    fun systemDir(ctx: Context) = File(ctx.filesDir, "system").apply { mkdirs() }

    /** Where games for the built-in player are kept (the app's own storage). */
    fun gamesRoot(ctx: Context): File = ctx.getExternalFilesDir("games") ?: File(ctx.filesDir, "games")

    /** Returns the core's file, downloading it first if needed. */
    fun ensureCore(ctx: Context, core: String): String {
        val dir = coresDir(ctx).apply { mkdirs() }
        val f = File(dir, libName(core))
        if (f.exists() && f.length() > 0) return f.absolutePath
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        val url = "https://github.com/Swordfish90/LemuroidCores/raw/$VERSION/lemuroid_core_$core/src/main/jniLibs/$abi/${libName(core)}"
        download(url, null, f)
        return f.absolutePath
    }

    /** Copies the console's BIOS/firmware files from RomM into the system folder (and arcade BIOS zips next to the game). */
    fun ensureFirmware(ctx: Context, base: String, token: String, platformId: Int, gameDir: File?): List<File> {
        val files = ArrayList<File>()
        val text = httpGet("${base.trimEnd('/')}/api/firmware?platform_id=$platformId", token)
        val a = JSONArray(text)
        val system = systemDir(ctx)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val name = o.optString("file_name")
            if (name.isEmpty() || name.contains('/') || name.contains("..")) continue
            val dest = File(system, name)
            if (!dest.exists()) {
                val url = "${base.trimEnd('/')}/api/firmware/${o.getInt("id")}/content/" +
                    URLEncoder.encode(name, "UTF-8").replace("+", "%20")
                download(url, token, dest)
            }
            files += dest
            // Arcade cores look for BIOS zips (e.g. neogeo.zip) beside the game too.
            if (gameDir != null && name.endsWith(".zip", ignoreCase = true)) {
                val beside = File(gameDir, name)
                if (!beside.exists()) dest.copyTo(beside, overwrite = false)
            }
        }
        return files
    }

    private fun httpGet(url: String, token: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun download(url: String, token: String?, dest: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "TVHub/1.8")
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode} for ${dest.name}")
        val tmp = File(dest.parentFile, dest.name + ".part")
        try {
            c.inputStream.use { input -> FileOutputStream(tmp).use { input.copyTo(it, 64 * 1024) } }
            dest.delete()
            if (!tmp.renameTo(dest)) throw IOException("Couldn't save ${dest.name}")
        } catch (t: Throwable) {
            tmp.delete()
            throw t
        }
    }
}
