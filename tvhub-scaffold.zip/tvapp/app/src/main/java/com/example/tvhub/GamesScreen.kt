package com.example.tvhub

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.compose.AsyncImage

private fun fmtSize(bytes: Long): String? = when {
    bytes <= 0 -> null
    bytes >= 1L shl 30 -> "%.1f GB".format(bytes / (1L shl 30).toDouble())
    bytes >= 1L shl 20 -> "%.0f MB".format(bytes / (1L shl 20).toDouble())
    else -> "%.0f KB".format(bytes / 1024.0)
}

private val consoleColors = listOf(
    0xFF2E7D9A, 0xFF3B7A57, 0xFF9C3B5B, 0xFF8A5A2B,
    0xFF5B4B9A, 0xFF2F6F6A, 0xFF9A7B2E, 0xFF6A3B7A,
)

private fun colorFor(key: String) = Color(consoleColors[(key.hashCode() and 0x7fffffff) % consoleColors.size])

@Composable
fun GamesScreen(vm: GamesViewModel) {
    val ctx = LocalContext.current
    var selected by remember { mutableStateOf<Game?>(null) }
    var pending by remember { mutableStateOf<Pair<Game, Boolean>?>(null) }

    // Android 9 and older need permission to save into Downloads.
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val p = pending
        pending = null
        if (granted && p != null) vm.playOrDownload(p.first, p.second)
        else if (!granted) vm.showNotice("Storage permission is needed to save games.")
    }

    fun go(g: Game, play: Boolean) {
        val needsPermission = vm.downloadedCopy(g) == null && Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            pending = g to play
            permission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            vm.playOrDownload(g, play)
        }
    }

    BackHandler(enabled = vm.list != null && vm.tab != GamesTab.RECENT && vm.tab != GamesTab.FAVORITES) { vm.closeConsole() }

    // When the player closes the emulator and comes back, tell RomM how long they played.
    val lifecycle = androidx.compose.ui.platform.LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) vm.onResumed() }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    Column(Modifier.fillMaxSize().padding(top = 8.dp)) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            item {
                Text("Games", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(end = 8.dp))
            }
            items(GamesTab.values().toList()) { t ->
                FilterChip(
                    selected = vm.tab == t,
                    onClick = { vm.openTab(t) },
                    label = { Text(t.label) },
                    modifier = Modifier.focusRing(ButtonShape),
                )
            }
        }
        // Multiplayer: join a game running on a TV (as a controller from this phone).
        if (!rememberIsTv()) {
            var joining by remember { mutableStateOf(false) }
            TextButton(onClick = { joining = true }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("🎮 Join a game on a TV") }
            if (joining) JoinGameDialog(onDismiss = { joining = false })
        }
        vm.notice?.let {
            Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        if (vm.pendingConflicts > 0 && vm.tab != GamesTab.MANAGE) {
            Text(
                "${vm.pendingConflicts} save conflict(s) found by background sync. Press Play on the game to choose which save to keep.",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp),
            )
        }
        when {
            !vm.rommConnected && vm.tab != GamesTab.MANAGE && vm.tab != GamesTab.DOWNLOADED && vm.tab != GamesTab.CLOUD -> NotConnected(vm)
            else -> when (vm.tab) {
                GamesTab.CONSOLES -> if (vm.list == null) ConsoleGrid(vm) else GameGridPage(vm, back = true) { selected = it }
                GamesTab.COLLECTIONS -> if (vm.list == null) CollectionGrid(vm) else GameGridPage(vm, back = true) { selected = it }
                GamesTab.RECENT, GamesTab.FAVORITES -> GameGridPage(vm, back = false) { selected = it }
                GamesTab.DOWNLOADED -> DownloadedTab(vm) { selected = it }
                GamesTab.CLOUD -> CloudGamingRow(Modifier.padding(16.dp))
                GamesTab.MANAGE -> SettingsTab(vm)
            }
        }
    }

    vm.conflict?.let { c ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Save conflict: ${c.title}") },
            text = {
                Text(
                    "The save on this device and the one on RomM both changed since they were last synced. " +
                        "Which one do you want to keep? The other is kept as a backup.\n\n${c.reason}",
                )
            },
            confirmButton = { TextButton(onClick = { vm.resolveConflict(keepRomm = true) }) { Text("Keep RomM's") } },
            dismissButton = { TextButton(onClick = { vm.resolveConflict(keepRomm = false) }) { Text("Keep this device's") } },
        )
    }

    LaunchedEffect(vm.randomPick) {
        vm.randomPick?.let {
            selected = it
            vm.clearRandom()
        }
    }

    vm.achievementsFor?.let { a -> AchievementsDialog(a) { vm.closeAchievements() } }

    // Background music on the Games screens (chosen in Settings).
    val music = vm.musicUri
    DisposableEffect(music) {
        val player = music?.let { u ->
            try {
                android.media.MediaPlayer().apply {
                    setDataSource(ctx, android.net.Uri.parse(u))
                    isLooping = true
                    setVolume(0.35f, 0.35f)
                    setOnPreparedListener { it.start() }
                    prepareAsync()
                }
            } catch (_: Exception) {
                null
            }
        }
        onDispose { try { player?.release() } catch (_: Exception) {} }
    }

    selected?.let { g -> GameDialog(vm, g, onClose = { selected = null }, onGo = { play -> go(g, play); selected = null }) }
}

@Composable
private fun NotConnected(vm: GamesViewModel) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Games come from your RomM server.", style = MaterialTheme.typography.titleMedium)
        Text(
            "RomM scans the games on your server and adds covers and game info, like Plex does for films. " +
                "Connect to it in Settings.",
        )
        Button(onClick = { vm.openTab(GamesTab.MANAGE) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Open Settings") }
    }
}

// ---------------------------------------------------------------- Consoles

@Composable
private fun ConsoleGrid(vm: GamesViewModel) {
    val tv = rememberIsTv()
    val consoles = vm.consoles
    if (consoles.isEmpty()) {
        Text(if (vm.platformsLoading) "Loading consoles…" else "No consoles with games on your RomM server yet.",
            modifier = Modifier.padding(16.dp))
        return
    }
    Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = { vm.pickRandom() }, modifier = Modifier.focusRing(ButtonShape)) { Text("🎲 Random game") }
        TextButton(onClick = { vm.openTopUnplayed() }, modifier = Modifier.focusRing(ButtonShape)) { Text("Top unplayed") }
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(if (tv) 200.dp else 160.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        itemsIndexed(consoles, key = { _, c -> c.id }) { _, c ->
            val shape = RoundedCornerShape(10.dp)
            val count = vm.platformOf(c)?.romCount ?: 0
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(if (tv) 110.dp else 100.dp)
                    .focusRing(shape, if (tv) 1.05f else 1f)
                    .clip(shape)
                    .background(colorFor(c.name))
                    .clickable { vm.openConsole(c) }
                    .padding(10.dp),
            ) {
                if (c.logo.isNotEmpty()) {
                    AsyncImage(
                        model = c.logo,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().padding(bottom = 28.dp),
                    )
                }
                Column(Modifier.align(Alignment.BottomStart)) {
                    Text(c.name, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleSmall)
                    Text("$count game" + if (count == 1) "" else "s", color = Color.White.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

private val FILTER_LABELS = linkedMapOf("genres" to "Genre", "player_counts" to "Players", "regions" to "Region")

@Composable
private fun GameGridPage(vm: GamesViewModel, back: Boolean, onGame: (Game) -> Unit) {
    val tv = rememberIsTv()
    val l = vm.list ?: return
    var picking by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (back) TextButton(onClick = { vm.closeConsole() }, modifier = Modifier.focusRing(ButtonShape)) { Text("‹ Back") }
            Text(l.title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f).padding(start = 4.dp))
            if (vm.total > 0) Text("${vm.total} games", style = MaterialTheme.typography.bodySmall)
            l.console?.let { c ->
                TextButton(onClick = { vm.pickRandom(c) }, modifier = Modifier.focusRing(ButtonShape)) { Text("🎲") }
            }
        }
        l.console?.description?.takeIf { it.isNotEmpty() }?.let {
            Text(it, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp))
        }
        OutlinedTextField(
            value = vm.query,
            onValueChange = { vm.updateQuery(it) },
            label = { Text("Search ${l.title}") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        )
        if (l.filterable) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(GameSort.values().toList()) { s ->
                    FilterChip(
                        selected = vm.sort == s && vm.query.isBlank(),
                        onClick = { vm.setSortOrder(s) },
                        label = { Text(s.label) },
                        modifier = Modifier.focusRing(ButtonShape),
                    )
                }
                items(FILTER_LABELS.keys.filter { vm.filterValues.containsKey(it) }.toList()) { key ->
                    val chosen = vm.filters[key]
                    FilterChip(
                        selected = chosen != null,
                        onClick = { picking = key },
                        label = { Text(if (chosen != null) "${FILTER_LABELS[key]}: $chosen" else "${FILTER_LABELS[key]} ▾") },
                        modifier = Modifier.focusRing(ButtonShape),
                    )
                }
            }
        }
        if (vm.loading && vm.results.isEmpty()) Text("Loading…", modifier = Modifier.padding(16.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(if (tv) 130.dp else 110.dp),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            itemsIndexed(vm.results, key = { _, g -> g.key }) { index, g ->
                // Fetch the next page when the last card appears.
                if (index == vm.results.size - 1 && vm.results.size < vm.total) {
                    LaunchedEffect(vm.results.size) { vm.loadMore() }
                }
                GameCard(vm, g) { onGame(g) }
            }
            if (vm.loading && vm.results.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text("Loading more…", modifier = Modifier.padding(8.dp))
                }
            }
        }
    }

    picking?.let { key ->
        AlertDialog(
            onDismissRequest = { picking = null },
            title = { Text(FILTER_LABELS[key] ?: key) },
            text = {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    item { ListRow(title = "Any", onClick = { vm.setFilter(key, null); picking = null }) }
                    items(vm.filterValues[key].orEmpty()) { v ->
                        ListRow(
                            title = v,
                            selected = vm.filters[key] == v,
                            onClick = { vm.setFilter(key, v); picking = null },
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { picking = null }) { Text("Close") } },
        )
    }
}

@Composable
private fun CollectionGrid(vm: GamesViewModel) {
    val tv = rememberIsTv()
    val cols = vm.collections
    if (cols.isEmpty()) {
        Text("No collections yet. Make them in RomM's web page and they appear here.", modifier = Modifier.padding(16.dp))
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(if (tv) 200.dp else 160.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        itemsIndexed(cols, key = { _, c -> (if (c.smart) "s" else "c") + c.id }) { _, c ->
            val shape = RoundedCornerShape(10.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(if (tv) 110.dp else 100.dp)
                    .focusRing(shape, if (tv) 1.05f else 1f)
                    .clip(shape)
                    .background(colorFor(c.name))
                    .clickable { vm.openCollection(c) },
            ) {
                if (c.cover != null) {
                    AsyncImage(model = c.cover, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))
                }
                Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
                    Text((if (c.favorite) "★ " else "") + c.name, color = Color.White, maxLines = 2,
                        overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                    Text((if (c.smart) "Smart collection · " else "") + "${c.count} games",
                        color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun GameCard(vm: GamesViewModel, g: Game, onClick: () -> Unit) {
    val tv = rememberIsTv()
    val view = androidx.compose.ui.platform.LocalView.current
    val shape = RoundedCornerShape(6.dp)
    val pct = vm.progress[g.key]
    Column(
        Modifier
            .fillMaxWidth()
            .focusRing(shape, if (tv) 1.08f else 1f)
            .clip(shape)
            .clickable {
                if (vm.uiSounds) view.playSoundEffect(android.view.SoundEffectConstants.CLICK)
                onClick()
            }
            .padding(2.dp),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.72f)
                .clip(shape)
                .background(colorFor(g.console).copy(alpha = 0.45f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(g.title, textAlign = TextAlign.Center, maxLines = 4, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(6.dp))
            if (g.art != null) {
                AsyncImage(
                    model = g.art,
                    contentDescription = g.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            val badge = when {
                pct != null -> "${(pct * 100).toInt()}%"
                vm.downloadedCopy(g) != null -> "✓"
                else -> null
            }
            if (badge != null) {
                Text(
                    badge,
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 1.dp),
                )
            }
        }
        Text(g.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun GameDialog(vm: GamesViewModel, g: Game, onClose: () -> Unit, onGo: (play: Boolean) -> Unit) {
    val ctx = LocalContext.current
    var sub by remember { mutableStateOf<String?>(null) }
    when (sub) {
        "rate" -> PickDialog(
            "Your rating",
            listOf("Clear rating" to 0) + (10 downTo 1).map { "$it / 10" to it },
            onPick = { vm.rate(g, it); sub = null },
            onClose = { sub = null },
        )
        "status" -> PickDialog(
            "Play status",
            listOf<Pair<String, String?>>("None" to null) + STATUS_LABELS.entries.map { it.value to it.key },
            onPick = { vm.setStatus(g, it); sub = null },
            onClose = { sub = null },
        )
        "saves" -> SavesDialog(vm, g) { sub = null }
    }
    val c = vm.consoleById(g.console)
    val have = vm.downloadedCopy(g)
    fun open(url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            vm.showNotice("No app on this device can open that.")
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(g.title) },
        text = {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (g.art != null) {
                    AsyncImage(
                        model = g.art,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.width(110.dp).heightIn(max = 160.dp),
                    )
                }
                Column {
                    listOfNotNull(
                        c?.name,
                        g.year?.let { "Year: $it" },
                        g.genre?.let { "Genre: $it" },
                        g.players?.let { "Players: $it" },
                        fmtSize(g.size)?.let { "Size: $it" },
                        c?.let { "Plays with: ${vm.launcherFor(it).name}" },
                        if (have != null) "On this device" else if (g.url != null) "Downloads first, then plays" else null,
                    ).forEach { Text(it, style = MaterialTheme.typography.bodyMedium) }
                    g.summary?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, maxLines = 8,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                    }
                    if (g.screenshots.isNotEmpty()) {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(top = 8.dp),
                        ) {
                            items(g.screenshots) { s ->
                                AsyncImage(model = s, contentDescription = null, contentScale = ContentScale.Crop,
                                    modifier = Modifier.width(140.dp).height(100.dp).clip(RoundedCornerShape(4.dp)))
                            }
                        }
                    }
                    Row(Modifier.padding(top = 8.dp)) {
                        if (vm.idOf(g) != 0) {
                            TextButton(onClick = { vm.toggleFavorite(g) }) {
                                Text(if (vm.isFavorite(g)) "★ Favorite" else "☆ Favorite")
                            }
                        }
                        g.manual?.let { m -> TextButton(onClick = { open(m) }) { Text("Manual") } }
                        g.playInBrowser?.let { u -> TextButton(onClick = { open(u) }) { Text("Play in browser") } }
                    }
                    if (vm.idOf(g) != 0) {
                        Row {
                            TextButton(onClick = { sub = "rate" }) {
                                Text(if (g.myRating > 0) "Rated ${g.myRating}/10" else "Rate")
                            }
                            TextButton(onClick = { sub = "status" }) {
                                Text(STATUS_LABELS[g.status] ?: "Status")
                            }
                            TextButton(onClick = { sub = "saves"; vm.loadHistory(g) }) {
                                Text(if (vm.isPinned(g)) "Saves (restored)" else "Saves")
                            }
                            TextButton(onClick = { vm.hide(g); onClose() }) { Text("Hide") }
                        }
                        Row {
                            if (g.raId != 0) TextButton(onClick = { vm.openAchievements(g) }) { Text("🏆 Achievements") }
                            g.trailer?.let { id -> TextButton(onClick = { open("https://www.youtube.com/watch?v=$id") }) { Text("▶ Trailer") } }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row {
                if (have == null && g.url != null) TextButton(onClick = { onGo(false) }) { Text("Download") }
                // Multiplayer: starts the game with a room open, so friends can join by code.
                TextButton(onClick = { vm.openRoomNext = true; onGo(true) }) { Text("Play with friends") }
                TextButton(onClick = { onGo(true) }) { Text("Play") }
            }
        },
        dismissButton = {
            Row {
                // On a phone: send the game to the TV, and use the phone as its controller.
                if (!rememberIsTv() && g.rommId != 0) {
                    var castTv by remember { mutableStateOf<CastSend.Tv?>(null) }
                    var asking by remember { mutableStateOf(false) }
                    TextButton(onClick = { asking = true }) { Text("📺 Cast") }
                    if (asking) CastDialog(CastRequest("game", title = g.title, rommId = g.rommId), onDismiss = { asking = false }) { tv ->
                        castTv = tv.copy(room = null)
                    }
                    castTv?.let { tv ->
                        // The TV opens a room for the cast game; join it as the controller.
                        // The game may need downloading first: check every few seconds (up to 3 minutes).
                        LaunchedEffect(tv.base) {
                            repeat(60) {
                                kotlinx.coroutines.delay(3000)
                                val fresh = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                    CastSend.connect(ctx2(vm), tv.base.removePrefix("http://"))
                                }
                                if (fresh?.room != null) { castTv = fresh; return@LaunchedEffect }
                            }
                        }
                        if (tv.room != null) JoinGameDialog(onDismiss = { castTv = null }, presetTv = tv)
                        else Text("Starting on the TV…", style = MaterialTheme.typography.labelSmall)
                    }
                }
                if (have != null) TextButton(onClick = { vm.deleteDownload(have); onClose() }) { Text("Delete") }
                TextButton(onClick = onClose) { Text("Close") }
            }
        },
    )
}

// ---------------------------------------------------------------- Downloaded

@Composable
private fun DownloadedTab(vm: GamesViewModel, onGame: (Game) -> Unit) {
    if (vm.downloads.isEmpty()) {
        Text("Nothing downloaded yet.", modifier = Modifier.padding(16.dp))
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(8.dp)) {
        items(vm.downloads, key = { it.sourceKey }) { d ->
            ListRow(
                title = d.title,
                subtitle = vm.consoleById(d.console)?.name ?: "",
                onClick = { onGame(Game(d.title, d.console, d.sourceKey, path = d.path, uri = d.uri)) },
            )
        }
    }
}

// ---------------------------------------------------------------- Settings

@Composable
private fun SettingsTab(vm: GamesViewModel) {
    var rommUrl by remember { mutableStateOf(vm.rommUrl) }
    var rommCode by remember { mutableStateOf("") }
    var url by remember { mutableStateOf(vm.dataUrl) }
    var editing by remember { mutableStateOf<Console?>(null) }
    @Suppress("UNUSED_VARIABLE") val version = vm.choiceVersion   // redraw when a launcher changes
    val ctx = LocalContext.current
    var pickingFor by remember { mutableStateOf<String?>(null) }
    @Suppress("UNUSED_VARIABLE") val foldersVersion = vm.saveFoldersVersion
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        val id = pickingFor
        if (uri != null && id != null) vm.setSaveFolder(id, uri)
        pickingFor = null
    }
    var storageAccess by remember { mutableStateOf(vm.hasStorageAccess()) }
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setMusic(uri)
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // --- RomM ---
        item { Text("RomM server", style = MaterialTheme.typography.titleMedium) }
        if (vm.rommConnected) {
            item {
                Text("Connected to ${vm.rommUrl} · ${vm.rommPlatforms.size} consoles, " +
                    "${vm.rommPlatforms.sumOf { it.romCount }} games.")
            }
            item {
                FilterChip(
                    selected = vm.syncSaves,
                    onClick = { vm.updateSyncSaves(!vm.syncSaves) },
                    label = { Text(if (vm.syncSaves) "Sync saves with RomM: on" else "Sync saves with RomM: off") },
                    modifier = Modifier.focusRing(ButtonShape),
                )
            }
            item {
                Text(
                    "Uses RomM's device sync, like Grout and Argosy: before and after each game RomM decides " +
                        "whether to upload or download the save, and asks you when both changed. Save states from " +
                        "the built-in player are backed up too.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.syncAllNow() }, modifier = Modifier.focusRing(ButtonShape)) { Text("Sync saves now") }
                    if (vm.pendingConflicts > 0) Text("${vm.pendingConflicts} conflict(s) waiting", color = MaterialTheme.colorScheme.error)
                }
            }
            item {
                Text(
                    "Saves also sync in the background every 15 minutes. Conflicts found then are left for you: " +
                        "press Play on that game to choose which save to keep.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            item { Text("Emulator save folders", style = MaterialTheme.typography.titleSmall) }
            item {
                Text(
                    "To sync games played in emulator apps, the app needs to reach their save folders. Either allow " +
                        "access to all files (the usual folders are then found automatically), or pick each folder. " +
                        "RetroArch: set Settings > Directory > Save Files to a shared folder such as /RetroArch/saves.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (!storageAccess && android.os.Build.VERSION.SDK_INT >= 30) {
                item {
                    Button(
                        onClick = {
                            val i = android.content.Intent(
                                android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                android.net.Uri.parse("package:${ctx.packageName}"),
                            )
                            try {
                                ctx.startActivity(i)
                            } catch (_: Exception) {
                                try {
                                    ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                                } catch (_: Exception) {
                                    vm.showNotice("This device has no all-files setting. Pick each save folder instead.")
                                }
                            }
                        },
                        modifier = Modifier.focusRing(ButtonShape),
                    ) { Text("Allow access to all files") }
                }
                item {
                    TextButton(onClick = { storageAccess = vm.hasStorageAccess() }, modifier = Modifier.focusRing(ButtonShape)) {
                        Text("I've allowed it — check again")
                    }
                }
            }
            items(vm.catalog.saveProfiles, key = { "sp_" + it.launcher }) { sp ->
                val picked = vm.saveFolder(sp.launcher)
                ListRow(
                    title = sp.name,
                    subtitle = when {
                        picked != null -> "Folder chosen · press to change"
                        storageAccess -> "Looks in /${sp.paths.joinToString(", /")} · press to pick another folder"
                        else -> "Not set up · press to pick its save folder"
                    },
                    onClick = {
                        pickingFor = sp.launcher
                        folderPicker.launch(null)
                    },
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.loadRommPlatforms() }, modifier = Modifier.focusRing(ButtonShape)) { Text("Refresh") }
                    TextButton(onClick = { vm.disconnectRomm() }, modifier = Modifier.focusRing(ButtonShape)) { Text("Disconnect") }
                }
            }
        } else {
            item {
                Text(
                    "In RomM's web page, open Client API Tokens and create a token. Give it the read permissions " +
                        "(including firmware.read for BIOS files), plus assets.write (save sync), roms.user.write " +
                        "(play time), collections.write (favorites) and devices.write (save sync). Choose Pair and type the 8-digit code here within 5 minutes.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            item {
                OutlinedTextField(value = rommUrl, onValueChange = { rommUrl = it },
                    label = { Text("RomM address, e.g. http://192.168.1.50:8080") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item {
                OutlinedTextField(value = rommCode, onValueChange = { rommCode = it },
                    label = { Text("Pairing code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item {
                Button(onClick = { vm.connectRomm(rommUrl, rommCode) }, enabled = !vm.rommBusy,
                    modifier = Modifier.focusRing(ButtonShape)) {
                    Text(if (vm.rommBusy) "Connecting…" else "Connect")
                }
            }
        }

        // --- launchers ---
        if (vm.consoles.isNotEmpty()) {
            item { Text("Emulators", style = MaterialTheme.typography.titleMedium) }
            items(vm.consoles, key = { it.id }) { c ->
                val l = vm.launcherFor(c)
                val core = vm.coreFor(c)
                ListRow(
                    title = c.name,
                    subtitle = l.name + (if (!vm.isInstalled(l)) " (not installed)" else "") +
                        (if (l.id == "retroarch" && core.isNotEmpty()) " · $core" else "") +
                        (if (l.id == "builtin") " · ${vm.builtinCoreFor(c).ifEmpty { "no core" }}" else ""),
                    onClick = { editing = c },
                )
            }
        }

        // --- look and sound ---
        item { Text("Music and sounds", style = MaterialTheme.typography.titleMedium) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { musicPicker.launch(arrayOf("audio/*")) }, modifier = Modifier.focusRing(ButtonShape)) {
                    Text(if (vm.musicUri == null) "Choose background music" else "Change background music")
                }
                if (vm.musicUri != null) {
                    TextButton(onClick = { vm.setMusic(null) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Turn music off") }
                }
            }
        }
        item {
            FilterChip(
                selected = vm.uiSounds,
                onClick = { vm.updateUiSounds(!vm.uiSounds) },
                label = { Text(if (vm.uiSounds) "Click sounds: on" else "Click sounds: off") },
                modifier = Modifier.focusRing(ButtonShape),
            )
        }

        // --- data folder ---
        item { Text("Data folder", style = MaterialTheme.typography.titleMedium) }
        item {
            Text(
                (if (vm.usingServerData) "Using files from your server. " else "Using the files built into the app. ") +
                    "consoles.json sets each console's emulator, RetroArch core and unzip rule; launchers.json says " +
                    "how each emulator starts. To update them without rebuilding, put them in a folder on your " +
                    "server and enter its address.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item {
            OutlinedTextField(value = url, onValueChange = { url = it },
                label = { Text("Data folder URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.updateData(url) }, enabled = !vm.updating, modifier = Modifier.focusRing(ButtonShape)) {
                    Text(if (vm.updating) "Updating…" else "Update from server")
                }
                TextButton(onClick = { vm.useBuiltIn() }, modifier = Modifier.focusRing(ButtonShape)) { Text("Use built-in data") }
            }
        }
    }

    editing?.let { c -> LauncherDialog(vm, c) { editing = null } }
}

@Composable
private fun LauncherDialog(vm: GamesViewModel, c: Console, onClose: () -> Unit) {
    var core by remember(c.id) { mutableStateOf(vm.coreFor(c)) }
    var builtinCore by remember(c.id) { mutableStateOf(vm.builtinCoreFor(c)) }
    val current = vm.launcherFor(c)
    val launchers = vm.catalog.launchers.sortedWith(compareBy({ !vm.isInstalled(it) }, { it.name.lowercase() }))
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Emulator for ${c.name}") },
        text = {
            Column {
                if (current.id == "builtin") {
                    OutlinedTextField(
                        value = builtinCore,
                        onValueChange = { builtinCore = it; vm.setBuiltinCore(c, it) },
                        label = { Text("Built-in core (e.g. snes9x, fbneo, mame2003_plus)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    OutlinedTextField(
                        value = core,
                        onValueChange = { core = it; vm.setCore(c, it) },
                        label = { Text("RetroArch core") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(launchers) { l ->
                        ListRow(
                            title = (if (l.id == current.id) "● " else "") + l.name,
                            subtitle = if (vm.isInstalled(l)) "Installed" else "Not installed",
                            selected = l.id == current.id,
                            onClick = {
                                vm.setLauncher(c, l)
                                onClose()
                            },
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } },
    )
}

private val STATUS_LABELS = linkedMapOf<String?, String>(
    "incomplete" to "Playing / unfinished",
    "finished" to "Finished",
    "completed_100" to "100% complete",
    "retired" to "Retired",
    "never_playing" to "Never playing",
)

@Composable
private fun <T> PickDialog(title: String, options: List<Pair<String, T>>, onPick: (T) -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(options) { (label, value) -> ListRow(title = label, onClick = { onPick(value) }) }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } },
    )
}

/** RomM's save history for a game; restoring one pins it until the next play session is synced. */
@Composable
private fun SavesDialog(vm: GamesViewModel, g: Game, onClose: () -> Unit) {
    val list = vm.history
    AlertDialog(
        onDismissRequest = { vm.closeHistory(); onClose() },
        title = { Text("Saves on RomM") },
        text = {
            when {
                list == null -> Text("Loading…")
                list.isEmpty() -> Text("No saves on RomM for this game yet.")
                else -> LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(list, key = { it.id }) { e ->
                        ListRow(
                            title = e.updatedAt.take(16).replace('T', ' ') + " UTC",
                            subtitle = listOf(e.slot.ifEmpty { "no slot" }, e.emulator, fmtSize(e.size) ?: "")
                                .filter { it.isNotEmpty() }.joinToString(" · ") + " · press to restore",
                            onClick = { vm.restore(g, e); onClose() },
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.closeHistory(); onClose() }) { Text("Close") } },
    )
}

@Composable
private fun AchievementsDialog(a: GamesViewModel.AchievementView, onClose: () -> Unit) {
    val list = a.game.achievements
    val earned = a.earned
    AlertDialog(
        onDismissRequest = onClose,
        title = {
            Text(
                "Achievements · ${a.game.title}" +
                    if (earned != null && list.isNotEmpty()) " (${list.count { it.raId in earned }}/${list.size})" else "",
            )
        },
        text = {
            when {
                earned == null -> Text("Loading…")
                list.isEmpty() -> Text("RomM has no RetroAchievements for this game.")
                else -> LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(list, key = { it.raId.toString() + "_" + it.title }) { x ->
                        val got = x.raId in earned
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            AsyncImage(
                                model = x.badge,
                                contentDescription = null,
                                modifier = Modifier.width(40.dp).height(40.dp).clip(RoundedCornerShape(4.dp))
                                    .background(Color.DarkGray.copy(alpha = if (got) 0f else 0.6f)),
                                alpha = if (got) 1f else 0.4f,
                            )
                            Column(Modifier.weight(1f)) {
                                Text((if (got) "✓ " else "") + x.title + " · ${x.points} pts", style = MaterialTheme.typography.bodyMedium)
                                Text(x.description, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } },
    )
}

private fun ctx2(vm: GamesViewModel): android.content.Context = vm.getApplication<android.app.Application>()
