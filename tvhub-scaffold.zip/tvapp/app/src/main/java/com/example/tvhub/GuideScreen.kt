package com.example.tvhub

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.Locale

private const val DP_PER_MIN = 5f
private const val SLOT_MIN = 30
private const val PAST_SLOTS = 12          // 6 hours back (catch-up)
private const val SLOTS = 28              // 6 hours back + 8 ahead
private val ROW_HEIGHT = 56.dp

@Composable
fun GuideScreen(vm: LiveViewModel, onCatchup: (Channel, Programme) -> Unit = { _, _ -> }, onPick: (Channel) -> Unit) {
    val channelCol = if (rememberIsWide()) 200.dp else 110.dp
    val now = remember { System.currentTimeMillis() }
    val slotMs = SLOT_MIN * 60_000L
    val windowStart = remember { now - now % slotMs - PAST_SLOTS * slotMs }
    val windowEnd = windowStart + SLOTS * slotMs
    val scroll = rememberScrollState()          // shared so the header and every row scroll together
    val density = androidx.compose.ui.platform.LocalDensity.current
    // Start at "now"; scroll left for earlier programmes (catch-up).
    androidx.compose.runtime.LaunchedEffect(Unit) {
        scroll.scrollTo(with(density) { msToDp(now - windowStart - 30 * 60_000L).coerceAtLeast(0.dp).roundToPx() })
    }
    val timeFmt = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    // What the info panel at the top shows: the focused programme (or channel without a guide).
    var focused by remember { mutableStateOf<Pair<Channel, Programme?>?>(null) }

    Column(Modifier.fillMaxSize().padding(start = 8.dp, top = 8.dp, end = 8.dp)) {
        // Groups, same as Live TV (All, Favorites, Sports, your groups).
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 6.dp)) {
            items(vm.groups.size) { i ->
                val g = vm.groups[i]
                GuideChip(g, vm.groupName == g) { vm.selectGroup(i) }
            }
        }
        InfoPanel(vm, focused, timeFmt)

        Row(Modifier.height(28.dp)) {
            Spacer(Modifier.width(channelCol))
            Row(Modifier.horizontalScroll(scroll)) {
                repeat(SLOTS) { s ->
                    Box(Modifier.width((SLOT_MIN * DP_PER_MIN).dp)) {
                        Text(timeFmt.format(windowStart + s * slotMs), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.visibleChannels) { ch ->
                val programmes = vm.programmesFor(ch)
                Row(Modifier.height(ROW_HEIGHT), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.width(channelCol).padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (ch.logo != null) {
                            AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
                                modifier = Modifier.size(36.dp))
                            Spacer(Modifier.width(6.dp))
                        }
                        Text((if (ch.key in vm.favorites) "★ " else "") + ch.name, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall)
                    }

                    Row(Modifier.horizontalScroll(scroll).fillMaxHeight()) {
                        var cursor = windowStart
                        for (p in programmes) {
                            val s = maxOf(p.start, cursor)
                            val e = minOf(p.end, windowEnd)
                            if (e <= s) continue
                            if (s > cursor) Spacer(Modifier.width(msToDp(s - cursor)))
                            val past = p.end <= now
                            val archived = past && Catchup.providerHas(ch, p, Opt.str(Opt.CATCHUP, "auto"))
                            GuideCell((if (archived) "↺ " else "") + p.title, msToDp(e - s), live = p.start <= now && p.end > now,
                                sport = Sports.isSportsProgramme(p),
                                onFocus = { focused = ch to p }) { if (past) onCatchup(ch, p) else onPick(ch) }
                            cursor = e
                        }
                        if (cursor < windowEnd) {
                            // No guide data: show the channel's name so the row is still useful.
                            val label = if (programmes.isEmpty()) ch.name else ""
                            GuideCell(label, msToDp(windowEnd - cursor), live = false, sport = false,
                                onFocus = { focused = ch to null }) { onPick(ch) }
                        }
                    }
                }
            }
        }
    }
}

/** The focused programme: artwork (from the guide, or Trakt), title, time and description. */
@Composable
private fun InfoPanel(vm: LiveViewModel, focused: Pair<Channel, Programme?>?, timeFmt: SimpleDateFormat) {
    val (ch, p) = focused ?: return
    Row(Modifier.fillMaxWidth().height(110.dp).padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        val art = p?.let { vm.artworkFor(it) } ?: ch.logo
        Box(Modifier.size(width = 73.dp, height = 110.dp).clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)) {
            if (art != null) {
                AsyncImage(model = art, contentDescription = null,
                    contentScale = if (art == ch.logo) ContentScale.Fit else ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
        }
        Column(Modifier.weight(1f)) {
            Text(p?.title ?: ch.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val detail = listOfNotNull(
                p?.let { "${timeFmt.format(it.start)} – ${timeFmt.format(it.end)}" },
                ch.name.takeIf { p != null },
                p?.takeIf { it.season > 0 }?.let { "S${it.season} E${it.episode}" },
                p?.subTitle?.takeIf { it.isNotEmpty() },
            ).joinToString(" · ")
            if (detail.isNotEmpty()) {
                Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(p?.desc?.ifEmpty { null } ?: if (p == null) "No guide information for this channel." else "",
                style = MaterialTheme.typography.bodySmall, maxLines = 4, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun GuideChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        label,
        style = MaterialTheme.typography.labelLarge,
        modifier = Modifier.focusRing(shape).clip(shape)
            .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp),
    )
}

@Composable
private fun GuideCell(text: String, width: Dp, live: Boolean, sport: Boolean, onFocus: () -> Unit, onClick: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    val bg = when {
        sport -> Color(0xFF1E3A2A)
        live -> MaterialTheme.colorScheme.secondaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    Box(
        Modifier
            .width(width)
            .fillMaxHeight()
            .padding(end = 2.dp)
            .onFocusChanged { if (it.hasFocus) onFocus() }
            .focusRing(shape)
            .clip(shape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Text(text, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
    }
}

private fun msToDp(ms: Long): Dp = (ms / 60_000f * DP_PER_MIN).dp
