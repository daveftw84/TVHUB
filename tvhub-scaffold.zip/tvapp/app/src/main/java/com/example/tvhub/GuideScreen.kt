package com.example.tvhub

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.tv.material3.*
import java.text.SimpleDateFormat
import java.util.Locale

private const val DP_PER_MIN = 5f
private const val SLOT_MIN = 30
private const val SLOTS = 12              // 6 hours
private val CHANNEL_COL = 180.dp
private val ROW_HEIGHT = 56.dp

@Composable
fun GuideScreen(vm: LiveViewModel, onPick: (Channel) -> Unit) {
    val now = remember { System.currentTimeMillis() }
    val slotMs = SLOT_MIN * 60_000L
    val windowStart = remember { now - now % slotMs }
    val windowEnd = windowStart + SLOTS * slotMs
    val scroll = rememberScrollState()          // shared so the header and every row scroll together
    val timeFmt = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().padding(start = 72.dp, top = 16.dp, end = 16.dp)) {
        Row(Modifier.height(32.dp)) {
            Spacer(Modifier.width(CHANNEL_COL))
            Row(Modifier.horizontalScroll(scroll)) {
                repeat(SLOTS) { s ->
                    Box(Modifier.width((SLOT_MIN * DP_PER_MIN).dp)) {
                        Text(timeFmt.format(windowStart + s * slotMs))
                    }
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.visibleChannels) { ch ->
                val programmes = ch.tvgId?.let { vm.epg[it] }.orEmpty()
                Row(Modifier.height(ROW_HEIGHT), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.width(CHANNEL_COL).padding(end = 8.dp),
                    )

                    Row(Modifier.horizontalScroll(scroll).fillMaxHeight()) {
                        var cursor = windowStart
                        for (p in programmes) {
                            val s = maxOf(p.start, cursor)
                            val e = minOf(p.end, windowEnd)
                            if (e <= s) continue
                            if (s > cursor) Spacer(Modifier.width(msToDp(s - cursor)))
                            Surface(
                                onClick = { onPick(ch) },
                                modifier = Modifier.width(msToDp(e - s)).fillMaxHeight().padding(end = 2.dp),
                            ) {
                                Text(
                                    p.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(8.dp),
                                )
                            }
                            cursor = e
                        }
                        if (cursor < windowEnd) {
                            val label = if (programmes.isEmpty()) "No guide data" else ""
                            Surface(
                                onClick = { onPick(ch) },
                                modifier = Modifier.width(msToDp(windowEnd - cursor)).fillMaxHeight().padding(end = 2.dp),
                            ) { Text(label, modifier = Modifier.padding(8.dp)) }
                        }
                    }
                }
            }
        }
    }
}

private fun msToDp(ms: Long): Dp = (ms / 60_000f * DP_PER_MIN).dp
