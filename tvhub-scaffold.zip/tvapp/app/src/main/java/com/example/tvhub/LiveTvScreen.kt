package com.example.tvhub

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import coil.compose.AsyncImage
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView

@Composable
fun LiveTvScreen(vm: LiveViewModel) {
    val wide = rememberIsWide()
    val keys = Modifier
        .fillMaxSize()
        .onPreviewKeyEvent { e ->
            if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
            when (e.nativeKeyEvent.keyCode) {
                KeyEvent.KEYCODE_CHANNEL_UP -> { vm.next(); true }
                KeyEvent.KEYCODE_CHANNEL_DOWN -> { vm.previous(); true }
                KeyEvent.KEYCODE_LAST_CHANNEL -> { vm.playLast(); true }
                else -> false
            }
        }

    if (wide) {
        Row(keys) {
            ChannelList(vm, Modifier.width(320.dp).fillMaxHeight())
            Column(Modifier.weight(1f).fillMaxHeight()) {
                VideoArea(vm, Modifier.weight(1f).fillMaxWidth())
                NowPlayingBar(vm)
            }
        }
    } else {
        Column(keys) {
            VideoArea(vm, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
            NowPlayingBar(vm)
            ChannelList(vm, Modifier.weight(1f).fillMaxWidth())
        }
    }
}

@Composable
private fun VideoArea(vm: LiveViewModel, modifier: Modifier) {
    Box(modifier.background(Color.Black), contentAlignment = Alignment.Center) {
        // The main channel and up to 4 windows, in the chosen layout. Selecting a window's channel
        // swaps it with the main one.
        MultiView(onSelect = { vm.swapCorner(it) }) { m ->
            AndroidView(
                modifier = m,
                factory = { c -> PlayerView(c).apply { player = vm.player; useController = false }.applyOptions() },
            )
        }
        vm.error?.let { Text(it, modifier = Modifier.padding(16.dp)) }
        // The main channel goes quiet while a corner window has the sound.
        androidx.compose.runtime.LaunchedEffect(Corners.mainMuted) { vm.player.volume = if (Corners.mainMuted) 0f else 1f }
        if (Corners.picking) {
            Text("Pick a channel for a corner window", style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.align(Alignment.TopCenter).padding(12.dp).background(Color(0xCC000000)).padding(8.dp))
        }
    }
}

private enum class LivePanel(val label: String) { CHANNELS("Channels"), SPORTS("Sports"), SEARCH("Search"), MANAGE("Manage") }

@Composable
private fun ChannelList(vm: LiveViewModel, modifier: Modifier) {
    var panel by remember { mutableStateOf(LivePanel.CHANNELS) }
    if (panel != LivePanel.CHANNELS) androidx.activity.compose.BackHandler { panel = LivePanel.CHANNELS }
    Column(modifier.padding(horizontal = 8.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(vertical = 6.dp)) {
            items(LivePanel.values().size) { i ->
                val p = LivePanel.values()[i]
                LiveChip(p.label, panel == p) { panel = p; if (p == LivePanel.SPORTS) vm.loadSports() }
            }
        }
        when (panel) {
            LivePanel.CHANNELS -> ChannelsPanel(vm)
            LivePanel.SPORTS -> SportsPanel(vm)
            LivePanel.SEARCH -> LiveSearchPanel(vm)
            LivePanel.MANAGE -> ManagePanel(vm)
        }
    }
}

@Composable
private fun LiveChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(50)
    Text(
        label,
        style = MaterialTheme.typography.labelLarge,
        modifier = Modifier.focusRing(shape).clip(shape)
            .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp),
    )
}

@Composable
private fun ChannelsPanel(vm: LiveViewModel) {
    LazyColumn {
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 6.dp)) {
                items(vm.groups.size) { i -> LiveChip(vm.groups[i], vm.groupName == vm.groups[i]) { vm.selectGroup(i) } }
            }
            Text("Long-press a channel to favorite it", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 12.dp, bottom = 4.dp))
        }
        items(vm.visibleChannels) { ch ->
            val (now, _) = vm.nowNext(ch)
            ListRow(
                title = (if (ch.key in vm.favorites) "★ " else "") + ch.name,
                subtitle = now?.title ?: ch.group,
                selected = ch.url == vm.current?.url,
                onClick = { vm.choose(ch) },
                onLongClick = { vm.toggleFavorite(ch) },
            )
        }
    }
}

/** Live and upcoming sports, each with every channel in your lineup showing it. */
@Composable
private fun SportsPanel(vm: LiveViewModel) {
    val ctx = LocalContext.current
    val fmt = remember { java.text.SimpleDateFormat("EEE h:mm a", java.util.Locale.getDefault()) }
    var sport by remember { mutableStateOf("All") }
    val all = vm.sportsEvents
    val sports = listOf("All", "Your teams") + all.map { it.sport }.distinct().sorted()
    val shown = when (sport) {
        "All" -> all
        "Your teams" -> all.filter { Sports.isFavorite(it, vm.sportsFavorites) }
        else -> all.filter { it.sport == sport }
    }.sortedWith(compareBy({ !Sports.isFavorite(it, vm.sportsFavorites) }, { !it.live }, { it.start }))
    LazyColumn {
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 6.dp)) {
                items(sports.size) { i -> LiveChip(sports[i], sport == sports[i]) { sport = sports[i] } }
            }
            vm.sportsMessage?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp)) }
            if (all.isEmpty()) {
                Text("No sports found in your guide for the next day. For full listings with broadcasters, add a " +
                    "TheSportsDB key in Settings.", modifier = Modifier.padding(8.dp))
            }
        }
        items(shown) { e ->
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text((if (e.live) "● LIVE  " else fmt.format(java.util.Date(e.start)) + "  ") + e.title,
                    style = MaterialTheme.typography.bodyLarge, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 12.dp))
                Text(listOfNotNull(e.league, e.sport.takeIf { e.league == null }).joinToString(" · "),
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp))
                // Every channel you have that shows it.
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                    items(e.channels.size) { i ->
                        val ch = e.channels[i]
                        LiveChip("▶ " + ch.name, ch.url == vm.current?.url) { vm.choose(ch) }
                        LiveChip("⧉", Corners.slots.any { it.url == ch.url }) { Corners.addChannel(ctx, ch) }
                    }
                }
                if (e.channels.isEmpty() && e.otherChannels.isNotEmpty()) {
                    Text("On ${e.otherChannels.joinToString(", ")} (not in your channels)", style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 12.dp))
                }
            }
        }
    }
}

/** Searches channel names and the guide (now and later). */
@Composable
private fun LiveSearchPanel(vm: LiveViewModel) {
    val ctx = LocalContext.current
    val prefs = remember { AppPrefs(ctx) }
    var q by remember { mutableStateOf("") }
    var recents by remember { mutableStateOf(prefs.recentSearches("live")) }
    val fmt = remember { java.text.SimpleDateFormat("EEE h:mm a", java.util.Locale.getDefault()) }
    val (chans, progs) = remember(q, vm.channels, vm.epg) { vm.searchLive(q) }
    fun pick(ch: Channel) { prefs.addRecentSearch("live", q); recents = prefs.recentSearches("live"); vm.choose(ch) }
    LazyColumn {
        item {
            androidx.compose.material3.OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true,
                placeholder = { Text("Channels and programmes") }, modifier = Modifier.fillMaxWidth())
        }
        if (q.trim().length < 2 && recents.isNotEmpty()) item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(vertical = 6.dp)) {
                items(recents.size) { i -> LiveChip(recents[i], false) { q = recents[i] } }
                item { LiveChip("Clear", false) { prefs.clearRecentSearches("live"); recents = emptyList() } }
            }
        }
        items(chans) { ch ->
            ListRow(title = ch.name, subtitle = vm.nowNext(ch).first?.title ?: ch.group, onClick = { pick(ch) })
        }
        items(progs) { h ->
            val onNow = h.programme.start <= System.currentTimeMillis()
            ListRow(title = h.programme.title + (h.programme.subTitle.takeIf { it.isNotEmpty() }?.let { " · $it" } ?: ""),
                subtitle = (if (onNow) "On now" else fmt.format(java.util.Date(h.programme.start))) + " · " + h.channel.name,
                onClick = { pick(h.channel) })
        }
        if (q.trim().length >= 2 && chans.isEmpty() && progs.isEmpty()) item {
            Text("Nothing found.", modifier = Modifier.padding(12.dp))
        }
    }
}

/** Reorder and hide groups and channels; favorite channels. */
@Composable
fun ManagePanel(vm: LiveViewModel) {
    var group by remember { mutableStateOf<String?>(null) }
    val g = group
    LazyColumn {
        if (g == null) {
            item {
                Row(Modifier.padding(4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LiveChip("Reload guide", false) { vm.refreshGuide() }
                    LiveChip("Reset order and hidden", false) { vm.resetLineup() }
                }
                Text("Groups: open one to arrange its channels.", style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(8.dp))
            }
            items(vm.allGroups) { name ->
                val hidden = name in vm.hiddenGroups
                ManageRow(
                    title = name + if (hidden) "  (hidden)" else "",
                    onOpen = { group = name },
                    onUp = { vm.moveGroup(name, -1) },
                    onDown = { vm.moveGroup(name, 1) },
                    hideLabel = if (hidden) "Show" else "Hide",
                    onHide = { vm.toggleGroupHidden(name) },
                )
            }
        } else {
            item { LiveChip("‹ All groups", false) { group = null } }
            items(vm.groupChannels(g)) { ch ->
                val hidden = ch.key in vm.hiddenChannels
                ManageRow(
                    title = (if (ch.key in vm.favorites) "★ " else "") + ch.name + if (hidden) "  (hidden)" else "",
                    onOpen = { vm.toggleFavorite(ch) },
                    openLabel = if (ch.key in vm.favorites) "★" else "☆",
                    onUp = { vm.moveChannel(ch, -1) },
                    onDown = { vm.moveChannel(ch, 1) },
                    hideLabel = if (hidden) "Show" else "Hide",
                    onHide = { vm.toggleChannelHidden(ch) },
                )
            }
        }
    }
}

@Composable
private fun ManageRow(title: String, onOpen: () -> Unit, onUp: () -> Unit, onDown: () -> Unit, hideLabel: String, onHide: () -> Unit,
                      openLabel: String = "Open") {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 8.dp))
        LiveChip(openLabel, false, onOpen)
        LiveChip("▲", false, onUp)
        LiveChip("▼", false, onDown)
        LiveChip(hideLabel, false, onHide)
    }
}

@Composable
private fun NowPlayingBar(vm: LiveViewModel) {
    val ctx = LocalContext.current
    val cur = vm.current ?: return
    val (now, next) = vm.nowNext(cur)
    val recording = cur.url in Recorder.active
    // Recording copies the raw stream, which only works for plain TS URLs, not HLS playlists.
    val canRecord = !cur.url.substringBefore('?').endsWith(".m3u8")

    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
    val art = now?.let { vm.artworkFor(it) }
    if (art != null) {
        AsyncImage(model = art, contentDescription = null, contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            modifier = Modifier.size(width = 60.dp, height = 90.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(6.dp)))
    }
    Column(Modifier.weight(1f)) {
        Text(cur.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        now?.let { Text("Now: ${it.title}", maxLines = 1, overflow = TextOverflow.Ellipsis) }
        next?.let { Text("Next: ${it.title}", maxLines = 1, overflow = TextOverflow.Ellipsis) }

        Row(Modifier.padding(top = 8.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { vm.toggleFavorite(cur) },
                modifier = Modifier.focusRing(ButtonShape),
            ) { Text(if (cur.key in vm.favorites) "★ Favorite" else "☆ Favorite") }

            CastButton({ CastRequest("channel", url = cur.url, title = cur.name, channelKey = cur.key) })
            // Corner windows: up to 4 more channels (or Plex videos) over this one.
            CornerButtons(onRotate = { vm.rotateScreens() })
            val activity = ctx as? android.app.Activity
            if (activity != null && Pip.supported(activity)) {
                OutlinedButton(onClick = { Pip.enter(activity) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Float over apps") }
            }
            OutlinedButton(onClick = { vm.toggleMiniPlayer() }, modifier = Modifier.focusRing(ButtonShape)) {
                Text(if (vm.miniPlayer) "Mini player: on" else "Mini player: off")
            }

            Button(
                enabled = recording || canRecord,
                onClick = {
                    if (recording) {
                        Recorder.stop(ctx, cur.url)
                    } else {
                        // Record to the end of the current programme (+2 min), or 1 hour if unknown.
                        val end = now?.end ?: (System.currentTimeMillis() + LiveViewModel.HOUR)
                        Recorder.start(ctx, cur.url, cur.name, end + Opt.int(Opt.REC_END, 2) * 60_000L)
                    }
                },
                modifier = Modifier.focusRing(ButtonShape),
            ) {
                Text(
                    when {
                        recording -> "■ Stop recording"
                        canRecord -> "● Record"
                        else -> "Can't record HLS"
                    }
                )
            }
        }
    }
    }
}

/** Add a corner window, choose which picture has sound, change the size, close them. */
@Composable
fun CornerButtons(onRotate: (() -> Unit)? = { Corners.rotateWindows() }) {
    if (!Corners.full) {
        OutlinedButton(onClick = { Corners.picking = !Corners.picking }, modifier = Modifier.focusRing(ButtonShape)) {
            Text(if (Corners.picking) "Cancel" else "⧉ Add corner (${Corners.slots.size}/${Corners.MAX})")
        }
    }
    if (Corners.slots.isNotEmpty()) {
        val soundName = Corners.slots.firstOrNull { it.id == Corners.soundId }?.title ?: "main"
        OutlinedButton(onClick = { Corners.cycleSound() }, modifier = Modifier.focusRing(ButtonShape)) {
            Text("🔊 $soundName", maxLines = 1)
        }
        // Layout: corners, or split (2 pictures), half + two quarters (3), four squares (4).
        OutlinedButton(onClick = { Corners.cycleLayout() }, modifier = Modifier.focusRing(ButtonShape)) {
            Text("▦ ${Corners.layout.label}", maxLines = 1)
        }
        if (onRotate != null) {
            OutlinedButton(onClick = onRotate, modifier = Modifier.focusRing(ButtonShape)) { Text("⟳ Rotate") }
        }
        if (Corners.layout == Corners.Layout.CORNERS) {
            OutlinedButton(onClick = { Corners.toggleSize() }, modifier = Modifier.focusRing(ButtonShape)) {
                Text(if (Corners.large) "Smaller" else "Bigger")
            }
        }
        Corners.slots.forEach { s ->
            OutlinedButton(onClick = { Corners.close(s.id) }, modifier = Modifier.focusRing(ButtonShape)) {
                Text("✕ ${s.title}", maxLines = 1)
            }
        }
    }
}
