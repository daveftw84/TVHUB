package com.example.tvhub

import android.view.KeyEvent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import androidx.tv.material3.*

@Composable
fun LiveTvScreen(vm: LiveViewModel) {
    val ctx = LocalContext.current
    Row(
        Modifier
            .fillMaxSize()
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (e.nativeKeyEvent.keyCode) {
                    KeyEvent.KEYCODE_CHANNEL_UP -> { vm.next(); true }
                    KeyEvent.KEYCODE_CHANNEL_DOWN -> { vm.previous(); true }
                    KeyEvent.KEYCODE_LAST_CHANNEL -> { vm.playLast(); true }
                    else -> false
                }
            }
    ) {
        LazyColumn(Modifier.width(320.dp).fillMaxHeight().padding(start = 72.dp)) {
            item {
                ListItem(
                    selected = false,
                    onClick = { vm.cycleGroup() },
                    headlineContent = { Text("Group: ${vm.groupName}", maxLines = 1) },
                    supportingContent = { Text("OK: next group · hold OK on a channel: favorite", maxLines = 1) },
                )
            }
            items(vm.visibleChannels) { ch ->
                val (now, _) = vm.nowNext(ch)
                ListItem(
                    selected = ch.url == vm.current?.url,
                    onClick = { vm.play(ch) },
                    onLongClick = { vm.toggleFavorite(ch) },
                    headlineContent = { Text((if (ch.key in vm.favorites) "★ " else "") + ch.name, maxLines = 1) },
                    supportingContent = { Text(now?.title ?: ch.group, maxLines = 1) },
                )
            }
        }

        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c -> PlayerView(c).apply { player = vm.player; useController = false } },
            )
            vm.error?.let { Text(it) }

            val cur = vm.current
            if (cur != null) {
                val (now, next) = vm.nowNext(cur)
                if (now != null || next != null) {
                    Column(Modifier.align(Alignment.BottomStart).padding(24.dp)) {
                        Text(cur.name, style = MaterialTheme.typography.titleMedium)
                        now?.let { Text("Now: ${it.title}") }
                        next?.let { Text("Next: ${it.title}") }
                    }
                }

                val recording = cur.url in Recorder.active
                // Recording copies the raw stream, which only works for plain TS URLs, not HLS playlists.
                val canRecord = !cur.url.substringBefore('?').endsWith(".m3u8")
                Button(
                    enabled = recording || canRecord,
                    onClick = {
                        if (recording) {
                            Recorder.stop(ctx, cur.url)
                        } else {
                            // Record to the end of the current programme (+2 min), or 1 hour if unknown.
                            val end = now?.end ?: (System.currentTimeMillis() + LiveViewModel.HOUR)
                            Recorder.start(ctx, cur.url, cur.name, end + 120_000L)
                        }
                    },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp),
                ) {
                    Text(
                        when {
                            recording -> "■ Stop recording"
                            canRecord -> "● Record"
                            else -> "Can't record HLS streams"
                        }
                    )
                }
            }
        }
    }
}
