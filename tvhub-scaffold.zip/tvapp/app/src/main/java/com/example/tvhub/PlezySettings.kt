@file:OptIn(coil.annotation.ExperimentalCoilApi::class)

package com.example.tvhub

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** A row of segments (Play | Open Details), like Plezy's settings. */
@Composable
fun SegmentRow(title: String, key: String, def: String, options: List<Pair<String, String>>) {
    var v by remember { mutableStateOf(Opt.str(key, def)) }
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(Color(0xFF1E1E20))) {
            options.forEach { (id, label) ->
                val on = v == id
                Text(label, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, color = if (on) Color.Black else Color.White,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.weight(1f).focusRing(RoundedCornerShape(50)).clip(RoundedCornerShape(50))
                        .background(if (on) Color(0xFFEEEEEE) else Color.Transparent)
                        .clickable { v = id; Opt.set(key, id) }.padding(vertical = 12.dp))
            }
        }
    }
}

// ---------------------------------------------------------------- Appearance

@Composable
fun AppearanceSettings() {
    SettingsHeader("Display")
    SettingsCard {
        SegmentRow("Theme", "theme", "dark", listOf("dark" to "Dark", "oled" to "OLED (pure black)"))
    }
    SettingsHeader("Library & Cards")
    SettingsCard {
        SwitchRow("Show ratings on cards", "card_ratings", true, "IMDb, Rotten Tomatoes and TMDB scores on posters")
        SettingsDivider()
        SwitchRow("Show Watched Indicators", "show_watched", true, "A checkmark on watched movies, shows and episodes")
        SettingsDivider()
        SwitchRow("Show Unwatched Count", "show_unwatched", true, "Unwatched episode count on shows and seasons")
        SettingsDivider()
        SwitchRow("Hide Spoilers for Unwatched Episodes", "hide_spoilers", false, "Blur pictures and hide descriptions of episodes you haven't seen")
    }
    SettingsHeader("Home Screen")
    SettingsCard {
        SwitchRow("Show Hero Section", "show_hero", true, "The featured carousel at the top of Home")
        SettingsDivider()
        SegmentRow("Continue Watching Action", "continue_action", "play", listOf("play" to "Play", "details" to "Open Details"))
    }
    SettingsHeader("Live TV")
    SettingsCard {
        SwitchRow("Default to Favorite Channels", "live_favorites_default", false, "Open Live TV on your Favorites")
    }
}

// ---------------------------------------------------------------- Profiles (Plex Home)

@Composable
fun ProfilesPage(plex: PlexViewModel) {
    LaunchedEffect(plex.server) { plex.loadHomeUsers() }
    var pinFor by remember { mutableStateOf<PlexHomeUser?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    val ctx = LocalContext.current
    if (plex.server == null) { Text("Sign in to Plex on the Library tab first.", modifier = Modifier.padding(8.dp)); return }
    Text("Your Plex Home users. Each profile has its own watch history, Continue Watching, ratings and (for kids) restrictions.",
        color = Color(0xFFAAAAAA), modifier = Modifier.padding(8.dp))
    if (plex.homeUsers.isEmpty()) Text("No Plex Home users found (or Plex Home isn't set up on this account).", modifier = Modifier.padding(8.dp))
    SettingsCard {
        plex.homeUsers.forEachIndexed { i, u ->
            if (i > 0) SettingsDivider()
            val active = u.title == plex.activeProfile || (plex.activeProfile == null && u.admin)
            Row(Modifier.fillMaxWidth().focusRing().clickable {
                if (u.protected && !active) pinFor = u else if (!active) { busy = u.title; plex.switchProfile(u, null) { e -> busy = null; e?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() } } }
            }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).clip(RoundedCornerShape(50)).background(Color(0xFFE8A0A0)), contentAlignment = Alignment.Center) {
                    if (u.thumb != null) AsyncImage(model = u.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    else Text(u.title.take(1).uppercase(), style = MaterialTheme.typography.headlineSmall, color = Color.White)
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(u.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (active) Text("  ✔ Active", color = Color(0xFFAAAAAA))
                        if (busy == u.title) Text("  switching…", color = Color(0xFFAAAAAA))
                    }
                    Text(listOfNotNull("Admin".takeIf { u.admin }, "Kids / restricted".takeIf { u.restricted }, "🔒 PIN".takeIf { u.protected })
                        .joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA))
                }
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("Add or edit profiles (and their PINs) at plex.tv → Settings → Plex Home.", style = MaterialTheme.typography.bodySmall,
        color = Color(0xFFAAAAAA), modifier = Modifier.padding(8.dp))
    pinFor?.let { u ->
        var pin by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { pinFor = null },
            title = { Text("PIN for ${u.title}") },
            text = {
                Column {
                    OutlinedTextField(value = pin, onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pin = it }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(), label = { Text("4-digit PIN") },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                    err?.let { Text(it, color = Color(0xFFFF6B6B)) }
                }
            },
            confirmButton = {
                TextButton(enabled = pin.length == 4, onClick = {
                    plex.switchProfile(u, pin) { e -> if (e == null) pinFor = null else err = e }
                }) { Text("Switch") }
            },
            dismissButton = { TextButton(onClick = { pinFor = null }) { Text("Cancel") } },
        )
    }
}

// ---------------------------------------------------------------- Manage Libraries

@Composable
fun ManageLibrariesPage(plex: PlexViewModel) {
    if (plex.server == null) { Text("Sign in to Plex on the Library tab first.", modifier = Modifier.padding(8.dp)); return }
    var actions by remember { mutableStateOf<PlexLibrary?>(null) }
    Text("Reorder and hide libraries. Hidden ones leave the Library tab, Home and search.", color = Color(0xFFAAAAAA),
        modifier = Modifier.padding(8.dp))
    Opt.version   // redraw on changes
    SettingsCard {
        val libs = plex.orderedLibraries
        libs.forEachIndexed { i, l ->
            if (i > 0) SettingsDivider()
            val hidden = plex.libraryHidden(l)
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (l.type == "movie") "🎬" else if (l.type == "show") "📺" else if (l.type == "artist") "🎵" else "📁", modifier = Modifier.width(32.dp))
                Text(l.title, modifier = Modifier.weight(1f), color = if (hidden) Color(0xFF777777) else Color.White)
                TextButton(onClick = { plex.moveLibrary(l, -1) }, enabled = i > 0, modifier = Modifier.focusRing(ButtonShape)) { Text("▲") }
                TextButton(onClick = { plex.moveLibrary(l, 1) }, enabled = i < libs.lastIndex, modifier = Modifier.focusRing(ButtonShape)) { Text("▼") }
                TextButton(onClick = { plex.toggleLibraryHidden(l) }, modifier = Modifier.focusRing(ButtonShape)) { Text(if (hidden) "⊘" else "👁") }
                TextButton(onClick = { actions = l }, modifier = Modifier.focusRing(ButtonShape)) { Text("⋮") }
            }
        }
    }
    actions?.let { l ->
        ModalBottomSheet(onDismissRequest = { actions = null }) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text(l.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                listOf(Triple("⟳", "Scan Library Files", "scan"), Triple("📊", "Analyze", "analyze"),
                    Triple("♻", "Refresh Metadata", "refresh"), Triple("🗑", "Empty Trash", "trash")).forEach { (icon, label, a) ->
                    Row(Modifier.fillMaxWidth().focusRing().clickable { actions = null; plex.libraryAction(l, a) }.padding(horizontal = 24.dp, vertical = 14.dp)) {
                        Text(icon, modifier = Modifier.width(36.dp))
                        Text(label, color = if (a == "refresh" || a == "trash") Color(0xFFFF6B6B) else Color.White)
                    }
                }
                Text("Only the server's owner can run these.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA),
                    modifier = Modifier.padding(horizontal = 24.dp))
            }
        }
    }
    plex.notice?.let { Text(it, color = Color(0xFF7FA6FF), modifier = Modifier.padding(8.dp)) }
}

// ---------------------------------------------------------------- Services (Seerr, MDBList, ...)

@Composable
fun ServicesPage(onTrakt: () -> Unit) {
    val scope = rememberCoroutineScope()
    Text("Sync watch progress and request new titles.", modifier = Modifier.padding(8.dp))
    SettingsCard {
        ServiceRow("✔", "Trakt", if (TraktAccount.signedIn) "Connected" + (TraktAccount.username?.let { " as $it" } ?: "") else "Not connected", onTrakt)
    }
    SettingsHeader("Seerr (Overseerr / Jellyseerr)")
    SettingsCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Request movies and shows that aren't in your library yet: open a Trakt title on Home and press Request.",
                style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA))
            var url by remember { mutableStateOf(Opt.str("seerr_url", "")) }
            var key by remember { mutableStateOf(Opt.str("seerr_key", "")) }
            var status by remember { mutableStateOf<String?>(null) }
            OutlinedTextField(value = url, onValueChange = { url = it; Opt.set("seerr_url", it.trim()) }, singleLine = true,
                label = { Text("Server address, like https://requests.example.com") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = key, onValueChange = { key = it; Opt.set("seerr_key", it.trim()) }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), label = { Text("API key (Seerr > Settings > General)") },
                modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = {
                    status = "Checking…"
                    scope.launch { status = withContext(Dispatchers.IO) { runCatching { "Connected ✓ (version ${Seerr.test()})" }.getOrElse { "Couldn't connect: ${it.message}" } } }
                }, enabled = url.isNotBlank() && key.isNotBlank(), modifier = Modifier.focusRing(ButtonShape)) { Text("Test") }
                Spacer(Modifier.width(12.dp))
                status?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
    SettingsHeader("MDBList")
    SettingsCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("More ratings (IMDb, Rotten Tomatoes, Metacritic, Letterboxd) on title pages. Free key at mdblist.com → Preferences → API.",
                style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA))
            var key by remember { mutableStateOf(Opt.str("mdblist_key", "")) }
            OutlinedTextField(value = key, onValueChange = { key = it; Opt.set("mdblist_key", it.trim()) }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), label = { Text("MDBList API key") }, modifier = Modifier.fillMaxWidth())
        }
    }
    SettingsHeader("Not available yet")
    SettingsCard {
        ServiceRow("MAL", "MyAnimeList", "Coming later", null)
        SettingsDivider(); ServiceRow("AL", "AniList", "Coming later", null)
        SettingsDivider(); ServiceRow("S", "Simkl", "Coming later", null)
    }
}

@Composable
private fun ServiceRow(icon: String, title: String, subtitle: String, onClick: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().then(if (onClick != null) Modifier.focusRing().clickable(onClick = onClick) else Modifier).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontWeight = FontWeight.Bold, modifier = Modifier.width(48.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFAAAAAA))
        }
        if (onClick != null) Text("›", style = MaterialTheme.typography.titleLarge)
    }
}

// ---------------------------------------------------------------- Downloads (Plex, offline)

@Composable
fun DownloadsList() {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { Downloads.load(ctx) }
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(2000); tick++ } }
    var kind by remember { mutableStateOf("all") }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
        PillChip("All", kind == "all") { kind = "all" }
        PillChip("TV Shows", kind == "episode") { kind = "episode" }
        PillChip("Movies", kind == "movie") { kind = "movie" }
    }
    val list = Downloads.items.filter { kind == "all" || it.type == kind }
    if (list.isEmpty()) Text("No downloads. Use ⤓ on a movie or episode page in the Library.", modifier = Modifier.padding(16.dp))
    list.forEach { d ->
        val p = remember(tick, d.id) { Downloads.progress(ctx, d) }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF1F1F22)).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = d.poster, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(52.dp, 78.dp).clip(RoundedCornerShape(8.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(d.title, style = MaterialTheme.typography.titleMedium)
                Text(listOf(d.subtitle, when { p >= 1f -> "Downloaded"; p < 0 -> "Failed"; else -> "${(p * 100).toInt()}%" }).filter { it.isNotEmpty() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA))
            }
            if (p >= 1f) TextButton(onClick = { CastHub.playLocal(ctx, android.net.Uri.fromFile(java.io.File(d.file)).toString(), d.title) },
                modifier = Modifier.focusRing(ButtonShape)) { Text("▶ Play") }
            TextButton(onClick = { Downloads.remove(ctx, d) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Delete") }
        }
    }
    SettingsCard {
        SwitchRow("Download on Wi-Fi only", "download_wifi_only", false, "Wait for Wi-Fi instead of using mobile data")
    }
}

// ---------------------------------------------------------------- Advanced & backup

@Composable
fun AdvancedSettings() {
    val ctx = LocalContext.current
    var logs by remember { mutableStateOf<String?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    val exportFile = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        val ok = runCatching { ctx.contentResolver.openOutputStream(uri)!!.use { it.write(Opt.exportJson().toByteArray()) } }.isSuccess
        Toast.makeText(ctx, if (ok) "Settings saved." else "Couldn't save the file.", Toast.LENGTH_SHORT).show()
    }
    val importFile = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        val n = runCatching { Opt.importJson(ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }) }.getOrNull()
        Toast.makeText(ctx, if (n != null) "Restored $n settings. Restart the app to apply everything." else "That isn't a TV Hub settings file.", Toast.LENGTH_LONG).show()
    }
    SettingsHeader("Advanced")
    SettingsCard {
        ServiceRow("📄", "View Logs", "The last crash, if there was one") { logs = CrashLog.read(ctx) ?: "No crashes recorded." }
        SettingsDivider()
        ServiceRow("🧹", "Clear Image Cache", "Pictures load again from the internet") {
            val loader = coil.Coil.imageLoader(ctx)
            loader.memoryCache?.clear()
            loader.diskCache?.clear()
            Toast.makeText(ctx, "Image cache cleared.", Toast.LENGTH_SHORT).show()
        }
        SettingsDivider()
        ServiceRow("↺", "Reset Settings", "Every option back to default (playlists and logins stay)") { confirmReset = true }
    }
    SettingsHeader("Backup")
    SettingsCard {
        ServiceRow("⤴", "Export Settings", "Save your preferences to a file (no logins or passwords)") {
            try { exportFile.launch("tvhub-settings.json") } catch (_: Exception) { Toast.makeText(ctx, "No file app on this device.", Toast.LENGTH_SHORT).show() }
        }
        SettingsDivider()
        ServiceRow("⤵", "Import Settings", "Restore preferences from a file") {
            try { importFile.launch(arrayOf("application/json", "text/plain", "*/*")) } catch (_: Exception) { Toast.makeText(ctx, "No file app on this device.", Toast.LENGTH_SHORT).show() }
        }
    }
    logs?.let { text ->
        AlertDialog(onDismissRequest = { logs = null }, title = { Text("Logs") },
            text = { Text(text, style = MaterialTheme.typography.bodySmall, modifier = Modifier.heightIn(max = 400.dp).verticalScrollCompat()) },
            confirmButton = { TextButton(onClick = { logs = null }) { Text("Close") } })
    }
    if (confirmReset) AlertDialog(onDismissRequest = { confirmReset = false }, title = { Text("Reset settings?") },
        text = { Text("All options go back to their defaults. Your playlists, Plex and Trakt sign-ins and favorites stay. This can't be undone.") },
        confirmButton = { TextButton(onClick = { Opt.resetAll(); confirmReset = false; Toast.makeText(ctx, "Settings reset.", Toast.LENGTH_SHORT).show() }) { Text("Reset") } },
        dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } })
}

@Composable
private fun Modifier.verticalScrollCompat(): Modifier = this.verticalScroll(androidx.compose.foundation.rememberScrollState())
