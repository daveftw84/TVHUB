package com.example.tvhub

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.mutableStateMapOf
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject

/**
 * The download queue. Downloads run here, outside any screen, two at a time, and a foreground service
 * keeps the app alive (with a notification) until they finish, so leaving the app doesn't stop them.
 */
object GameDownloads {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val slots = Semaphore(2)
    private val lock = Any()

    /** Progress 0..1 by game key; a game is in here while queued or downloading. */
    val progress = mutableStateMapOf<String, Float>()
    private val titles = HashMap<String, String>()

    fun start(ctx: Context, key: String, title: String, work: ((Float) -> Unit) -> Downloaded): Deferred<Downloaded> {
        val app = ctx.applicationContext
        synchronized(lock) {
            progress[key] = 0f
            titles[key] = title
        }
        DownloadService.update(app)
        return scope.async {
            try {
                slots.withPermit {
                    val d = work { f -> progress[key] = f }
                    record(app, d)    // saved even if the screen that asked is gone
                    d
                }
            } finally {
                synchronized(lock) {
                    progress.remove(key)
                    titles.remove(key)
                }
                DownloadService.update(app)
            }
        }
    }

    fun active(): Int = synchronized(lock) { progress.size }
    fun label(): String = synchronized(lock) {
        when (titles.size) {
            0 -> ""
            1 -> titles.values.first()
            else -> "${titles.size} games"
        }
    }

    /** Adds a finished download to the Downloaded list (the same list the Games screen reads). */
    private fun record(ctx: Context, d: Downloaded) = synchronized(lock) {
        val prefs = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString("games_downloads_v2", "[]")) } catch (_: Exception) { JSONArray() }
        val out = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.getJSONObject(i)
            if (o.optString("sourceKey") != d.sourceKey) out.put(o)
        }
        out.put(
            JSONObject().put("title", d.title).put("console", d.console).put("sourceKey", d.sourceKey)
                .put("path", d.path).put("uri", d.uri.orEmpty()).put("files", JSONArray(d.files))
        )
        prefs.edit().putString("games_downloads_v2", out.toString()).apply()
    }
}

/** Keeps downloads running in the background and shows their progress as a notification. */
class DownloadService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (GameDownloads.active() == 0) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Game downloads", NotificationManager.IMPORTANCE_LOW))
        }
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Downloading ${GameDownloads.label()}")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setProgress(0, 0, true)
            .build()
        ServiceCompat.startForeground(this, 2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        return START_NOT_STICKY
    }

    companion object {
        private const val CHANNEL = "downloads"

        fun update(ctx: Context) {
            val i = Intent(ctx, DownloadService::class.java)
            try {
                if (GameDownloads.active() > 0) ContextCompat.startForegroundService(ctx, i) else ctx.stopService(i)
            } catch (_: Exception) {
                // Starting a foreground service from the background can be refused; the download still runs.
            }
        }
    }
}
