package com.example.tvhub

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

// ======================================================================= Save files

/** One game's save file, wherever it lives: our own storage, or an emulator's save folder. */
interface SaveFile {
    val name: String
    /** Where it is, so background sync can find it again ("file:<path>" or "tree:<uri>|<name>"). */
    val location: String
    fun exists(): Boolean
    fun lastModified(): Long
    fun read(): ByteArray
    fun write(bytes: ByteArray)
}

class LocalSaveFile(private val f: File) : SaveFile {
    override val name: String get() = f.name
    override val location: String get() = "file:" + f.absolutePath
    override fun exists() = f.exists() && f.length() > 0
    override fun lastModified() = f.lastModified()
    override fun read() = f.readBytes()
    override fun write(bytes: ByteArray) {
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, f.name + ".part")
        tmp.writeBytes(bytes)
        f.delete()
        if (!tmp.renameTo(f)) throw IOException("Couldn't save ${f.name}")
    }
}

/**
 * A save file inside a folder picked with Android's folder picker. It is looked for in the folder and
 * one level of sub-folders (RetroArch can sort saves into a folder per core).
 */
class TreeSaveFile(private val ctx: Context, private val treeUri: String, override val name: String) : SaveFile {
    private val tree = Uri.parse(treeUri)
    private val rootDoc = DocumentsContract.getTreeDocumentId(tree)
    override val location: String get() = "tree:$treeUri|$name"

    private fun children(docId: String): List<Triple<String, String, Pair<String?, Long>>> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        val out = ArrayList<Triple<String, String, Pair<String?, Long>>>()
        ctx.contentResolver.query(uri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                out += Triple(c.getString(0), c.getString(1) ?: "", c.getString(2) to (if (c.isNull(3)) 0L else c.getLong(3)))
            }
        }
        return out
    }

    private fun find(): Pair<Uri, Long>? {
        val top = children(rootDoc)
        top.firstOrNull { it.second == name }?.let { return DocumentsContract.buildDocumentUriUsingTree(tree, it.first) to it.third.second }
        for (dir in top.filter { it.third.first == DocumentsContract.Document.MIME_TYPE_DIR }) {
            children(dir.first).firstOrNull { it.second == name }?.let {
                return DocumentsContract.buildDocumentUriUsingTree(tree, it.first) to it.third.second
            }
        }
        return null
    }

    override fun exists() = find() != null
    override fun lastModified() = find()?.second ?: 0L
    override fun read(): ByteArray {
        val uri = find()?.first ?: throw IOException("$name not found")
        return ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Couldn't read $name")
    }

    override fun write(bytes: ByteArray) {
        val uri = find()?.first ?: DocumentsContract.createDocument(
            ctx.contentResolver,
            DocumentsContract.buildDocumentUriUsingTree(tree, rootDoc),
            "application/octet-stream",
            name,
        ) ?: throw IOException("Couldn't create $name")
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) } ?: throw IOException("Couldn't write $name")
    }

    companion object {
        fun fromLocation(ctx: Context, location: String): SaveFile? = when {
            location.startsWith("file:") -> LocalSaveFile(File(location.removePrefix("file:")))
            location.startsWith("folders:") -> {
                val rest = location.removePrefix("folders:")
                val bar = rest.lastIndexOf('|')
                if (bar < 0) null else FolderZipSaveFile(File(rest.substring(0, bar)), rest.substring(bar + 1))
            }
            location.startsWith("tree:") -> {
                val rest = location.removePrefix("tree:")
                val bar = rest.lastIndexOf('|')
                if (bar < 0) null else TreeSaveFile(ctx, rest.substring(0, bar), rest.substring(bar + 1))
            }
            else -> null
        }
    }
}

/**
 * Saves made of folders (PSP SAVEDATA: one or more folders whose names start with the game's serial).
 * They travel to RomM as one zip, with fixed timestamps so the same saves always hash the same.
 */
class FolderZipSaveFile(private val root: File, private val prefix: String) : SaveFile {
    override val name: String get() = "$prefix.zip"
    override val location: String get() = "folders:${root.absolutePath}|$prefix"

    private fun folders(): List<File> =
        root.listFiles { f -> f.isDirectory && f.name.startsWith(prefix, ignoreCase = true) }?.sortedBy { it.name } ?: emptyList()

    override fun exists() = folders().any { d -> d.walkTopDown().any { it.isFile } }
    override fun lastModified() = folders().flatMap { d -> d.walkTopDown().filter { it.isFile }.toList() }
        .maxOfOrNull { it.lastModified() } ?: 0L

    override fun read(): ByteArray {
        val bos = java.io.ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(bos).use { zip ->
            for (d in folders()) {
                for (f in d.walkTopDown().filter { it.isFile }.sortedBy { it.path }) {
                    val e = java.util.zip.ZipEntry(d.name + "/" + f.relativeTo(d).path.replace('\\', '/'))
                    e.time = 315532800000L   // 1980-01-01: keeps the zip (and its hash) the same for the same saves
                    zip.putNextEntry(e)
                    f.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
        return bos.toByteArray()
    }

    override fun write(bytes: ByteArray) {
        val entries = ArrayList<Pair<String, ByteArray>>()
        java.util.zip.ZipInputStream(bytes.inputStream()).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (!e.isDirectory) entries += e.name to zip.readBytes()
            }
        }
        // Only folders belonging to this game, and nothing outside SAVEDATA.
        val safe = entries.filter { (n, _) ->
            val top = n.substringBefore('/')
            top.startsWith(prefix, ignoreCase = true) && !n.contains("..")
        }
        if (safe.isEmpty()) throw IOException("The save from RomM has no folders for $prefix")
        safe.map { it.first.substringBefore('/') }.toSet().forEach { File(root, it).deleteRecursively() }
        for ((n, data) in safe) {
            val f = File(root, n)
            f.parentFile?.mkdirs()
            f.writeBytes(data)
        }
    }
}

/** Reads a PSP game's serial (e.g. ULUS10041) from an .iso, for finding its saves. */
object PspId {
    fun fromTitleId(titleId: String?): String? =
        titleId?.uppercase()?.filter { it.isLetterOrDigit() }?.takeIf { it.length >= 9 }?.take(9)

    fun fromIso(path: String): String? = try {
        java.io.RandomAccessFile(path, "r").use { f ->
            fun sector(lba: Long, len: Int): ByteArray {
                val b = ByteArray(len)
                f.seek(lba * 2048)
                f.readFully(b)
                return b
            }
            fun le32(b: ByteArray, o: Int) =
                (b[o].toLong() and 0xff) or ((b[o + 1].toLong() and 0xff) shl 8) or
                    ((b[o + 2].toLong() and 0xff) shl 16) or ((b[o + 3].toLong() and 0xff) shl 24)
            val pvd = sector(16, 2048)
            val rootLba = le32(pvd, 156 + 2)
            val rootLen = le32(pvd, 156 + 10).toInt().coerceIn(2048, 65536)
            val dir = sector(rootLba, rootLen)
            var i = 0
            var result: String? = null
            while (i < dir.size) {
                val len = dir[i].toInt() and 0xff
                if (len == 0) { i = ((i / 2048) + 1) * 2048; continue }
                val nameLen = dir[i + 32].toInt() and 0xff
                val name = String(dir, i + 33, nameLen, Charsets.US_ASCII)
                if (name.startsWith("UMD_DATA.BIN", ignoreCase = true)) {
                    val data = sector(le32(dir, i + 2), 2048)
                    result = fromTitleId(String(data, 0, 10, Charsets.US_ASCII))
                    break
                }
                i += len
            }
            result
        }
    } catch (_: Exception) {
        null
    }
}

// ======================================================================= Where emulators keep saves

/** From saves.json: where an emulator app keeps its save files, and their file types. */
data class SaveProfile(
    val launcher: String,
    val name: String,
    val paths: List<String>,
    val exts: List<String>,
    val kind: String = "file",              // "file": one save file named after the game; "psp": PSP SAVEDATA folders
    val biosPaths: List<String> = emptyList(), // where this emulator looks for BIOS files
)

object SaveLocator {
    fun parseProfiles(text: String): List<SaveProfile> {
        val a = JSONArray(text)
        return (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
            val p = o.optJSONArray("paths") ?: JSONArray()
            val e = o.optJSONArray("exts") ?: JSONArray()
            val b = o.optJSONArray("bios_paths") ?: JSONArray()
            SaveProfile(
                launcher = o.getString("launcher"),
                name = o.optString("name", o.getString("launcher")),
                paths = (0 until p.length()).map { p.getString(it) },
                exts = (0 until e.length()).map { e.getString(it).lowercase() },
                kind = o.optString("kind", "file"),
                biosPaths = (0 until b.length()).map { b.getString(it) },
            )
        }
    }

    /** True when the app may read and write other apps' folders on shared storage. */
    fun hasStorageAccess(ctx: Context): Boolean = when {
        Build.VERSION.SDK_INT >= 30 -> Environment.isExternalStorageManager()
        else -> ctx.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    /**
     * The save file an emulator app uses for a game whose file is called [romStem] (name without
     * extension). Looks in the folder the user picked for that emulator, else in the emulator's usual
     * folders. Returns where the save would go even if the game hasn't been saved yet, or null.
     */
    fun locate(ctx: Context, profile: SaveProfile, pickedFolder: String?, romStem: String, gameId: String? = null): SaveFile? {
        if (profile.kind == "psp") {
            // PPSSPP keeps each game's saves in SAVEDATA folders named after the game's serial.
            val id = gameId ?: return null
            if (!hasStorageAccess(ctx)) return null
            @Suppress("DEPRECATION")
            val root = Environment.getExternalStorageDirectory()
            val dir = profile.paths.map { File(root, it) }.firstOrNull { it.isDirectory } ?: return null
            return FolderZipSaveFile(dir, id)
        }
        if (pickedFolder != null) {
            for (ext in profile.exts) {
                val f = TreeSaveFile(ctx, pickedFolder, "$romStem.$ext")
                if (f.exists()) return f
            }
            return TreeSaveFile(ctx, pickedFolder, "$romStem.${profile.exts.firstOrNull() ?: "sav"}")
        }
        if (!hasStorageAccess(ctx)) return null
        @Suppress("DEPRECATION")
        val root = Environment.getExternalStorageDirectory()
        val dirs = profile.paths.map { File(root, it) }.filter { it.isDirectory }
        for (dir in dirs) {
            val candidates = listOf(dir) + (dir.listFiles { f -> f.isDirectory }?.toList() ?: emptyList())
            for (d in candidates) for (ext in profile.exts) {
                val f = File(d, "$romStem.$ext")
                if (f.exists()) return LocalSaveFile(f)
            }
        }
        val first = dirs.firstOrNull() ?: return null
        return LocalSaveFile(File(first, "$romStem.${profile.exts.firstOrNull() ?: "sav"}"))
    }
}

// ======================================================================= RomM device sync protocol

/**
 * RomM's device save-sync protocol (the one Grout and Argosy use): the device sends what it has,
 * RomM answers with a plan (upload / download / conflict / nothing), the device carries it out,
 * confirms each download and closes the session, reporting play time with it.
 */
object SaveSync {
    const val SLOT = "autosave"

    data class Op(val action: String, val romId: Int, val saveId: Int?, val fileName: String, val reason: String)
    data class Plan(val sessionId: Int, val ops: List<Op>)
    data class PlayTime(val romId: Int, val startMs: Long, val endMs: Long)
    data class Entry(val id: Int, val fileName: String, val updatedAt: String, val emulator: String, val slot: String, val size: Long)

    fun iso(ms: Long): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        .apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(ms))

    fun md5(bytes: ByteArray): String = MessageDigest.getInstance("MD5").digest(bytes).joinToString("") { "%02x".format(it) }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun call(base: String, token: String, path: String, method: String, body: ByteArray?, contentType: String?): HttpURLConnection {
        val c = URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15_000
        c.readTimeout = 60_000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/json")
        if (body != null) {
            c.doOutput = true
            if (contentType != null) c.setRequestProperty("Content-Type", contentType)
            c.outputStream.use { it.write(body) }
        }
        if (c.responseCode !in 200..299) {
            val detail = try { c.errorStream?.bufferedReader()?.use { it.readText() }?.take(200) } catch (_: Exception) { null }
            throw IOException("RomM returned HTTP ${c.responseCode}" + (detail?.let { ": $it" } ?: ""))
        }
        return c
    }

    private fun json(base: String, token: String, path: String, method: String, body: JSONObject?): String =
        call(base, token, path, method, body?.toString()?.toByteArray(), if (body != null) "application/json" else null)
            .inputStream.bufferedReader().use { it.readText() }

    fun registerDevice(base: String, token: String, name: String): String {
        val body = JSONObject()
            .put("name", name)
            .put("platform", "android")
            .put("client", "TV Hub")
            .put("client_version", "2.0")
            .put("hostname", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
            .put("sync_mode", "push_pull")
            .put("allow_existing", true)
        return JSONObject(json(base, token, "/api/devices", "POST", body)).getString("device_id")
    }

    fun negotiate(base: String, token: String, deviceId: String, romId: Int, emulator: String, core: String?, file: SaveFile): Plan {
        val saves = JSONArray()
        if (file.exists()) {
            val bytes = file.read()
            saves.put(
                JSONObject()
                    .put("rom_id", romId)
                    .put("file_name", file.name)
                    .put("slot", SLOT)
                    .put("emulator", emulator)
                    .put("content_hash", md5(bytes))
                    .put("updated_at", iso(file.lastModified()))
                    .put("file_size_bytes", bytes.size)
            )
        }
        val body = JSONObject()
            .put("device_id", deviceId)
            .put("saves", saves)
            .put("rom_ids", JSONArray().put(romId))
        if (core != null) body.put("cores", JSONArray().put(core))
        val o = JSONObject(json(base, token, "/api/sync/negotiate", "POST", body))
        val a = o.optJSONArray("operations") ?: JSONArray()
        val ops = (0 until a.length()).map { a.getJSONObject(it) }.map {
            Op(
                action = it.optString("action"),
                romId = it.optInt("rom_id"),
                saveId = if (it.isNull("save_id")) null else it.optInt("save_id"),
                fileName = it.optString("file_name"),
                reason = it.optString("reason"),
            )
        }.filter { it.romId == romId }
        return Plan(o.getInt("session_id"), ops)
    }

    /** Downloads a save without marking it as held yet; [confirm] does that once it is written. */
    fun download(base: String, token: String, deviceId: String, sessionId: Int?, saveId: Int): ByteArray {
        var q = "device_id=${enc(deviceId)}&optimistic=false"
        if (sessionId != null) q += "&session_id=$sessionId"
        return call(base, token, "/api/saves/$saveId/content?$q", "GET", null, null).inputStream.use { it.readBytes() }
    }

    fun confirm(base: String, token: String, deviceId: String, saveId: Int, bytes: ByteArray) {
        val body = JSONObject().put("device_id", deviceId).put("content_hash", md5(bytes))
        json(base, token, "/api/saves/$saveId/downloaded", "POST", body)
    }

    fun upload(
        base: String, token: String, deviceId: String, sessionId: Int?, romId: Int, emulator: String, core: String?,
        file: SaveFile, overwrite: Boolean,
    ) {
        val bytes = file.read()
        val boundary = "----TVHub" + UUID.randomUUID().toString().replace("-", "")
        val head = "--$boundary\r\nContent-Disposition: form-data; name=\"saveFile\"; filename=\"${file.name}\"\r\n" +
            "Content-Type: application/octet-stream\r\n\r\n"
        val body = head.toByteArray() + bytes + "\r\n--$boundary--\r\n".toByteArray()
        var q = "rom_id=$romId&emulator=${enc(emulator)}&slot=$SLOT&device_id=${enc(deviceId)}" +
            "&content_hash=${md5(bytes)}&overwrite=$overwrite&autocleanup=true"
        if (core != null) q += "&core=${enc(core)}"
        if (sessionId != null) q += "&session_id=$sessionId"
        call(base, token, "/api/saves?$q", "POST", body, "multipart/form-data; boundary=$boundary").inputStream.close()
    }

    fun complete(base: String, token: String, sessionId: Int, done: Int, failed: Int, play: PlayTime?) {
        val body = JSONObject().put("operations_completed", done).put("operations_failed", failed)
        if (play != null) {
            body.put(
                "play_sessions",
                JSONArray().put(
                    JSONObject()
                        .put("rom_id", play.romId)
                        .put("start_time", iso(play.startMs))
                        .put("end_time", iso(play.endMs))
                        .put("duration_ms", (play.endMs - play.startMs).coerceAtLeast(0))
                ),
            )
        }
        json(base, token, "/api/sync/sessions/$sessionId/complete", "POST", body)
    }

    /** Every save RomM holds for a game (newest first), for the save history screen. */
    fun history(base: String, token: String, romId: Int): List<Entry> {
        val a = JSONArray(json(base, token, "/api/saves?rom_id=$romId", "GET", null))
        return (0 until a.length()).map { a.getJSONObject(it) }.map {
            Entry(
                id = it.getInt("id"),
                fileName = it.optString("file_name"),
                updatedAt = it.optString("updated_at"),
                emulator = it.optString("emulator"),
                slot = it.optString("slot"),
                size = it.optLong("file_size_bytes"),
            )
        }.sortedByDescending { it.updatedAt }
    }

    /** Keeps the last few local copies before a download replaces them. */
    fun backup(ctx: Context, file: SaveFile) {
        if (!file.exists()) return
        val dir = File(ctx.filesDir, "save_backups").apply { mkdirs() }
        File(dir, "${file.name}.${System.currentTimeMillis()}").writeBytes(file.read())
        dir.listFiles { f -> f.name.startsWith(file.name + ".") }
            ?.sortedByDescending { it.lastModified() }?.drop(5)?.forEach { it.delete() }
    }
}

/**
 * Runs syncs with RomM for the screens and for background sync. Blocking: call it off the main thread.
 * [ask] decides a conflict: true keeps RomM's save, false keeps this device's, null skips it for now.
 */
class SyncEngine(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)
    val base: String get() = prefs.getString("romm_url", "").orEmpty()
    val token: String? get() = prefs.getString("romm_token", null)
    val enabled: Boolean get() = token != null && prefs.getBoolean("games_sync_saves", true)

    data class Outcome(val done: Int, val failed: Int, val skippedConflicts: Int, val error: String?)

    fun deviceId(): String? {
        prefs.getString("romm_device_id", null)?.let { return it }
        val t = token ?: return null
        val id = try {
            SaveSync.registerDevice(base, t, "TV Hub on ${Build.MODEL}")
        } catch (_: Exception) {
            return null
        }
        prefs.edit().putString("romm_device_id", id).apply()
        return id
    }

    // A pinned save was restored on purpose: sync leaves it alone until the next session uploads it.
    fun isPinned(romId: Int) = prefs.getBoolean("save_pin_$romId", false)
    fun setPinned(romId: Int, on: Boolean) {
        prefs.edit().putBoolean("save_pin_$romId", on).apply()
    }

    /**
     * One sync of one game's save. [afterPlay] is true right after a session (a pinned save is then
     * uploaded and unpinned); [play] is reported to RomM with the session.
     */
    fun sync(
        romId: Int, emulator: String, core: String?, file: SaveFile, afterPlay: Boolean,
        play: SaveSync.PlayTime?, ask: (String) -> Boolean?,
    ): Outcome {
        val t = token ?: return Outcome(0, 0, 0, null)
        val device = deviceId() ?: return Outcome(0, 0, 0, "Couldn't register this device with RomM (the token needs devices.write).")
        val pinned = isPinned(romId)
        if (pinned && !afterPlay) return Outcome(0, 0, 0, null)
        val plan = try {
            SaveSync.negotiate(base, t, device, romId, emulator, core, file)
        } catch (e: Exception) {
            if (e.message?.contains("HTTP 404") == true) prefs.edit().remove("romm_device_id").apply()
            return Outcome(0, 0, 0, "Couldn't sync saves with RomM: ${e.message}")
        }
        var done = 0
        var failed = 0
        var skipped = 0
        fun download(op: SaveSync.Op) {
            val id = op.saveId ?: throw IOException("RomM didn't say which save to download")
            val bytes = SaveSync.download(base, t, device, plan.sessionId, id)
            SaveSync.backup(ctx, file)
            file.write(bytes)
            SaveSync.confirm(base, t, device, id, bytes)
        }
        fun upload(overwrite: Boolean) = SaveSync.upload(base, t, device, plan.sessionId, romId, emulator, core, file, overwrite)
        for (op in plan.ops) {
            try {
                when (op.action) {
                    "upload" -> { upload(false); done++ }
                    "download" -> if (pinned) { upload(true); done++ } else { download(op); done++ }
                    "conflict" -> {
                        val keepRomm = if (pinned) false else ask(op.reason)
                        when (keepRomm) {
                            true -> { download(op); done++ }
                            false -> { upload(true); done++ }
                            null -> skipped++
                        }
                    }
                }
            } catch (_: Exception) {
                failed++
            }
        }
        try {
            SaveSync.complete(base, t, plan.sessionId, done, failed, play)
        } catch (_: Exception) {
        }
        if (pinned && afterPlay && failed == 0) setPinned(romId, false)
        return Outcome(done, failed, skipped, if (failed > 0) "$failed save transfer(s) with RomM failed." else null)
    }

    // ----- what background sync looks after -----

    data class Target(val romId: Int, val title: String, val emulator: String, val core: String?, val location: String)

    fun targets(): List<Target> = try {
        val a = JSONArray(prefs.getString("sync_targets", "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }.map {
            Target(it.getInt("rom"), it.optString("title"), it.getString("emu"),
                it.optString("core").ifEmpty { null }, it.getString("loc"))
        }
    } catch (_: Exception) {
        emptyList()
    }

    fun remember(t: Target) {
        val list = targets().filter { !(it.romId == t.romId && it.emulator == t.emulator) } + t
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("rom", it.romId).put("title", it.title).put("emu", it.emulator)
                .put("core", it.core.orEmpty()).put("loc", it.location))
        }
        prefs.edit().putString("sync_targets", a.toString()).apply()
    }

    fun forget(romId: Int) {
        val list = targets().filter { it.romId != romId }
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("rom", it.romId).put("title", it.title).put("emu", it.emulator)
                .put("core", it.core.orEmpty()).put("loc", it.location))
        }
        prefs.edit().putString("sync_targets", a.toString()).apply()
    }

    /** Syncs every remembered game. Conflicts are left for the user (counted, never decided here). */
    fun syncAll(): Outcome {
        if (!enabled) return Outcome(0, 0, 0, null)
        var done = 0
        var failed = 0
        var skipped = 0
        for (t in targets()) {
            val file = TreeSaveFile.fromLocation(ctx, t.location) ?: continue
            val o = try {
                sync(t.romId, t.emulator, t.core, file, afterPlay = false, play = null) { null }
            } catch (_: Exception) {
                Outcome(0, 1, 0, null)
            }
            done += o.done
            failed += o.failed
            skipped += o.skippedConflicts
        }
        prefs.edit().putInt("sync_pending_conflicts", skipped).putLong("sync_last_run", System.currentTimeMillis()).apply()
        return Outcome(done, failed, skipped, null)
    }
}
