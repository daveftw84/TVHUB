package com.example.tvhub

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/** UI-facing recording state and helpers. `active` maps stream URL to channel name. */
object Recorder {
    var active by mutableStateOf<Map<String, String>>(emptyMap())

    fun start(ctx: Context, url: String, name: String, endMs: Long) {
        val i = Intent(ctx, RecorderService::class.java)
            .setAction(RecorderService.ACTION_START)
            .putExtra(RecorderService.EXTRA_URL, url)
            .putExtra(RecorderService.EXTRA_NAME, name)
            .putExtra(RecorderService.EXTRA_END, endMs)
        ContextCompat.startForegroundService(ctx, i)
    }

    fun stop(ctx: Context, url: String) {
        ctx.startService(
            Intent(ctx, RecorderService::class.java)
                .setAction(RecorderService.ACTION_STOP)
                .putExtra(RecorderService.EXTRA_URL, url)
        )
    }

    fun dir(ctx: Context): File = ctx.getExternalFilesDir("recordings") ?: ctx.filesDir
}

/**
 * Saves a stream to disk by copying its bytes. Works for plain MPEG-TS over HTTP
 * (typical for Xtream "live" URLs). HLS (.m3u8) playlists are not supported.
 */
class RecorderService : Service() {
    private val stops = ConcurrentHashMap<String, AtomicBoolean>()
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null) {
            when (intent.action) {
                ACTION_START -> {
                    goForeground()
                    start(intent)
                }
                ACTION_STOP -> intent.getStringExtra(EXTRA_URL)?.let { stops[it]?.set(true) }
            }
        }
        if (stops.isEmpty()) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stops.values.forEach { it.set(true) }
        super.onDestroy()
    }

    private fun start(intent: Intent) {
        val url = intent.getStringExtra(EXTRA_URL) ?: return
        if (stops.containsKey(url)) return
        val name = intent.getStringExtra(EXTRA_NAME) ?: "Channel"
        val endMs = intent.getLongExtra(EXTRA_END, System.currentTimeMillis() + 3_600_000L)

        val stop = AtomicBoolean(false)
        stops[url] = stop
        Recorder.active = Recorder.active + (url to name)

        Thread {
            record(url, name, endMs, stop)
            stops.remove(url)
            main.post {
                Recorder.active = Recorder.active - url
                if (stops.isEmpty()) stopSelf()
            }
        }.start()
    }

    private fun record(url: String, name: String, endMs: Long, stop: AtomicBoolean) {
        val safe = name.replace(Regex("[^A-Za-z0-9 _-]"), "_").trim().ifEmpty { "recording" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val file = File(Recorder.dir(this), "${safe}_$stamp.ts")
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", USER_AGENT)
            c.inputStream.use { input ->
                file.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (!stop.get() && System.currentTimeMillis() < endMs) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                    }
                }
            }
        } catch (_: Exception) {
        }
        if (file.exists() && file.length() == 0L) file.delete()
    }

    private fun goForeground() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Recording", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("TV Hub is recording")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }

    companion object {
        const val ACTION_START = "com.example.tvhub.START"
        const val ACTION_STOP = "com.example.tvhub.STOP"
        const val EXTRA_URL = "url"
        const val EXTRA_NAME = "name"
        const val EXTRA_END = "end"
        private const val CHANNEL = "recording"
    }
}
