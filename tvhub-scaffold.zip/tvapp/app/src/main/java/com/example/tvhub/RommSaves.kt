package com.example.tvhub

import android.content.Context
import org.json.JSONArray
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

/**
 * Keeps the built-in player's saves in step with RomM: in-game saves (.srm) and save states.
 * Before a game starts, a newer copy on RomM replaces the local one; after playing, a changed
 * local copy is uploaded. Files are stored under the core's name, so RomM keeps them per emulator.
 */
object RommSaves {
    fun sramFile(ctx: Context, core: String, key: String) =
        File(ctx.filesDir, "saves/$core/${safe(key)}.srm").apply { parentFile?.mkdirs() }

    fun stateFile(ctx: Context, core: String, key: String) =
        File(ctx.filesDir, "states/$core/${safe(key)}.state").apply { parentFile?.mkdirs() }

    fun safe(key: String) = key.replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun parseTime(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
            .parse(s.take(19))?.time ?: 0L
    } catch (_: Exception) {
        0L
    }

    private fun get(base: String, token: String, path: String): HttpURLConnection {
        val c = URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 40_000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/json")
        if (c.responseCode !in 200..299) throw IOException("RomM returned HTTP ${c.responseCode}")
        return c
    }

    /** Newest copy on RomM for this game and core: its id and time, or null. */
    private fun newest(base: String, token: String, kind: String, romId: Int, core: String): Pair<Int, Long>? {
        val text = get(base, token, "/api/$kind?rom_id=$romId").inputStream.bufferedReader().use { it.readText() }
        val a = JSONArray(text)
        var best: Pair<Int, Long>? = null
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val emu = o.optString("emulator")
            val oc = o.optString("core")
            if (emu != core && oc != core) continue
            val t = parseTime(o.optString("updated_at"))
            if (best == null || t > best.second) best = o.getInt("id") to t
        }
        return best
    }

    /** Downloads RomM's copy when it's newer than the local file. Returns true if it replaced it. */
    fun pull(base: String, token: String, kind: String, romId: Int, core: String, local: File): Boolean {
        val (id, time) = newest(base, token, kind, romId, core) ?: return false
        if (local.exists() && local.lastModified() >= time) return false
        val tmp = File(local.parentFile, local.name + ".part")
        get(base, token, "/api/$kind/$id/content").inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
        local.delete()
        if (!tmp.renameTo(local)) throw IOException("Couldn't save ${local.name}")
        local.setLastModified(time)
        return true
    }

    /** Uploads the local file if it changed since [since] (milliseconds). */
    fun push(base: String, token: String, kind: String, romId: Int, core: String, local: File, since: Long) {
        if (!local.exists() || local.length() == 0L || local.lastModified() <= since) return
        val field = if (kind == "saves") "saveFile" else "stateFile"
        var query = "rom_id=$romId&emulator=$core&core=$core"
        if (kind == "saves") query += "&slot=autosave&overwrite=true&autocleanup=true"
        val boundary = "----TVHub" + UUID.randomUUID().toString().replace("-", "")
        val c = URL("${base.trimEnd('/')}/api/$kind?$query").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15_000
        c.readTimeout = 60_000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        c.outputStream.use { out ->
            out.write(
                ("--$boundary\r\nContent-Disposition: form-data; name=\"$field\"; filename=\"${local.name}\"\r\n" +
                    "Content-Type: application/octet-stream\r\n\r\n").toByteArray()
            )
            local.inputStream().use { it.copyTo(out) }
            out.write("\r\n--$boundary--\r\n".toByteArray())
        }
        if (c.responseCode !in 200..299) throw IOException("RomM returned HTTP ${c.responseCode}")
    }
}
