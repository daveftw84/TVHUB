package com.example.tvhub

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import com.example.tvhub.Corners.Region
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/**
 * Picture-in-picture like TiviMate: up to four small windows, one in each corner, over Live TV, the
 * Plex player or a game. Each window shows a Live TV channel or a Plex video. One picture has the
 * sound: the main one, or a window you choose.
 */
object Corners {
    /** Windows allowed (Settings > MultiView > Maximum screens, counting the main picture). */
    val MAX: Int get() = (Opt.int("mv_max", 5) - 1).coerceIn(1, 8)

    class Slot(val id: Int, val title: String, val url: String, val channel: Channel?, val plex: PlexItem?, val player: ExoPlayer)

    /** The windows, in corner order: bottom right, bottom left, top left, top right. */
    val slots = mutableStateListOf<Slot>()
    /** The window that has the sound, or -1 for the main picture. */
    var soundId by mutableStateOf(-1)
        private set
    var large by mutableStateOf(false)
        private set
    /** True while choosing a channel (or video) for a new window. */
    var picking by mutableStateOf(false)
    val errors = mutableStateMapOf<Int, String>()
    /** Channels to offer when adding a window from a game (kept up to date by Live TV). */
    var channelChoices: List<Channel> = emptyList()

    private var nextId = 1
    private var hosts = 0

    val mainMuted: Boolean get() = soundId != -1 && slots.any { it.id == soundId }
    val full: Boolean get() = slots.size >= MAX

    private fun add(ctx: Context, title: String, url: String, channel: Channel?, plex: PlexItem?,
                    source: androidx.media3.exoplayer.source.MediaSource? = null, startMs: Long = 0): String? {
        picking = false
        if (slots.any { it.url == url }) return null
        if (full) return "Up to $MAX corner windows. Close one first."
        val id = nextId++
        val p = ExoPlayer.Builder(ctx.applicationContext).build().apply {
            volume = 0f
            if (source != null) setMediaSource(source) else setMediaItem(MediaItem.fromUri(url))
            if (plex != null && plex.viewOffset > 0) seekTo(plex.viewOffset)
            if (startMs > 0) seekTo(startMs)
            prepare()
            playWhenReady = hosts > 0
            addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    errors[id] = if (channel != null) "Didn't play. Your provider may allow fewer streams at once."
                    else "Didn't play."
                }
            })
        }
        slots += Slot(id, title, url, channel, plex, p)
        // "Mute new screens" off: the new window gets the sound.
        if (!Opt.bool(Opt.MV_MUTE_NEW, true)) { soundId = id; applySound() }
        return null
    }

    fun addChannel(ctx: Context, ch: Channel): String? = add(ctx, ch.name, ch.url, ch, null)

    /** A YouTube video (its streams are resolved first, so call this off the main thread's work). */
    fun addYouTube(ctx: Context, title: String, url: String, source: androidx.media3.exoplayer.source.MediaSource, startMs: Long = 0): String? =
        add(ctx, title, url, null, null, source, startMs)

    fun addPlex(ctx: Context, item: PlexItem, url: String): String? =
        add(ctx, item.displayTitle + (item.displaySubtitle?.let { " · $it" } ?: ""), url, null, item)

    fun close(id: Int) {
        val s = slots.firstOrNull { it.id == id } ?: return
        s.player.release()
        slots.remove(s)
        errors.remove(id)
        if (soundId == id) soundId = -1
        applySound()
    }

    fun closeAll() {
        slots.toList().forEach { close(it.id) }
    }

    /** Gives the sound to a window, or back to the main picture when it already has it. */
    fun toggleSound(id: Int) {
        soundId = if (soundId == id) -1 else id
        applySound()
    }

    /** Main picture, then each window in turn. */
    fun cycleSound() {
        val ids = listOf(-1) + slots.map { it.id }
        soundId = ids[(ids.indexOf(soundId) + 1) % ids.size]
        applySound()
    }

    fun toggleSize() { large = !large }

    fun giveSoundToMain() { soundId = -1; applySound() }

    // --- Layouts: windows in the corners, or the screen split between the pictures ---

    enum class Layout(val label: String) {
        CORNERS("Corners"),
        SIDE("Split side by side"),
        STACK("Split top and bottom"),
        HALF_LEFT("Half and two quarters"),
        HALF_TOP("Half on top, two below"),
        GRID("Four squares"),
        MANY("Grid"),
    }

    /** A screen region, as fractions of the width and height. */
    data class Region(val x: Float, val y: Float, val w: Float, val h: Float)

    var chosenLayout by mutableStateOf(Layout.CORNERS)
        private set

    /** Layouts that fit the number of pictures: 2 can split, 3 can be half + two quarters, 4 a grid. */
    fun layoutsFor(windows: Int): List<Layout> = when (windows) {
        0 -> listOf(Layout.CORNERS)      // no windows: full screen
        1 -> listOf(Layout.CORNERS, Layout.SIDE, Layout.STACK)
        2 -> listOf(Layout.CORNERS, Layout.HALF_LEFT, Layout.HALF_TOP)
        3 -> listOf(Layout.CORNERS, Layout.GRID)
        4 -> listOf(Layout.CORNERS, Layout.MANY)
        else -> listOf(Layout.MANY)      // 6 to 9 screens: a grid
    }

    val layout: Layout get() = chosenLayout.takeIf { it in layoutsFor(slots.size) } ?: layoutsFor(slots.size).first()

    fun cycleLayout() {
        val options = layoutsFor(slots.size)
        chosenLayout = options[(options.indexOf(layout) + 1) % options.size]
    }

    /** Regions for the main picture then each window, or null for the corners layout. */
    fun regions(): List<Region>? = if (slots.isEmpty()) null else when (layout) {   // no windows: the main video fills the screen
        Layout.CORNERS -> null
        Layout.SIDE -> listOf(Region(0f, 0f, .5f, 1f), Region(.5f, 0f, .5f, 1f))
        Layout.STACK -> listOf(Region(0f, 0f, 1f, .5f), Region(0f, .5f, 1f, .5f))
        Layout.HALF_LEFT -> listOf(Region(0f, 0f, .5f, 1f), Region(.5f, 0f, .5f, .5f), Region(.5f, .5f, .5f, .5f))
        Layout.HALF_TOP -> listOf(Region(0f, 0f, 1f, .5f), Region(0f, .5f, .5f, .5f), Region(.5f, .5f, .5f, .5f))
        Layout.GRID -> listOf(Region(0f, 0f, .5f, .5f), Region(.5f, 0f, .5f, .5f), Region(0f, .5f, .5f, .5f), Region(.5f, .5f, .5f, .5f))
        Layout.MANY -> {
            // Up to 9 pictures: 3 columns; the main picture first.
            val n = slots.size + 1
            val cols = if (n <= 4) 2 else 3
            val rows = (n + cols - 1) / cols
            (0 until n).map { i -> Region((i % cols).toFloat() / cols, (i / cols).toFloat() / rows, 1f / cols, 1f / rows) }
        }
    }

    /** Moves every window one place along (the last one comes first). */
    fun rotateWindows() {
        if (slots.size < 2) return
        val last = slots.removeAt(slots.lastIndex)
        slots.add(0, last)
    }

    /** Puts a window at the front (the first place in a layout). */
    fun moveToFront(id: Int) {
        val i = slots.indexOfFirst { it.id == id }
        if (i > 0) slots.add(0, slots.removeAt(i))
    }

    internal fun insertFirst(slot: Slot) { slots.add(0, slot) }

    private fun applySound() {
        for (s in slots) s.player.volume = if (s.id == soundId) 1f else 0f
    }

    /** The windows play only while a screen shows them. */
    fun attach() {
        hosts++
        slots.forEach { it.player.playWhenReady = true }
    }

    fun detach() {
        hosts = (hosts - 1).coerceAtLeast(0)
        if (hosts == 0) slots.forEach { it.player.playWhenReady = false }
    }
}

/**
 * The main picture ([main], given the modifier for its place) and the windows, in the current layout.
 * [onSelect] runs when a window is selected (Live TV swaps it with the main channel); by default
 * selecting a window gives it the sound. With [enabled] false only the main picture is shown.
 */
@Composable
fun MultiView(
    modifier: Modifier = Modifier,
    focusable: Boolean = true,
    enabled: Boolean = true,
    onSelect: ((Corners.Slot) -> Unit)? = null,
    main: (@Composable (Modifier) -> Unit)? = null,
) {
    DisposableEffect(Unit) {
        Corners.attach()
        onDispose { Corners.detach() }
    }
    BoxWithConstraints(modifier.fillMaxSize()) {
        val regions = if (enabled) Corners.regions() else null
        fun place(r: Region): Modifier =
            Modifier.offset(x = maxWidth * r.x, y = maxHeight * r.y).size(maxWidth * r.w, maxHeight * r.h)
        main?.invoke(regions?.getOrNull(0)?.let { place(it) } ?: Modifier.fillMaxSize())
        if (!enabled) return@BoxWithConstraints
        val w = maxWidth * (if (Corners.large) 0.4f else 0.27f)
        Corners.slots.forEachIndexed { i, slot ->
            val shape = RoundedCornerShape(if (regions != null) 0.dp else 6.dp)
            val sound = Corners.soundId == slot.id
            val box = regions?.getOrNull(i + 1)?.let { place(it).padding(2.dp) } ?: run {
                val align = when (i) {
                    0 -> Alignment.BottomEnd
                    1 -> Alignment.BottomStart
                    2 -> Alignment.TopStart
                    else -> Alignment.TopEnd
                }
                Modifier.align(align).padding(12.dp).width(w).aspectRatio(16f / 9f)
            }
            key(slot.id) {
                var m = box
                if (focusable) m = m.focusRing(shape)
                val select = { onSelect?.invoke(slot) ?: Corners.toggleSound(slot.id) }
                var drag = 0f
                Box(
                    m.clip(shape).background(Color.Black)
                        .border(2.dp, if (sound) MaterialTheme.colorScheme.primary else Color(0x88FFFFFF), shape)
                        // Screen gestures (Settings > MultiView): double tap, swipe up, swipe down.
                        .pointerInput(slot.id) {
                            detectVerticalDragGestures(onDragStart = { drag = 0f }, onVerticalDrag = { _, d -> drag += d }, onDragEnd = {
                                if (drag < -60 && Opt.str(Opt.MV_UP, "resize") == "resize") Corners.toggleSize()
                                if (drag > 60 && Opt.str(Opt.MV_DOWN, "close") == "close") Corners.close(slot.id)
                            })
                        }
                        .combinedClickable(enabled = focusable, onClick = { select() }, onDoubleClick = {
                            when (Opt.str(Opt.MV_DOUBLE, "fullscreen")) {
                                "fullscreen" -> select()
                                "sound" -> Corners.toggleSound(slot.id)
                            }
                        }),
                ) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        // A TextureView keeps the window drawn above the main video.
                        factory = { c ->
                            (android.view.LayoutInflater.from(c).inflate(R.layout.pip_player_view, null) as PlayerView)
                                .apply { player = slot.player; useController = false }
                        },
                    )
                    val icon = when {
                        sound && !Opt.bool(Opt.MV_HIDE_AUDIO, false) -> "🔊 "
                        !sound && !Opt.bool(Opt.MV_HIDE_MUTED, false) -> "🔇 "
                        else -> ""
                    }
                    Text(icon + slot.title, style = MaterialTheme.typography.labelSmall, maxLines = 1,
                        modifier = Modifier.align(Alignment.BottomStart).background(Color(0xAA000000)).padding(horizontal = 4.dp))
                    Corners.errors[slot.id]?.let {
                        Text(it, style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.Center).padding(6.dp))
                    }
                }
            }
        }
    }
}

/** Just the windows (the main picture is drawn elsewhere, as in games). */
@Composable
fun CornerWindows(modifier: Modifier = Modifier, focusable: Boolean = true, onSelect: ((Corners.Slot) -> Unit)? = null) =
    MultiView(modifier, focusable, true, onSelect, null)

/** Choose a Live TV channel for a new corner window (recent and favorite channels first). */
@Composable
fun CornerPickerDialog(onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var q by androidx.compose.runtime.remember { mutableStateOf("") }
    val all = Corners.channelChoices
    val shown = if (q.isBlank()) all else all.filter { it.name.contains(q.trim(), true) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Channel for a corner window") },
        text = {
            androidx.compose.foundation.layout.Column {
                androidx.compose.material3.OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true,
                    placeholder = { Text("Search channels") })
                if (all.isEmpty()) Text("Open Live TV once so your channels are loaded.", modifier = Modifier.padding(top = 8.dp))
                androidx.compose.foundation.lazy.LazyColumn(Modifier.padding(top = 8.dp).heightIn(max = 360.dp)) {
                    items(shown.size) { i ->
                        val ch = shown[i]
                        ListRow(title = ch.name, subtitle = ch.group, onClick = {
                            Corners.addChannel(ctx, ch)
                            onDismiss()
                        })
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

