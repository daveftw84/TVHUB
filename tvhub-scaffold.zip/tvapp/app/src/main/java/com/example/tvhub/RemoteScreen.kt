package com.example.tvhub

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Companion Remote: this phone controls TV Hub on a TV on the same Wi-Fi
 * (arrows, OK, back, play, channels, volume, typing), and works as a controller in games too.
 */
@Composable
fun CompanionRemote() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var tvs by remember { mutableStateOf<List<CastSend.Tv>?>(null) }
    var tv by remember { mutableStateOf<CastSend.Tv?>(null) }
    var address by remember { mutableStateOf("") }
    var manual by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { tvs = withContext(Dispatchers.IO) { CastSend.discover(ctx) } }

    val current = tv
    if (current == null) {
        Text("TV Hub devices on your Wi-Fi appear here", textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(12.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFF151517)).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            when {
                tvs == null -> Text("Looking for TVs…")
                tvs!!.isEmpty() -> {
                    Text("📺", style = MaterialTheme.typography.headlineLarge)
                    Text("No devices found on your network")
                    Text("Open TV Hub on the TV, turn on Settings → Casting → Receive casts, and use the same Wi-Fi",
                        style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    TextButton(onClick = { tvs = null; scope.launch { tvs = withContext(Dispatchers.IO) { CastSend.discover(ctx) } } }) { Text("Search again") }
                }
                else -> tvs!!.forEach { t ->
                    Row(Modifier.fillMaxWidth().focusRing().clickable { tv = t }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("📺  ", style = MaterialTheme.typography.titleLarge)
                        Column(Modifier.weight(1f)) {
                            Text(t.name, style = MaterialTheme.typography.titleMedium)
                            Text(t.base.removePrefix("http://"), style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA))
                        }
                        Text("Connect ›", color = Color(0xFF4D8DFF))
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().clickable { manual = !manual }.padding(vertical = 14.dp)) {
            Text(if (manual) "⌄  " else "›  ", fontWeight = FontWeight.Bold)
            Text("Manual Connection", fontWeight = FontWeight.Bold)
        }
        if (manual) {
            OutlinedTextField(value = address, onValueChange = { address = it }, singleLine = true,
                label = { Text("TV's address, like 192.168.1.20") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                status = "Connecting…"
                scope.launch {
                    val t = withContext(Dispatchers.IO) { CastSend.connect(ctx, address) }
                    if (t != null) { tv = t; status = null } else status = "TV Hub not found at that address."
                }
            }, modifier = Modifier.padding(top = 8.dp)) { Text("Connect") }
            status?.let { Text(it, modifier = Modifier.padding(top = 6.dp)) }
        }
        return
    }

    fun press(k: String) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); CastSend.remote(current.base, k) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("📺 ${current.name}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        TextButton(onClick = { tv = null }) { Text("Change") }
    }
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        RemoteKey("⏻ Back") { press("back") }
        RemoteKey("☰ Menu") { press("menu") }
        RemoteKey("🔍") { press("search") }
    }
    Spacer(Modifier.height(16.dp))
    // The D-pad.
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
    Box(Modifier.size(260.dp).clip(CircleShape).background(Color(0xFF232326)), contentAlignment = Alignment.Center) {
        PadArrow("▲", Modifier.align(Alignment.TopCenter)) { press("up") }
        PadArrow("▼", Modifier.align(Alignment.BottomCenter)) { press("down") }
        PadArrow("◀", Modifier.align(Alignment.CenterStart)) { press("left") }
        PadArrow("▶", Modifier.align(Alignment.CenterEnd)) { press("right") }
        Box(Modifier.size(96.dp).clip(CircleShape).background(Color(0xFF3A3A3F)).clickable { press("ok") }, contentAlignment = Alignment.Center) {
            Text("OK", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
    }
    Spacer(Modifier.height(16.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        RemoteKey("⏪") { press("rew") }
        RemoteKey("⏯") { press("play") }
        RemoteKey("⏩") { press("ff") }
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            RemoteKey("VOL +") { press("volup") }; Spacer(Modifier.height(6.dp)); RemoteKey("VOL −") { press("voldown") }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            RemoteKey("🔇") { press("mute") }; Spacer(Modifier.height(6.dp)); RemoteKey("Guide") { press("guide") }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            RemoteKey("CH ▲") { press("chup") }; Spacer(Modifier.height(6.dp)); RemoteKey("CH ▼") { press("chdown") }
        }
    }
    Spacer(Modifier.height(16.dp))
    // Type on the TV (search boxes, logins).
    var text by remember { mutableStateOf("") }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true, label = { Text("Type on the TV") },
            modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Button(onClick = { CastSend.remote(current.base, "", text); text = "" }, enabled = text.isNotEmpty()) { Text("Send") }
        TextButton(onClick = { press("del") }) { Text("⌫") }
    }
    Text("Tip: in a game on the TV, the arrows and OK work as the controller's D-pad and A button.",
        style = MaterialTheme.typography.bodySmall, color = Color(0xFFAAAAAA), modifier = Modifier.padding(top = 10.dp))
}

@Composable
private fun RemoteKey(label: String, onClick: () -> Unit) {
    Box(Modifier.width(96.dp).height(52.dp).clip(RoundedCornerShape(50)).background(Color(0xFF26272B)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) { Text(label, fontWeight = FontWeight.Bold) }
}

@Composable
private fun PadArrow(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.size(80.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, style = MaterialTheme.typography.headlineSmall, color = Color(0xFFDDDDDD))
    }
}
