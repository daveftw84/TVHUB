package com.example.tvhub

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Red = Color(0xFFFF5A5F)
private val Blue = Color(0xFF3D7BFF)

/**
 * The phone Live TV player, like iMPlayer: the picture on top with its own buttons, then the channel,
 * what's on, the description and the day-by-day schedule. Turn the phone (or ⤢) for full screen, with
 * swipe brightness (left) and volume (right), channel up/down, stream info, MultiView and more channels.
 */
@Composable
fun PhoneLivePlayer(vm: LiveViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    var resize by remember { mutableStateOf(0) }
    var channels by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    // Full screen hides the system bars; leaving restores them and lets the phone rotate freely again.
    DisposableEffect(landscape) {
        val w = activity?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, w.decorView)
            if (landscape) {
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.systemBars())
            } else c.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { }
    }
    DisposableEffect(Unit) {
        onDispose {
            activity?.window?.let { WindowCompat.getInsetsController(it, it.decorView).show(WindowInsetsCompat.Type.systemBars()) }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    fun setFull(on: Boolean) {
        activity?.requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT
    }
    if (landscape) BackHandler { setFull(false) }

    val cur = vm.current
    if (landscape) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            LiveVideo(vm, Modifier.fillMaxSize(), resize)
            FullControls(vm, resize, onResize = { resize = (resize + 1) % 3 }, onExit = { setFull(false) },
                onChannels = { channels = true }, onMenu = { menu = true })
            if (channels) ChannelSidePanel(vm) { channels = false }
        }
    } else {
        Column(Modifier.fillMaxSize().background(Color.Black)) {
            // Header: back, favorite, more.
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Glyph("←", 26) { onBack() }
                Text("Live TV", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 4.dp))
                if (cur != null) {
                    val fav = cur.key in vm.favorites
                    Box(Modifier.size(44.dp).clip(CircleShape).background(if (fav) Red else Color(0xFF2A2A2D)).clickable { vm.toggleFavorite(cur) },
                        contentAlignment = Alignment.Center) { Text(if (fav) "♥" else "♡", fontSize = 22.sp, color = Color.White) }
                }
                Glyph("⋮", 26) { menu = true }
            }
            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black)) {
                LiveVideo(vm, Modifier.fillMaxSize(), resize)
                SmallControls(vm, onFull = { setFull(true) }, onMultiView = { Corners.picking = true; channels = true })
            }
            if (cur != null) ChannelDetails(vm, cur) else Text("Pick a channel.", modifier = Modifier.padding(16.dp))
        }
        if (channels) ModalBottomSheet(onDismissRequest = { channels = false; Corners.picking = false }) {
            Box(Modifier.fillMaxWidth().heightIn(max = 560.dp)) { ChannelPickList(vm) { channels = false } }
        }
    }
    if (menu) PlayerMenu(vm, resize, onResize = { resize = (resize + 1) % 3 }) { menu = false }
}

// ---------------------------------------------------------------- Portrait: buttons over the picture

@Composable
private fun SmallControls(vm: LiveViewModel, onFull: () -> Unit, onMultiView: () -> Unit) {
    val ctx = LocalContext.current
    var shown by remember { mutableStateOf(true) }
    var touch by remember { mutableStateOf(0) }
    LaunchedEffect(shown, touch) { if (shown) { delay(4000); shown = false } }
    var playing by remember { mutableStateOf(vm.player.isPlaying) }
    var muted by remember { mutableStateOf(vm.player.volume == 0f) }
    LaunchedEffect(Unit) { while (true) { playing = vm.player.isPlaying || vm.player.playWhenReady; delay(500) } }
    // Corner windows take their own taps, so the tap-to-show layer is only there without them.
    val tapLayer = if (Corners.slots.isEmpty()) Modifier.pointerInput(Unit) { detectTapGestures { shown = !shown; touch++ } } else Modifier
    Box(Modifier.fillMaxSize().then(tapLayer)) {
        if (shown || Corners.slots.isNotEmpty()) {
            Round(if (muted) "🔇" else "🔊", Modifier.align(Alignment.TopStart).padding(10.dp)) {
                muted = !muted; vm.player.volume = if (muted) 0f else 1f; touch++
            }
            Row(Modifier.align(Alignment.TopEnd).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Round("⊞") { onMultiView() }
                (ctx as? Activity)?.takeIf { Pip.supported(it) }?.let { a -> Round("⧉") { Pip.enter(a) } }
                Round("⤢") { onFull() }
            }
        }
        if (shown && vm.playError == null) {
            Box(Modifier.align(Alignment.Center).size(64.dp).clip(CircleShape).background(Color(0x88000000))
                .border(2.dp, Color.White, CircleShape).clickable {
                    vm.player.playWhenReady = !vm.player.playWhenReady; touch++
                }, contentAlignment = Alignment.Center) {
                Text(if (playing) "❚❚" else "▶", color = Color.White, fontSize = 22.sp)
            }
        }
    }
}

// ---------------------------------------------------------------- Portrait: channel, now, description, schedule

@Composable
private fun ChannelDetails(vm: LiveViewModel, ch: Channel) {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); tick++ } }
    val now = remember(tick) { System.currentTimeMillis() }
    val (cur, _) = vm.nowNext(ch, now)
    val all = vm.programmesFor(ch)
    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val dayFmt = remember { SimpleDateFormat("EEE, d", Locale.getDefault()) }
    fun dayOf(t: Long) = Calendar.getInstance().apply { timeInMillis = t; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    val days = remember(all) { all.map { dayOf(it.start) }.distinct().sorted() }
    val today = dayOf(now)
    var day by remember(ch.key) { mutableStateOf(today) }
    val list = all.filter { dayOf(it.start) == day }
    val listState = rememberLazyListState()
    LaunchedEffect(ch.key, day, list.size) {
        val i = list.indexOfFirst { now < it.end }
        if (i > 0) listState.scrollToItem(i)
    }

    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(96.dp, 72.dp), contentAlignment = Alignment.Center) {
                    if (ch.logo != null) AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                    else Text("📺", fontSize = 44.sp)
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(vm.nameOf(ch), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    cur?.let {
                        Text(it.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${((it.end - now) / 60_000).coerceAtLeast(0)} minutes left", color = Color(0xFF999999))
                    }
                }
            }
        }
        cur?.let { p ->
            item {
                val f = ((now - p.start).toFloat() / (p.end - p.start).coerceAtLeast(1)).coerceIn(0f, 1f)
                Box(Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(14.dp).clip(RoundedCornerShape(50)).background(Color(0xFF2A2A2D))) {
                    Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(50)).background(Blue))
                }
            }
            item {
                val text = listOf(p.subTitle, p.desc).filter { it.isNotBlank() }.joinToString("\n")
                if (text.isNotEmpty()) Text(text, color = Color(0xFFAAAAAA), maxLines = 5, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp))
            }
        }
        if (days.isNotEmpty()) item {
            LazyRow(contentPadding = PaddingValues(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items(days) { d ->
                    Column(Modifier.clip(RoundedCornerShape(8.dp)).clickable { day = d }.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (d == today) "Today" else dayFmt.format(Date(d)), color = if (d == day) Blue else Color.White,
                            fontWeight = if (d == day) FontWeight.Bold else FontWeight.Normal)
                        Box(Modifier.padding(top = 4.dp).width(36.dp).height(3.dp).background(if (d == day) Blue else Color.Transparent))
                    }
                }
            }
        }
        if (all.isEmpty()) item { Text("No guide information for this channel.", color = Color(0xFF999999), modifier = Modifier.padding(18.dp)) }
        items(list.distinctBy { it.start.toString() + it.title }, key = { it.start.toString() + it.title }) { p ->
            val live = now in p.start until p.end
            val past = p.end <= now
            val reminderId = "${ch.key}-${p.start}"
            var reminded by remember(reminderId) { mutableStateOf(Reminders.isSet(ctx, reminderId)) }
            Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(50))
                .background(if (live) Color(0xFF3A2224) else Color(0xFF1E1E20))
                .clickable {
                    when {
                        live -> vm.play(ch)
                        past -> if (!vm.playCatchup(ch, p)) android.widget.Toast.makeText(ctx, "No catch-up for this programme.", android.widget.Toast.LENGTH_SHORT).show()
                        reminded -> { Reminders.cancel(ctx, reminderId); reminded = false }
                        else -> {
                            Reminders.set(ctx, reminderId, p.title, "Starting now on ${vm.nameOf(ch)}", p.start); reminded = true
                            android.widget.Toast.makeText(ctx, "Reminder set", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                val color = when { live -> Red; past -> Color(0xFF888888); else -> Color.White }
                Text(timeFmt.format(Date(p.start)), color = color, modifier = Modifier.width(96.dp))
                Text(p.title, color = color, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                when {
                    live -> Text("((•))", color = Red)
                    past && Catchup.providerHas(ch, p, Opt.str(Opt.CATCHUP, "auto")) -> Text("↺", color = Color(0xFF888888))
                    reminded -> Text("🔔")
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Full screen

@Composable
private fun FullControls(vm: LiveViewModel, resize: Int, onResize: () -> Unit, onExit: () -> Unit, onChannels: () -> Unit, onMenu: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val cur = vm.current
    var shown by remember { mutableStateOf(true) }
    var touch by remember { mutableStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf(false) }
    LaunchedEffect(shown, touch, info) { if (shown && !info) { delay(5000); shown = false } }
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1000); tick++ } }

    // Swipe up/down: left half brightness, right half volume.
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember { mutableStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol) }
    var bright by remember { mutableStateOf(activity?.window?.attributes?.screenBrightness ?: -1f) }
    var adjusting by remember { mutableStateOf<String?>(null) }
    var muted by remember { mutableStateOf(vm.player.volume == 0f) }

    if (locked) {
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { shown = !shown } }) {
            if (shown) Round("🔒", Modifier.align(Alignment.BottomEnd).padding(24.dp)) { locked = false; touch++ }
        }
        return
    }
    Box(Modifier.fillMaxSize()
        .pointerInput(Corners.slots.isEmpty()) { if (Corners.slots.isEmpty()) detectTapGestures { shown = !shown; touch++ } }
        .pointerInput(Unit) {
            var left = true
            detectVerticalDragGestures(
                onDragStart = { o -> left = o.x < size.width / 2 },
                onDragEnd = { adjusting = null },
                onDragCancel = { adjusting = null },
            ) { _, dy ->
                val delta = -dy / (size.height * 0.8f)
                if (left) {
                    bright = ((if (bright < 0) 0.5f else bright) + delta).coerceIn(0.02f, 1f)
                    activity?.window?.let { w -> w.attributes = w.attributes.apply { screenBrightness = bright } }
                    adjusting = "bright"
                } else {
                    volume = (volume + delta).coerceIn(0f, 1f)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, (volume * maxVol).toInt(), 0)
                    adjusting = "volume"
                }
            }
        }) {
        if (shown || adjusting != null) {
            // Brightness and volume.
            LevelPill(if (bright < 0) "AUTO" else "${(bright * 100).toInt()}%", "☀", if (bright < 0) 1f else bright, Modifier.align(Alignment.CenterStart).padding(start = 64.dp))
            LevelPill("${(volume * 100).toInt()}%", if (volume == 0f) "🔇" else "🔊", volume, Modifier.align(Alignment.CenterEnd).padding(end = 64.dp))
        }
        if (shown) {
        Box(Modifier.fillMaxSize().background(Color(0x66000000)))

        // Top: back, channel and programme, buttons.
        val (now, _) = cur?.let { vm.nowNext(it) } ?: (null to null)
        Row(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Glyph("←", 30) { onExit() }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(cur?.let { vm.nameOf(it) } ?: "", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                now?.let { Text(it.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            }
            Glyph("ⓘ", 26) { info = !info; touch++ }
            if (cur != null) {
                val recording = cur.url in Recorder.active
                Glyph(if (recording) "⏺" else "⤓", 26, if (recording) Red else Color.White) {
                    if (recording) Recorder.stop(ctx, cur.url)
                    else if (cur.url.substringBefore('?').endsWith(".m3u8")) android.widget.Toast.makeText(ctx, "This channel can't be recorded (HLS).", android.widget.Toast.LENGTH_SHORT).show()
                    else {
                        Recorder.start(ctx, cur.url, cur.name, (now?.end ?: (System.currentTimeMillis() + LiveViewModel.HOUR)) + Opt.int(Opt.REC_END, 2) * 60_000L)
                        android.widget.Toast.makeText(ctx, "Recording until the programme ends", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    touch++
                }
                Glyph(if (cur.key in vm.favorites) "♥" else "♡", 26, if (cur.key in vm.favorites) Red else Color.White) { vm.toggleFavorite(cur); touch++ }
            }
            Glyph(listOf("▭", "▬", "⛶")[resize], 26) { onResize(); touch++ }
            Glyph("CC", 18) { toggleSubtitles(vm); touch++ }
            activity?.takeIf { Pip.supported(it) }?.let { a -> Glyph("⧉", 26) { Pip.enter(a) } }
            Glyph("⚙", 26) { onMenu() }
        }

        // Middle: previous channel, rewind, play/pause, forward, next channel.
        val seekable = vm.player.isCurrentMediaItemSeekable
        Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
            Glyph("⏮", 34) { vm.previous(); touch++ }
            Glyph("↺", 30, if (seekable) Color.White else Color(0x66FFFFFF)) { if (seekable) vm.player.seekBack(); touch++ }
            Box(Modifier.size(70.dp).clip(CircleShape).background(Color.White).clickable { vm.player.playWhenReady = !vm.player.playWhenReady; touch++ },
                contentAlignment = Alignment.Center) {
                @Suppress("UNUSED_VARIABLE") val t = tick
                Text(if (vm.player.playWhenReady) "❚❚" else "▶", color = Color.Black, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Glyph("↻", 30, if (seekable) Color.White else Color(0x66FFFFFF)) { if (seekable) vm.player.seekForward(); touch++ }
            Glyph("⏭", 34) { vm.next(); touch++ }
        }

        if (info && now != null) {
            Column(Modifier.align(Alignment.CenterStart).padding(start = 32.dp).widthIn(max = 420.dp).clip(RoundedCornerShape(12.dp))
                .background(Color(0xDD000000)).padding(16.dp)) {
                Text(now.title, fontWeight = FontWeight.Bold, color = Color.White)
                if (now.subTitle.isNotEmpty()) Text(now.subTitle, color = Color(0xFFCCCCCC))
                Text(now.desc, color = Color(0xFFAAAAAA), maxLines = 8, overflow = TextOverflow.Ellipsis)
            }
        }

        // Bottom: programme progress, stream info, MultiView, more channels, lock, mute, exit.
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                @Suppress("UNUSED_VARIABLE") val t = tick
                now?.let { p ->
                    val el = (System.currentTimeMillis() - p.start).coerceAtLeast(0)
                    Text(hms(el), color = Color.White, fontWeight = FontWeight.Bold)
                    Text("  /  " + hms(p.end - p.start), color = Color(0xFFAAAAAA))
                }
                Spacer(Modifier.weight(1f))
                Glyph("🔒", 24) { locked = true; shown = false }
                Glyph(if (muted) "🔇" else "🔈", 24) { muted = !muted; vm.player.volume = if (muted) 0f else 1f; touch++ }
                Glyph("⤡", 26) { onExit() }
            }
            Spacer(Modifier.height(8.dp))
            val f = now?.let { ((System.currentTimeMillis() - it.start).toFloat() / (it.end - it.start).coerceAtLeast(1)).coerceIn(0f, 1f) } ?: 0f
            Box(Modifier.fillMaxWidth().height(4.dp).background(Color(0x55FFFFFF))) {
                Box(Modifier.fillMaxWidth(f).fillMaxHeight().background(Red))
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                @Suppress("UNUSED_VARIABLE") val t = tick
                val fmt = vm.player.videoFormat
                if (fmt != null && fmt.height > 0) {
                    Stat("${fmt.width} × ${fmt.height} (" + when { fmt.height >= 2160 -> "4K"; fmt.height >= 1080 -> "FHD"; fmt.height >= 720 -> "HD"; else -> "SD" } + ")")
                    if (fmt.frameRate > 0) Stat("${fmt.frameRate.toInt()} FPS")
                    val br = listOf(fmt.bitrate, fmt.averageBitrate, fmt.peakBitrate).firstOrNull { it > 0 }
                    if (br != null) Stat("%.1f Mbps".format(br / 1_000_000f))
                }
                Spacer(Modifier.weight(1f))
                OutlineButton("⊞  Open MultiView") { Corners.picking = true; onChannels() }
                OutlineButton("☰  More Channels") { Corners.picking = false; onChannels() }
            }
        }
        }
    }
}

/** Full screen: the group's channels slide in from the right. */
@Composable
private fun ChannelSidePanel(vm: LiveViewModel, onClose: () -> Unit) {
    BackHandler { Corners.picking = false; onClose() }
    Row(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxHeight().clickable { Corners.picking = false; onClose() })
        Column(Modifier.width(380.dp).fillMaxHeight().background(Color(0xEE111113)).padding(8.dp)) {
            ChannelPickList(vm, onClose)
        }
    }
}

@Composable
private fun ChannelPickList(vm: LiveViewModel, onDone: () -> Unit) {
    Column {
        Text(if (Corners.picking) "Add a channel to MultiView" else vm.groupName, style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(horizontal = 8.dp)) {
            itemsIndexed(vm.groups) { i, g -> PillChip(g, i == vm.groupIndex) { vm.selectGroup(i) } }
        }
        val list = vm.visibleChannels
        val state = rememberLazyListState()
        LaunchedEffect(vm.groupIndex) {
            val i = list.indexOfFirst { it.url == vm.current?.url }
            if (i > 2) state.scrollToItem(i - 2)
        }
        LazyColumn(state = state, modifier = Modifier.fillMaxWidth()) {
            items(list.distinctBy { it.key + it.url }, key = { it.key + it.url }) { ch ->
                val on = ch.url == vm.current?.url
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (on) Color(0xFF2E2E33) else Color.Transparent)
                    .clickable { vm.choose(ch); onDone() }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp, 36.dp), contentAlignment = Alignment.Center) {
                        if (ch.logo != null) AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                        else Text("📺")
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(vm.nameOf(ch), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        vm.nowNext(ch).first?.let { Text(it.title, color = Color(0xFF999999), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    }
                }
            }
        }
    }
}

/** ⋮ / ⚙: everything else (aspect, subtitles, cast, record, mini player, corner layouts, other player). */
@Composable
private fun PlayerMenu(vm: LiveViewModel, resize: Int, onResize: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val cur = vm.current
    ModalBottomSheet(onDismissRequest = onClose) {
        Column(Modifier.padding(bottom = 24.dp)) {
            @Composable fun Item(icon: String, label: String, go: () -> Unit) {
                Row(Modifier.fillMaxWidth().clickable { go() }.padding(horizontal = 24.dp, vertical = 14.dp)) {
                    Text(icon, modifier = Modifier.width(36.dp)); Text(label)
                }
            }
            Item("▭", "Picture: " + listOf("Fit", "Fill", "Zoom")[resize]) { onResize() }
            Item("CC", "Subtitles on/off") { toggleSubtitles(vm) }
            Item("▣", if (vm.miniPlayer) "Mini player: on" else "Mini player: off") { vm.toggleMiniPlayer() }
            if (cur != null) {
                Item("↗", "Play in another app") {
                    onClose()
                    runCatching { ctx.startActivity(android.content.Intent.createChooser(android.content.Intent(android.content.Intent.ACTION_VIEW)
                        .setDataAndType(android.net.Uri.parse(cur.url), "video/*"), "Play with")) }
                }
                Row(Modifier.padding(horizontal = 16.dp)) { CastButton({ CastRequest("channel", url = cur.url, title = cur.name, channelKey = cur.key) }) }
            }
            if (Corners.slots.isNotEmpty()) {
                Text("MultiView", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                Row(Modifier.padding(horizontal = 16.dp).horizontalScrollCompat(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CornerButtons(onRotate = { vm.rotateScreens() })
                }
            }
        }
    }
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier = this.then(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()))

private fun toggleSubtitles(vm: LiveViewModel) {
    val p = vm.player
    val off = p.trackSelectionParameters.disabledTrackTypes.contains(androidx.media3.common.C.TRACK_TYPE_TEXT)
    p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
        .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, !off).build()
}

private fun hms(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) else "%02d:%02d".format(s / 60, s % 60)
}

// ---------------------------------------------------------------- Small pieces

@Composable
private fun Glyph(text: String, size: Int, color: Color = Color.White, onClick: () -> Unit) {
    Box(Modifier.size((size + 22).dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, fontSize = size.sp, color = color, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Round(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.size(48.dp).clip(CircleShape).background(Color(0x99333333)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, fontSize = 20.sp, color = Color.White)
    }
}

@Composable
private fun LevelPill(label: String, icon: String, level: Float, modifier: Modifier) {
    Box(modifier.size(92.dp, 200.dp).clip(RoundedCornerShape(50)).background(Color(0x66222222)), contentAlignment = Alignment.BottomCenter) {
        Box(Modifier.fillMaxWidth().fillMaxHeight(level.coerceIn(0f, 1f)).background(Color(0xEEFFFFFF)))
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 22.sp)
            Text(label, fontWeight = FontWeight.Bold, color = if (level > 0.45f) Color.Black else Color.White)
        }
    }
}

@Composable
private fun Stat(text: String) {
    Text(text, color = Color.White, style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(0x66222222)).border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(50))
            .padding(horizontal = 14.dp, vertical = 8.dp))
}

@Composable
private fun OutlineButton(text: String, onClick: () -> Unit) {
    Text(text, color = Color.White, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, Color.White, RoundedCornerShape(50)).clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp))
}
