package com.example.tvhub

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private val YtShape = RoundedCornerShape(8.dp)

@Composable
fun YouTubeScreen(vm: YouTubeViewModel) {
    LaunchedEffect(Unit) { vm.loadHome() }
    BackHandler(enabled = vm.canGoBack) { vm.back() }
    val playing = vm.playing
    if (playing != null) {
        key(playing.url) { YouTubePlayer(vm, playing) }
        return
    }
    Column(Modifier.fillMaxSize()) {
        TubeTopBar(vm)
        vm.notice?.let {
            Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp))
        }
        when (val s = vm.screen) {
            null -> TubeHome(vm)
            TubeScreen.Search -> TubeSearch(vm)
            TubeScreen.Library -> TubeLibrary(vm)
            TubeScreen.Explore -> TubeExplore(vm)
            is TubeScreen.Video -> TubeVideoPage(vm, s.video)
            is TubeScreen.Channel -> TubeChannelPage(vm, s.channel)
        }
    }
}

@Composable
private fun TubeChip(label: String, selected: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        label, style = MaterialTheme.typography.labelLarge, maxLines = 1,
        modifier = Modifier.focusRing(shape).clip(shape)
            .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp),
    )
}

@Composable
private fun TubeTopBar(vm: YouTubeViewModel) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        item { Text("YouTube", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(end = 8.dp)) }
        if (vm.screen != null) item { TubeChip("‹ Back") { vm.back() } }
        item { TubeChip("Home", vm.screen == null) { vm.goHome() } }
        item { TubeChip("🔍 Search", vm.screen == TubeScreen.Search) { vm.openSearch() } }
        item { TubeChip("Explore", vm.screen == TubeScreen.Explore) { vm.openExplore() } }
        item { TubeChip("Library", vm.screen == TubeScreen.Library) { vm.openLibrary() } }
        item { TubeChip(if (vm.hideShorts) "Shorts: hidden" else "Shorts: shown") { vm.toggleHideShorts() } }
        item { TubeChip(if (vm.sponsorBlock) "SponsorBlock: on" else "SponsorBlock: off") { vm.toggleSponsorBlock() } }
        item { TubeChip("Quality: up to ${vm.maxQuality}p") { vm.cycleQuality() } }
        item { TubeChip(if (vm.autoplayNext) "Autoplay: on" else "Autoplay: off") { vm.toggleAutoplay() } }
        item { TubeChip("⟳ Refresh") { vm.loadHome(true) } }
    }
}

// ---------------------------------------------------------------- Cards and rows

@Composable
fun TubeCard(v: TubeVideo, width: androidx.compose.ui.unit.Dp, progress: Float = 0f, onClick: () -> Unit) {
    Column(Modifier.width(width)) {
        Box(
            Modifier.width(width).aspectRatio(16f / 9f).focusRing(YtShape, 1.05f).clip(YtShape)
                .background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onClick),
        ) {
            if (v.thumb != null) AsyncImage(model = v.thumb, contentDescription = v.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            val badge = if (v.isLive) "LIVE" else YouTube.duration(v.durationSec)
            if (badge.isNotEmpty()) {
                Text(badge, style = MaterialTheme.typography.labelSmall, color = Color.White,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp).clip(RoundedCornerShape(4.dp))
                        .background(if (v.isLive) Color(0xFFCC0000) else Color(0xCC000000)).padding(horizontal = 4.dp))
            }
            if (progress > 0f) {
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(Color(0x66000000))) {
                    Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(Color(0xFFFF0000)))
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        Text(listOf(v.channel, if (v.views > 0) YouTube.compact(v.views) + " views" else "", v.ago.orEmpty()).filter { it.isNotEmpty() }.joinToString(" · "),
            maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun cardWidth() = if (rememberIsTv()) 260.dp else 200.dp

@Composable
private fun TubeRow(title: String, videos: List<TubeVideo>, onClick: (TubeVideo) -> Unit) {
    if (videos.isEmpty()) return
    val w = cardWidth()
    Column {
        Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(8.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(videos) { v -> TubeCard(v, w) { onClick(v) } }
        }
    }
}

@Composable
private fun VideoGrid(videos: List<TubeVideo>, vm: YouTubeViewModel, header: (@Composable () -> Unit)? = null) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(cardWidth()),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        if (header != null) item(span = { GridItemSpan(maxLineSpan) }) { header() }
        items(videos) { v -> TubeCard(v, cardWidth()) { vm.openVideo(v) } }
    }
}

// ---------------------------------------------------------------- Home

/** YouTube's home: a grid of recommended videos, with Continue Watching and your subscriptions on top. */
@Composable
private fun TubeHome(vm: YouTubeViewModel) {
    val cont = vm.continueWatching
    VideoGrid(vm.recommended, vm, header = {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (cont.isNotEmpty()) {
                val w = cardWidth()
                Column {
                    Text("Continue Watching", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(cont) { h ->
                            val p = if (h.durationMs > 0) (h.positionMs.toFloat() / h.durationMs).coerceIn(0f, 1f) else 0f
                            TubeCard(h.video, w, p) { vm.play(h.video) }
                        }
                    }
                }
            }
            if (vm.subscriptions.isNotEmpty() && vm.feed.isNotEmpty()) {
                val w = cardWidth()
                Column {
                    Text("New from Your Subscriptions", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(vm.feed.take(30)) { v -> TubeCard(v, w) { vm.openVideo(v) } } }
                }
            }
            Text("Recommended", style = MaterialTheme.typography.titleMedium)
            if (vm.recommended.isEmpty()) {
                Text(if (vm.loading) "Loading…" else "Watch a few videos and your recommendations appear here.")
            }
        }
    })
}

/** YouTube's own lists: Trending, Live, Music, Gaming, Podcasts, Movie trailers. */
@Composable
private fun TubeExplore(vm: YouTubeViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        items(vm.kiosks) { (name, videos) -> TubeRow(name, videos) { vm.openVideo(it) } }
        if (vm.kiosks.isEmpty()) item { Text(if (vm.loading) "Loading…" else "Nothing to show right now.", modifier = Modifier.padding(20.dp)) }
    }
}

// ---------------------------------------------------------------- Search

@Composable
private fun TubeSearch(vm: YouTubeViewModel) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Throwable) {} }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = vm.query, onValueChange = { vm.typeQuery(it) }, singleLine = true,
            placeholder = { Text("Search YouTube") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.search() }),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).focusRequester(focus),
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { TubeChip("Search") { vm.search() } }
            // Suggestions while typing, recent searches otherwise.
            if (vm.suggestions.isNotEmpty()) {
                items(vm.suggestions) { s -> TubeChip(s) { vm.search(s) } }
            } else {
                items(vm.recentSearches) { s -> TubeChip("🕘 $s") { vm.search(s) } }
                if (vm.recentSearches.isNotEmpty()) item { TubeChip("Clear") { vm.clearRecent() } }
            }
        }
        if (vm.searching) Text("Searching…", modifier = Modifier.padding(horizontal = 20.dp))
        VideoGrid(vm.results, vm, header = if (vm.channelResults.isEmpty()) null else ({
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(vm.channelResults) { c -> ChannelBubble(c) { vm.openChannel(c) } }
            }
        }))
    }
}

@Composable
private fun ChannelBubble(c: TubeChannel, onClick: () -> Unit) {
    Column(Modifier.width(110.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(84.dp).focusRing(CircleShape, 1.05f).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)) {
            if (c.avatar != null) AsyncImage(model = c.avatar, contentDescription = c.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        Text(c.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
        if (c.subscribers > 0) Text(YouTube.compact(c.subscribers) + " subscribers", style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------------------------------------------------------------- Video page

@Composable
private fun TubeVideoPage(vm: YouTubeViewModel, v: TubeVideo) {
    val info = vm.info
    var showDesc by remember(v.url) { mutableStateOf(false) }
    val channel = TubeChannel(info?.uploaderUrl ?: v.channelUrl ?: "", info?.uploaderName ?: v.channel,
        info?.uploaderAvatars?.maxByOrNull { it.height }?.url, info?.uploaderSubscriberCount ?: -1)
    VideoGrid(vm.related, vm, header = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Box(Modifier.width(if (rememberIsTv()) 420.dp else 240.dp).aspectRatio(16f / 9f).clip(YtShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)) {
                    if (v.thumb != null) AsyncImage(model = v.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(info?.name ?: v.title, style = MaterialTheme.typography.titleLarge, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    val views = info?.viewCount ?: v.views
                    Text(listOfNotNull(
                        views.takeIf { it > 0 }?.let { YouTube.compact(it) + " views" },
                        info?.textualUploadDate ?: v.ago,
                        vm.votes?.let { (l, d) -> "👍 ${YouTube.compact(l)}  👎 ${YouTube.compact(d)}" }
                            ?: info?.likeCount?.takeIf { it > 0 }?.let { "👍 ${YouTube.compact(it)}" },
                    ).joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { TubeChip(if (vm.resumeAt(v.url) > 0) "▶ Resume" else "▶ Play", true) { vm.play(v) } }
                        if (vm.resumeAt(v.url) > 0) item { TubeChip("Start over") { vm.savePosition(v, 0, 0); vm.play(v) } }
                        item { TubeChip("⧉ Play in corner") { vm.playInCorner(v) } }
                        item { CastButton({ CastRequest("youtube", url = v.url, title = v.title, art = v.thumb.orEmpty(), artist = v.channel, startMs = vm.resumeAt(v.url)) }) }
                        item { TubeChip(if (vm.watchLater.any { it.url == v.url }) "✓ Watch later" else "+ Watch later") { vm.toggleWatchLater(v) } }
                    }
                    if (channel.url.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TubeChip(channel.name + (if (channel.subscribers > 0) " · " + YouTube.compact(channel.subscribers) else "")) { vm.openChannel(channel) }
                            TubeChip(if (vm.isSubscribed(channel.url)) "✓ Subscribed" else "Subscribe", vm.isSubscribed(channel.url)) { vm.toggleSubscribe(channel) }
                        }
                    }
                }
            }
            if (vm.infoLoading) Text("Loading…")
            info?.description?.content?.takeIf { it.isNotBlank() }?.let { raw ->
                val text = remember(raw) { androidx.core.text.HtmlCompat.fromHtml(raw, androidx.core.text.HtmlCompat.FROM_HTML_MODE_COMPACT).toString() }
                Text(text, maxLines = if (showDesc) 200 else 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.focusRing().clickable { showDesc = !showDesc }.padding(4.dp))
            }
            if (vm.related.isNotEmpty()) Text("Up Next", style = MaterialTheme.typography.titleMedium)
        }
    })
}

// ---------------------------------------------------------------- Channel page

@Composable
private fun TubeChannelPage(vm: YouTubeViewModel, c: TubeChannel) {
    val page = vm.channelPage
    val ch = page?.channel ?: c
    VideoGrid(page?.videos.orEmpty(), vm, header = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            page?.banner?.let {
                AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(110.dp).clip(YtShape))
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)) {
                    ch.avatar?.let { AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                }
                Column(Modifier.weight(1f)) {
                    Text(ch.name, style = MaterialTheme.typography.titleLarge)
                    if (ch.subscribers > 0) Text(YouTube.compact(ch.subscribers) + " subscribers", style = MaterialTheme.typography.bodySmall)
                }
                TubeChip(if (vm.isSubscribed(ch.url)) "✓ Subscribed" else "Subscribe", vm.isSubscribed(ch.url)) { vm.toggleSubscribe(ch) }
            }
            if (page == null) Text("Loading…")
        }
    })
}

// ---------------------------------------------------------------- Library: subscriptions, watch later, history

@Composable
private fun TubeLibrary(vm: YouTubeViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Column {
                Text("Subscriptions (${vm.subscriptions.size})", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 20.dp))
                if (vm.subscriptions.isEmpty()) Text("Open a channel and press Subscribe.", modifier = Modifier.padding(20.dp))
                LazyRow(contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(vm.subscriptions) { c -> ChannelBubble(c) { vm.openChannel(c) } }
                }
            }
        }
        item { TubeRow("Watch Later", vm.watchLater) { vm.openVideo(it) } }
        item { TubeRow("History", vm.history.map { it.video }) { vm.openVideo(it) } }
        if (vm.history.isNotEmpty()) item {
            Row(Modifier.padding(horizontal = 20.dp)) { TubeChip("Clear history") { vm.clearHistory() } }
        }
    }
}

// ---------------------------------------------------------------- Player

@Composable
private fun YouTubePlayer(vm: YouTubeViewModel, v: TubeVideo) {
    val ctx = LocalContext.current
    val info = vm.playingInfo
    if (info == null) {
        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) { Text("Loading ${v.title}…", color = Color.White) }
        return
    }
    var quality by remember { mutableStateOf(vm.maxQuality) }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var showTools by remember { mutableStateOf(false) }
    var speed by remember { mutableStateOf(1f) }
    var segments by remember { mutableStateOf<List<YouTube.Segment>>(emptyList()) }

    // (Re)load the streams for the chosen quality, keeping the position.
    LaunchedEffect(quality) {
        val pos = if (player.currentPosition > 0) player.currentPosition else vm.resumeAt(v.url)
        val src = withContext(Dispatchers.Default) { runCatching { YouTube.mediaSource(info, quality) } }
        src.onSuccess {
            player.setMediaSource(it)
            player.prepare()
            if (pos > 0) player.seekTo(pos)
            player.playWhenReady = true
        }.onFailure { vm.showNotice("Couldn't play: ${it.message}"); vm.stopPlaying() }
    }
    // SponsorBlock: skip sponsors, self-promotion, reminders to subscribe, intros and outros.
    LaunchedEffect(Unit) {
        if (vm.sponsorBlock) YouTube.videoId(v.url)?.let { id ->
            segments = withContext(Dispatchers.IO) {
                YouTube.sponsorSegments(id, listOf("sponsor", "selfpromo", "interaction", "intro", "outro", "music_offtopic"))
            }
        }
    }
    LaunchedEffect(segments) {
        var tick = 0
        while (true) {
            delay(500)
            val pos = player.currentPosition
            segments.firstOrNull { pos >= it.startMs && pos < it.endMs - 500 }?.let { seg ->
                player.seekTo(seg.endMs)
                Toast.makeText(ctx, "Skipped ${seg.category.replace('_', ' ')}", Toast.LENGTH_SHORT).show()
            }
            if (++tick % 20 == 0 && player.duration > 0) vm.savePosition(v, pos, player.duration)
        }
    }
    DisposableEffect(Unit) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    vm.savePosition(v, 0, player.duration)
                    val next = if (vm.autoplayNext) vm.nextAfter(v) else null
                    if (next != null) vm.play(next) else vm.stopPlaying()
                }
            }
        }
        player.addListener(listener)
        onDispose {
            if (player.duration > 0 && player.playbackState != Player.STATE_ENDED) vm.savePosition(v, player.currentPosition, player.duration)
            player.removeListener(listener)
            player.release()
        }
    }
    LaunchedEffect(Corners.mainMuted) { player.volume = if (Corners.mainMuted) 0f else 1f }
    var cornerPicker by remember { mutableStateOf(false) }

    BackHandler { if (showTools) showTools = false else vm.back() }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        MultiView(enabled = !Pip.active) { m ->
            AndroidView(modifier = m, factory = { c -> PlayerView(c).apply { this.player = player; useController = true }.applyOptions() },
                update = { it.useController = !Pip.active })
        }
        if (cornerPicker) CornerPickerDialog { cornerPicker = false }
        if (!Pip.active) Row(Modifier.align(Alignment.TopEnd).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (showTools) {
                val qs = remember(info) { YouTube.qualities(info) }
                TubeChip("Quality: ${quality}p") {
                    val opts = qs.ifEmpty { listOf(720) }
                    val cur = opts.indexOfFirst { it <= quality }.coerceAtLeast(0)
                    quality = opts[(cur + 1) % opts.size]
                }
                TubeChip("Speed ${speed}x") {
                    val sp = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
                    speed = sp[(sp.indexOf(speed) + 1) % sp.size]
                    player.setPlaybackSpeed(speed)
                }
                TubeChip("Skip +10s") { player.seekTo(player.currentPosition + 10_000) }
                vm.nextAfter(v)?.let { n -> TubeChip("Next ▶") { vm.play(n) } }
                if (!Corners.full) TubeChip("⧉ TV in corner") { showTools = false; cornerPicker = true }
                if (Corners.slots.isNotEmpty()) TubeChip("▦ ${Corners.layout.label}") { Corners.cycleLayout() }
                (ctx as? android.app.Activity)?.takeIf { Pip.supported(it) }?.let { a -> TubeChip("Float over apps") { showTools = false; Pip.enter(a) } }
            }
            TubeChip(if (showTools) "Close" else "⋯", showTools) { showTools = !showTools }
        }
        if (segments.isNotEmpty() && !Pip.active) {
            Text("SponsorBlock: ${segments.size} segment(s)", style = MaterialTheme.typography.labelSmall, color = Color.White,
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp).background(Color(0x88000000)).padding(horizontal = 6.dp))
        }
    }
}
