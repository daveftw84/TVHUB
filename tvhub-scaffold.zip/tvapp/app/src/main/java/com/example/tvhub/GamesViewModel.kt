package com.example.tvhub

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

enum class GamesTab(val label: String) {
    CONSOLES("Consoles"), RECENT("Recently played"), FAVORITES("Favorites"), COLLECTIONS("Collections"),
    DOWNLOADED("Downloaded"), CLOUD("Cloud gaming"), MANAGE("Settings"),
}

/** What a game grid shows: a console, a collection, favourites or recently played. */
data class GameList(val title: String, val query: RommQuery, val console: Console? = null, val filterable: Boolean = true)

enum class GameSort(val label: String, val orderBy: String, val dir: String) {
    NAME("A–Z", "name", "asc"),
    ADDED("Recently added", "created_at", "desc"),
    RELEASED("Release date", "first_release_date", "desc"),
    RATING("Rating", "average_rating", "desc"),
}

/** The Games tab: a client for your RomM server (github.com/rommapp/romm). */
class GamesViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("tvhub", Context.MODE_PRIVATE)

    var catalog by mutableStateOf(GameCatalog.load(app))
        private set
    var tab by mutableStateOf(GamesTab.CONSOLES)
        private set
    var notice by mutableStateOf<String?>(null)
        private set

    // --- RomM ---
    var rommUrl by mutableStateOf(prefs.getString("romm_url", "") ?: "")
        private set
    private var rommToken: String? = prefs.getString("romm_token", null)
    var rommConnected by mutableStateOf(rommToken != null)
        private set
    var rommPlatforms by mutableStateOf<List<RommPlatform>>(emptyList())
        private set
    var rommBusy by mutableStateOf(false)
        private set
    var platformsLoading by mutableStateOf(false)
        private set

    // --- game grid ---
    var list by mutableStateOf<GameList?>(null)
        private set
    /** Kept for screens that only need the console being browsed. */
    val console: Console? get() = list?.console
    var query by mutableStateOf("")
        private set
    var sort by mutableStateOf(GameSort.NAME)
        private set
    var filters by mutableStateOf<Map<String, String>>(emptyMap())
        private set
    var filterValues by mutableStateOf<Map<String, List<String>>>(emptyMap())
        private set
    val results = mutableStateListOf<Game>()
    var total by mutableStateOf(0)
        private set
    var loading by mutableStateOf(false)
        private set
    private var loadJob: Job? = null

    // --- collections / favourites / play time ---
    var collections by mutableStateOf<List<RommCollection>>(emptyList())
        private set
    private var playing: Pair<Game, Long>? = null
    /** Core of the game running in the built-in player, so its saves can be uploaded afterwards. */
    private var playingCore: String? = null
    /** Emulator, core and save file of a game running in an emulator app, synced again afterwards. */
    private var playingSync: Triple<String, String?, SaveFile>? = null
    private val engine = SyncEngine(app)
    var syncSaves by mutableStateOf(prefs.getBoolean("games_sync_saves", true))
        private set

    fun updateSyncSaves(on: Boolean) {
        syncSaves = on
        prefs.edit().putBoolean("games_sync_saves", on).apply()
    }

    // --- downloads ---
    var downloads by mutableStateOf(loadDownloads())
        private set
    /** Download progress by game key, from the shared download queue (survives leaving the screen). */
    val progress get() = GameDownloads.progress

    // --- data folder ---
    var dataUrl by mutableStateOf(prefs.getString("games_data_url", null) ?: catalog.settings.remoteDataUrl)
        private set
    var updating by mutableStateOf(false)
        private set
    /** Bumped when a per-console launcher changes, so screens showing it redraw. */
    var choiceVersion by mutableStateOf(0)
        private set

    private suspend fun <T> io(block: () -> T): Result<T> = withContext(Dispatchers.IO) {
        try {
            Result.success(block())
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    fun showNotice(m: String?) { notice = m }

    fun openTab(t: GamesTab) {
        tab = t
        downloads = loadDownloads()   // downloads may have finished while you were away
        list = null
        notice = null
        results.clear()
        when (t) {
            GamesTab.RECENT, GamesTab.FAVORITES -> openSpecial(t)
            GamesTab.COLLECTIONS -> loadCollections()
            else -> {}
        }
    }

    // ------------------------------------------------------------ Consoles (RomM platforms)

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** The console settings (launcher, core, unzip) that a RomM platform uses: matched by id or folder-name aliases. */
    private fun settingsFor(p: RommPlatform): Console? {
        val keys = setOf(norm(p.slug), norm(p.fsSlug))
        return catalog.consoles.firstOrNull { c -> norm(c.id) in keys || c.aliases.any { norm(it) in keys } }
    }

    private fun toConsole(p: RommPlatform): Console {
        val base = settingsFor(p)
        return Console(
            id = "romm:${p.id}",
            name = p.name,
            maker = base?.maker.orEmpty(),
            year = base?.year ?: 0,
            libretro = base?.libretro.orEmpty(),
            exts = base?.exts ?: emptySet(),
            aliases = base?.aliases ?: emptyList(),
            launcher = base?.launcher ?: "open_with",
            core = base?.core.orEmpty(),
            postProcess = base?.postProcess ?: "none",
            description = base?.description.orEmpty(),
            logo = p.logo.orEmpty(),
            builtin = base?.builtin.orEmpty(),
        )
    }

    /** One tile per RomM platform. */
    val consoles: List<Console> get() = rommPlatforms.map { toConsole(it) }

    fun consoleById(id: String): Console? = consoles.firstOrNull { it.id == id }
    fun platformOf(c: Console): RommPlatform? = rommPlatforms.firstOrNull { "romm:${it.id}" == c.id }

    /** Launcher and core choices are remembered per data-folder console, so all its RomM platforms share them. */
    private fun choiceKey(c: Console): String {
        val p = platformOf(c) ?: return c.id
        return settingsFor(p)?.id ?: c.id
    }

    fun launcherFor(c: Console): Launcher {
        val id = prefs.getString("games_launcher_${choiceKey(c)}", null) ?: c.launcher
        return catalog.launchers.firstOrNull { it.id == id }
            ?: catalog.launchers.firstOrNull { it.id == "open_with" }
            ?: Launcher("open_with", "Open with", emptyList(), "", "", emptyList(), emptyList(), emptyList(), "")
    }

    fun setLauncher(c: Console, l: Launcher) {
        prefs.edit().putString("games_launcher_${choiceKey(c)}", l.id).apply()
        choiceVersion++
    }

    fun coreFor(c: Console): String = prefs.getString("games_core_${choiceKey(c)}", null) ?: c.core
    fun setCore(c: Console, core: String) {
        prefs.edit().putString("games_core_${choiceKey(c)}", core.trim()).apply()
    }

    fun isInstalled(l: Launcher): Boolean =
        l.packages.isEmpty() || GameLauncher.installedPackage(getApplication<Application>(), l) != null

    // ------------------------------------------------------------ Game grids

    private fun openList(l: GameList) {
        list = l
        query = ""
        filters = emptyMap()
        filterValues = emptyMap()
        sort = GameSort.NAME
        notice = null
        reload(0)
    }

    fun openConsole(c: Console) {
        val p = platformOf(c) ?: return
        openList(GameList(c.name, RommQuery(platformIds = listOf(p.id)), console = c))
    }

    fun openCollection(col: RommCollection) {
        openList(
            GameList(
                col.name,
                if (col.smart) RommQuery(smartCollectionId = col.id) else RommQuery(collectionId = col.id),
            )
        )
    }

    private fun openSpecial(t: GamesTab) {
        when (t) {
            GamesTab.RECENT -> openList(
                GameList("Recently played", RommQuery(lastPlayed = true, orderBy = "last_played", orderDir = "desc"), filterable = false)
            )
            GamesTab.FAVORITES -> openList(GameList("Favorites", RommQuery(favorite = true)))
            else -> {}
        }
    }

    fun closeConsole() {
        list = null
        loadJob?.cancel()
        results.clear()
    }

    fun updateQuery(q: String) {
        query = q
        reload(400)
    }

    fun setSortOrder(s: GameSort) {
        if (s == sort) return
        sort = s
        reload(0)
    }

    /** Sets (or with null clears) one filter, e.g. "genres" = "Platform". */
    fun setFilter(key: String, value: String?) {
        filters = if (value == null) filters - key else filters + (key to value)
        reload(0)
    }

    private fun effectiveQuery(l: GameList): RommQuery {
        val base = l.query.copy(search = query, filters = l.query.filters + filters)
        return if (l.query.lastPlayed || l.query.unplayed) base else base.copy(orderBy = sort.orderBy, orderDir = sort.dir)
    }

    private fun reload(delayMs: Long) {
        loadJob?.cancel()
        results.clear()
        total = 0
        val l = list ?: return
        loadJob = viewModelScope.launch {
            delay(delayMs)
            loadPage(l)
        }
    }

    fun loadMore() {
        val l = list ?: return
        if (loading || results.size >= total) return
        loading = true
        loadJob = viewModelScope.launch { loadPage(l) }
    }

    private suspend fun loadPage(l: GameList) {
        val token = rommToken ?: return
        loading = true
        notice = null
        val first = results.isEmpty()
        val r = io {
            RommApi.roms(rommUrl, token, effectiveQuery(l), offset = results.size,
                withFilterValues = first && l.filterable && filterValues.isEmpty())
        }
        loading = false
        val pg = r.getOrNull()
        if (pg == null) {
            notice = "Couldn't load games from RomM: ${r.exceptionOrNull()?.message}"
            return
        }
        if (pg.filterValues.isNotEmpty()) filterValues = pg.filterValues
        results.addAll(pg.games.filter { g -> results.none { it.key == g.key } })
        total = pg.total
        if (results.isEmpty()) notice = when {
            query.isNotBlank() || filters.isNotEmpty() -> "Nothing found."
            l.query.lastPlayed -> "Nothing played yet. Games you play from here show up in this list."
            l.query.favorite -> "No favorites yet. Open a game and choose Favorite."
            else -> "No games here."
        }
    }

    // ------------------------------------------------------------ Your rating, status, hiding; random and unplayed

    private fun updateProps(g: Game, data: JSONObject, done: String, after: (() -> Unit)? = null) {
        val token = rommToken ?: return
        val romId = idOf(g)
        if (romId == 0) return
        viewModelScope.launch {
            val r = io { RommApi.updateProps(rommUrl, token, romId, data) }
            notice = if (r.isSuccess) done else "Couldn't update RomM: ${r.exceptionOrNull()?.message}"
            if (r.isSuccess) after?.invoke()
        }
    }

    private fun replaceResult(g: Game, updated: Game) {
        val i = results.indexOfFirst { it.key == g.key }
        if (i >= 0) results[i] = updated
    }

    fun rate(g: Game, rating: Int) =
        updateProps(g, JSONObject().put("rating", rating), if (rating == 0) "Rating cleared." else "Rated $rating/10.") {
            replaceResult(g, g.copy(myRating = rating))
        }

    fun setStatus(g: Game, status: String?) =
        updateProps(g, JSONObject().put("status", status ?: JSONObject.NULL), "Status updated.") {
            replaceResult(g, g.copy(status = status))
        }

    fun hide(g: Game) = updateProps(g, JSONObject().put("hidden", true), "Hidden. Unhide it in RomM's web page.") {
        results.removeAll { it.key == g.key }
    }

    /** Set to a random game so the screen can show it. */
    var randomPick by mutableStateOf<Game?>(null)
        private set

    fun pickRandom(c: Console? = null) {
        val token = rommToken ?: return
        val ids = c?.let { platformOf(it) }?.let { listOf(it.id) } ?: emptyList()
        viewModelScope.launch {
            val r = io { RommApi.random(rommUrl, token, ids) }
            randomPick = r.getOrNull()
            if (randomPick == null) notice = "Couldn't pick a game: ${r.exceptionOrNull()?.message ?: "none found"}"
        }
    }

    fun clearRandom() {
        randomPick = null
    }

    /** Highly rated games you haven't played yet. */
    fun openTopUnplayed() {
        openList(GameList("Top unplayed", RommQuery(unplayed = true, orderBy = "average_rating", orderDir = "desc"), filterable = false))
    }

    // ------------------------------------------------------------ BIOS files for emulator apps

    private suspend fun copyBiosFor(c: Console, profile: SaveProfile) {
        val token = rommToken ?: return
        val p = platformOf(c) ?: return
        val ctx = getApplication<Application>()
        if (!SaveLocator.hasStorageAccess(ctx)) return
        io {
            val files = BuiltinCores.ensureFirmware(ctx, rommUrl, token, p.id, null)
            if (files.isEmpty()) return@io
            @Suppress("DEPRECATION")
            val root = android.os.Environment.getExternalStorageDirectory()
            val dir = profile.biosPaths.map { File(root, it) }.firstOrNull { it.isDirectory }
                ?: File(root, profile.biosPaths.first()).apply { mkdirs() }
            for (f in files) {
                val dest = File(dir, f.name)
                if (!dest.exists() || dest.length() != f.length()) f.copyTo(dest, overwrite = true)
            }
        }
    }

    // ------------------------------------------------------------ Achievements

    data class AchievementView(val game: Game, val earned: Set<Int>?)

    var achievementsFor by mutableStateOf<AchievementView?>(null)
        private set

    /** Loads a game's RetroAchievements and which of them you've earned (both from RomM). */
    fun openAchievements(g: Game) {
        val token = rommToken ?: return
        val romId = idOf(g)
        achievementsFor = AchievementView(g, null)
        viewModelScope.launch {
            val details = io { RommApi.romDetails(rommUrl, token, romId) }.getOrNull() ?: g
            val earned = io { RommApi.raEarned(rommUrl, token) }.getOrNull()
            achievementsFor = AchievementView(details, earned?.get(details.raId) ?: emptySet())
        }
    }

    fun closeAchievements() {
        achievementsFor = null
    }

    // ------------------------------------------------------------ Music and sounds on the Games screens

    var musicUri by mutableStateOf(prefs.getString("games_music_uri", null))
        private set
    var uiSounds by mutableStateOf(prefs.getBoolean("games_ui_sounds", false))
        private set

    fun setMusic(uri: Uri?) {
        if (uri != null) {
            try {
                getApplication<Application>().contentResolver
                    .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
        }
        musicUri = uri?.toString()
        prefs.edit().putString("games_music_uri", musicUri).apply()
    }

    fun updateUiSounds(on: Boolean) {
        uiSounds = on
        prefs.edit().putBoolean("games_ui_sounds", on).apply()
    }

    // ------------------------------------------------------------ Collections and favourites

    fun loadCollections() {
        val token = rommToken ?: return
        viewModelScope.launch {
            val r = io { RommApi.collections(rommUrl, token) }
            r.getOrNull()?.let { collections = it }
            if (r.isFailure) notice = "Couldn't load collections: ${r.exceptionOrNull()?.message}"
        }
    }

    /** RomM's id for a game (also works for entries rebuilt from the Downloaded list). */
    fun idOf(g: Game): Int = g.rommId.takeIf { it > 0 } ?: g.key.removePrefix("romm:").toIntOrNull() ?: 0

    private val favorites: RommCollection? get() = collections.firstOrNull { it.favorite && !it.smart }

    fun isFavorite(g: Game): Boolean = favorites?.romIds?.contains(idOf(g)) == true

    fun toggleFavorite(g: Game) {
        val token = rommToken ?: return
        val romId = idOf(g)
        if (romId == 0) return
        val add = !isFavorite(g)
        viewModelScope.launch {
            val r = io {
                val id = favorites?.id ?: RommApi.createFavorites(rommUrl, token)
                RommApi.setInCollection(rommUrl, token, id, romId, add)
                RommApi.collections(rommUrl, token)
            }
            val cols = r.getOrNull()
            if (cols == null) {
                notice = "Couldn't change favorites: ${r.exceptionOrNull()?.message}"
            } else {
                collections = cols
                notice = if (add) "Added to favorites." else "Removed from favorites."
                if (list?.query?.favorite == true && !add) results.removeAll { it.key == g.key }
            }
        }
    }

    // ------------------------------------------------------------ Play time

    /** Called when the app comes back to the front: syncs the game's save with RomM and reports play time. */
    fun onResumed() {
        refreshPendingConflicts()
        val (g, start) = playing ?: return
        val core = playingCore
        val external = playingSync
        playing = null
        playingCore = null
        playingSync = null
        val end = System.currentTimeMillis()
        val token = rommToken ?: return
        val romId = idOf(g)
        if (romId == 0) return
        val base = rommUrl
        val ctx = getApplication<Application>()
        val play = if (end - start >= 30_000) SaveSync.PlayTime(romId, start, end) else null   // ignore quick bounces
        viewModelScope.launch {
            val synced = when {
                !syncSaves -> false
                core != null -> {
                    syncGame(g, core, core, LocalSaveFile(RommSaves.sramFile(ctx, core, g.key)), afterPlay = true, play = play)
                    // Save states are backed up too (RomM's device sync covers in-game saves).
                    io { RommSaves.push(base, token, "states", romId, core, RommSaves.stateFile(ctx, core, g.key), start) }
                    true
                }
                external != null -> {
                    syncGame(g, external.first, external.second, external.third, afterPlay = true, play = play)
                    true
                }
                else -> false
            }
            // Without a sync session, report play time on its own.
            if (!synced && play != null) io { RommApi.reportPlay(base, token, romId, start, end) }
        }
    }

    // ------------------------------------------------------------ Save sync (RomM device sync)

    data class SaveConflict(val title: String, val reason: String)

    /** Set while the user must choose between this device's save and RomM's. */
    var conflict by mutableStateOf<SaveConflict?>(null)
        private set
    private var conflictAnswer: CompletableDeferred<Boolean>? = null

    /** Conflicts background sync found and left for the user. */
    var pendingConflicts by mutableStateOf(prefs.getInt("sync_pending_conflicts", 0))
        private set

    fun refreshPendingConflicts() {
        pendingConflicts = prefs.getInt("sync_pending_conflicts", 0)
    }

    fun resolveConflict(keepRomm: Boolean) {
        conflict = null
        conflictAnswer?.complete(keepRomm)
        conflictAnswer = null
    }

    private suspend fun askConflict(title: String, reason: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        conflictAnswer = d
        conflict = SaveConflict(title, reason)
        return d.await()
    }

    /** The folder the user picked for an emulator's saves (overrides the usual folders). */
    fun saveFolder(launcherId: String): String? = prefs.getString("save_folder_$launcherId", null)

    var saveFoldersVersion by mutableStateOf(0)
        private set

    fun setSaveFolder(launcherId: String, uri: Uri) {
        try {
            getApplication<Application>().contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        } catch (_: Exception) {
        }
        prefs.edit().putString("save_folder_$launcherId", uri.toString()).apply()
        saveFoldersVersion++
    }

    fun hasStorageAccess(): Boolean = SaveLocator.hasStorageAccess(getApplication<Application>())

    /** Syncs one game's save with RomM, asking the user about conflicts. Returns a problem message or null. */
    private suspend fun syncGame(
        g: Game, emulator: String, core: String?, file: SaveFile, afterPlay: Boolean, play: SaveSync.PlayTime?,
    ): String? {
        val romId = idOf(g)
        if (romId == 0 || rommToken == null) return null
        val r = io {
            engine.sync(romId, emulator, core, file, afterPlay, play) { reason ->
                runBlocking { askConflict(g.title, reason) }
            }
        }
        val o = r.getOrNull() ?: return "Couldn't sync saves: ${r.exceptionOrNull()?.message}"
        // Background sync keeps this game's save in step from now on.
        engine.remember(SyncEngine.Target(romId, g.title, emulator, core, file.location))
        o.error?.let { notice = it }
        return o.error
    }

    /** Runs background sync now (also runs on its own every 15 minutes). */
    fun syncAllNow() {
        viewModelScope.launch {
            notice = "Syncing saves with RomM…"
            val r = io { engine.syncAll() }
            refreshPendingConflicts()
            val o = r.getOrNull()
            notice = when {
                o == null -> "Sync failed: ${r.exceptionOrNull()?.message}"
                o.skippedConflicts > 0 -> "${o.skippedConflicts} save conflict(s) need you: open those games and press Play."
                o.failed > 0 -> "${o.failed} save transfer(s) failed."
                else -> "Saves are in sync (${o.done} transfer(s))."
            }
        }
    }

    // --- save history and restore ---

    var history by mutableStateOf<List<SaveSync.Entry>?>(null)
        private set

    fun loadHistory(g: Game) {
        val token = rommToken ?: return
        val romId = idOf(g)
        history = null
        viewModelScope.launch {
            val r = io { SaveSync.history(rommUrl, token, romId) }
            history = r.getOrNull() ?: emptyList()
            if (r.isFailure) notice = "Couldn't load saves: ${r.exceptionOrNull()?.message}"
        }
    }

    fun isPinned(g: Game) = engine.isPinned(idOf(g))

    /** The game's serial for emulators that file saves by it (PSP). */
    private fun gameIdFor(g: Game, path: String?): String? =
        PspId.fromTitleId(g.titleId) ?: path?.takeIf { it.lowercase().endsWith(".iso") }?.let { PspId.fromIso(it) }

    /** Where a game's save lives for the emulator its console uses (null when unknown). */
    private fun saveTargetFor(g: Game): Triple<String, String?, SaveFile>? {
        val c = consoleById(g.console) ?: return null
        val ctx = getApplication<Application>()
        val l = launcherFor(c)
        if (l.id == "builtin") {
            val core = builtinCoreFor(c).ifEmpty { return null }
            return Triple(core, core, LocalSaveFile(RommSaves.sramFile(ctx, core, g.key)))
        }
        val d = downloadedCopy(g) ?: return null
        val profile = catalog.saveProfiles.firstOrNull { it.launcher == l.id } ?: return null
        val file = SaveLocator.locate(ctx, profile, saveFolder(profile.launcher), File(d.path).nameWithoutExtension,
            gameIdFor(g, d.path)) ?: return null
        val core = if (l.id == "retroarch") coreFor(c).removeSuffix("_libretro_android.so") else null
        return Triple(profile.launcher, core, file)
    }

    /** Puts an older save from RomM in place and pins it, so sync won't replace it until you play. */
    fun restore(g: Game, e: SaveSync.Entry) {
        val token = rommToken ?: return
        val target = saveTargetFor(g)
        if (target == null) {
            notice = "Download the game first, and make sure its emulator's save folder is set up in Settings."
            return
        }
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val r = io {
                val device = engine.deviceId() ?: throw IOException("Couldn't register this device with RomM")
                val bytes = SaveSync.download(rommUrl, token, device, null, e.id)
                SaveSync.backup(ctx, target.third)
                target.third.write(bytes)
                SaveSync.confirm(rommUrl, token, device, e.id, bytes)
                engine.setPinned(idOf(g), true)
            }
            notice = if (r.isSuccess) "Restored the save from ${e.updatedAt.take(16).replace('T', ' ')}. " +
                "It stays until your next play session is synced." else "Restore failed: ${r.exceptionOrNull()?.message}"
            history = null
        }
    }

    fun closeHistory() {
        history = null
    }

    private fun startedPlaying(g: Game) {
        playing = g to System.currentTimeMillis()
        rememberPlayed(g)
    }

    // ------------------------------------------------------------ Recently played (for Home)

    data class RecentGame(val game: Game, val playedAt: Long)

    var recentGames by mutableStateOf(loadRecent())
        private set

    private fun loadRecent(): List<RecentGame> = try {
        val a = org.json.JSONArray(prefs.getString("recent_games", "[]") ?: "[]")
        (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
            RecentGame(
                Game(
                    title = o.getString("title"),
                    console = o.optString("console"),
                    key = o.getString("key"),
                    art = o.optString("art").ifEmpty { null },
                    rommId = o.optInt("rommId"),
                ),
                o.optLong("at"),
            )
        }
    } catch (_: Exception) {
        emptyList()
    }

    private fun rememberPlayed(g: Game) {
        val list = (listOf(RecentGame(g, System.currentTimeMillis())) + recentGames.filter { it.game.key != g.key }).take(20)
        recentGames = list
        val a = org.json.JSONArray()
        for (r in list) {
            a.put(
                JSONObject().put("title", r.game.title).put("console", r.game.console).put("key", r.game.key)
                    .put("art", r.game.art ?: "").put("rommId", r.game.rommId).put("at", r.playedAt)
            )
        }
        prefs.edit().putString("recent_games", a.toString()).apply()
    }

    /** Set just before playing to start the game with a multiplayer room open. */
    var openRoomNext = false

    /** A game cast from a phone: get its details, then download (if needed) and play it, with a room open. */
    fun castPlay(rommId: Int) {
        val token = rommToken ?: run { notice = "A game was cast here, but RomM isn't connected on this TV."; return }
        viewModelScope.launch {
            val g = io { RommApi.romDetails(rommUrl, token, rommId) }.getOrNull()
            if (g == null) { notice = "Couldn't find the cast game on RomM."; return@launch }
            openRoomNext = true
            playOrDownload(g, true)
        }
    }

    /** Searches every game on your RomM server (used by Home's search). */
    suspend fun searchAll(q: String): List<Game> {
        val token = rommToken ?: return emptyList()
        return io { RommApi.roms(rommUrl, token, RommQuery(search = q), 0, 30).games }.getOrNull().orEmpty()
    }

    fun consoleName(id: String): String =
        consoles.firstOrNull { it.id == id }?.name ?: catalog.consoles.firstOrNull { it.id == id }?.name ?: id

    /** Opens a game's page on the Games tab (full details are fetched from RomM when connected). */
    fun showGame(g: Game) {
        val token = rommToken
        if (g.rommId == 0 || token == null) {
            randomPick = g
            return
        }
        viewModelScope.launch {
            randomPick = io { RommApi.romDetails(rommUrl, token, g.rommId) }.getOrNull() ?: g
        }
    }

    // ------------------------------------------------------------ Downloading and playing

    fun downloadedCopy(g: Game): Downloaded? = downloads.firstOrNull { it.sourceKey == g.key }

    private fun usesBuiltin(c: Console?): Boolean = c != null && launcherFor(c).id == "builtin"

    fun builtinCoreFor(c: Console): String = prefs.getString("games_builtin_${choiceKey(c)}", null) ?: c.builtin
    fun setBuiltinCore(c: Console, core: String) {
        prefs.edit().putString("games_builtin_${choiceKey(c)}", core.trim()).apply()
    }

    /**
     * Plays a game: downloads it from RomM first if needed (unzipping multi-disc games), then starts it
     * in the built-in player or the console's emulator app.
     */
    fun playOrDownload(g: Game, play: Boolean) {
        val c = consoleById(g.console)
        val builtin = usesBuiltin(c)
        // The built-in player needs a file it can read directly.
        val have = downloadedCopy(g)?.takeIf { !builtin || File(it.path).canRead() }
        if (have != null && !play) return
        if (have == null && g.url == null) {
            if (play) {
                notice = launch(g.console, g.path, g.uri)
                if (notice == null) startedPlaying(g)
            }
            return
        }
        if (progress.containsKey(g.key)) return
        viewModelScope.launch {
            val d = have ?: download(g, c, if (builtin) BuiltinCores.gamesRoot(getApplication<Application>()) else null)
                ?: return@launch
            if (!play) {
                notice = "Downloaded ${g.title}."
                return@launch
            }
            if (builtin && c != null) {
                notice = startBuiltin(g, c, d)
                if (notice == null) startedPlaying(g)
                return@launch
            }
            // Emulator apps: sync the save in the emulator's save folder before and after playing.
            val external = if (c != null && syncSaves && rommToken != null) {
                val l = launcherFor(c)
                val profile = catalog.saveProfiles.firstOrNull { it.launcher == l.id }
                val file = profile?.let {
                    SaveLocator.locate(getApplication<Application>(), it, saveFolder(it.launcher), File(d.path).nameWithoutExtension,
                        gameIdFor(g, d.path))
                }
                // BIOS files from RomM, copied where the emulator looks for them.
                if (profile != null && profile.biosPaths.isNotEmpty()) copyBiosFor(c, profile)
                if (profile != null && file != null) {
                    val core = if (l.id == "retroarch") coreFor(c).removeSuffix("_libretro_android.so") else null
                    notice = "Syncing saves with RomM…"
                    notice = syncGame(g, profile.launcher, core, file, afterPlay = false, play = null)
                    Triple(profile.launcher, core, file)
                } else null
            } else null
            val problem = launch(d.console, d.path, d.uri)
            if (problem != null) notice = problem
            else {
                startedPlaying(g)
                playingSync = external
            }
        }
    }

    private suspend fun download(g: Game, c: Console?, privateRoot: File?): Downloaded? {
        val url = g.url ?: return null
        val ctx = getApplication<Application>()
        val token = rommToken
        val folder = c?.let { platformOf(it)?.fsSlug } ?: "games"
        val relDir = if (privateRoot != null) folder else "${catalog.settings.downloadFolder}/$folder"
        notice = "Downloading ${g.title}…"
        // Runs in the download queue, so it carries on (with a notification) if you leave the app.
        val job = GameDownloads.start(ctx, g.key, g.title) { report ->
            val name = g.file ?: g.title
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 20_000
            conn.readTimeout = 60_000
            conn.setRequestProperty("User-Agent", "TVHub/2.1")
            if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
            if (conn.responseCode !in 200..299) throw IllegalStateException("RomM returned HTTP ${conn.responseCode}")
            val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else g.size
            // Arcade games stay zipped; multi-disc bundles and consoles marked "unzip" get unpacked.
            val unzip = name.lowercase().endsWith(".zip") && (g.bundle || c?.postProcess == "unzip")
            val saved = conn.inputStream.use { input ->
                if (unzip) GameFiles.saveUnzipped(ctx, relDir, g.title, input, total, privateRoot, report)
                else GameFiles.save(ctx, relDir, name, input, total, privateRoot, report)
            }
            val main = GameFiles.launchFile(saved, c)
            Downloaded(g.title, g.console, g.key, main.path, main.uri, saved.map { it.uri ?: it.path })
        }
        val d = try {
            job.await()
        } catch (e: Exception) {
            notice = "Download failed: ${e.message ?: "unknown error"}"
            return null
        }
        downloads = loadDownloads()
        return d
    }

    /** Gets the console's core (and BIOS files from RomM), then opens the built-in player. */
    private suspend fun startBuiltin(g: Game, c: Console, d: Downloaded): String? {
        val ctx = getApplication<Application>()
        val coreName = builtinCoreFor(c)
        if (coreName.isEmpty()) return "There's no built-in player for ${c.name}. Pick an emulator app in Settings."
        notice = "Getting the ${c.name} emulator…"
        val core = io { BuiltinCores.ensureCore(ctx, coreName) }
        val corePath = core.getOrNull()
            ?: return "Couldn't download the emulator: ${core.exceptionOrNull()?.message}"
        val p = platformOf(c)
        val token = rommToken
        if (p != null && token != null) {
            // BIOS files are optional for most consoles, so a failure here doesn't stop the game.
            io { BuiltinCores.ensureFirmware(ctx, rommUrl, token, p.id, File(d.path).parentFile) }
        }
        // Sync this game's save with RomM before starting (it may have been played on another device).
        val coreKey = File(corePath).name.removePrefix("lib").removeSuffix("_libretro_android.so")
        val romId = idOf(g)
        if (syncSaves && token != null && romId != 0) {
            notice = "Syncing saves with RomM…"
            notice = syncGame(g, coreKey, coreKey, LocalSaveFile(RommSaves.sramFile(ctx, coreKey, g.key)), afterPlay = false, play = null)
            if (!engine.isPinned(romId)) {
                io { RommSaves.pull(rommUrl, token, "states", romId, coreKey, RommSaves.stateFile(ctx, coreKey, g.key)) }
            }
        }
        val i = Intent(ctx, PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_OPEN_ROOM, openRoomNext.also { openRoomNext = false })
            .putExtra(PlayerActivity.EXTRA_CORE, corePath)
            .putExtra(PlayerActivity.EXTRA_ROM, d.path)
            .putExtra(PlayerActivity.EXTRA_TITLE, g.title)
            .putExtra(PlayerActivity.EXTRA_KEY, g.key)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            playingCore = coreKey
            null
        } catch (e: Exception) {
            "Couldn't start the player: ${e.message}"
        }
    }

    private fun launch(consoleId: String, path: String?, uri: String?): String? {
        val c = consoleById(consoleId) ?: return GameLauncher.openWith(getApplication<Application>(), path, uri)
        return GameLauncher.launch(getApplication<Application>(), launcherFor(c), coreFor(c), path, uri)
    }

    fun deleteDownload(d: Downloaded) {
        viewModelScope.launch {
            io { GameFiles.delete(getApplication<Application>(), d) }
            downloads = downloads.filter { it.sourceKey != d.sourceKey }
            saveDownloads()
        }
    }

    private fun loadDownloads(): List<Downloaded> = try {
        val a = JSONArray(prefs.getString("games_downloads_v2", "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
            val files = o.optJSONArray("files") ?: JSONArray()
            Downloaded(
                o.getString("title"), o.getString("console"), o.getString("sourceKey"),
                o.getString("path"), o.optString("uri").ifEmpty { null },
                (0 until files.length()).map { files.getString(it) },
            )
        }
    } catch (_: Exception) {
        emptyList()
    }

    private fun saveDownloads() {
        val a = JSONArray()
        downloads.forEach { d ->
            a.put(
                JSONObject().put("title", d.title).put("console", d.console).put("sourceKey", d.sourceKey)
                    .put("path", d.path).put("uri", d.uri.orEmpty()).put("files", JSONArray(d.files))
            )
        }
        prefs.edit().putString("games_downloads_v2", a.toString()).apply()
    }

    // ------------------------------------------------------------ RomM connection

    /** Pairs with a RomM server using the 8-digit code from RomM's Client API Tokens page. */
    fun connectRomm(url: String, code: String) {
        var base = url.trim().trimEnd('/')
        if (base.isNotEmpty() && !base.startsWith("http")) base = "http://$base"
        if (base.isEmpty() || code.isBlank()) {
            notice = "Enter your RomM address and the pairing code from RomM."
            return
        }
        rommBusy = true
        viewModelScope.launch {
            val r = io { RommApi.exchange(base, code.replace("-", "").replace(" ", "")) }
            rommBusy = false
            val token = r.getOrNull()
            if (token == null) {
                notice = "Pairing failed: ${r.exceptionOrNull()?.message}. Codes last 5 minutes and work once."
                return@launch
            }
            rommUrl = base
            rommToken = token
            rommConnected = true
            prefs.edit().putString("romm_url", base).putString("romm_token", token).apply()
            notice = "Connected to RomM."
            loadRommPlatforms()
            SaveSyncWorker.schedule(getApplication<Application>())
            tab = GamesTab.CONSOLES
        }
    }

    fun loadRommPlatforms() {
        val token = rommToken ?: return
        val base = rommUrl
        platformsLoading = true
        viewModelScope.launch {
            val r = io { RommApi.platforms(base, token) }
            platformsLoading = false
            val list = r.getOrNull()
            if (list == null) notice = "Couldn't reach RomM: ${r.exceptionOrNull()?.message}"
            else {
                rommPlatforms = list.sortedBy { it.name.lowercase() }
                prefs.edit().putString("romm_platforms_cache", RommApi.platformsToJson(rommPlatforms)).apply()
            }
            loadCollections()
        }
    }

    fun disconnectRomm() {
        rommToken = null
        rommConnected = false
        rommPlatforms = emptyList()
        list = null
        prefs.edit().remove("romm_token").remove("romm_device_id").remove("romm_platforms_cache").apply()
        SaveSyncWorker.cancel(getApplication<Application>())
        notice = "Disconnected from RomM."
    }

    // ------------------------------------------------------------ Data folder (consoles.json, launchers.json)

    fun updateData(url: String) {
        dataUrl = url.trim()
        prefs.edit().putString("games_data_url", dataUrl).apply()
        if (dataUrl.isEmpty()) {
            notice = "Enter the address of the folder that holds consoles.json and launchers.json."
            return
        }
        updating = true
        viewModelScope.launch {
            val r = io { GameCatalog.updateFromServer(getApplication<Application>(), dataUrl) }
            updating = false
            val n = r.getOrNull()
            notice = when {
                n == null -> "Update failed: ${r.exceptionOrNull()?.message}"
                n == 0 -> "No data files found at that address."
                else -> "Updated $n file(s)."
            }
            catalog = GameCatalog.load(getApplication<Application>())
        }
    }

    fun useBuiltIn() {
        GameCatalog.useBuiltIn(getApplication<Application>())
        catalog = GameCatalog.load(getApplication<Application>())
        notice = "Using the data built into the app."
    }

    val usingServerData: Boolean get() = GameCatalog.usingServerCopy(getApplication<Application>())

    // Last, so every property above is ready before it runs.
    init {
        if (rommToken != null) {
            // Show the last known consoles straight away (and offline), then refresh from the server.
            prefs.getString("romm_platforms_cache", null)?.let { cached ->
                try { rommPlatforms = RommApi.platformsFromJson(cached) } catch (_: Exception) {}
            }
            loadRommPlatforms()
            SaveSyncWorker.schedule(app)
        }
    }
}
