package com.example.tvhub

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.zip.GZIPInputStream

data class Programme(
    val channelId: String,
    val title: String,
    val desc: String,
    val start: Long,
    val end: Long,
    val subTitle: String = "",   // usually the episode name
    val season: Int = 0,         // 1-based, 0 = unknown
    val episode: Int = 0,        // 1-based, 0 = unknown
    val year: Int = 0,
    val categories: List<String> = emptyList(),
    val icon: String? = null,    // picture from the guide itself, when it has one
)

/** A downloaded guide: programmes by guide channel id, and guide channel ids by (normalized) channel name. */
data class Guide(val programmes: Map<String, List<Programme>>, val idsByName: Map<String, String>)

/** Channel names compared loosely: "ESPN HD", "US: ESPN (East)" and "espn" all become "espn". */
fun normalizeChannelName(name: String): String =
    name.lowercase()
        .replace(Regex("^[a-z]{2,3}\\s*[:|]\\s*"), "")          // "US: ", "UK | "
        .replace(Regex("\\((east|west|e|w|pacific)\\)|\\b(east|west)\\b"), "")
        .replace(Regex("\\b(fhd|uhd|hd|sd|4k|hevc|h265|1080p?|720p?|backup|raw)\\b"), "")
        .filter { it.isLetterOrDigit() }

object XmltvParser {
    /** Downloads an XMLTV guide (plain or .gz) and keeps only wanted channels within [from, to]. */
    fun fetch(url: String, wantedIds: Set<String>, wantedNames: Set<String>, from: Long, to: Long): Guide {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 90_000
        conn.setRequestProperty("User-Agent", USER_AGENT)
        if (conn.responseCode !in 200..299) throw IOException("Guide returned HTTP ${conn.responseCode}")
        var stream: InputStream = conn.inputStream
        if (url.substringBefore('?').endsWith(".gz")) stream = GZIPInputStream(stream)
        return stream.use { parse(it, wantedIds, wantedNames, from, to) }
    }

    fun parse(stream: InputStream, wantedIds: Set<String>, wantedNames: Set<String>, from: Long, to: Long): Guide {
        val fmt = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)
        fun time(s: String?): Long {
            if (s == null) return 0L
            val t = s.trim()
            return try {
                fmt.parse(if (t.contains(' ')) t else "$t +0000")?.time ?: 0L
            } catch (e: Exception) {
                0L
            }
        }

        val out = mutableMapOf<String, MutableList<Programme>>()
        val p = Xml.newPullParser()
        p.setInput(stream, null)

        var ch: String? = null
        var start = 0L
        var stop = 0L
        var title = ""
        var desc = ""
        var sub = ""
        var season = 0
        var episode = 0
        var year = 0
        var inProg = false
        var cats = ArrayList<String>()
        var icon: String? = null
        // <channel id="..."><display-name>ESPN</display-name></channel>: lets channels without a
        // matching tvg-id still find their guide by name.
        val idsByName = HashMap<String, String>()
        val accepted = HashSet<String>(wantedIds)
        var chanId: String? = null

        var event = p.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (p.name) {
                    "channel" -> chanId = p.getAttributeValue(null, "id")
                    "display-name" -> if (!inProg) {
                        val id = chanId
                        val n = normalizeChannelName(p.nextText())
                        if (id != null && n.isNotEmpty()) {
                            idsByName.putIfAbsent(n, id)
                            if (n in wantedNames) accepted += id
                        }
                    }
                    "category" -> if (inProg) cats.add(p.nextText().trim())
                    "icon" -> if (inProg && icon == null) icon = p.getAttributeValue(null, "src")
                    "programme" -> {
                        inProg = true
                        ch = p.getAttributeValue(null, "channel")
                        start = time(p.getAttributeValue(null, "start"))
                        stop = time(p.getAttributeValue(null, "stop"))
                        title = ""
                        desc = ""
                        sub = ""
                        season = 0
                        episode = 0
                        year = 0
                        cats = ArrayList()
                        icon = null
                    }
                    "title" -> if (inProg && title.isEmpty()) title = p.nextText()
                    "desc" -> if (inProg && desc.isEmpty()) desc = p.nextText()
                    "sub-title" -> if (inProg && sub.isEmpty()) sub = p.nextText()
                    "date" -> if (inProg) year = p.nextText().take(4).toIntOrNull() ?: 0
                    "episode-num" -> if (inProg) {
                        val system = p.getAttributeValue(null, "system").orEmpty()
                        val value = p.nextText().trim()
                        if (system == "xmltv_ns") {
                            // "season.episode.part", zero-based, e.g. "2.4." = S03E05
                            val parts = value.split('.')
                            val s = parts.getOrNull(0)?.substringBefore('/')?.trim()?.toIntOrNull()
                            val e = parts.getOrNull(1)?.substringBefore('/')?.trim()?.toIntOrNull()
                            if (s != null && e != null) { season = s + 1; episode = e + 1 }
                        } else if (season == 0) {
                            // "S03E05", "S3 E5"
                            Regex("(?i)S(\\d+)\\s*E(\\d+)").find(value)?.let {
                                season = it.groupValues[1].toInt()
                                episode = it.groupValues[2].toInt()
                            }
                        }
                    }
                }
            } else if (event == XmlPullParser.END_TAG && p.name == "programme") {
                inProg = false
                val id = ch
                if (id != null && id in accepted && stop > from && start < to) {
                    out.getOrPut(id) { mutableListOf() }.add(Programme(id, title, desc, start, stop, sub, season, episode, year, cats, icon))
                }
            }
            event = p.next()
        }
        return Guide(out.mapValues { (_, v) -> v.sortedBy { it.start } }, idsByName)
    }
}
