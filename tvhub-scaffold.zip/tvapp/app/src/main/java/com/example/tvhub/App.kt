package com.example.tvhub

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel

private enum class Tab(val label: String, val icon: ImageVector) {
    LIVE("Live TV", Icons.Default.PlayArrow),
    GUIDE("Guide", Icons.Default.List),
    LIBRARY("Library", Icons.Default.Home),
    RECORDINGS("Recordings", Icons.Default.DateRange),
    SETTINGS("Settings", Icons.Default.Settings),
}

@Composable
fun App() {
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            val vm: LiveViewModel = viewModel()
            val plex: PlexViewModel = viewModel()
            val tv = rememberIsTv()
            var tab by remember { mutableStateOf(Tab.LIVE) }

            // Live audio keeps playing on the Guide tab, but stops elsewhere.
            LaunchedEffect(tab) { vm.player.playWhenReady = tab == Tab.LIVE || tab == Tab.GUIDE }

            val body: @Composable (Modifier) -> Unit = { m ->
                Box(m) {
                    when (tab) {
                        Tab.LIVE -> LiveTvScreen(vm)
                        Tab.GUIDE -> GuideScreen(vm) { ch -> vm.play(ch); tab = Tab.LIVE }
                        Tab.LIBRARY -> LibraryScreen(plex)
                        Tab.RECORDINGS -> RecordingsScreen()
                        Tab.SETTINGS -> SettingsScreen(vm)
                    }
                }
            }

            if (tv) {
                // TV: side menu, driven by the remote's arrow keys.
                Row(Modifier.fillMaxSize()) {
                    NavigationRail {
                        Tab.values().forEach { t ->
                            NavigationRailItem(
                                selected = tab == t,
                                onClick = { tab = t },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label) },
                            )
                        }
                    }
                    body(Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                // Phone/tablet: tab bar along the bottom.
                Column(Modifier.fillMaxSize()) {
                    body(Modifier.weight(1f).fillMaxWidth())
                    NavigationBar {
                        Tab.values().forEach { t ->
                            NavigationBarItem(
                                selected = tab == t,
                                onClick = { tab = t },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label, maxLines = 1) },
                            )
                        }
                    }
                }
            }
        }
    }
}
