package com.example.tvhub

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.tv.material3.*

private enum class Tab(val label: String, val icon: ImageVector) {
    LIVE("Live TV", Icons.Default.PlayArrow),
    GUIDE("Guide", Icons.Default.List),
    LIBRARY("Library", Icons.Default.Home),
    RECORDINGS("Recordings", Icons.Default.DateRange),
    SETTINGS("Settings", Icons.Default.Settings),
}

@Composable
fun App() {
    MaterialTheme(colorScheme = darkColorScheme()) {
        // Surface supplies the background and the default text colour for everything inside.
        Surface(Modifier.fillMaxSize()) {
            val vm: LiveViewModel = viewModel()
            val plex: PlexViewModel = viewModel()
            var tab by remember { mutableStateOf(Tab.LIVE) }
            // Live audio keeps playing on the Guide tab, but stops elsewhere.
            LaunchedEffect(tab) { vm.player.playWhenReady = tab == Tab.LIVE || tab == Tab.GUIDE }

            NavigationDrawer(
                drawerContent = {
                    Column(Modifier.padding(12.dp)) {
                        Tab.values().forEach { t ->
                            NavigationDrawerItem(
                                selected = tab == t,
                                onClick = { tab = t },
                                leadingContent = { Icon(t.icon, contentDescription = t.label) },
                            ) { Text(t.label) }
                        }
                    }
                }
            ) {
                when (tab) {
                    Tab.LIVE -> LiveTvScreen(vm)
                    Tab.GUIDE -> GuideScreen(vm) { ch -> vm.play(ch); tab = Tab.LIVE }
                    Tab.LIBRARY -> LibraryScreen(plex)
                    Tab.RECORDINGS -> RecordingsScreen()
                    Tab.SETTINGS -> SettingsScreen(vm)
                }
            }
        }
    }
}
