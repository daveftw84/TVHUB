package com.example.tvhub

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import androidx.lifecycle.viewmodel.compose.viewModel

private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    LIVE("Live TV", Icons.Default.PlayArrow),
    GUIDE("Guide", Icons.Default.List),
    LIBRARY("Library", Icons.Default.Menu),
    YOUTUBE("YouTube", Icons.Default.ThumbUp),
    MUSIC("Music", Icons.Default.Favorite),
    SPORTS("Sports", Icons.Default.Star),
    GAMES("Games", Icons.Default.Star),
    RECORDINGS("Recordings", Icons.Default.DateRange),
    SETTINGS("Settings", Icons.Default.Settings),
}

@Composable
fun App() {
    // Settings > Appearance > Theme: OLED is pure black.
    val oled = Opt.str("theme", "dark") == "oled"
    MaterialTheme(colorScheme = if (oled) darkColorScheme(background = androidx.compose.ui.graphics.Color.Black,
        surface = androidx.compose.ui.graphics.Color.Black) else darkColorScheme()) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            val ctx = LocalContext.current
            val vm: LiveViewModel = viewModel()
            val plex: PlexViewModel = viewModel()
            val games: GamesViewModel = viewModel()
            val tube: YouTubeViewModel = viewModel()
            val music: MusicViewModel = viewModel()
            val appScope = androidx.compose.runtime.rememberCoroutineScope()
            val sports: SportsViewModel = viewModel()
            // Phones: Live TV shows the channel list first; picking a channel opens the player.
            var phonePlayer by remember { mutableStateOf(false) }
            var more by remember { mutableStateOf(false) }
            val tv = rememberIsTv()
            var tab by remember {
                // Settings > App Behavior > "On app load open" (or where you left off).
                Opt.init(ctx)
                val start = Opt.str(Opt.START_TAB, "HOME").let { if (it == "LAST") Opt.str("last_tab", "HOME") else it }
                mutableStateOf(Tab.values().firstOrNull { it.name == start && it != Tab.SETTINGS } ?: Tab.HOME)
            }
            LaunchedEffect(tab) { Opt.set("last_tab", tab.name) }
            // A title started from Home goes back to Home when the player closes.
            var playFromHome by remember { mutableStateOf(false) }
            var crash by remember { mutableStateOf(CrashLog.read(ctx)) }
            val clipboard = LocalClipboardManager.current

            val onLiveTabs = tab == Tab.LIVE || tab == Tab.GUIDE
            // A video playing full screen (Live TV, Plex or YouTube) pauses the music.
            val videoActive = (onLiveTabs && vm.current != null && !vm.listMode) || (plex.playing != null && tab == Tab.LIBRARY) ||
                (tube.playing != null && tab == Tab.YOUTUBE)
            LaunchedEffect(videoActive) { if (videoActive) MusicPlayer.pause() }
            val activity = ctx as? android.app.Activity

            // Button Mapper: remote buttons mapped to actions.
            LaunchedEffect(Buttons.pending) {
                val action = Buttons.pending?.first ?: return@LaunchedEffect
                Buttons.done()
                when (action) {
                    Buttons.Action.HOME -> tab = Tab.HOME
                    Buttons.Action.LIVE -> tab = Tab.LIVE
                    Buttons.Action.GUIDE -> tab = Tab.GUIDE
                    Buttons.Action.LIBRARY -> tab = Tab.LIBRARY
                    Buttons.Action.YOUTUBE -> tab = Tab.YOUTUBE
                    Buttons.Action.MUSIC -> tab = Tab.MUSIC
                    Buttons.Action.GAMES -> tab = Tab.GAMES
                    Buttons.Action.SETTINGS -> tab = Tab.SETTINGS
                    Buttons.Action.SEARCH -> { tab = Tab.HOME; Buttons.searchRequested = true }
                    Buttons.Action.LAST_CHANNEL -> { vm.playLast(); tab = Tab.LIVE }
                    Buttons.Action.CHANNEL_UP -> { vm.next(); if (!onLiveTabs) tab = Tab.LIVE }
                    Buttons.Action.CHANNEL_DOWN -> { vm.previous(); if (!onLiveTabs) tab = Tab.LIVE }
                    Buttons.Action.FAVORITE -> vm.current?.let { vm.toggleFavorite(it) }
                    Buttons.Action.FAVORITES -> { tab = Tab.LIVE; vm.selectGroup(1) }
                    Buttons.Action.ADD_CORNER -> { if (!onLiveTabs && plex.playing == null && tube.playing == null) tab = Tab.LIVE; Corners.picking = true }
                    Buttons.Action.LAYOUT -> Corners.cycleLayout()
                    Buttons.Action.CORNER_SOUND -> Corners.cycleSound()
                    Buttons.Action.CLOSE_CORNERS -> Corners.closeAll()
                    Buttons.Action.MUSIC_PLAY_PAUSE -> MusicPlayer.toggle()
                    Buttons.Action.MUSIC_NEXT -> MusicPlayer.next()
                    Buttons.Action.MINI_PLAYER -> vm.toggleMiniPlayer()
                    Buttons.Action.FLOAT -> if (activity != null && Pip.canEnter()) Pip.enter(activity)
                }
            }

            // Something cast to this TV (from TV Hub on a phone, or a DLNA app).
            LaunchedEffect(CastHub.incoming) {
                val c = CastHub.incoming ?: return@LaunchedEffect
                CastHub.consumed()
                fun asVideo() { if (c.url.isNotEmpty()) CastHub.playCast(c.url, c.title, c.startMs) }
                when (c.type) {
                    "youtube" -> { tube.play(TubeVideo(c.url, c.title, c.artist, null, c.art.ifEmpty { null }, 0, 0, null, false, false)); tab = Tab.YOUTUBE }
                    "plex" -> { if (plex.playByKey(c.ratingKey, c.startMs)) tab = Tab.LIBRARY else asVideo() }
                    "channel" -> {
                        val ch = vm.allChannels.firstOrNull { it.key == c.channelKey } ?: vm.allChannels.firstOrNull { it.url == c.url }
                        if (ch != null) { vm.play(ch); tab = Tab.LIVE } else asVideo()
                    }
                    "game" -> { games.castPlay(c.rommId); tab = Tab.GAMES }
                    "song" -> MusicPlayer.playAll(ctx, listOf(Song(c.url, c.title, c.artist, null, c.art.ifEmpty { null }, 0)))
                    else -> if (CastHub.castTitle == null) asVideo() else CastHub.castPlayer?.play()   // DLNA already loaded it
                }
            }
            // The small Live TV window on other tabs (turned on from Live TV), paused while a Plex video plays.
            val showMini = vm.miniPlayer && !onLiveTabs && vm.current != null && plex.playing == null && tube.playing == null && !Pip.active
            // Live audio keeps playing on the Guide tab (and in the mini player), but stops elsewhere.
            LaunchedEffect(tab, showMini, Pip.active, vm.listMode) {
                val live = (onLiveTabs && !vm.listMode) || showMini || (Pip.active && plex.playing == null)
                vm.playbackAllowed = live
                vm.player.playWhenReady = live
                if (tab != Tab.LIBRARY) playFromHome = false
            }
            LaunchedEffect(tab) { if (tab != Tab.LIBRARY) playFromHome = false }
            // What picture-in-picture would show: the Plex video, or Live TV.
            androidx.compose.runtime.SideEffect {
                Pip.canEnter = {
                    (plex.playing != null && tab == Tab.LIBRARY) || (tube.playing != null && tab == Tab.YOUTUBE) ||
                        (vm.current != null && (onLiveTabs || showMini))
                }
            }
            if (Pip.active) {
                Box(Modifier.fillMaxSize()) {
                    when {
                        plex.playing != null && tab == Tab.LIBRARY -> LibraryScreen(plex)
                        tube.playing != null && tab == Tab.YOUTUBE -> YouTubeScreen(tube)
                        else -> LiveVideo(vm, Modifier.fillMaxSize())
                    }
                }
                return@Surface
            }
            LaunchedEffect(plex.playing) {
                if (plex.playing == null && playFromHome) {
                    playFromHome = false
                    tab = Tab.HOME
                }
            }

            val body: @Composable (Modifier) -> Unit = { m ->
                Box(m) {
                    when (tab) {
                        Tab.HOME -> HomeScreen(
                            live = vm,
                            plex = plex,
                            games = games,
                            onWatchChannel = { ch -> vm.play(ch); tab = Tab.LIVE },
                            onPlayPlex = { item -> plex.resume(item); playFromHome = true; tab = Tab.LIBRARY },
                            onOpenPlex = { item -> plex.open(item); tab = Tab.LIBRARY },
                            onOpenGame = { g -> games.showGame(g); tab = Tab.GAMES },
                            onGoTab = { name -> Tab.values().firstOrNull { it.name == name }?.let { if (it == Tab.LIVE) phonePlayer = false; tab = it } },
                            onSearchLive = { q -> vm.searchRequest = q; phonePlayer = false; tab = Tab.LIVE },
                        )
                        Tab.LIVE -> if (tv) LiveTvScreen(vm) else if (phonePlayer) {
                            androidx.activity.compose.BackHandler { phonePlayer = false }
                            LiveTvScreen(vm)
                        } else MobileLiveScreen(vm) { phonePlayer = true }
                        Tab.SPORTS -> SportsScreen(sports, vm,
                            onWatch = { ch -> vm.play(ch); phonePlayer = true; tab = Tab.LIVE },
                            onSearch = { q -> vm.searchRequest = q; phonePlayer = false; tab = Tab.LIVE })
                        Tab.GUIDE -> GuideScreen(vm, onCatchup = { ch, p ->
                            // Catch-up: the provider's archive first, then Plex (the same episode or movie in your library).
                            appScope.launch {
                                val source = Opt.str(Opt.CATCHUP, "auto")
                                when {
                                    vm.playCatchup(ch, p) -> { phonePlayer = true; tab = Tab.LIVE }
                                    (source == "auto" || source == "plex") && plex.playProgramme(p) -> tab = Tab.LIBRARY
                                    else -> android.widget.Toast.makeText(ctx, "\"${p.title}\" isn't in the archive or your Plex library.", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        }) { ch -> vm.play(ch); tab = Tab.LIVE }
                        Tab.LIBRARY -> LibraryScreen(plex)
                        Tab.YOUTUBE -> YouTubeScreen(tube)
                        Tab.MUSIC -> MusicScreen(music)
                        Tab.GAMES -> GamesScreen(games)
                        Tab.RECORDINGS -> RecordingsScreen()
                        Tab.SETTINGS -> SettingsScreen(vm)
                    }
                    // Music keeps playing on every tab: a small bar to see and control it.
                    if (MusicPlayer.current != null && tab != Tab.MUSIC && !videoActive) {
                        MiniMusicBar(
                            Modifier.align(Alignment.BottomStart).padding(12.dp).fillMaxWidth(if (tv) 0.45f else 1f),
                            onOpen = { music.page = MusicPage.NOW_PLAYING; tab = Tab.MUSIC },
                        )
                    }
                    if (showMini) {
                        MiniPlayer(vm, Modifier.align(Alignment.BottomEnd).padding(16.dp), onOpen = { tab = Tab.LIVE })
                    }
                }
            }

            if (tv) {
                // TV: side menu, driven by the remote's arrow keys.
                Row(Modifier.fillMaxSize()) {
                    NavigationRail {
                        Tab.values().forEach { t ->
                            NavigationRailItem(
                                selected = tab == t,
                                onClick = { tab = t },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label) },
                            )
                        }
                    }
                    body(Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                // Phone/tablet: a floating bar (Home, Live TV, Library, Sports, More).
                val fullScreenVideo = (tab == Tab.LIVE && phonePlayer) || (plex.playing != null && tab == Tab.LIBRARY) ||
                    (tube.playing != null && tab == Tab.YOUTUBE)
                Box(Modifier.fillMaxSize()) {
                    body(Modifier.fillMaxSize().padding(bottom = if (fullScreenVideo) 0.dp else 84.dp))
                    if (!fullScreenVideo) {
                        val main = listOf(Tab.HOME, Tab.LIVE, Tab.LIBRARY, Tab.SPORTS).filter { !Opt.bool(Opt.navHidden(it.name), false) }
                        FloatingNavBar(
                            main.map { t -> NavItem(t.label, t.icon, tab == t) { tab = t; if (t == Tab.LIVE) phonePlayer = false } } +
                                NavItem("More", Icons.Default.Menu, tab !in main) { more = true },
                            Modifier.align(Alignment.BottomCenter),
                        )
                    }
                    if (more) MoreSheet(
                        (listOf(Tab.HOME, Tab.LIVE, Tab.LIBRARY, Tab.SPORTS).filter { Opt.bool(Opt.navHidden(it.name), false) } +
                            listOf(Tab.GUIDE, Tab.YOUTUBE, Tab.MUSIC, Tab.GAMES, Tab.RECORDINGS, Tab.SETTINGS)).map { t -> t.label to { tab = t } },
                        onClose = { more = false },
                    )
                }
            }

            // First launch: a short walk-through, then ask to allow notifications (reminders, recordings).
            var tips by remember { mutableStateOf(!Opt.bool("onboarded", false)) }
            val notifyAsk = androidx.activity.compose.rememberLauncherForActivityResult(
                androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }
            if (tips) Onboarding(tv) {
                tips = false
                Opt.set("onboarded", true)
                if (android.os.Build.VERSION.SDK_INT >= 33) runCatching { notifyAsk.launch(android.Manifest.permission.POST_NOTIFICATIONS) }
            }

            // A video cast here (DLNA apps, or a link from a phone) plays over everything; Back stops it.
            if (CastHub.castTitle != null) CastPlayerScreen()

            // If the app crashed last time, show the error so it can be reported.
            crash?.let { text ->
                AlertDialog(
                    onDismissRequest = {
                        CrashLog.clear(ctx)
                        crash = null
                    },
                    title = { Text("The app crashed last time") },
                    text = {
                        SelectionContainer {
                            Text(
                                text,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                            )
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { clipboard.setText(AnnotatedString(text)) }) { Text("Copy") }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            CrashLog.clear(ctx)
                            crash = null
                        }) { Text("Close") }
                    },
                )
            }
        }
    }
}

/** Live TV's picture, nothing else (picture-in-picture and the mini player). */
@Composable
fun LiveVideo(vm: LiveViewModel, modifier: Modifier) {
    androidx.compose.ui.viewinterop.AndroidView(
        modifier = modifier.background(androidx.compose.ui.graphics.Color.Black),
        factory = { c -> androidx.media3.ui.PlayerView(c).apply { player = vm.player; useController = false }.applyOptions() },
        update = { it.player = vm.player },
    )
}

/** The small Live TV window shown on other tabs. Select it to go back to Live TV. */
@Composable
private fun MiniPlayer(vm: LiveViewModel, modifier: Modifier, onOpen: () -> Unit) {
    val tv = rememberIsTv()
    val w = if (tv) 320.dp else 220.dp
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
    Column(modifier.width(w)) {
        Box(Modifier.width(w).height(w * 9 / 16).focusRing(shape).clip(shape).clickable(onClick = onOpen)) {
            LiveVideo(vm, Modifier.fillMaxSize())
        }
        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, shape).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(vm.current?.name.orEmpty(), maxLines = 1, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.toggleMiniPlayer() }, modifier = Modifier.focusRing(ButtonShape)) { Text("Close") }
        }
    }
}

@Composable
private fun CastPlayerScreen() {
    val p = CastHub.castPlayer ?: return
    androidx.activity.compose.BackHandler { CastHub.stopCast() }
    LaunchedEffect(Unit) { MusicPlayer.pause() }
    Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black)) {
        androidx.compose.ui.viewinterop.AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c -> androidx.media3.ui.PlayerView(c).apply { player = p; useController = true } },
        )
        Text("Cast: ${CastHub.castTitle}", style = MaterialTheme.typography.labelMedium,
            color = androidx.compose.ui.graphics.Color.White, modifier = Modifier.align(Alignment.TopStart).padding(12.dp))
    }
}
