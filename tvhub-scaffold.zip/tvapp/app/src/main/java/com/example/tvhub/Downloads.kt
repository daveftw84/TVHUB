package com.example.tvhub

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Plex downloads for watching offline: the original file, saved in TV Hub's own folder with Android's
 * download manager (it keeps going in the background and shows progress in the notification shade).
 */
object Downloads {
    data class Item(
        val id: Long,               // DownloadManager id
        val ratingKey: String,
        val title: String,
        val subtitle: String,
        val type: String,           // movie, episode
        val poster: String?,
        val file: String,
    )

    var items by mutableStateOf<List<Item>>(emptyList())
        private set

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        items = try {
            val a = JSONArray(prefs(ctx).getString("plex_downloads", "[]"))
            (0 until a.length()).map { a.getJSONObject(it) }.map {
                Item(it.getLong("id"), it.getString("rk"), it.optString("title"), it.optString("sub"), it.optString("type"),
                    it.optString("poster").ifEmpty { null }, it.getString("file"))
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun save(ctx: Context) {
        val a = JSONArray()
        items.forEach {
            a.put(JSONObject().put("id", it.id).put("rk", it.ratingKey).put("title", it.title).put("sub", it.subtitle)
                .put("type", it.type).put("poster", it.poster ?: "").put("file", it.file))
        }
        prefs(ctx).edit().putString("plex_downloads", a.toString()).apply()
    }

    fun isDownloaded(ratingKey: String?) = ratingKey != null && items.any { it.ratingKey == ratingKey }

    /** Starts downloading [url] (the Plex file link). Returns a message for the user. */
    fun start(ctx: Context, media: PlexItem, url: String, poster: String?): String {
        val rk = media.ratingKey ?: return "Can't download this."
        if (isDownloaded(rk)) return "Already downloaded."
        Opt.init(ctx)
        val ext = media.partKey?.substringAfterLast('.', "mkv")?.takeIf { it.length in 2..4 } ?: "mkv"
        val name = (media.displayTitle + (if (media.type == "episode") " S${media.season}E${media.index}" else ""))
            .replace(Regex("[^A-Za-z0-9 ._-]"), "").trim().ifEmpty { "video" } + ".$ext"
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: return "No storage available."
        val file = File(dir, name)
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(media.displayTitle)
            .setDescription("TV Hub download")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationUri(Uri.fromFile(file))
            .setAllowedOverMetered(!Opt.bool("download_wifi_only", false))
            .setAllowedOverRoaming(false)
        return try {
            val id = (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            items = items + Item(id, rk, media.displayTitle, media.displaySubtitle.orEmpty(), media.type, poster, file.path)
            save(ctx)
            "Downloading “${media.displayTitle}”…"
        } catch (e: Exception) {
            "Couldn't start the download: ${e.message}"
        }
    }

    /** 0..1 while downloading, 1 when done, -1 if it failed. */
    fun progress(ctx: Context, item: Item): Float {
        val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dm.query(DownloadManager.Query().setFilterById(item.id))?.use { c ->
            if (!c.moveToFirst()) return if (File(item.file).exists()) 1f else -1f
            val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            if (status == DownloadManager.STATUS_SUCCESSFUL) return 1f
            if (status == DownloadManager.STATUS_FAILED) return -1f
            val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            return if (total > 0) (done.toFloat() / total).coerceIn(0f, 0.99f) else 0f
        }
        return if (File(item.file).exists()) 1f else -1f
    }

    fun remove(ctx: Context, item: Item) {
        runCatching { (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(item.id) }
        runCatching { File(item.file).delete() }
        items = items.filter { it.id != item.id }
        save(ctx)
    }
}
