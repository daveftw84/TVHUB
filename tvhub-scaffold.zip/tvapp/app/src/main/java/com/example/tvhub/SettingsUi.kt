package com.example.tvhub

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** App options (one place, read anywhere). */
object Opt {
    private lateinit var p: SharedPreferences
    /** Bumped on every change so screens that read options redraw. */
    var version by mutableStateOf(0)
        private set

    fun init(ctx: Context) { if (!::p.isInitialized) p = ctx.applicationContext.getSharedPreferences("tvhub", Context.MODE_PRIVATE) }

    fun bool(key: String, def: Boolean): Boolean { version; return p.getBoolean(key, def) }
    fun str(key: String, def: String): String { version; return p.getString(key, def) ?: def }
    fun int(key: String, def: Int): Int { version; return p.getInt(key, def) }
    fun float(key: String, def: Float): Float { version; return p.getFloat(key, def) }
    fun set(key: String, v: Any?) {
        p.edit().apply {
            when (v) {
                is Boolean -> putBoolean(key, v)
                is String -> putString(key, v)
                is Int -> putInt(key, v)
                is Float -> putFloat(key, v)
                is Set<*> -> putStringSet(key, v.map { it.toString() }.toSet())
                null -> remove(key)
            }
            // Remember which keys are app options, so "Reset Settings" can clear just those.
            if (key != "opt_keys") putStringSet("opt_keys", (p.getStringSet("opt_keys", emptySet()) ?: emptySet()) + key)
        }.apply()
        version++
    }

    /** Settings > Advanced > Reset Settings: every option back to its default (playlists, logins and favorites stay). */
    fun resetAll() {
        val keys = p.getStringSet("opt_keys", emptySet()).orEmpty()
        p.edit().apply { keys.forEach { remove(it) }; remove("opt_keys") }.apply()
        version++
    }

    /** All settings as JSON, without logins, passwords, keys or tokens. */
    fun exportJson(): String {
        val o = org.json.JSONObject()
        val secret = Regex("token|secret|pass|playlists|_key|account|reminders|downloads|crash", RegexOption.IGNORE_CASE)
        p.all.forEach { (k, v) ->
            if (secret.containsMatchIn(k)) return@forEach
            val t = when (v) { is Boolean -> "b"; is Int -> "i"; is Long -> "l"; is Float -> "f"; is String -> "s"; is Set<*> -> "set"; else -> return@forEach }
            o.put(k, org.json.JSONObject().put("t", t).put("v", if (v is Set<*>) org.json.JSONArray(v.toList()) else v))
        }
        return o.toString(2)
    }

    /** Restores settings saved by [exportJson]. Returns how many were restored. */
    fun importJson(json: String): Int {
        val o = org.json.JSONObject(json)
        var n = 0
        p.edit().apply {
            o.keys().forEach { k ->
                val e = o.optJSONObject(k) ?: return@forEach
                when (e.optString("t")) {
                    "b" -> putBoolean(k, e.optBoolean("v"))
                    "i" -> putInt(k, e.optInt("v"))
                    "l" -> putLong(k, e.optLong("v"))
                    "f" -> putFloat(k, e.optDouble("v").toFloat())
                    "s" -> putString(k, e.optString("v"))
                    "set" -> e.optJSONArray("v")?.let { a -> putStringSet(k, (0 until a.length()).map { a.optString(it) }.toSet()) }
                    else -> return@forEach
                }
                n++
            }
        }.apply()
        version++
        return n
    }
    fun set(key: String): Set<String> { version; return p.getStringSet(key, emptySet())?.toSet() ?: emptySet() }

    // Names used across the app
    const val START_TAB = "start_tab"
    const val LIVE_RECONNECT = "live_reconnect"
    const val FORCE_HLS = "force_hls"
    const val FREEZE_IMAGE = "freeze_image"
    const val ALWAYS_CC = "always_cc"
    const val SUB_SIZE = "sub_size"
    const val SUB_BG = "sub_bg"
    const val CATCHUP = "catchup_source"
    const val VOD_RESUME = "vod_resume"         // off, dialog, auto
    const val SKIP_INTRO = "skip_intro"         // off, button, auto
    const val REC_START = "rec_start_offset"    // minutes
    const val REC_END = "rec_end_offset"
    const val REMIND = "remind_offset"
    const val REMIND2 = "remind2"
    const val REMIND2_OFFSET = "remind2_offset"
    const val MV_MUTE_NEW = "mv_mute_new"
    const val MV_HIDE_MUTED = "mv_hide_muted"
    const val MV_HIDE_AUDIO = "mv_hide_audio"
    const val MV_DOUBLE = "mv_double_tap"       // fullscreen, sound, none
    const val MV_UP = "mv_swipe_up"             // resize, none
    const val MV_DOWN = "mv_swipe_down"         // close, none
    const val HOME_HIDDEN = "home_hidden"
    fun navHidden(tab: String) = "hide_nav_$tab"
}

// ---------------------------------------------------------------- Building blocks (iMPlayer-style grouped cards)

@Composable
fun SettingsHeader(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = Color(0xFFAAAAAA), modifier = Modifier.padding(start = 8.dp, top = 18.dp, bottom = 8.dp))
}

@Composable
fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF2A2A2D)), content = content)
}

@Composable
private fun RowBase(title: String, subtitle: String?, note: String?, onClick: (() -> Unit)?, trailing: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().then(if (onClick != null) Modifier.focusRing().clickable(onClick = onClick) else Modifier)
        .padding(horizontal = 22.dp, vertical = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFAAAAAA))
            }
            trailing()
        }
        if (note != null) Text(note, style = MaterialTheme.typography.bodySmall, color = Color(0xFF999999), modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun SettingsDivider() = Box(Modifier.fillMaxWidth().padding(horizontal = 22.dp).height(1.dp).background(Color(0xFF3A3A3D)))

/** A row that opens a list of choices (radio buttons). */
@Composable
fun ChoiceRow(title: String, key: String, def: String, options: List<Pair<String, String>>, note: String? = null, onChange: (String) -> Unit = {}) {
    var open by remember { mutableStateOf(false) }
    val cur = Opt.str(key, def)
    RowBase(title, options.firstOrNull { it.first == cur }?.second ?: cur, note, { open = true }) { Text("›", style = MaterialTheme.typography.titleLarge) }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(title) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    options.forEach { (value, label) ->
                        Row(Modifier.fillMaxWidth().selectable(value == cur) { Opt.set(key, value); onChange(value); open = false }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = value == cur, onClick = null)
                            Spacer(Modifier.width(16.dp))
                            Text(label, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { open = false }) { Text("Cancel") } },
        )
    }
}

@Composable
fun SwitchRow(title: String, key: String, def: Boolean, subtitle: String? = null, note: String? = null, onChange: (Boolean) -> Unit = {}) {
    val on = Opt.bool(key, def)
    RowBase(title, subtitle, note, { Opt.set(key, !on); onChange(!on) }) {
        Switch(checked = on, onCheckedChange = { Opt.set(key, it); onChange(it) })
    }
}

@Composable
fun MinutesRow(title: String, key: String, def: Int, choices: List<Int>, note: String? = null) {
    ChoiceRow(title, key + "_s", def.toString(), choices.map { it.toString() to "$it Minutes" }, note) { Opt.set(key, it.toInt()) }
}

// ---------------------------------------------------------------- The settings pages from the screenshots

@Composable
fun AppBehaviorSettings() {
    SettingsHeader("App")
    SettingsCard {
        ChoiceRow("On app load open", Opt.START_TAB, "HOME", listOf("HOME" to "Home", "LIVE" to "Live TV", "GUIDE" to "Guide",
            "LIBRARY" to "Library", "SPORTS" to "Sports", "YOUTUBE" to "YouTube", "MUSIC" to "Music", "GAMES" to "Games", "LAST" to "Where I left off"))
        SettingsDivider()
        ChoiceRow("On app minimize", "minimize", "pip", listOf("pip" to "Go to PiP mode", "none" to "Do nothing")) {
            Opt.set("auto_pip", it == "pip")
        }
    }
    SettingsHeader("Bottom Menu (phones)")
    SettingsCard {
        listOf("HOME" to "Hide Home", "LIVE" to "Hide Live TV", "LIBRARY" to "Hide Library", "SPORTS" to "Hide Sports").forEachIndexed { i, (t, label) ->
            if (i > 0) SettingsDivider()
            SwitchRow(label, Opt.navHidden(t), false)
        }
    }
}

@Composable
fun PlayerBehaviorSettings() {
    SettingsHeader("Player Behavior")
    SettingsCard {
        SwitchRow("Auto stream reconnect", Opt.LIVE_RECONNECT, false, "Stream will reload after 5 seconds of buffering")
        SettingsDivider()
        SwitchRow("Force HLS format", Opt.FORCE_HLS, false, "Xtream Codes: use HLS (.m3u8) streams when possible (reload channels)")
        SettingsDivider()
        SwitchRow("On channel change, freeze image", Opt.FREEZE_IMAGE, false)
        SettingsDivider()
        SwitchRow("Always show \"Closed Captions\"", Opt.ALWAYS_CC, false)
        SettingsDivider()
        ChoiceRow("Subtitle size", Opt.SUB_SIZE + "_s", "1.0", listOf("0.75" to "Small", "1.0" to "Normal", "1.25" to "Large", "1.5" to "Extra large")) {
            Opt.set(Opt.SUB_SIZE, it.toFloat())
        }
        SettingsDivider()
        SwitchRow("Subtitle background", Opt.SUB_BG, true, "A dark box behind subtitles and captions")
    }
    SettingsHeader("Catch-Up")
    SettingsCard {
        ChoiceRow("Set Catch-up source", Opt.CATCHUP, "auto", listOf("auto" to "Automatic", "xc" to "Xtream Codes (XC)",
            "m3u" to "Playlist (catchup-source)", "plex" to "Plex (play the same show or movie from your library)", "off" to "Off"),
            note = "Watch past programmes from the guide on channels your provider archives.")
    }
}

@Composable
fun VodPlaybackSettings() {
    SettingsHeader("Playback (Plex and YouTube)")
    SettingsCard {
        ChoiceRow("VOD auto resume behavior", Opt.VOD_RESUME, "dialog", listOf("off" to "OFF", "dialog" to "Dialog", "auto" to "Auto"),
            note = "Start from the beginning, show the resume dialog, or automatically continue from your saved position.")
    }
    SettingsHeader("Next Episode")
    SettingsCard {
        val p = remember { Opt }
        SwitchRow("Disable auto play next episode", "auto_next_off", false) { off -> p.set("auto_next", !off) }
    }
    SettingsHeader("Skip Intros")
    SettingsCard {
        ChoiceRow("Skip behavior", Opt.SKIP_INTRO, "button", listOf("off" to "Disabled", "button" to "Show Skip Button", "auto" to "Automatically Skip"),
            note = "Control how the player reacts to intros and credits Plex detected.")
    }
}

@Composable
fun RecordingsRemindersSettings() {
    SettingsHeader("Recordings")
    SettingsCard {
        MinutesRow("Recordings start offset", Opt.REC_START, 0, listOf(0, 1, 2, 5, 10))
        SettingsDivider()
        MinutesRow("Recordings end offset", Opt.REC_END, 2, listOf(0, 2, 5, 10, 15, 30))
    }
    SettingsHeader("Reminders")
    SettingsCard {
        MinutesRow("Default reminder offset", Opt.REMIND, 1, listOf(0, 1, 5, 10, 15, 30),
            note = "When a reminder notification is shown before the event starts (guide or sport event)")
        SettingsDivider()
        SwitchRow("Second default reminder", Opt.REMIND2, false, note = "Adds a second notification for each reminder using the offset below")
        if (Opt.bool(Opt.REMIND2, false)) {
            SettingsDivider()
            MinutesRow("Second reminder offset", Opt.REMIND2_OFFSET, 10, listOf(5, 10, 15, 30, 60))
        }
    }
}

@Composable
fun MultiViewSettings() {
    SettingsHeader("MultiView (corner windows)")
    SettingsCard {
        SwitchRow("Mute new screens", Opt.MV_MUTE_NEW, true)
    }
    SettingsHeader("Audio indicators")
    SettingsCard {
        SwitchRow("Hide muted icon", Opt.MV_HIDE_MUTED, false)
        SettingsDivider()
        SwitchRow("Hide audio-on icon", Opt.MV_HIDE_AUDIO, false)
    }
    SettingsHeader("Screen gestures")
    SettingsCard {
        ChoiceRow("Double tap", Opt.MV_DOUBLE, "fullscreen", listOf("fullscreen" to "Fullscreen (swap with the main picture)", "sound" to "Sound on / off", "none" to "Nothing"))
        SettingsDivider()
        ChoiceRow("Swipe up", Opt.MV_UP, "resize", listOf("resize" to "Enlarge / shrink screen", "none" to "Nothing"))
        SettingsDivider()
        ChoiceRow("Swipe down", Opt.MV_DOWN, "close", listOf("close" to "Close screen", "none" to "Nothing"))
        SettingsDivider()
        RowBase("Restore default settings", null, null, {
            listOf(Opt.MV_MUTE_NEW, Opt.MV_HIDE_MUTED, Opt.MV_HIDE_AUDIO, Opt.MV_DOUBLE, Opt.MV_UP, Opt.MV_DOWN).forEach { Opt.set(it, null) }
        }) { Text("›", style = MaterialTheme.typography.titleLarge) }
    }
}

/** "Visible Home Categories" (phones): which rows Home shows. */
@Composable
fun HomeCategoriesDialog(onClose: () -> Unit) {
    var hidden by remember { mutableStateOf(Opt.set(Opt.HOME_HIDDEN)) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Visible Home Categories") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                HomeCategory.values().forEach { c ->
                    Row(Modifier.fillMaxWidth().clickable { hidden = if (c.name in hidden) hidden - c.name else hidden + c.name }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = c.name !in hidden, onCheckedChange = { hidden = if (it) hidden - c.name else hidden + c.name })
                        Spacer(Modifier.width(12.dp))
                        Text(c.label, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { Opt.set(Opt.HOME_HIDDEN, hidden); onClose() }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
    )
}

/** Settings > Playback applied to a player view: subtitle size and background, freezing the picture on channel change. */
fun androidx.media3.ui.PlayerView.applyOptions(): androidx.media3.ui.PlayerView {
    val size = Opt.float(Opt.SUB_SIZE, 1f)
    subtitleView?.setFractionalTextSize(androidx.media3.ui.SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * size)
    subtitleView?.setStyle(
        androidx.media3.ui.CaptionStyleCompat(
            android.graphics.Color.WHITE,
            if (Opt.bool(Opt.SUB_BG, true)) 0xAA000000.toInt() else android.graphics.Color.TRANSPARENT,
            android.graphics.Color.TRANSPARENT,
            androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
            android.graphics.Color.BLACK,
            null,
        )
    )
    setKeepContentOnPlayerReset(Opt.bool(Opt.FREEZE_IMAGE, false))
    return this
}

/** Rows on the phone Home screen (Settings: Visible Home Categories, the ⚙ on Home). */
enum class HomeCategory(val label: String) {
    TRENDING("Trending V.O.D"),
    CONTINUE_MOVIES("Continue Watching Movies"),
    CONTINUE_SHOWS("Continue Watching TV Shows"),
    UP_NEXT("TV Calendar"),
    LAST_CHANNELS("Last Watched Channels"),
    TOP10_CHANNELS("Top 10 Watched Channels"),
    FAVORITE_CHANNELS("Favorite Channels"),
    RECENT_LIVE("Recently Added Live TV"),
    SPORTS_NOW("Live Sports"),
    FOLLOWED_TEAMS("Followed Sport Teams"),
    MOVIES("Movies"),
    SHOWS("TV Shows"),
    GAMES("Games"),
}
