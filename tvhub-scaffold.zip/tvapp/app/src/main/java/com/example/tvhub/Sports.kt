package com.example.tvhub

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** One sports event and the channels in your lineup that show it. */
data class SportsEvent(
    val title: String,
    val sport: String,          // "Football", "Basketball", ... or "Sports" when unknown
    val league: String?,
    val start: Long,
    val end: Long,
    val channels: List<Channel>,          // your channels showing it
    val otherChannels: List<String>,      // broadcasters from the listings that aren't in your lineup
    val image: String?,
    val fromListings: Boolean,            // from TheSportsDB (true) or your guide (false)
) {
    val live: Boolean get() = System.currentTimeMillis() in start until end
}

/**
 * The Sports section of Live TV. Events come from your own guide (programmes that look like sports
 * on sports channels), and, with a TheSportsDB key in Settings, from TheSportsDB's TV listings, which
 * name the broadcaster; those are matched to the channels in your lineup by name.
 */
object Sports {
    private val SPORTS_CHANNEL = Regex(
        "(?i)espn|fox ?sports|fs1|fs2|sky ?sports|bein|tnt ?sports|bt ?sport|dazn|nfl|nba|nhl|mlb|mls|" +
            "golf|tennis|sportsnet|tsn|eurosport|premier ?sports|bally|nesn|yes network|msg|sny|acc ?network|" +
            "sec ?network|big ?ten|btn|pac-?12|cbs ?sports|nbc ?sports|peacock|fubo|ufc|wwe|redzone|willow|" +
            "supersport|arena ?sport|movistar ?deportes|tudn|tyc|claro ?sports|\\bsport"
    )
    private val SPORTS_CATEGORY = Regex(
        "(?i)sport|football|soccer|basketball|baseball|hockey|tennis|golf|boxing|mma|wrestling|racing|motor|" +
            "rugby|cricket|volleyball|cycling|athletics|olympic|fútbol|futbol|deportes"
    )
    private val MATCHUP = Regex("(?i)\\b(vs\\.?|v\\.?|at|@)\\b")
    private val LEAGUES = linkedMapOf(
        "NFL" to "Football", "College Football" to "Football", "NCAAF" to "Football",
        "NBA" to "Basketball", "WNBA" to "Basketball", "College Basketball" to "Basketball", "NCAAB" to "Basketball",
        "NHL" to "Hockey", "MLB" to "Baseball", "MLS" to "Soccer", "Premier League" to "Soccer",
        "La Liga" to "Soccer", "Serie A" to "Soccer", "Bundesliga" to "Soccer", "Ligue 1" to "Soccer",
        "Champions League" to "Soccer", "Liga MX" to "Soccer", "UFC" to "Fighting", "Boxing" to "Fighting",
        "WWE" to "Wrestling", "AEW" to "Wrestling", "Formula 1" to "Motorsports", "F1" to "Motorsports",
        "NASCAR" to "Motorsports", "IndyCar" to "Motorsports", "MotoGP" to "Motorsports", "PGA" to "Golf",
        "LPGA" to "Golf", "ATP" to "Tennis", "WTA" to "Tennis", "Wimbledon" to "Tennis",
    )

    fun isSportsChannel(name: String): Boolean = SPORTS_CHANNEL.containsMatchIn(name)

    fun isSportsProgramme(p: Programme): Boolean =
        p.categories.any { SPORTS_CATEGORY.containsMatchIn(it) } ||
            LEAGUES.keys.any { Regex("(?i)\\b${Regex.escape(it)}\\b").containsMatchIn(p.title) }

    /** League and sport named in a title or categories, if any. */
    fun classify(title: String, categories: List<String>): Pair<String?, String> {
        for ((league, sport) in LEAGUES) {
            if (Regex("(?i)\\b${Regex.escape(league)}\\b").containsMatchIn(title)) return league to sport
        }
        val cat = categories.firstOrNull { SPORTS_CATEGORY.containsMatchIn(it) && !it.equals("sports", true) && !it.equals("sport", true) }
        return null to (cat ?: "Sports")
    }

    /** Sports in your guide from now until [hours] ahead, with every channel showing the same event. */
    fun fromGuide(live: LiveViewModel, hours: Int = 24): List<SportsEvent> {
        val now = System.currentTimeMillis()
        val until = now + hours * 3_600_000L
        data class Hit(val ch: Channel, val p: Programme)
        val hits = ArrayList<Hit>()
        for (ch in live.channels.distinctBy { it.key }) {
            val sportsChannel = isSportsChannel(ch.name) || isSportsChannel(ch.group)
            for (p in live.programmesFor(ch)) {
                if (p.end <= now || p.start > until) continue
                val looksLikeGame = MATCHUP.containsMatchIn(p.title) && sportsChannel
                if (isSportsProgramme(p) || looksLikeGame) hits += Hit(ch, p)
            }
        }
        // The same event on several channels: same title, starting within 30 minutes.
        return hits.groupBy { normTitle(it.p.title) + "|" + (it.p.start / 1_800_000L) }.values.map { group ->
            val p = group.first().p
            val (league, sport) = classify(p.title, p.categories)
            SportsEvent(p.title, sport, league, p.start, p.end, group.map { it.ch }.distinctBy { it.key }, emptyList(),
                p.icon, fromListings = false)
        }.sortedBy { it.start }
    }

    private fun normTitle(t: String) = t.lowercase().replace(Regex("^(live:?|en vivo:?)\\s*"), "").filter { it.isLetterOrDigit() }

    // --- TheSportsDB TV listings (needs your key: thesportsdb.com > Patreon) ---

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 20_000
        c.setRequestProperty("User-Agent", "TVHub")
        if (c.responseCode !in 200..299) throw IOException("TheSportsDB returned HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Today's TV sports listings for a country, matched to your channels by broadcaster name. */
    fun fromListings(key: String, country: String, date: String, live: LiveViewModel): List<SportsEvent> {
        val url = "https://www.thesportsdb.com/api/v1/json/$key/eventstv.php?d=$date&a=" +
            URLEncoder.encode(country.replace(' ', '_'), "UTF-8")
        val o = JSONObject(get(url))
        val arr = o.optJSONArray("tvevents") ?: o.optJSONArray("events") ?: return emptyList()
        val lineup = live.channels.distinctBy { it.key }
        val byName = lineup.groupBy { normalizeChannelName(it.name) }
        fun matchChannel(broadcaster: String): List<Channel> {
            val n = normalizeChannelName(broadcaster)
            if (n.isEmpty()) return emptyList()
            byName[n]?.let { return it }
            // "ESPN" also matches "ESPN 2"? No: only names that start with the broadcaster and add a region.
            return lineup.filter {
                val c = normalizeChannelName(it.name)
                c.startsWith(n) && c.length - n.length <= 3 && !c.substring(n.length).any { ch -> ch.isDigit() }
            }
        }
        data class Row(val id: String, val title: String, val sport: String, val league: String?, val start: Long, val channel: String, val image: String?)
        val rows = (0 until arr.length()).mapNotNull { i ->
            val e = arr.optJSONObject(i) ?: return@mapNotNull null
            val title = e.optString("strEvent").ifEmpty { return@mapNotNull null }
            val stamp = e.optString("strTimeStamp").ifEmpty { e.optString("dateEvent") + "T" + e.optString("strTime").ifEmpty { "00:00:00" } }
            val start = parseUtc(stamp) ?: return@mapNotNull null
            Row(e.optString("idEvent").ifEmpty { title }, title, e.optString("strSport").ifEmpty { "Sports" },
                e.optString("strLeague").ifEmpty { null }, start, e.optString("strChannel"),
                e.optString("strEventThumb").ifEmpty { e.optString("strThumb") }.ifEmpty { e.optString("strEventPoster") }.ifEmpty { null })
        }
        return rows.groupBy { it.id }.values.map { g ->
            val r = g.first()
            val mine = g.flatMap { matchChannel(it.channel) }.distinctBy { it.key }
            val others = g.map { it.channel }.filter { b -> b.isNotEmpty() && matchChannel(b).isEmpty() }.distinct()
            SportsEvent(r.title, r.sport, r.league, r.start, r.start + 3 * 3_600_000L, mine, others, r.image, fromListings = true)
        }.sortedBy { it.start }
    }

    private fun parseUtc(s: String): Long? = try {
        val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
        f.timeZone = java.util.TimeZone.getTimeZone("UTC")
        f.parse(s.take(19))?.time
    } catch (_: Exception) {
        null
    }

    /** Both sources together; a listing and a guide entry for the same game become one event. */
    fun merge(guide: List<SportsEvent>, listings: List<SportsEvent>): List<SportsEvent> {
        val out = listings.toMutableList()
        for (g in guide) {
            val i = out.indexOfFirst { l -> kotlin.math.abs(l.start - g.start) < 45 * 60_000L && similar(l.title, g.title) }
            if (i >= 0) {
                val l = out[i]
                out[i] = l.copy(channels = (l.channels + g.channels).distinctBy { it.key }, end = maxOf(l.end, g.end))
            } else {
                out += g
            }
        }
        return out.sortedBy { it.start }
    }

    /** Titles share their team names ("Chiefs vs Bills" ~ "NFL Football: Kansas City Chiefs at Buffalo Bills"). */
    private fun similar(a: String, b: String): Boolean {
        val stop = setOf("vs", "v", "at", "the", "fc", "live", "nfl", "nba", "nhl", "mlb", "football", "basketball", "hockey", "baseball", "soccer")
        fun words(s: String) = s.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length > 2 && it !in stop }.toSet()
        val wa = words(a)
        val wb = words(b)
        return (wa intersect wb).size >= 2 || (wa.isNotEmpty() && wb.containsAll(wa))
    }

    /** True when the event mentions one of your teams or leagues. */
    fun isFavorite(e: SportsEvent, favorites: List<String>): Boolean =
        favorites.any { f -> f.isNotBlank() && (e.title.contains(f, true) || e.league?.contains(f, true) == true || e.sport.equals(f, true)) }
}
