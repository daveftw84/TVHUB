package com.example.tvhub

import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Catch-up: watching a programme that already aired. From your provider's archive (Xtream Codes, or a
 * playlist's catchup-source), or from Plex: the same episode or movie in your library.
 */
object Catchup {
    /** The Xtream Codes server's time zone (catch-up times are in it). */
    var xcTimezone: String? = null

    /** Whether the provider archives this programme (the channel keeps it and it's within the archive days). */
    fun providerHas(ch: Channel, p: Programme, source: String): Boolean {
        if (source == "off" || source == "plex" || ch.archiveDays <= 0 || ch.catchupSource == null) return false
        val isXc = ch.catchupSource.contains("{xcstart}")
        if (source == "xc" && !isXc) return false
        if (source == "m3u" && isXc) return false
        return p.start > System.currentTimeMillis() - ch.archiveDays * 86_400_000L && p.start < System.currentTimeMillis()
    }

    /** The address of the archived programme. */
    fun url(ch: Channel, p: Programme): String? {
        val tpl = ch.catchupSource ?: return null
        val start = p.start
        val end = p.end
        val minutes = ((end - start) / 60_000).coerceAtLeast(1)
        fun fmt(pattern: String, tz: TimeZone = TimeZone.getTimeZone("UTC")) = SimpleDateFormat(pattern, Locale.US).apply { timeZone = tz }.format(start)
        val xcTz = xcTimezone?.let { TimeZone.getTimeZone(it) } ?: TimeZone.getDefault()
        var u = when {
            tpl == "@default" || tpl == "@flussonic" -> ch.url.substringBeforeLast('/') + "/timeshift_rel-${(System.currentTimeMillis() - start) / 1000}.m3u8"
            tpl == "@append" || tpl == "@shift" -> ch.url + (if (ch.url.contains('?')) "&" else "?") + "utc=${start / 1000}&lutc=${System.currentTimeMillis() / 1000}"
            tpl.startsWith("?") || tpl.startsWith("&") -> ch.url + tpl
            else -> tpl
        }
        u = u.replace("{xcstart}", fmt("yyyy-MM-dd:HH-mm", xcTz))
            .replace("{duration}", minutes.toString()).replace("\${duration}", (minutes * 60).toString())
            .replace("{utc}", (start / 1000).toString()).replace("\${start}", (start / 1000).toString())
            .replace("{utcend}", (end / 1000).toString()).replace("\${end}", (end / 1000).toString())
            .replace("{lutc}", (System.currentTimeMillis() / 1000).toString()).replace("\${timestamp}", (System.currentTimeMillis() / 1000).toString())
            .replace("{offset}", ((System.currentTimeMillis() - start) / 1000).toString())
            .replace("{Y}", fmt("yyyy")).replace("{m}", fmt("MM")).replace("{d}", fmt("dd"))
            .replace("{H}", fmt("HH")).replace("{M}", fmt("mm")).replace("{S}", fmt("ss"))
        return u
    }
}
