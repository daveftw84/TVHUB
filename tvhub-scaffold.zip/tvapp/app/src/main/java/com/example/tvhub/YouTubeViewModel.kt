package com.example.tvhub

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.stream.StreamInfo

/** Pages of the YouTube tab. An empty stack is YouTube Home. */
sealed interface TubeScreen {
    data object Search : TubeScreen
    data class Video(val video: TubeVideo) : TubeScreen
    data class Channel(val channel: TubeChannel) : TubeScreen
    data object Library : TubeScreen
    data object Explore : TubeScreen
}

/**
 * The YouTube tab (like PipePipe / NewPipe): subscriptions without a Google account (kept on this
 * device), a feed of their new videos, trending, search with suggestions, history with resume,
 * Watch Later, SponsorBlock and Return YouTube Dislike.
 */
class YouTubeViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("tvhub", Context.MODE_PRIVATE)
    private val appPrefs = AppPrefs(app)

    private val stack = mutableStateListOf<TubeScreen>()
    val screen: TubeScreen? get() = stack.lastOrNull()
    val canGoBack: Boolean get() = playing != null || stack.isNotEmpty()

    var notice by mutableStateOf<String?>(null)
        private set

    // --- Settings (PipePipe-style) ---
    var hideShorts by mutableStateOf(prefs.getBoolean("yt_hide_shorts", true))
        private set
    var sponsorBlock by mutableStateOf(prefs.getBoolean("yt_sponsorblock", true))
        private set
    var maxQuality by mutableStateOf(prefs.getInt("yt_quality", 1080))
        private set
    var autoplayNext by mutableStateOf(prefs.getBoolean("yt_autoplay", true))
        private set

    fun toggleHideShorts() { hideShorts = !hideShorts; prefs.edit().putBoolean("yt_hide_shorts", hideShorts).apply(); loadHome(true) }
    fun toggleSponsorBlock() { sponsorBlock = !sponsorBlock; prefs.edit().putBoolean("yt_sponsorblock", sponsorBlock).apply() }
    fun toggleAutoplay() { autoplayNext = !autoplayNext; prefs.edit().putBoolean("yt_autoplay", autoplayNext).apply() }
    fun cycleQuality() {
        val q = listOf(480, 720, 1080, 1440, 2160)
        maxQuality = q[(q.indexOf(maxQuality) + 1).mod(q.size)]
        prefs.edit().putInt("yt_quality", maxQuality).apply()
    }

    private fun shown(list: List<TubeVideo>) = if (hideShorts) list.filter { !it.isShort } else list

    // --- Subscriptions, history, watch later (saved on this device, like NewPipe) ---

    var subscriptions by mutableStateOf(loadChannels("yt_subs"))
        private set

    data class Watched(val video: TubeVideo, val positionMs: Long, val durationMs: Long, val at: Long)

    var history by mutableStateOf(loadHistory())
        private set
    var watchLater by mutableStateOf(loadVideos("yt_later"))
        private set

    private fun videoJson(v: TubeVideo) = JSONObject().put("url", v.url).put("title", v.title).put("channel", v.channel)
        .put("channelUrl", v.channelUrl ?: "").put("thumb", v.thumb ?: "").put("dur", v.durationSec).put("views", v.views)
        .put("ago", v.ago ?: "").put("short", v.isShort).put("live", v.isLive)

    private fun videoFrom(o: JSONObject) = TubeVideo(o.getString("url"), o.optString("title"), o.optString("channel"),
        o.optString("channelUrl").ifEmpty { null }, o.optString("thumb").ifEmpty { null }, o.optLong("dur"), o.optLong("views"),
        o.optString("ago").ifEmpty { null }, o.optBoolean("short"), o.optBoolean("live"))

    private fun loadVideos(key: String): List<TubeVideo> = try {
        val a = JSONArray(prefs.getString(key, "[]"))
        (0 until a.length()).map { videoFrom(a.getJSONObject(it)) }
    } catch (_: Exception) { emptyList() }

    private fun saveVideos(key: String, list: List<TubeVideo>) {
        val a = JSONArray()
        list.forEach { a.put(videoJson(it)) }
        prefs.edit().putString(key, a.toString()).apply()
    }

    private fun loadChannels(key: String): List<TubeChannel> = try {
        val a = JSONArray(prefs.getString(key, "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }.map { TubeChannel(it.getString("url"), it.optString("name"), it.optString("avatar").ifEmpty { null }) }
    } catch (_: Exception) { emptyList() }

    private fun loadHistory(): List<Watched> = try {
        val a = JSONArray(prefs.getString("yt_history", "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }.map { Watched(videoFrom(it.getJSONObject("v")), it.optLong("pos"), it.optLong("len"), it.optLong("at")) }
    } catch (_: Exception) { emptyList() }

    private fun saveHistory() {
        val a = JSONArray()
        history.take(300).forEach { a.put(JSONObject().put("v", videoJson(it.video)).put("pos", it.positionMs).put("len", it.durationMs).put("at", it.at)) }
        prefs.edit().putString("yt_history", a.toString()).apply()
    }

    fun isSubscribed(url: String?) = url != null && subscriptions.any { it.url == url }

    fun toggleSubscribe(c: TubeChannel) {
        subscriptions = if (isSubscribed(c.url)) subscriptions.filter { it.url != c.url } else subscriptions + c.copy(subscribers = -1)
        val a = JSONArray()
        subscriptions.forEach { a.put(JSONObject().put("url", it.url).put("name", it.name).put("avatar", it.avatar ?: "")) }
        prefs.edit().putString("yt_subs", a.toString()).apply()
        notice = if (isSubscribed(c.url)) "Subscribed to ${c.name}." else "Unsubscribed from ${c.name}."
        loadFeed()
    }

    fun toggleWatchLater(v: TubeVideo) {
        watchLater = if (watchLater.any { it.url == v.url }) watchLater.filter { it.url != v.url } else listOf(v) + watchLater
        saveVideos("yt_later", watchLater)
    }

    fun clearHistory() { history = emptyList(); saveHistory() }

    /** Saves where you are in a video (for "Continue watching" and resume). */
    fun savePosition(v: TubeVideo, posMs: Long, lenMs: Long) {
        val done = lenMs > 0 && posMs > lenMs * 0.95
        history = listOf(Watched(v, if (done) 0 else posMs, lenMs, System.currentTimeMillis())) + history.filter { it.video.url != v.url }
        saveHistory()
    }

    fun resumeAt(url: String): Long = history.firstOrNull { it.video.url == url }?.positionMs ?: 0

    /** Videos you started and didn't finish. */
    val continueWatching: List<Watched> get() = history.filter { it.positionMs > 30_000 }

    // --- Home: subscription feed and YouTube's lists ---

    var feed by mutableStateOf<List<TubeVideo>>(emptyList())
        private set
    var kiosks by mutableStateOf<List<Pair<String, List<TubeVideo>>>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    private var homeLoadedAt = 0L

    fun loadHome(force: Boolean = false) {
        if (!force && System.currentTimeMillis() - homeLoadedAt < 20 * 60_000 && (kiosks.isNotEmpty() || feed.isNotEmpty())) return
        homeLoadedAt = System.currentTimeMillis()
        loadFeed()
        loadRecommended(force)
        viewModelScope.launch {
            loading = true
            val r = io { YouTube.kiosks() }
            r.getOrNull()?.let { list -> kiosks = list.map { (n, v) -> n to shown(v) }.filter { it.second.isNotEmpty() } }
            if (r.isFailure && feed.isEmpty()) notice = "Couldn't reach YouTube: ${r.exceptionOrNull()?.message}"
            loading = false
        }
    }

    // --- Recommended (YouTube's home grid) ---

    /**
     * Recommended for you, built on this device the way NewPipe-based apps do it (there's no Google account):
     * the videos YouTube suggests next to what you watched recently, plus your subscriptions' new videos.
     * Before you've watched anything, it starts from Trending.
     */
    var recommended by mutableStateOf<List<TubeVideo>>(emptyList())
        private set
    private var recommendedAt = 0L

    fun loadRecommended(force: Boolean = false) {
        if (!force && recommended.isNotEmpty() && System.currentTimeMillis() - recommendedAt < 30 * 60_000) return
        recommendedAt = System.currentTimeMillis()
        viewModelScope.launch {
            val seeds = history.take(6).map { it.video }
            val watched = history.map { it.video.url }.toSet()
            val fromHistory = withContext(Dispatchers.IO) {
                seeds.map { v -> async { try { YouTube.stream(v.url).relatedItems.mapNotNull { YouTube.toVideo(it) }.take(12) } catch (_: Exception) { emptyList() } } }
                    .awaitAll()
            }
            // Take turns between sources so no single video's suggestions take over.
            val mixed = ArrayList<TubeVideo>()
            val lists = (fromHistory + listOf(feed.take(20))).filter { it.isNotEmpty() }.map { it.toMutableList() }
            while (lists.any { it.isNotEmpty() }) for (l in lists) if (l.isNotEmpty()) mixed += l.removeAt(0)
            var out = shown(mixed).filter { it.url !in watched }.distinctBy { it.url }
            if (out.size < 12) {
                val trending = kiosks.flatMap { it.second }.ifEmpty { io { YouTube.kiosks() }.getOrNull().orEmpty().flatMap { it.second } }
                out = (out + shown(trending)).distinctBy { it.url }
            }
            recommended = out.take(120)
        }
    }

    fun openExplore() { if (screen != TubeScreen.Explore) stack.add(TubeScreen.Explore) }

    private var feedJob: Job? = null

    /** New videos from your subscriptions, newest first (a few channels at a time). */
    fun loadFeed() {
        val subs = subscriptions
        feedJob?.cancel()
        if (subs.isEmpty()) { feed = emptyList(); return }
        feedJob = viewModelScope.launch {
            val all = withContext(Dispatchers.IO) {
                subs.chunked(6).flatMap { chunk ->
                    chunk.map { c -> async { try { YouTube.feed(c.url).take(15) } catch (_: Exception) { emptyList() } } }.awaitAll().flatten()
                }
            }
            feed = shown(all).distinctBy { it.url }.sortedByDescending { it.published }.take(200)
        }
    }

    // --- Search ---

    var query by mutableStateOf("")
        private set
    var suggestions by mutableStateOf<List<String>>(emptyList())
        private set
    var results by mutableStateOf<List<TubeVideo>>(emptyList())
        private set
    var channelResults by mutableStateOf<List<TubeChannel>>(emptyList())
        private set
    var searching by mutableStateOf(false)
        private set
    var recentSearches by mutableStateOf(appPrefs.recentSearches("youtube"))
        private set
    private var suggestJob: Job? = null

    fun openSearch() {
        if (screen != TubeScreen.Search) stack.add(TubeScreen.Search)
    }

    fun typeQuery(q: String) {
        query = q
        suggestJob?.cancel()
        suggestJob = viewModelScope.launch {
            delay(250)
            suggestions = if (q.trim().length < 2) emptyList() else io { YouTube.suggestions(q) }.getOrNull().orEmpty().take(8)
        }
    }

    fun search(q: String = query) {
        val t = q.trim()
        if (t.isEmpty()) return
        query = t
        suggestions = emptyList()
        appPrefs.addRecentSearch("youtube", t)
        recentSearches = appPrefs.recentSearches("youtube")
        viewModelScope.launch {
            searching = true
            val r = io { YouTube.search(t) }
            r.getOrNull()?.let { (v, c) -> results = shown(v); channelResults = c }
            if (r.isFailure) notice = "Search failed: ${r.exceptionOrNull()?.message}"
            searching = false
        }
    }

    fun clearRecent() { appPrefs.clearRecentSearches("youtube"); recentSearches = emptyList() }

    /** For Home's search-everything box. */
    suspend fun quickSearch(q: String): List<TubeVideo> = io { YouTube.search(q).first }.getOrNull()?.let { shown(it) }.orEmpty().take(20)

    // --- Video page ---

    var info by mutableStateOf<StreamInfo?>(null)
        private set
    var related by mutableStateOf<List<TubeVideo>>(emptyList())
        private set
    var votes by mutableStateOf<Pair<Long, Long>?>(null)
        private set
    var infoLoading by mutableStateOf(false)
        private set
    private var infoJob: Job? = null

    fun openVideo(v: TubeVideo) {
        stack.add(TubeScreen.Video(v))
        loadVideo(v)
    }

    private fun loadVideo(v: TubeVideo) {
        info = null
        related = emptyList()
        votes = null
        infoJob?.cancel()
        infoJob = viewModelScope.launch {
            infoLoading = true
            val r = io { YouTube.stream(v.url) }
            info = r.getOrNull()
            related = shown(info?.relatedItems.orEmpty().mapNotNull { YouTube.toVideo(it) })
            if (r.isFailure) notice = "Couldn't load the video: ${r.exceptionOrNull()?.message}"
            infoLoading = false
            YouTube.videoId(v.url)?.let { id -> votes = io { YouTube.votes(id) }.getOrNull() }
        }
    }

    // --- Channel page ---

    var channelPage by mutableStateOf<YouTube.ChannelPage?>(null)
        private set

    fun openChannel(c: TubeChannel) {
        stack.add(TubeScreen.Channel(c))
        channelPage = null
        viewModelScope.launch {
            val r = io { YouTube.channel(c.url) }
            channelPage = r.getOrNull()?.let { it.copy(videos = shown(it.videos)) }
            if (r.isFailure) notice = "Couldn't load the channel: ${r.exceptionOrNull()?.message}"
        }
    }

    fun openChannelOf(v: TubeVideo) {
        val url = v.channelUrl ?: return
        openChannel(TubeChannel(url, v.channel, null))
    }

    fun openLibrary() { if (screen != TubeScreen.Library) stack.add(TubeScreen.Library) }

    // --- Playing ---

    /** The video playing full screen, with its resolved streams. */
    var playing by mutableStateOf<TubeVideo?>(null)
        private set
    var playingInfo by mutableStateOf<StreamInfo?>(null)
        private set

    fun play(v: TubeVideo) {
        val known = info?.takeIf { it.url == v.url || YouTube.videoId(it.url) == YouTube.videoId(v.url) }
        playing = v
        playingInfo = known
        if (known == null) {
            viewModelScope.launch {
                val r = io { YouTube.stream(v.url) }
                if (playing?.url == v.url) playingInfo = r.getOrNull()
                if (r.isFailure) { notice = "Couldn't play: ${r.exceptionOrNull()?.message}"; playing = null }
            }
        }
    }

    /** Next video for autoplay: the first related one you haven't just watched. */
    fun nextAfter(v: TubeVideo): TubeVideo? {
        val rel = (playingInfo?.relatedItems ?: info?.relatedItems).orEmpty().mapNotNull { YouTube.toVideo(it) }
        return shown(rel).firstOrNull { r -> r.url != v.url && history.take(20).none { it.video.url == r.url } }
    }

    /** Plays a video in a corner window (over Live TV, Plex, games or another video). */
    fun playInCorner(v: TubeVideo) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val r = io {
                val i = if (info?.url == v.url) info!! else YouTube.stream(v.url)
                YouTube.mediaSource(i, minOf(maxQuality, 720))
            }
            notice = r.getOrNull()?.let { src -> Corners.addYouTube(ctx, v.title, v.url, src, resumeAt(v.url)) ?: "Playing in a corner window." }
                ?: "Couldn't play: ${r.exceptionOrNull()?.message}"
        }
    }

    fun stopPlaying() {
        playing = null
        playingInfo = null
    }

    fun back() {
        when {
            playing != null -> stopPlaying()
            stack.isNotEmpty() -> {
                stack.removeAt(stack.lastIndex)
                (stack.lastOrNull() as? TubeScreen.Video)?.let { loadVideo(it.video) }
            }
        }
        notice = null
    }

    fun goHome() { stack.clear(); playing = null }

    fun showNotice(t: String?) { notice = t }

    private suspend fun <T> io(block: () -> T): Result<T> = withContext(Dispatchers.IO) {
        try { Result.success(block()) } catch (t: Throwable) { Result.failure(t) }
    }
}
