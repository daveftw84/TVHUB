package com.example.tvhub

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Sports schedules and scores from ESPN's public scoreboard feed (no key needed; it's what ESPN's own
 * site uses, so it isn't an official, documented API and could change).
 */
object Espn {
    data class League(val name: String, val path: String, val extra: String = "")
    data class Sport(val name: String, val emoji: String, val leagues: List<League>)

    val SPORTS = listOf(
        Sport("Football", "⚽", listOf(
            League("Premier League", "soccer/eng.1"), League("MLS", "soccer/usa.1"), League("Champions League", "soccer/uefa.champions"),
            League("La Liga", "soccer/esp.1"), League("Serie A", "soccer/ita.1"), League("Bundesliga", "soccer/ger.1"),
            League("Ligue 1", "soccer/fra.1"), League("Liga MX", "soccer/mex.1"), League("Europa League", "soccer/uefa.europa"),
            League("FA Cup", "soccer/eng.fa"), League("NWSL", "soccer/usa.nwsl"),
        )),
        Sport("American Football", "🏈", listOf(
            League("NFL", "football/nfl"), League("College Football", "football/college-football", "&groups=80&limit=400"),
            League("CFL", "football/cfl"), League("UFL", "football/ufl"),
        )),
        Sport("Basketball", "🏀", listOf(
            League("NBA", "basketball/nba"), League("WNBA", "basketball/wnba"),
            League("NCAA Men", "basketball/mens-college-basketball", "&groups=50&limit=400"),
            League("NCAA Women", "basketball/womens-college-basketball", "&groups=50&limit=400"),
        )),
        Sport("Baseball", "⚾", listOf(League("MLB", "baseball/mlb"), League("College Baseball", "baseball/college-baseball"))),
        Sport("Hockey", "🏒", listOf(League("NHL", "hockey/nhl"))),
        Sport("Fighting", "🥊", listOf(League("UFC", "mma/ufc"), League("PFL", "mma/pfl"))),
        Sport("Motorsport", "🏎️", listOf(League("Formula 1", "racing/f1"), League("NASCAR", "racing/nascar-premier"), League("IndyCar", "racing/irl"))),
        Sport("Golf", "⛳", listOf(League("PGA Tour", "golf/pga"), League("LPGA", "golf/lpga"))),
        Sport("Tennis", "🎾", listOf(League("ATP", "tennis/atp"), League("WTA", "tennis/wta"))),
    )

    data class Team(val name: String, val logo: String?, val score: String?)

    data class Match(
        val id: String,
        val league: String,
        val title: String,           // "Pittsburgh Steelers vs Denver Broncos" (or the event name)
        val start: Long,
        val state: String,           // pre, in, post
        val status: String,          // "Final", "Q3 5:12", "7:00 PM"...
        val away: Team?,
        val home: Team?,
        val channels: List<String>,  // TV networks / streaming services
    ) {
        val live: Boolean get() = state == "in"
        val ended: Boolean get() = state == "post"
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12_000
        c.readTimeout = 20_000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 TVHub")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun parseTime(iso: String): Long = try {
        val f = java.text.SimpleDateFormat(if (iso.length > 17) "yyyy-MM-dd'T'HH:mm:ss" else "yyyy-MM-dd'T'HH:mm", java.util.Locale.US)
        f.timeZone = java.util.TimeZone.getTimeZone("UTC")
        f.parse(iso.removeSuffix("Z").take(19))?.time ?: 0
    } catch (_: Exception) { 0 }

    /** One league's games on a day (yyyyMMdd, US Eastern days as ESPN counts them). */
    fun scoreboard(league: League, day: String): List<Match> {
        val o = JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/${league.path}/scoreboard?dates=$day${league.extra}"))
        val events = o.optJSONArray("events") ?: return emptyList()
        return (0 until events.length()).mapNotNull { i ->
            val e = events.optJSONObject(i) ?: return@mapNotNull null
            val comp = e.optJSONArray("competitions")?.optJSONObject(0)
            val type = (comp?.optJSONObject("status") ?: e.optJSONObject("status"))?.optJSONObject("type")
            val teams = comp?.optJSONArray("competitors")
            var home: Team? = null
            var away: Team? = null
            if (teams != null && teams.length() == 2) {
                for (k in 0 until 2) {
                    val c = teams.optJSONObject(k) ?: continue
                    val t = c.optJSONObject("team") ?: c.optJSONObject("athlete")
                    val team = Team(t?.optString("displayName").orEmpty().ifEmpty { t?.optString("fullName").orEmpty() },
                        t?.optString("logo")?.ifEmpty { null } ?: t?.optJSONObject("flag")?.optString("href"),
                        c.optString("score").ifEmpty { null })
                    if (c.optString("homeAway") == "home") home = team else away = team
                }
            }
            val nets = LinkedHashSet<String>()
            comp?.optJSONArray("broadcasts")?.let { b ->
                for (k in 0 until b.length()) b.optJSONObject(k)?.optJSONArray("names")?.let { n -> for (m in 0 until n.length()) nets += n.optString(m) }
            }
            comp?.optJSONArray("geoBroadcasts")?.let { b ->
                for (k in 0 until b.length()) b.optJSONObject(k)?.optJSONObject("media")?.optString("shortName")?.takeIf { it.isNotEmpty() }?.let { nets += it }
            }
            val title = if (home != null && away != null) "${away.name} vs ${home.name}" else e.optString("name")
            Match(e.optString("id"), league.name, title, parseTime(e.optString("date")), type?.optString("state") ?: "pre",
                type?.optString("shortDetail").orEmpty(), away, home, nets.filter { it.isNotBlank() })
        }.sortedBy { it.start }
    }

    /** Every league of a sport on a day: league -> games (leagues without games left out). */
    fun sportDay(sport: Sport, day: String): List<Pair<League, List<Match>>> {
        val pool = java.util.concurrent.Executors.newFixedThreadPool(4)
        try {
            val futures = sport.leagues.map { l -> l to pool.submit<List<Match>> { runCatching { scoreboard(l, day) }.getOrDefault(emptyList()) } }
            return futures.map { (l, f) -> l to f.get() }.filter { it.second.isNotEmpty() }
        } finally {
            pool.shutdown()
        }
    }

    // ---- Followed teams (Home > Sports > Followed Sport Teams) ----
    data class TeamInfo(val league: String, val path: String, val id: String, val name: String, val logo: String?) {
        fun encode() = listOf(league, path, id, name, logo.orEmpty()).joinToString("|")
        companion object {
            fun decode(s: String): TeamInfo? = s.split("|").takeIf { it.size >= 4 }?.let { TeamInfo(it[0], it[1], it[2], it[3], it.getOrNull(4)?.ifEmpty { null }) }
        }
    }

    /** Every team in a league (for the "Follow a Team" list). */
    fun teams(league: League): List<TeamInfo> {
        val o = JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/${league.path}/teams?limit=500"))
        val arr = o.optJSONArray("sports")?.optJSONObject(0)?.optJSONArray("leagues")?.optJSONObject(0)?.optJSONArray("teams") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optJSONObject("team") }.map { t ->
            TeamInfo(league.name, league.path, t.optString("id"), t.optString("displayName"),
                t.optJSONArray("logos")?.optJSONObject(0)?.optString("href"))
        }.sortedBy { it.name }
    }

    /** A team's next game (or the one being played now), from its schedule. */
    fun nextGame(t: TeamInfo): Match? {
        val o = JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/${t.path}/teams/${t.id}/schedule"))
        val events = o.optJSONArray("events") ?: return null
        val now = System.currentTimeMillis()
        val all = (0 until events.length()).mapNotNull { events.optJSONObject(it) }.map { e ->
            val comp = e.optJSONArray("competitions")?.optJSONObject(0)
            val type = comp?.optJSONObject("status")?.optJSONObject("type")
            val nets = LinkedHashSet<String>()
            comp?.optJSONArray("broadcasts")?.let { b ->
                for (k in 0 until b.length()) b.optJSONObject(k)?.optJSONObject("media")?.optString("shortName")?.takeIf { it.isNotEmpty() }?.let { nets += it }
            }
            Match(e.optString("id"), t.league, e.optString("name"), parseTime(e.optString("date")), type?.optString("state") ?: "pre",
                type?.optString("shortDetail").orEmpty(), null, null, nets.toList())
        }
        return all.firstOrNull { it.live } ?: all.filter { it.start > now - 3 * 3_600_000L && !it.ended }.minByOrNull { it.start }
    }
}
