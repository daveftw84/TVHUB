package com.example.tvhub

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** One Live TV source: an Xtream Codes login, an M3U link, or an M3U file on this device. */
data class Playlist(
    val id: String,
    val name: String,
    val type: String,             // xc, m3u, file
    val server: String = "",      // xc
    val user: String = "",
    val pass: String = "",
    val url: String = "",         // m3u link, or the copied file's path
    val epgCustom: String = "",   // empty = the provider's guide (XC) / none (M3U)
    val updatedAt: Long = 0,
) {
    val subtitle: String get() = when (type) {
        "xc" -> "Username: $user"
        "file" -> "Local M3U file"
        else -> url.take(60)
    }
}

/** Your playlists, and which one Live TV shows. */
object Playlists {
    var all by mutableStateOf<List<Playlist>>(emptyList())
        private set
    var activeId by mutableStateOf("")
        private set
    val active: Playlist? get() = all.firstOrNull { it.id == activeId } ?: all.firstOrNull()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)
    private var loaded = false

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = prefs(ctx)
        all = try {
            val a = JSONArray(p.getString("playlists", "[]"))
            (0 until a.length()).map { a.getJSONObject(it) }.map {
                Playlist(it.getString("id"), it.optString("name"), it.optString("type"), it.optString("server"), it.optString("user"),
                    it.optString("pass"), it.optString("url"), it.optString("epg"), it.optLong("updated"))
            }
        } catch (_: Exception) { emptyList() }
        // First run after updating: turn the old single playlist settings into a playlist.
        if (all.isEmpty()) {
            val prefsOld = AppPrefs(ctx)
            val migrated = when {
                prefsOld.xcServer.isNotBlank() && prefsOld.xcUser.isNotBlank() ->
                    Playlist("p1", "My playlist", "xc", prefsOld.xcServer, prefsOld.xcUser, prefsOld.xcPass, epgCustom = prefsOld.epgUrl)
                prefsOld.playlistUrl.isNotBlank() -> Playlist("p1", "My playlist", "m3u", url = prefsOld.playlistUrl, epgCustom = prefsOld.epgUrl)
                else -> null
            }
            if (migrated != null) { all = listOf(migrated); save(ctx) }
        }
        activeId = p.getString("playlist_active", all.firstOrNull()?.id ?: "") ?: ""
    }

    private fun save(ctx: Context) {
        val a = JSONArray()
        all.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("type", it.type).put("server", it.server).put("user", it.user)
                .put("pass", it.pass).put("url", it.url).put("epg", it.epgCustom).put("updated", it.updatedAt))
        }
        prefs(ctx).edit().putString("playlists", a.toString()).putString("playlist_active", activeId).apply()
    }

    fun upsert(ctx: Context, p: Playlist) {
        all = if (all.any { it.id == p.id }) all.map { if (it.id == p.id) p else it } else all + p
        if (activeId.isEmpty() || all.size == 1) activeId = p.id
        save(ctx)
    }

    fun remove(ctx: Context, id: String) {
        all = all.filter { it.id != id }
        if (activeId == id) activeId = all.firstOrNull()?.id ?: ""
        save(ctx)
    }

    fun select(ctx: Context, id: String) { activeId = id; save(ctx) }

    fun touched(ctx: Context, id: String) {
        all = all.map { if (it.id == id) it.copy(updatedAt = System.currentTimeMillis()) else it }
        save(ctx)
    }

    fun newId() = "p" + System.currentTimeMillis()
}
