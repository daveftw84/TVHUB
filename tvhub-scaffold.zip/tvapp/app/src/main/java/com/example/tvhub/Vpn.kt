package com.example.tvhub

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.StringReader

/**
 * A WireGuard VPN built into TV Hub (WireGuard's own Android library). Paste or import the WireGuard
 * config your VPN provider gives you (Mullvad, Proton VPN, Surfshark, PIA, IVPN, AirVPN, your own
 * server...). It can cover only TV Hub (IPTV, Plex, YouTube...) or the whole device.
 */
object Vpn {
    enum class State { OFF, CONNECTING, ON, ERROR }

    var state by mutableStateOf(State.OFF)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    var received by mutableStateOf(0L)
        private set
    var sent by mutableStateOf(0L)
        private set

    private var backend: GoBackend? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val tunnel = object : Tunnel {
        override fun getName() = "tvhub"
        override fun onStateChange(newState: Tunnel.State) {
            state = if (newState == Tunnel.State.UP) State.ON else State.OFF
        }
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tvhub", Context.MODE_PRIVATE)

    fun savedConfig(ctx: Context): String = prefs(ctx).getString("vpn_config", "").orEmpty()
    fun onlyThisApp(ctx: Context): Boolean = prefs(ctx).getBoolean("vpn_app_only", true)
    fun autoConnect(ctx: Context): Boolean = prefs(ctx).getBoolean("vpn_auto", false)

    fun save(ctx: Context, config: String, appOnly: Boolean, auto: Boolean) {
        prefs(ctx).edit().putString("vpn_config", config.trim()).putBoolean("vpn_app_only", appOnly).putBoolean("vpn_auto", auto).apply()
    }

    /** Android's "allow this app to set up a VPN" screen, when it hasn't been allowed yet (else null). */
    fun permissionIntent(ctx: Context): Intent? = android.net.VpnService.prepare(ctx)

    /** Checks a config without connecting. Returns an error message, or null when it's fine. */
    fun check(text: String): String? = try {
        Config.parse(BufferedReader(StringReader(text)))
        null
    } catch (e: Exception) {
        "That config isn't valid: ${e.message ?: e.javaClass.simpleName}"
    }

    /** "TV Hub only": adds IncludedApplications to the [Interface] section, so only this app uses the VPN. */
    private fun withAppOnly(text: String, pkg: String): String {
        val lines = text.lines().filter { !it.trim().startsWith("IncludedApplications", true) && !it.trim().startsWith("ExcludedApplications", true) }
        val i = lines.indexOfFirst { it.trim().equals("[Interface]", true) }
        if (i < 0) return text
        return (lines.take(i + 1) + "IncludedApplications = $pkg" + lines.drop(i + 1)).joinToString("\n")
    }

    fun connect(ctx: Context) {
        val app = ctx.applicationContext
        val text = savedConfig(app)
        if (text.isBlank()) { message = "Add your WireGuard config first."; return }
        if (permissionIntent(app) != null) { message = "Allow TV Hub to set up a VPN first."; return }
        state = State.CONNECTING
        message = null
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val finalText = if (onlyThisApp(app)) withAppOnly(text, app.packageName) else text
                    val config = Config.parse(BufferedReader(StringReader(finalText)))
                    val b = backend ?: GoBackend(app).also { backend = it }
                    b.setState(tunnel, Tunnel.State.UP, config)
                }
            }
            r.onSuccess {
                state = State.ON
                message = if (onlyThisApp(app)) "VPN on for TV Hub." else "VPN on for the whole device."
                watchStats()
            }.onFailure {
                state = State.ERROR
                message = "Couldn't connect: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    fun disconnect() {
        val b = backend ?: run { state = State.OFF; return }
        scope.launch {
            withContext(Dispatchers.IO) { runCatching { b.setState(tunnel, Tunnel.State.DOWN, null) } }
            state = State.OFF
            message = "VPN off."
        }
    }

    private fun watchStats() {
        scope.launch {
            while (state == State.ON) {
                val stats = withContext(Dispatchers.IO) { runCatching { backend?.getStatistics(tunnel) }.getOrNull() }
                if (stats != null) { received = stats.totalRx(); sent = stats.totalTx() }
                kotlinx.coroutines.delay(2_000)
            }
        }
    }

    /** At start-up: connect when "connect automatically" is on and permission was already given. */
    fun autoStart(ctx: Context) {
        if (autoConnect(ctx) && savedConfig(ctx).isNotBlank() && permissionIntent(ctx) == null && state == State.OFF) connect(ctx)
    }

    fun size(bytes: Long): String = when {
        bytes >= 1L shl 30 -> String.format(java.util.Locale.US, "%.2f GB", bytes / (1L shl 30).toDouble())
        bytes >= 1L shl 20 -> String.format(java.util.Locale.US, "%.1f MB", bytes / (1L shl 20).toDouble())
        else -> "${bytes / 1024} KB"
    }
}
