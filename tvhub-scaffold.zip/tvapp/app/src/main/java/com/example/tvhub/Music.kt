package com.example.tvhub

import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.channel.ChannelInfoItem
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.IOException

/** A song (a YouTube Music track or video). */
data class Song(val url: String, val title: String, val artist: String, val artistUrl: String?, val art: String?, val durationSec: Long)

/** An album, playlist or artist from YouTube Music search. */
data class MusicCollection(val url: String, val title: String, val subtitle: String, val art: String?, val kind: Kind) {
    enum class Kind { ALBUM, PLAYLIST, ARTIST }
}

/** YouTube Music through NewPipe Extractor (no account needed): search, albums, playlists, artists and radio. */
object Music {
    private val yt get() = ServiceList.YouTube

    private fun best(images: List<org.schabi.newpipe.extractor.Image>): String? = images.maxByOrNull { it.height }?.url

    fun toSong(item: InfoItem): Song? {
        val s = item as? StreamInfoItem ?: return null
        return Song(s.url, s.name, s.uploaderName.orEmpty().removeSuffix(" - Topic"), s.uploaderUrl, best(s.thumbnails), s.duration)
    }

    fun fromVideo(v: TubeVideo) = Song(v.url, v.title, v.channel.removeSuffix(" - Topic"), v.channelUrl, v.thumb, v.durationSec)

    private fun search(q: String, filter: String): List<InfoItem> {
        YouTube.init()
        val ex = yt.getSearchExtractor(q, listOf(filter), "")
        ex.fetchPage()
        return ex.initialPage.items
    }

    data class Results(val songs: List<Song>, val albums: List<MusicCollection>, val playlists: List<MusicCollection>, val artists: List<MusicCollection>)

    fun searchAll(q: String): Results {
        fun safe(f: String) = try { search(q, f) } catch (_: Exception) { emptyList() }
        val songs = safe(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS).mapNotNull { toSong(it) }
        fun lists(f: String, kind: MusicCollection.Kind) = safe(f).mapNotNull { i ->
            when (i) {
                is PlaylistInfoItem -> MusicCollection(i.url, i.name, i.uploaderName.orEmpty(), best(i.thumbnails), kind)
                is ChannelInfoItem -> MusicCollection(i.url, i.name, if (i.subscriberCount > 0) YouTube.compact(i.subscriberCount) + " subscribers" else "Artist", best(i.thumbnails), kind)
                else -> null
            }
        }
        return Results(
            songs,
            lists(YoutubeSearchQueryHandlerFactory.MUSIC_ALBUMS, MusicCollection.Kind.ALBUM),
            lists(YoutubeSearchQueryHandlerFactory.MUSIC_PLAYLISTS, MusicCollection.Kind.PLAYLIST),
            lists(YoutubeSearchQueryHandlerFactory.MUSIC_ARTISTS, MusicCollection.Kind.ARTIST),
        )
    }

    fun suggestions(q: String): List<String> = YouTube.suggestions(q)

    /** The songs of an album or playlist, or an artist's songs. */
    fun songsOf(c: MusicCollection): List<Song> {
        YouTube.init()
        return when (c.kind) {
            MusicCollection.Kind.ARTIST -> YouTube.channel(c.url).videos.map { fromVideo(it) }
            else -> PlaylistInfo.getInfo(yt, c.url).relatedItems.mapNotNull { toSong(it) }
        }
    }

    /** A radio (YouTube Music's endless mix) starting from a song: what YouTube Music recommends with it. */
    fun radio(song: Song): List<Song> {
        val id = YouTube.videoId(song.url) ?: return emptyList()
        return try {
            PlaylistInfo.getInfo(yt, "https://www.youtube.com/watch?v=$id&list=RDAMVM$id").relatedItems.mapNotNull { toSong(it) }
        } catch (_: Exception) {
            try {
                PlaylistInfo.getInfo(yt, "https://www.youtube.com/watch?v=$id&list=RD$id").relatedItems.mapNotNull { toSong(it) }
            } catch (_: Exception) {
                emptyList()
            }
        }
    }

    /** Audio only (the best quality, the original language track), with the song's details for the notification. */
    fun audioSource(song: Song): MediaSource {
        val info = YouTube.stream(song.url)
        val meta = MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist)
            .setArtworkUri(song.art?.let { android.net.Uri.parse(it) }).build()
        val df = YouTube.dataSourceFactory()
        val audio = info.audioStreams.filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
            .sortedWith(compareBy<org.schabi.newpipe.extractor.stream.AudioStream> {
                if (it.audioTrackType == null || it.audioTrackType.name == "ORIGINAL") 0 else 1
            }.thenByDescending { it.averageBitrate })
            .firstOrNull()
        if (audio != null) {
            return ProgressiveMediaSource.Factory(df).createMediaSource(MediaItem.Builder().setUri(audio.content).setMediaId(song.url).setMediaMetadata(meta).build())
        }
        if (!info.hlsUrl.isNullOrEmpty()) {
            return HlsMediaSource.Factory(df).createMediaSource(MediaItem.Builder().setUri(info.hlsUrl).setMediaId(song.url).setMediaMetadata(meta).build())
        }
        throw IOException("No audio for this song.")
    }

    /** Fills in the art and artist when a song came from somewhere with fewer details. */
    fun details(song: Song): Song = try {
        val i: StreamInfo = YouTube.stream(song.url)
        song.copy(title = i.name, artist = i.uploaderName.orEmpty().removeSuffix(" - Topic"), art = artUrlOr(i, song), durationSec = i.duration)
    } catch (_: Exception) { song }

    private fun artUrlOr(i: StreamInfo, s: Song) = best(i.thumbnails) ?: s.art
}
