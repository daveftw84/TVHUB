package com.example.tvhub

import android.graphics.Bitmap
import android.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.BindException
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/**
 * Tiny web server so you can type your URLs on a phone instead of the TV remote.
 *
 * - Only runs while the Settings screen is open.
 * - Only reachable on your local network.
 * - Saving needs the 4-digit code shown on the TV, and locks after 5 wrong tries.
 * - The page never shows your saved URLs (they often contain provider logins).
 */
class SetupServer(
    private val onSave: (playlist: String, epg: String) -> Unit,
) {
    val code: String = (SecureRandom().nextInt(9000) + 1000).toString()
    private val failures = AtomicInteger(0)
    @Volatile private var server: ServerSocket? = null

    /** Binds the first free port from 8080 and starts serving. Returns the port, or -1. */
    fun start(): Int {
        for (port in 8080..8089) {
            try {
                val s = ServerSocket(port)
                server = s
                thread(isDaemon = true) { serve(s) }
                return port
            } catch (_: BindException) {
            }
        }
        return -1
    }

    fun stop() {
        try {
            server?.close()
        } catch (_: IOException) {
        }
        server = null
    }

    private fun serve(s: ServerSocket) {
        while (!s.isClosed) {
            try {
                val client = s.accept()
                thread(isDaemon = true) { client.use { handle(it) } }
            } catch (_: IOException) {
                return
            }
        }
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            if (sb.length > 8192) return null
            sb.append(b.toChar())
        }
    }

    private fun handle(sock: Socket) {
        try {
            sock.soTimeout = 5_000
            val input = BufferedInputStream(sock.getInputStream())
            val out = sock.getOutputStream()
            val request = readLine(input) ?: return
            var length = 0
            while (true) {
                val h = readLine(input) ?: break
                if (h.isEmpty()) break
                if (h.startsWith("Content-Length:", ignoreCase = true)) {
                    length = h.substringAfter(':').trim().toIntOrNull() ?: 0
                }
            }
            val method = request.substringBefore(' ')
            val path = request.substringAfter(' ').substringBefore(' ')

            if (method == "POST" && path == "/save") {
                val buf = ByteArray(length.coerceIn(0, 16_384))
                var read = 0
                while (read < buf.size) {
                    val n = input.read(buf, read, buf.size - read)
                    if (n < 0) break
                    read += n
                }
                val form = String(buf, 0, read, Charsets.UTF_8).split('&').mapNotNull { kv ->
                    val i = kv.indexOf('=')
                    if (i < 0) null
                    else URLDecoder.decode(kv.substring(0, i), "UTF-8") to URLDecoder.decode(kv.substring(i + 1), "UTF-8")
                }.toMap()

                val playlist = form["playlist"].orEmpty().trim()
                val epg = form["epg"].orEmpty().trim()
                when {
                    failures.get() >= MAX_FAILURES ->
                        respond(out, "429 Too Many Requests", page("Too many wrong codes. Close and reopen Settings on the TV to get a new code."))
                    form["code"]?.trim() != code -> {
                        failures.incrementAndGet()
                        respond(out, "403 Forbidden", page("Wrong code. Go back and check the code on your TV."))
                    }
                    !playlist.startsWith("http") || (epg.isNotEmpty() && !epg.startsWith("http")) ->
                        respond(out, "400 Bad Request", page("URLs must start with http:// or https://"))
                    else -> {
                        onSave(playlist, epg)
                        respond(out, "200 OK", page("Saved. Your TV is loading the playlist. You can close this page."))
                    }
                }
            } else {
                respond(out, "200 OK", FORM)
            }
        } catch (_: Exception) {
        }
    }

    private fun respond(out: OutputStream, status: String, body: String) {
        val b = body.toByteArray(Charsets.UTF_8)
        out.write(
            ("HTTP/1.1 $status\r\nContent-Type: text/html; charset=utf-8\r\n" +
                "Content-Length: ${b.size}\r\nConnection: close\r\n\r\n").toByteArray()
        )
        out.write(b)
        out.flush()
    }

    private fun esc(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun page(message: String) =
        """<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1">
<body style="font-family:sans-serif;padding:24px;max-width:520px;margin:auto"><p>${esc(message)}</p></body>"""

    companion object {
        private const val MAX_FAILURES = 5

        private const val FORM = """<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TV Hub setup</title>
<body style="font-family:sans-serif;padding:24px;max-width:520px;margin:auto">
<h2>TV Hub setup</h2>
<form method="post" action="/save">
<p><label>Playlist URL (M3U)<br><input name="playlist" placeholder="http://..." style="width:100%;padding:10px;font-size:16px"></label></p>
<p><label>Guide URL (XMLTV, optional)<br><input name="epg" placeholder="http://..." style="width:100%;padding:10px;font-size:16px"></label></p>
<p><label>Code shown on your TV<br><input name="code" inputmode="numeric" style="width:100%;padding:10px;font-size:16px"></label></p>
<p><button style="padding:12px 24px;font-size:16px">Save</button></p>
</form></body>"""

        /** The TV's address on the local network, e.g. 192.168.1.20. */
        fun localIp(): String? = try {
            NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
                .filter { it.isUp && !it.isLoopback }
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }
                ?.hostAddress
        } catch (_: Exception) {
            null
        }

        fun qr(text: String, size: Int = 512): ImageBitmap {
            val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
            val pixels = IntArray(size * size)
            for (y in 0 until size) {
                for (x in 0 until size) {
                    pixels[y * size + x] = if (m.get(x, y)) Color.BLACK else Color.WHITE
                }
            }
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            bmp.setPixels(pixels, 0, size, 0, 0, size, size)
            return bmp.asImageBitmap()
        }
    }
}
