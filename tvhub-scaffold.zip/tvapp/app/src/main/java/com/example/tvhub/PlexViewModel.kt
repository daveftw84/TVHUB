package com.example.tvhub

import android.app.Application
import android.content.Context
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import org.json.JSONObject
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

sealed interface PlexState {
    object SignedOut : PlexState
    data class WaitingForCode(val code: String) : PlexState
    object Loading : PlexState
    data class Failed(val message: String) : PlexState
    object Ready : PlexState
}

sealed interface PlexScreen {
    object Home : PlexScreen
    object Libraries : PlexScreen
    data class Library(val lib: PlexLibrary) : PlexScreen
    data class Grid(val title: String, val path: String) : PlexScreen
    data class Detail(val item: PlexItem) : PlexScreen
    object Search : PlexScreen
    object Trakt : PlexScreen
}

enum class TraktTab(val label: String) {
    UPCOMING("Calendar"), WATCHLIST("Watchlist"), RECOMMENDED("Recommended"), FAVORITES("Favorites"),
    RATED("Rated"), COLLECTION("Collection"), LISTS("Lists"), POPULAR_LISTS("Popular lists"), HISTORY("History"),
}

enum class LibTab(val label: String) {
    RECOMMENDED("Recommended"),
    TRAKT("Trakt"),
    BROWSE("Browse"),
    COLLECTIONS("Collections"),
    CATEGORIES("Categories"),
}

enum class GridSort(val label: String, val param: String) {
    TITLE("A–Z", "titleSort"),
    ADDED("Recently added", "addedAt:desc"),
    RELEASED("Release date", "originallyAvailableAt:desc"),
    RATING("Rating", "audienceRating:desc"),
}

data class HomeRow(val title: String, val items: List<PlexItem>, val seeAll: String? = null)

/** A row of cards on the app's Home tab. [source] is shown beside the title (e.g. "Trakt"). */
data class HubRow2(val title: String, val cards: List<HubTitle>, val source: String? = null)

/** A titled group of rows on Home: Movies, TV Shows, 4K, Español. */
data class HubSection(val title: String, val rows: List<HubRow2>)

/** One card on the app's Home tab: a title, with its Plex item when it's in your library. */
data class HubTitle(
    val title: String,
    val subtitle: String,
    val poster: String?,
    val item: PlexItem?,
    val progress: Float = 0f,
    val overview: String? = null,
    val resume: Boolean = false,   // Continue Watching: plays instead of opening the page
)

class PlexViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("tvhub", Context.MODE_PRIVATE)

    init {
        TraktAccount.load(app)   // so Home and the Trakt chip know whether you're signed in
    }
    private val clientId: String = prefs.getString("client_id", null)
        ?: UUID.randomUUID().toString().also { prefs.edit().putString("client_id", it).apply() }

    var state by mutableStateOf<PlexState>(PlexState.SignedOut)
        private set
    var server by mutableStateOf<PlexServer?>(null)
        private set
    var libraries by mutableStateOf<List<PlexLibrary>>(emptyList())
        private set
    var playing by mutableStateOf<PlexItem?>(null)
        private set
    var notice by mutableStateOf<String?>(null)
        private set

    // --- Home rows ---
    private var plexRows by mutableStateOf<List<HomeRow>>(emptyList())
    /** Trakt lists (only titles you have), shown on Home right under Continue Watching. */
    private var traktRows by mutableStateOf<List<HomeRow>>(emptyList())
    val homeRows: List<HomeRow>
        get() {
            val rows = plexRows
            val cw = rows.takeWhile { it.title == "Continue Watching" }
            return cw + traktRows + rows.drop(cw.size)
        }
    var homeLoading by mutableStateOf(false)
        private set
    private var homeJob: Job? = null

    // --- Navigation: an empty stack means Home ---
    private val stack = mutableStateListOf<PlexScreen>()
    val screen: PlexScreen get() = stack.lastOrNull() ?: PlexScreen.Home
    val canGoBack: Boolean get() = playing != null || stack.isNotEmpty()

    // --- Library page (tabs) ---
    var libTab by mutableStateOf(LibTab.RECOMMENDED)
        private set
    var libHubs by mutableStateOf<List<HomeRow>>(emptyList())
        private set
    var libCollections by mutableStateOf<List<PlexItem>>(emptyList())
        private set
    var libGenres by mutableStateOf<List<PlexGenre>>(emptyList())
        private set
    var libLoading by mutableStateOf(false)
        private set
    private var libGen = 0

    // --- Paged grid (Browse tab, collections, categories, "see all") ---
    val gridItems = mutableStateListOf<PlexItem>()
    var gridLoading by mutableStateOf(false)
        private set
    var gridSort by mutableStateOf(GridSort.TITLE)
        private set
    var gridState by mutableStateOf(LazyGridState())
        private set
    var gridTotalItems by mutableStateOf(0)
        private set
    var gridUnwatched by mutableStateOf(false)
        private set
    var letters by mutableStateOf<List<PlexLetter>>(emptyList())
        private set
    private var lettersLib: String? = null
    private var gridBase: String? = null
    private var gridSortable = false
    private var gridPath: String? = null
    private var gridOffset = 0
    private var gridTotal = 0
    private var gridGen = 0

    // --- Search ---
    var searchQuery by mutableStateOf("")
        private set
    var searchResults by mutableStateOf<List<PlexItem>>(emptyList())
        private set
    var searching by mutableStateOf(false)
        private set
    /** Set when some libraries did not answer in time, so "nothing found" is not mistaken for "no match". */
    var searchProblem by mutableStateOf<String?>(null)
        private set
    private var searchJob: Job? = null

    // --- On-device copy of all titles, so search is instant ---
    private val index = PlexIndex(app)
    private var indexJob: Job? = null
    /** Progress line for the search page, e.g. "Saving Movies for fast search… 12,000 / 74,545". */
    var indexStatus by mutableStateOf<String?>(null)
        private set
    /** True once every library has been saved on the device. */
    var indexReady by mutableStateOf(false)
        private set

    // --- Detail page ---
    var seasons by mutableStateOf<List<PlexItem>>(emptyList())
        private set
    var episodes by mutableStateOf<List<PlexItem>>(emptyList())
        private set
    var selectedSeason by mutableStateOf<PlexItem?>(null)
        private set
    var detailLoading by mutableStateOf(false)
        private set
    private var detailGen = 0

    init {
        prefs.getString("plex_token", null)?.let { connect(it) }
    }

    /** Runs blocking network code off the main thread and turns any failure (even out-of-memory) into a Result. */
    private suspend fun <T> io(block: () -> T): Result<T> = withContext(Dispatchers.IO) {
        try {
            Result.success(block())
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    // ------------------------------------------------------------ Sign-in

    fun signIn() {
        viewModelScope.launch {
            val pinResult = io { PlexApi.createPin(clientId) }
            val pin = pinResult.getOrNull()
            if (pin == null) {
                state = PlexState.Failed(pinResult.exceptionOrNull()?.message ?: "Sign-in failed")
                return@launch
            }
            state = PlexState.WaitingForCode(pin.code)
            repeat(150) {                       // ~5 minutes
                delay(2_000)
                val token = io { PlexApi.checkPin(pin, clientId) }.getOrNull()
                if (token != null) {
                    prefs.edit().putString("plex_token", token).apply()
                    connect(token)
                    return@launch
                }
            }
            state = PlexState.Failed("The code expired. Try again.")
        }
    }

    private fun connect(token: String) {
        viewModelScope.launch {
            state = PlexState.Loading
            val serverResult = io { PlexApi.findServer(token, clientId) }
            val s = serverResult.getOrNull()
            if (s == null) {
                state = PlexState.Failed(serverResult.exceptionOrNull()?.message ?: "Could not reach Plex")
                return@launch
            }
            server = s
            allLibraries = io { PlexApi.libraries(s, clientId) }.getOrNull().orEmpty()
            applyLibraryPrefs()
            state = PlexState.Ready
            refreshHome()
            loadPlexWatchlist()
            startIndexing(s, libraries)
        }
    }

    fun retry() {
        val token = prefs.getString("plex_token", null)
        if (token != null) connect(token) else signIn()
    }

    fun signOut() {
        prefs.edit().remove("plex_token").apply()
        homeJob?.cancel()
        searchJob?.cancel()
        indexJob?.cancel()
        indexStatus = null
        indexReady = false
        viewModelScope.launch { io { index.clear() } }
        server = null
        libraries = emptyList()
        allLibraries = emptyList()
        prefs.edit().remove("plex_account_token").remove("plex_profile").apply()
        plexRows = emptyList()
        traktRows = emptyList()
        hubContinue = emptyList()
        synchronized(leavesCache) { leavesCache.clear() }
        stack.clear()
        libGen++
        libHubs = emptyList()
        libCollections = emptyList()
        libGenres = emptyList()
        libLoading = false
        gridGen++
        gridItems.clear()
        gridPath = null
        gridOffset = 0
        gridTotalItems = 0
        letters = emptyList()
        lettersLib = null
        gridLoading = false
        searchQuery = ""
        searchResults = emptyList()
        playing = null
        notice = null
        state = PlexState.SignedOut
    }

    // ------------------------------------------------------------ Home

    fun refreshHome() {
        val s = server ?: return
        val libs = libraries
        homeJob?.cancel()
        homeJob = viewModelScope.launch {
            homeLoading = true
            try {
                val rows = mutableListOf<HomeRow>()
                io { PlexApi.page(s, clientId, "/library/onDeck", 0, 20).items }.getOrNull()
                    ?.takeIf { it.isNotEmpty() }
                    ?.let { rows += HomeRow("Continue Watching", it) }
                for (lib in libs) {
                    val path = "/library/sections/${lib.id}/all?sort=addedAt:desc"
                    io { PlexApi.page(s, clientId, path, 0, 20).items }
                        .getOrNull()
                        ?.takeIf { it.isNotEmpty() }
                        ?.let { rows += HomeRow("Recently Added in ${lib.title}", it, seeAll = path) }
                }
                plexRows = rows
            } finally {
                homeLoading = false
            }
            loadTraktRows()
        }
    }

    private var traktJob: Job? = null
    private var traktLoadedAt = 0L

    /** Fills the Trakt rows on Home (needs a Trakt Client ID and the saved library list). */
    fun loadTraktRows(force: Boolean = false) {
        val key = traktKey()
        if (key.isEmpty()) {
            traktRows = emptyList()
            return
        }
        if (!force && traktRows.isNotEmpty() && System.currentTimeMillis() - traktLoadedAt < 60 * 60 * 1000) return
        val types = libraries.map { it.type }.toSet()
        traktJob?.cancel()
        traktJob = viewModelScope.launch {
            if ((io { index.count() }.getOrNull() ?: 0) == 0) return@launch
            val specs = buildList {
                if ("movie" in types) add(Triple("movies", "trending", "Trending Movies on Trakt"))
                if ("show" in types) add(Triple("shows", "trending", "Trending Shows on Trakt"))
                if ("movie" in types) add(Triple("movies", "popular", "Popular Movies on Trakt"))
                if ("show" in types) add(Triple("shows", "popular", "Popular Shows on Trakt"))
                if ("movie" in types) add(Triple("movies", "watched/weekly", "Most Watched Movies This Week"))
                if ("show" in types) add(Triple("shows", "watched/weekly", "Most Watched Shows This Week"))
            }
            val rows = ArrayList<HomeRow>()
            // Signed in: your recommendations and watchlist come first.
            val ctx = getApplication<Application>()
            if (TraktAccount.signedIn) {
                val mine = io {
                    val token = TraktAccount.token(ctx) ?: return@io emptyList<Pair<String, List<TraktId>>>()
                    listOf(
                        "Recommended for you on Trakt" to
                            (TraktApi.recommendations(key, token, "movies") + TraktApi.recommendations(key, token, "shows")).map { it.id },
                        "On your Trakt watchlist" to
                            (TraktApi.watchlist(key, token, "movies") + TraktApi.watchlist(key, token, "shows")).map { it.id },
                    )
                }.getOrNull().orEmpty()
                for ((label, ids) in mine) {
                    val items = io { index.matchExternal(ids) }.getOrNull().orEmpty().take(20)
                    if (items.isNotEmpty()) rows += HomeRow(label, items)
                }
                if (rows.isNotEmpty()) traktRows = rows.toList()
            }
            for ((kind, list, label) in specs) {
                val ids = io { TraktApi.list(key, kind, list, 100) }.getOrNull() ?: continue
                val items = io { index.matchExternal(ids) }.getOrNull().orEmpty().take(20)
                if (items.isNotEmpty()) {
                    rows += HomeRow(label, items, seeAll = "trakt://$kind/$list")
                    traktRows = rows.toList()
                }
            }
            traktLoadedAt = System.currentTimeMillis()
        }
    }

    // ------------------------------------------------------------ App Home (the hub on the first tab)

    /** Continue Watching: from Trakt when signed in there, otherwise Plex's On Deck. */
    var hubContinue by mutableStateOf<List<HubTitle>>(emptyList())
        private set
    var hubContinueFrom by mutableStateOf("Plex")
        private set
    /** Home's Movies, TV Shows, 4K and Spanish sections (only titles in your library). */
    var hubSections by mutableStateOf<List<HubSection>>(emptyList())
        private set
    /** Trakt TV calendar: episodes of your shows airing this week (shows in your library). */
    var hubCalendar by mutableStateOf<List<HubTitle>>(emptyList())
        private set
    var hubLoading by mutableStateOf(false)
        private set
    private var hubJob: Job? = null
    private var hubListsAt = 0L
    private var hubListsSignedIn = false
    private val leavesCache = HashMap<String, List<PlexItem>>()

    /**
     * Fills the Home tab. Continue Watching is reloaded every time; the Trakt lists at most hourly
     * (or when [force] is set, or after signing in or out of Trakt).
     */
    fun loadHub(force: Boolean = false) {
        hubJob?.cancel()
        hubJob = viewModelScope.launch {
            hubLoading = true
            synchronized(leavesCache) { leavesCache.clear() }   // new episodes may have been added
            try {
                val ctx = getApplication<Application>()
                val key = traktKey()
                val signedIn = TraktAccount.signedIn && key.isNotEmpty()
                val token = if (signedIn) io { TraktAccount.token(ctx) }.getOrNull() else null

                // Continue Watching
                var cw: List<HubTitle>? = null
                if (token != null) {
                    // Trakt's own Continue Watching list; if that fails, paused titles plus Up Next built here.
                    val merged = io { TraktApi.continueWatching(key, token) }.getOrNull()
                    if (merged != null) {
                        cw = matchPlayback(merged)
                    } else {
                        val paused = io { TraktApi.playback(key, token) }.getOrNull()
                        if (paused != null) {
                            cw = matchPlayback(paused)
                            hubContinueFrom = "Trakt"
                            hubContinue = cw.orEmpty()   // show paused titles while Up Next loads
                            val pausedShows = paused.filter { it.id.isShow }.map { it.id.imdb ?: it.id.tmdb ?: it.id.tvdb ?: it.id.title }.toSet()
                            val next = io { TraktApi.upNext(key, token) }.getOrNull().orEmpty()
                                .filter { (it.id.imdb ?: it.id.tmdb ?: it.id.tvdb ?: it.id.title) !in pausedShows }
                            if (next.isNotEmpty()) cw = matchPlayback((paused + next).sortedByDescending { it.pausedAt })
                        }
                    }
                }
                if (cw != null) {
                    hubContinueFrom = "Trakt"
                } else {
                    hubContinueFrom = "Plex"
                    val s = server
                    cw = if (s == null) emptyList() else
                        io { PlexApi.page(s, clientId, "/library/onDeck", 0, 20).items }.getOrNull().orEmpty().map { item ->
                            HubTitle(item.displayTitle, item.displaySubtitle.orEmpty(), poster(item), item, item.progress, item.summary, resume = true)
                        }
                }
                hubContinue = cw.orEmpty()

                // Only titles in your library are shown, so Continue Watching hides the rest too.
                hubContinue = cw.orEmpty().filter { it.item != null }

                // TV calendar
                if (token != null) {
                    val start = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                    io { TraktApi.myShowsAiring(key, token, start, 7) }.getOrNull()?.let { airing ->
                        val shows = io { index.matchIn(airing.map { it.show }) }.getOrNull() ?: airing.map { null }
                        hubCalendar = airing.mapIndexedNotNull { i, a ->
                            val show = shows.getOrNull(i) ?: return@mapIndexedNotNull null
                            HubTitle(a.show.title, "${airTime(a.airsAt)} · S${a.season} E${a.episode}",
                                a.poster ?: poster(show), show, 0f, a.episodeTitle)
                        }
                    }
                } else {
                    hubCalendar = emptyList()
                }

                // Movies, TV Shows, 4K and Spanish sections
                val stale = System.currentTimeMillis() - hubListsAt > 60 * 60 * 1000L
                if (key.isNotEmpty() && (force || stale || hubListsSignedIn != signedIn || hubSections.isEmpty())) {
                    buildSections(key, token)
                    hubListsAt = System.currentTimeMillis()
                    hubListsSignedIn = signedIn
                }
            } finally {
                hubLoading = false
            }
        }
    }

    private fun isSpanishLib(l: PlexLibrary) = Regex("(?i)spanish|espa[nñ]ol|latino|castellano").containsMatchIn(l.title)
    private fun is4kLib(l: PlexLibrary) = Regex("(?i)\\b4k\\b|uhd|2160").containsMatchIn(l.title)

    /** Libraries with "Spanish" (or Español, Latino) in the name. */
    val spanishLibraries: List<PlexLibrary> get() = libraries.filter { isSpanishLib(it) }

    /** Turns Trakt titles into cards for titles that are in the given libraries (the rest are hidden). */
    private suspend fun cards(list: List<TraktApi.Title>, only: Collection<String>? = null, skip: Collection<String> = emptyList(),
                              avoid: Collection<String> = emptyList(), max: Int = 25): List<HubTitle> {
        val matches = io { index.matchIn(list.map { it.id }, only, skip, avoid) }.getOrNull() ?: return emptyList()
        return list.mapIndexedNotNull { i, t ->
            val item = matches.getOrNull(i) ?: return@mapIndexedNotNull null
            HubTitle(t.id.title, t.year.takeIf { it > 0 }?.toString().orEmpty(), item.let { poster(it) } ?: t.poster, item, 0f, t.overview)
        }.distinctBy { it.item?.ratingKey }.take(max)
    }

    private suspend fun plexCards(path: String, max: Int = 25): List<HubTitle> {
        val s = server ?: return emptyList()
        return io { PlexApi.page(s, clientId, path, 0, max).items }.getOrNull().orEmpty().map { item ->
            HubTitle(item.displayTitle, item.displaySubtitle.orEmpty(), poster(item), item, item.progress, item.summary)
        }
    }

    private suspend fun buildSections(key: String, token: String?) {
        val libs = libraries
        val spanish = libs.filter { isSpanishLib(it) }.map { it.id }
        val fourK = libs.filter { is4kLib(it) && !isSpanishLib(it) }.map { it.id }
        val types = libs.map { it.type }.toSet()
        // Each Trakt list is fetched once, then matched for every section.
        val cache = HashMap<String, List<TraktApi.Title>>()
        suspend fun fetch(name: String, block: () -> List<TraktApi.Title>): List<TraktApi.Title> =
            cache[name] ?: (io(block).getOrNull().orEmpty()).also { cache[name] = it }

        suspend fun kindSection(kind: String, title: String, libType: String): HubSection? {
            if (libType !in types) return null
            val rows = ArrayList<HubRow2>()
            if (token != null) {
                rows += HubRow2("Recommended for You", cards(fetch("rec$kind") { TraktApi.recommended(key, token, kind, 100) }, skip = spanish, avoid = fourK), "Trakt")
                rows += HubRow2("On Your Watchlist", cards(fetch("wl$kind") { TraktApi.watchlistTitles(key, token, kind) }, skip = spanish, avoid = fourK), "Trakt")
                rows += HubRow2("Your Favorites", cards(fetch("fav$kind") { TraktApi.favorites(key, token, kind) }, skip = spanish, avoid = fourK), "Trakt")
                rows += HubRow2("You Rated Highly", cards(fetch("rated$kind") { TraktApi.ratedHigh(key, token, kind) }, skip = spanish, avoid = fourK), "Trakt")
            }
            for (spec in TraktApi.PUBLIC_LISTS) {
                if (spec.moviesOnly && kind != "movies") continue
                val list = fetch(kind + spec.path) { TraktApi.publicList(key, kind, spec.path) }
                rows += HubRow2(spec.label, cards(list, skip = spanish, avoid = fourK), "Trakt")
            }
            for (lib in libs.filter { it.type == libType && it.id !in spanish && it.id !in fourK }) {
                rows += HubRow2("Recently Added in ${lib.title}", plexCards("/library/sections/${lib.id}/all?sort=addedAt:desc"))
            }
            return HubSection(title, rows.filter { it.cards.isNotEmpty() }).takeIf { it.rows.isNotEmpty() }
        }

        val sections = ArrayList<HubSection>()
        kindSection("movies", "Movies", "movie")?.let { sections += it; hubSections = sections.toList() }
        kindSection("shows", "TV Shows", "show")?.let { sections += it; hubSections = sections.toList() }

        // 4K: libraries named 4K / UHD, plus 4K movies in your other movie libraries.
        run {
            val rows = ArrayList<HubRow2>()
            if (fourK.isNotEmpty()) {
                for (kind in listOf("movies", "shows")) {
                    val word = if (kind == "movies") "Movies" else "Shows"
                    rows += HubRow2("Trending $word in 4K", cards(fetch(kind + "trending") { TraktApi.publicList(key, kind, "trending") }, only = fourK), "Trakt")
                    rows += HubRow2("Popular $word in 4K", cards(fetch(kind + "popular") { TraktApi.publicList(key, kind, "popular") }, only = fourK), "Trakt")
                }
                for (lib in libs.filter { it.id in fourK }) {
                    rows += HubRow2("Recently Added in ${lib.title}", plexCards("/library/sections/${lib.id}/all?sort=addedAt:desc"))
                }
            }
            for (lib in libs.filter { it.type == "movie" && it.id !in fourK && it.id !in spanish }) {
                rows += HubRow2("4K Movies in ${lib.title}", plexCards("/library/sections/${lib.id}/all?type=1&resolution=4k&sort=addedAt:desc"))
            }
            HubSection("4K", rows.filter { it.cards.isNotEmpty() }).takeIf { it.rows.isNotEmpty() }?.let {
                sections += it
                hubSections = sections.toList()
            }
        }

        // Spanish: Trakt lists played from your Spanish libraries.
        if (spanish.isNotEmpty()) {
            val rows = ArrayList<HubRow2>()
            for (kind in listOf("movies", "shows")) {
                val word = if (kind == "movies") "Películas" else "Series"
                if (token != null) rows += HubRow2("Recomendadas · $word", cards(fetch("rec$kind") { TraktApi.recommended(key, token, kind, 100) }, only = spanish), "Trakt")
                rows += HubRow2("Tendencias · $word", cards(fetch(kind + "trending") { TraktApi.publicList(key, kind, "trending") }, only = spanish), "Trakt")
                rows += HubRow2("Populares · $word", cards(fetch(kind + "popular") { TraktApi.publicList(key, kind, "popular") }, only = spanish), "Trakt")
                rows += HubRow2("Más vistas esta semana · $word", cards(fetch(kind + "watched/weekly") { TraktApi.publicList(key, kind, "watched/weekly") }, only = spanish), "Trakt")
            }
            for (lib in libs.filter { it.id in spanish }) {
                rows += HubRow2("Recién agregadas en ${lib.title}", plexCards("/library/sections/${lib.id}/all?sort=addedAt:desc"))
            }
            HubSection("Español", rows.filter { it.cards.isNotEmpty() }).takeIf { it.rows.isNotEmpty() }?.let { sections += it }
        }
        hubSections = sections.toList()
    }

    private fun airTime(iso: String): String = try {
        val inFmt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        val d = inFmt.parse(iso.take(19))!!
        java.text.SimpleDateFormat("EEE h:mm a", java.util.Locale.getDefault()).format(d)
    } catch (_: Exception) {
        iso.take(10)
    }

    /** True when this title should play with Spanish audio and subtitles (it's in a Spanish library). */
    fun isSpanish(item: PlexItem): Boolean {
        val lib = item.sectionId ?: return false
        return libraries.any { it.id == lib && isSpanishLib(it) }
    }

    /** Trakt's paused movies and episodes, matched to the exact Plex movie or episode. */
    private suspend fun matchPlayback(list: List<TraktApi.Playback>): List<HubTitle> {
        val matches = io { index.matchEach(list.map { it.id }) }.getOrNull() ?: list.map { null }
        val s = server
        return list.mapIndexed { i, p ->
            var item = matches.getOrNull(i)
            if (p.id.isShow) {
                val showRk = item?.ratingKey
                item = if (s == null || showRk == null) null else {
                    val leaves = synchronized(leavesCache) { leavesCache[showRk] }
                        ?: io { PlexApi.page(s, clientId, "/library/metadata/$showRk/allLeaves", 0, 3000).items }.getOrNull()
                            ?.also { synchronized(leavesCache) { leavesCache[showRk] = it } }
                    leaves?.firstOrNull { it.season == p.season && it.index == p.episode }
                }
            }
            // Picked up where Trakt says you stopped, if Plex itself doesn't know.
            val pct = (p.progress / 100.0).toFloat().coerceIn(0f, 1f)
            if (item != null && item.viewOffset == 0L && item.duration > 0) {
                item = item.copy(viewOffset = (item.duration * pct).toLong())
            }
            val what = if (p.id.isShow) listOfNotNull(if (p.upNext) "Up next" else null, "S${p.season} · E${p.episode}", p.episodeTitle).joinToString(" · ") else "Movie"
            HubTitle(
                title = p.id.title,
                subtitle = if (item != null) what else "$what · not in your library",
                poster = p.poster ?: item?.let { poster(it) },
                item = item,
                progress = pct,
                resume = true,
            )
        }
    }

    /** From Home: plays (resumes) a Continue Watching item. Basic items are fetched in full first. */
    fun resume(item: PlexItem) {
        if (item.playable && !item.light) {
            play(item)
            return
        }
        val s = server ?: return
        val rk = item.ratingKey ?: return
        viewModelScope.launch {
            val full = io { PlexApi.page(s, clientId, "/library/metadata/$rk", 0, 1).items.firstOrNull() }.getOrNull()
            when {
                full == null -> notice = "Couldn't load that title from Plex."
                full.playable -> play(if (full.viewOffset == 0L && item.viewOffset > 0) full.copy(viewOffset = item.viewOffset) else full)
                else -> openDetail(full)
            }
        }
    }

    fun goHome() {
        stack.clear()
        notice = null
    }

    fun goLibraries() {
        stack.clear()
        stack.add(PlexScreen.Libraries)
        notice = null
    }

    // ------------------------------------------------------------ Library page

    private fun libBrowsePath(lib: PlexLibrary) = "/library/sections/${lib.id}/all"

    fun openLibrary(lib: PlexLibrary) {
        notice = null
        libGen++
        libLoading = false
        libTab = LibTab.RECOMMENDED
        libHubs = emptyList()
        libCollections = emptyList()
        libGenres = emptyList()
        letters = emptyList()
        lettersLib = null
        gridUnwatched = false
        stack.add(PlexScreen.Library(lib))
        loadLibTab()
    }

    fun selectLibTab(tab: LibTab) {
        if (tab == libTab) return
        libTab = tab
        notice = null
        loadLibTab()
    }

    private fun loadLibTab() {
        val lib = (stack.lastOrNull() as? PlexScreen.Library)?.lib ?: return
        val s = server ?: return
        when (libTab) {
            LibTab.RECOMMENDED -> if (libHubs.isEmpty()) loadHubs(lib, s)
            LibTab.BROWSE -> {
                startGrid(libBrowsePath(lib), true)
                loadLetters(lib, s)
            }
            LibTab.COLLECTIONS -> if (libCollections.isEmpty()) loadCollections(lib, s)
            LibTab.CATEGORIES -> if (libGenres.isEmpty()) loadGenres(lib, s)
            LibTab.TRAKT -> loadLibTrakt(lib, libTraktMenu)
        }
    }

    // ------------------------------------------------------------ Trakt menus inside a library (only titles in that library)

    /** The Trakt menus for a Movies or TV library: id to label. Your own lists only when signed in. */
    fun libTraktMenus(lib: PlexLibrary): List<Pair<String, String>> {
        val movies = lib.type == "movie"
        val public = listOf("trending" to "Trending", "popular" to "Popular", "anticipated" to "Anticipated",
            "watched/weekly" to "Most Watched This Week", "played/weekly" to "Most Played This Week",
            "collected/weekly" to "Most Collected This Week", "favorited/weekly" to "Most Favorited This Week",
            "watched/all" to "Most Watched of All Time") + (if (movies) listOf("boxoffice" to "Box Office") else emptyList())
        val mine = if (TraktAccount.signedIn) listOf("my:recommended" to "Recommended for You", "my:watchlist" to "Watchlist",
            "my:favorites" to "Favorites", "my:rated" to "Rated Highly", "my:collection" to "Collection") +
            (if (!movies) listOf("my:calendar" to "Calendar") else emptyList()) else emptyList()
        return mine.take(2) + public + mine.drop(2)
    }

    var libTraktMenu by mutableStateOf("trending")
        private set
    var libTraktItems by mutableStateOf<List<HubTitle>>(emptyList())
        private set
    var libTraktLoading by mutableStateOf(false)
        private set

    fun selectLibTrakt(menu: String) {
        val lib = (stack.lastOrNull() as? PlexScreen.Library)?.lib ?: return
        libTraktMenu = menu
        loadLibTrakt(lib, menu)
    }

    private fun loadLibTrakt(lib: PlexLibrary, menu: String) {
        val gen = libGen
        val key = traktKey()
        if (key.isEmpty()) { libTraktItems = emptyList(); notice = "Trakt isn't set up."; return }
        val kind = if (lib.type == "movie") "movies" else "shows"
        libTraktLoading = true
        libTraktItems = emptyList()
        viewModelScope.launch {
            try {
                val ctx = getApplication<Application>()
                val token = if (menu.startsWith("my:")) io { TraktAccount.token(ctx) }.getOrNull() else null
                if (menu == "my:calendar") {
                    val start = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                    val airing = token?.let { t -> io { TraktApi.myShowsAiring(key, t, start, 14) }.getOrNull() }.orEmpty()
                    val shows = io { index.matchIn(airing.map { it.show }, listOf(lib.id)) }.getOrNull().orEmpty()
                    if (gen == libGen) libTraktItems = airing.mapIndexedNotNull { i, a ->
                        val show = shows.getOrNull(i) ?: return@mapIndexedNotNull null
                        HubTitle(a.show.title, "${airTime(a.airsAt)} · S${a.season} E${a.episode}", a.poster ?: poster(show), show, 0f, a.episodeTitle)
                    }
                    return@launch
                }
                val list: List<TraktApi.Title> = io {
                    when (menu) {
                        "my:recommended" -> TraktApi.recommended(key, token!!, kind, 100)
                        "my:watchlist" -> TraktApi.watchlistTitles(key, token!!, kind)
                        "my:favorites" -> TraktApi.favorites(key, token!!, kind)
                        "my:rated" -> TraktApi.ratedHigh(key, token!!, kind)
                        "my:collection" -> TraktApi.collection(key, token!!, kind)
                        else -> TraktApi.publicList(key, kind, menu)
                    }
                }.getOrNull().orEmpty()
                val found = cards(list, only = listOf(lib.id), max = 100)
                if (gen == libGen) libTraktItems = found
            } finally {
                if (gen == libGen) libTraktLoading = false
            }
        }
    }

    private fun loadHubs(lib: PlexLibrary, s: PlexServer) {
        val gen = libGen
        libLoading = true
        viewModelScope.launch {
            val r = io { PlexApi.hubs(s, clientId, "/hubs/sections/${lib.id}?count=15") }
            if (gen != libGen) return@launch
            r.getOrNull()?.let { hubs -> libHubs = hubs.map { HomeRow(it.title, it.items, it.key) } }
            if (r.isFailure) notice = "Couldn't load recommendations."
            libLoading = false
        }
    }

    private fun loadCollections(lib: PlexLibrary, s: PlexServer) {
        val gen = libGen
        libLoading = true
        viewModelScope.launch {
            val r = io { PlexApi.page(s, clientId, "/library/sections/${lib.id}/collections", 0, 300).items }
            if (gen != libGen) return@launch
            libCollections = r.getOrNull().orEmpty()
            if (r.isFailure) notice = "Couldn't load collections."
            libLoading = false
        }
    }

    /**
     * Trakt's Client ID: the one typed in Settings, else the one built into the app
     * (assets/trakt_client_id.txt), so every device gets the Trakt menus without typing anything.
     */
    private fun traktKey(): String = TraktAccount.clientId(getApplication<Application>())

    /** Trakt lists shown as categories (when a Trakt Client ID is built in or set in Settings). */
    private fun traktTiles(lib: PlexLibrary): List<PlexGenre> {
        if (traktKey().isBlank()) return emptyList()
        val kind = if (lib.type == "show") "shows" else "movies"
        return listOf(
            PlexGenre("Trending on Trakt", "trakt://$kind/trending"),
            PlexGenre("Popular on Trakt", "trakt://$kind/popular"),
            PlexGenre("Most Watched This Week", "trakt://$kind/watched/weekly"),
        )
    }

    private var traktGridGen = -1

    /** A Trakt list as a grid: only the titles of the list that are in your library, in the list's order. */
    private fun loadTraktGrid(path: String) {
        val key = traktKey()
        val spec = path.removePrefix("trakt://")             // e.g. "movies/trending"
        val kind = spec.substringBefore('/')
        val list = spec.substringAfter('/')
        val gen = gridGen
        traktGridGen = gen
        gridLoading = true
        viewModelScope.launch {
            val r = io { TraktApi.list(key, kind, list, 200) }
            if (gen != gridGen) return@launch
            val ids = r.getOrNull()
            if (ids == null) {
                notice = "Couldn't reach Trakt. Check the Client ID in Settings and your connection."
            } else {
                val items = io { index.matchExternal(ids) }.getOrNull().orEmpty()
                gridItems.addAll(items)
                gridTotal = items.size
                gridTotalItems = items.size
                notice = if (items.isEmpty()) {
                    if (indexReady) "None of this list is in your library." else
                        "Your library list is still being saved, so matches may be missing."
                } else null
            }
            gridLoading = false
        }
    }

    private fun loadGenres(lib: PlexLibrary, s: PlexServer) {
        val gen = libGen
        libLoading = true
        viewModelScope.launch {
            val r = io { PlexApi.genres(s, clientId, lib.id) }
            if (gen != libGen) return@launch
            libGenres = traktTiles(lib) + r.getOrNull().orEmpty()
            if (r.isFailure) notice = "Couldn't load categories."
            libLoading = false
        }
    }

    // ------------------------------------------------------------ Paged grid

    private fun gridPathFor(base: String, sortable: Boolean): String {
        if (!sortable) return base
        val sep = if (base.contains('?')) "&" else "?"
        return base + sep + "sort=${gridSort.param}" + (if (gridUnwatched) "&unwatched=1" else "")
    }

    /**
     * Starts (or keeps, if it's already showing) the paged list for [base].
     * [offset] starts the list part-way through, which the A–Z jump bar uses.
     */
    private fun startGrid(base: String, sortable: Boolean, offset: Int = 0) {
        val path = gridPathFor(base, sortable)
        gridBase = base
        gridSortable = sortable
        // Coming back from a detail page: keep the items and scroll position.
        if (path == gridPath && offset == gridOffset && (gridItems.isNotEmpty() || gridLoading)) return
        gridGen++
        gridPath = path
        gridOffset = offset
        gridItems.clear()
        gridTotal = 0
        gridLoading = false
        gridState = LazyGridState()
        loadMore()
    }

    fun openGrid(title: String, path: String) {
        notice = null
        stack.add(PlexScreen.Grid(title, path))
        startGrid(path, false)
    }

    fun setSort(sort: GridSort) {
        if (sort == gridSort) return
        gridSort = sort
        val base = gridBase ?: return
        startGrid(base, gridSortable)
    }

    fun setUnwatched(on: Boolean) {
        if (on == gridUnwatched) return
        gridUnwatched = on
        val base = gridBase ?: return
        startGrid(base, gridSortable)
    }

    /** Jump to a position in the A–Z list. The list then starts there; "#" goes back to the beginning. */
    fun jumpTo(index: Int) {
        val base = gridBase ?: return
        startGrid(base, gridSortable, index)
    }

    private fun loadLetters(lib: PlexLibrary, s: PlexServer) {
        if (lettersLib == lib.id && letters.isNotEmpty()) return
        lettersLib = lib.id
        val gen = libGen
        viewModelScope.launch {
            val r = io { PlexApi.firstCharacters(s, clientId, lib.id) }
            if (gen != libGen) return@launch
            letters = r.getOrNull().orEmpty()
        }
    }

    fun loadMore() {
        val s = server ?: return
        val key = gridPath ?: return
        if (gridLoading) return
        if (key.startsWith("trakt://")) {
            if (traktGridGen != gridGen) loadTraktGrid(key)
            return
        }
        if (gridItems.isNotEmpty() && gridOffset + gridItems.size >= gridTotal) return
        val gen = gridGen
        val start = gridOffset + gridItems.size
        gridLoading = true
        viewModelScope.launch {
            val result = io { PlexApi.page(s, clientId, key, start, PAGE_SIZE) }
            if (gen != gridGen) return@launch       // the user switched list or sort meanwhile
            val pg = result.getOrNull()
            if (pg != null) {
                gridItems.addAll(pg.items)
                gridTotal = pg.total
                gridTotalItems = pg.total
                notice = null
            } else {
                notice = "Couldn't load this list. Check your connection and try again."
            }
            gridLoading = false
        }
    }

    // ------------------------------------------------------------ Search

    fun openSearch() {
        if (screen is PlexScreen.Search) return
        searchQuery = ""
        searchResults = emptyList()
        searching = false
        searchProblem = null
        notice = null
        stack.add(PlexScreen.Search)
    }

    fun updateSearch(q: String) {
        searchQuery = q
        searchJob?.cancel()
        searchProblem = null
        val s = server
        val text = q.trim()
        if (s == null || text.length < 2) {
            searchResults = emptyList()
            searching = false
            return
        }
        runSearch(s, text, delayMs = 400)    // wait until the user stops typing
    }

    /** Try the same search again (after a timeout). */
    fun retrySearch() {
        val s = server ?: return
        val text = searchQuery.trim()
        if (text.length < 2) return
        searchJob?.cancel()
        searchProblem = null
        runSearch(s, text, delayMs = 0)
    }

    private fun runSearch(s: PlexServer, text: String, delayMs: Long) {
        searchJob = viewModelScope.launch {
            delay(delayMs)
            searching = true
            // 1. The saved copy on this device answers straight away.
            val local = io { index.search(text) }.getOrNull().orEmpty()
            searchResults = local
            // An IMDb number can only be looked up in the saved copy (the server cannot search by it).
            if (PlexIndex.imdbIdIn(text) != null) {
                searching = false
                if (local.isEmpty() && !indexReady) {
                    searchProblem = "IMDb search works from the saved list, which is still being saved (see above)."
                }
                return@launch
            }
            // 2. The server is asked too (one request per library, all at once), which also finds
            //    episodes and anything not saved yet. Its answers are added as they arrive.
            val targets: List<String?> = libraries.map { it.id }.ifEmpty { listOf(null) }
            val found = HashMap<String?, List<PlexItem>>()
            var discovered: List<PlexItem> = emptyList()
            var failed = 0
            val lock = Any()
            kotlinx.coroutines.coroutineScope {
                // Plex's online catalog finds titles by name quickly; its IDs are matched to the saved copy.
                val token = prefs.getString("plex_token", null)
                if (token != null) launch {
                    val ids = io { PlexApi.discoverSearch(token, clientId, text) }.getOrNull()
                    val mine = if (ids == null) emptyList() else
                        io { index.byIds(ids.imdb, ids.guids) }.getOrNull().orEmpty()
                    synchronized(lock) {
                        discovered = mine
                        searchResults = (local + discovered + targets.flatMap { found[it].orEmpty() })
                            .distinctBy { it.ratingKey }
                    }
                }
                targets.map { id ->
                    launch {
                        val r = io { PlexApi.search(s, clientId, text, id) }
                        synchronized(lock) {
                            if (r.isSuccess) found[id] = r.getOrThrow() else failed++
                            searchResults = (local + discovered + targets.flatMap { found[it].orEmpty() })
                                .distinctBy { it.ratingKey }
                        }
                    }
                }
            }
            searching = false
            // Only worry the user when the saved copy could not cover the gap.
            if (failed > 0 && (searchResults.isEmpty() || !indexReady)) {
                searchProblem = if (failed == targets.size) {
                    "The server didn't answer in time."
                } else {
                    "$failed of ${targets.size} libraries didn't answer in time, so results may be missing."
                }
            }
        }
    }

    // ------------------------------------------------------------ On-device title list

    /**
     * Saves every title of every library on the device, one page at a time (the same paged requests
     * Browse uses). Runs once in the background; later runs only redo a library when its size changed
     * or it is more than a day old.
     */
    private fun startIndexing(s: PlexServer, libs: List<PlexLibrary>) {
        indexJob?.cancel()
        indexJob = viewModelScope.launch {
            if (io { index.getMeta("server") }.getOrNull() != s.name) {
                io { index.clear(); index.setMeta("server", s.name) }
            }
            var allDone = true
            for (lib in libs) {
                val total = io { PlexApi.page(s, clientId, "/library/sections/${lib.id}/all", 0, 1).total }
                    .getOrNull()
                if (total == null) {
                    allDone = false
                    continue
                }
                val have = io { index.count(lib.id) }.getOrNull() ?: 0
                val last = io { index.getMeta("synced_${lib.id}") }.getOrNull()?.toLongOrNull() ?: 0L
                val fresh = System.currentTimeMillis() - last < 24L * 60 * 60 * 1000
                if (have == total && fresh) continue

                val stamp = System.currentTimeMillis()
                var start = 0
                var ok = true
                while (start < total) {
                    indexStatus = "Saving ${lib.title} for fast search… " +
                        "%,d / %,d".format(start, total)
                    var page = io {
                        PlexApi.page(s, clientId, "/library/sections/${lib.id}/all?sort=titleSort&includeGuids=1", start, 300)
                    }
                    if (page.isFailure) {          // one retry
                        delay(3_000)
                        page = io {
                            PlexApi.page(s, clientId, "/library/sections/${lib.id}/all?sort=titleSort&includeGuids=1", start, 300)
                        }
                    }
                    val items = page.getOrNull()?.items
                    if (items == null || items.isEmpty()) {
                        ok = false
                        break
                    }
                    io { index.upsert(lib.id, items, stamp) }
                    start += items.size
                    delay(50)                      // be gentle with the server
                }
                if (ok) {
                    io {
                        index.deleteOlder(lib.id, stamp)
                        index.setMeta("synced_${lib.id}", stamp.toString())
                    }
                } else {
                    allDone = false
                }
            }
            val saved = io { index.count() }.getOrNull() ?: 0
            indexReady = allDone && saved > 0
            loadTraktRows(force = true)   // the saved list may now match more titles
            loadHub(force = true)
            indexStatus = if (indexReady) {
                "Fast search ready · %,d titles saved on this device".format(saved)
            } else if (saved > 0) {
                "Saved %,d titles so far. The rest will finish next time.".format(saved)
            } else {
                null
            }
        }
    }

    /** Instant search of the saved copy of your libraries (used by Home's search). */
    suspend fun quickSearch(q: String): List<PlexItem> = io { index.search(q, 40) }.getOrNull().orEmpty()

    /** Search results come from the saved copy; [open] fetches the full item before showing it. */
    fun openSearchResult(item: PlexItem) = open(item)

    // ------------------------------------------------------------ Opening items and detail page

    /** Collections open as a list of their items; everything else opens its detail page. */
    fun open(item: PlexItem) {
        when {
            item.type == "collection" -> {
                val rk = item.ratingKey ?: return
                openGrid(item.title, "/library/collections/$rk/children")
            }
            item.light -> openFromSavedCopy(item)
            else -> openDetail(item)
        }
    }

    /** Items from search and Trakt rows come from the saved copy (basic details only): fetch the full item first. */
    private fun openFromSavedCopy(item: PlexItem) {
        val s = server
        val rk = item.ratingKey
        if (s == null || rk == null) {
            openDetail(item.copy(light = false))
            return
        }
        viewModelScope.launch {
            val full = io { PlexApi.page(s, clientId, "/library/metadata/$rk", 0, 1).items.firstOrNull() }.getOrNull()
            openDetail(full ?: item.copy(light = false))
        }
    }

    // --- Trakt on the detail page ---

    /** Trakt rating, whether it's on your watchlist, and similar titles you have. */
    data class DetailTrakt(val id: TraktId, val rating: TraktApi.Rating?, val related: List<HubTitle>)

    var detailTrakt by mutableStateOf<DetailTrakt?>(null)
        private set
    var onWatchlist by mutableStateOf<Boolean?>(null)
        private set
    private var watchlistKeys: Set<String>? = null

    private fun loadDetailTrakt(item: PlexItem) {
        detailTrakt = null
        onWatchlist = null
        if (item.type != "movie" && item.type != "show") return
        val s = server ?: return
        val key = traktKey()
        if (key.isEmpty()) return
        val rk = item.ratingKey ?: return
        viewModelScope.launch {
            val full = io { PlexApi.page(s, clientId, "/library/metadata/$rk?includeGuids=1", 0, 1).items.firstOrNull() }.getOrNull() ?: return@launch
            val imdb = full.imdb ?: return@launch
            val isShow = item.type == "show"
            val kind = if (isShow) "shows" else "movies"
            val id = TraktId(item.title, imdb, full.tmdb, full.tvdb, isShow)
            val rating = io { TraktApi.rating(key, kind, imdb) }.getOrNull()
            detailTrakt = DetailTrakt(id, rating, emptyList())
            val related = io { TraktApi.related(key, kind, imdb, 40) }.getOrNull().orEmpty()
            detailTrakt = DetailTrakt(id, rating, cards(related, max = 20).filter { it.item?.ratingKey != rk })
            if (TraktAccount.signedIn) {
                val ctx = getApplication<Application>()
                val keys = watchlistKeys ?: io {
                    val t = TraktAccount.token(ctx) ?: return@io null
                    TraktApi.watchlistKeys(key, t)
                }.getOrNull()?.also { watchlistKeys = it }
                onWatchlist = keys?.contains(imdb)
            }
        }
    }

    private fun traktAction(done: String, block: (String, String, TraktId) -> Unit) {
        val id = detailTrakt?.id ?: return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val r = io {
                val t = TraktAccount.token(ctx) ?: throw IllegalStateException("Sign in to Trakt in Settings.")
                block(traktKey(), t, id)
            }
            notice = if (r.isSuccess) done else "Trakt: ${r.exceptionOrNull()?.message}"
        }
    }

    fun toggleWatchlist() {
        val add = onWatchlist != true
        traktAction(if (add) "Added to your Trakt watchlist." else "Removed from your Trakt watchlist.") { k, t, id ->
            TraktApi.setWatchlist(k, t, id, add)
        }
        onWatchlist = add
        watchlistKeys = null
    }

    fun traktFavorite() = traktAction("Added to your Trakt favorites.") { k, t, id -> TraktApi.setFavorite(k, t, id, true) }
    fun traktMarkWatched() = traktAction("Marked as watched on Trakt.") { k, t, id -> TraktApi.markWatched(k, t, id) }
    fun traktRate(r: Int) = traktAction(if (r == 0) "Rating removed on Trakt." else "Rated $r/10 on Trakt.") { k, t, id -> TraktApi.rate(k, t, id, r) }

    fun openDetail(item: PlexItem) {
        stack.add(PlexScreen.Detail(item))
        notice = null
        loadDetail(item)
        loadDetailTrakt(item)
        loadDetailExtras(item)
    }

    // ------------------------------------------------------------ Detail extras (cast, ratings, trailers, related)

    /** The full item (cast, genres, ratings, logo) for the open detail page. */
    var detailFull by mutableStateOf<PlexItem?>(null)
        private set
    var detailExtras by mutableStateOf<List<PlexItem>>(emptyList())
        private set
    var detailRelated by mutableStateOf<List<PlexHub>>(emptyList())
        private set
    var actorRow by mutableStateOf<Pair<String, List<PlexItem>>?>(null)
        private set
    var onPlexWatchlist by mutableStateOf<Boolean?>(null)
        private set

    private fun loadDetailExtras(item: PlexItem) {
        detailFull = null; detailExtras = emptyList(); detailRelated = emptyList(); actorRow = null; onPlexWatchlist = null
        val s = server ?: return
        val rk = item.ratingKey ?: return
        viewModelScope.launch {
            val full = io { PlexApi.details(s, clientId, rk) }.getOrNull() ?: return@launch
            if ((screen as? PlexScreen.Detail)?.item?.ratingKey != rk) return@launch
            detailFull = full
            // MDBList (Settings > Services): more ratings when the server's agent has few.
            val imdb = full.imdb
            if (imdb != null && MdbList.key.isNotEmpty()) {
                io { MdbList.ratings(imdb) }.getOrNull()?.let { extra ->
                    detailFull = full.copy(ratings = (full.ratings + extra).distinctBy { it.source })
                }
            }
            detailExtras = io { PlexApi.extras(s, clientId, rk) }.getOrNull().orEmpty()
            detailRelated = io { PlexApi.related(s, clientId, rk) }.getOrNull().orEmpty()
            full.guid?.let { g -> onPlexWatchlist = plexWatchlist.any { it.guid == g } }
            val actor = full.cast.firstOrNull { it.id.isNotEmpty() }
            val sec = full.sectionId ?: item.sectionId
            if (actor != null && sec != null) {
                val titles = io { PlexApi.byActor(s, clientId, sec, actor.id) }.getOrNull().orEmpty().filter { it.ratingKey != rk }
                if (titles.isNotEmpty()) actorRow = actor.name to titles
            }
        }
    }

    /** Opens the titles of an actor (from the Cast row). */
    fun openActor(p: PlexPerson, sectionId: String?) {
        val sec = sectionId ?: return
        openGrid("More with ${p.name}", "/library/sections/$sec/all?actor=${p.id}&sort=year:desc")
    }

    fun setWatched(item: PlexItem, watched: Boolean) {
        val s = server ?: return
        val rk = item.ratingKey ?: return
        viewModelScope.launch {
            val ok = io { PlexApi.setWatched(s, clientId, rk, watched) }.isSuccess
            notice = if (!ok) "Couldn't update Plex." else if (watched) "Marked as watched" else "Marked as unwatched"
            if (ok) {
                refreshHome()
                val fresh = io { PlexApi.details(s, clientId, rk) }.getOrNull()
                if (fresh != null && (screen as? PlexScreen.Detail)?.item?.ratingKey == rk) {
                    stack[stack.lastIndex] = PlexScreen.Detail(fresh); detailFull = fresh
                }
                (screen as? PlexScreen.Detail)?.item?.let { cur -> if (cur.ratingKey != rk) refreshDetail() }
            }
        }
    }

    fun ratePlex(item: PlexItem, stars10: Int) {
        val s = server ?: return
        val rk = item.ratingKey ?: return
        viewModelScope.launch {
            notice = if (io { PlexApi.rate(s, clientId, rk, stars10) }.isSuccess) (if (stars10 > 0) "Rated $stars10/10" else "Rating cleared") else "Couldn't rate."
            detailFull = detailFull?.copy(userRating = stars10.toDouble())
        }
    }

    // ------------------------------------------------------------ Plex Watchlist

    var plexWatchlist by mutableStateOf<List<PlexItem>>(emptyList())
        private set

    fun loadPlexWatchlist() {
        val token = prefs.getString("plex_token", null) ?: return
        viewModelScope.launch { io { PlexApi.watchlist(token, clientId) }.getOrNull()?.let { plexWatchlist = it } }
    }

    /** A watchlist title in your libraries (matched by Plex's id, or title and year). */
    suspend fun findInLibrary(w: PlexItem): PlexItem? = io {
        index.search(w.title, 15).firstOrNull { (w.guid != null && it.guid == w.guid) || (it.title.equals(w.title, true) && (w.year == 0 || it.year == w.year)) }
    }.getOrNull()

    fun togglePlexWatchlist(item: PlexItem) {
        val token = prefs.getString("plex_token", null) ?: return
        val g = (detailFull ?: item).guid ?: run { notice = "This title can't be added to the Plex Watchlist."; return }
        val on = onPlexWatchlist != true
        viewModelScope.launch {
            if (io { PlexApi.setWatchlist(token, clientId, g, on) }.isSuccess) {
                onPlexWatchlist = on
                notice = if (on) "Added to your Plex Watchlist" else "Removed from your Plex Watchlist"
                loadPlexWatchlist()
            } else notice = "Couldn't update the Watchlist."
        }
    }

    // ------------------------------------------------------------ Libraries: order, hide, maintenance

    var allLibraries by mutableStateOf<List<PlexLibrary>>(emptyList())
        private set

    private fun applyLibraryPrefs() {
        Opt.init(getApplication())
        val hidden = Opt.set("plex_hidden_libs")
        val order = Opt.str("plex_lib_order", "").split(",").filter { it.isNotEmpty() }
        libraries = allLibraries.filter { it.id !in hidden }.sortedBy { l -> order.indexOf(l.id).let { if (it < 0) Int.MAX_VALUE else it } }
    }

    fun libraryHidden(l: PlexLibrary) = l.id in Opt.set("plex_hidden_libs")

    fun toggleLibraryHidden(l: PlexLibrary) {
        val h = Opt.set("plex_hidden_libs")
        Opt.set("plex_hidden_libs", if (l.id in h) h - l.id else h + l.id)
        applyLibraryPrefs()
    }

    /** All libraries in your order (hidden ones too), for Manage Libraries. */
    val orderedLibraries: List<PlexLibrary> get() {
        val order = Opt.str("plex_lib_order", "").split(",").filter { it.isNotEmpty() }
        return allLibraries.sortedBy { l -> order.indexOf(l.id).let { if (it < 0) Int.MAX_VALUE else it } }
    }

    fun moveLibrary(l: PlexLibrary, by: Int) {
        val list = orderedLibraries.toMutableList()
        val i = list.indexOfFirst { it.id == l.id }
        val j = (i + by).coerceIn(0, list.lastIndex)
        if (i < 0 || i == j) return
        list.add(j, list.removeAt(i))
        Opt.set("plex_lib_order", list.joinToString(",") { it.id })
        applyLibraryPrefs()
    }

    fun libraryAction(l: PlexLibrary, action: String) {
        val s = server ?: return
        viewModelScope.launch {
            notice = if (io { PlexApi.libraryAction(s, clientId, l.id, action) }.isSuccess)
                "${l.title}: " + when (action) { "scan" -> "scanning files"; "refresh" -> "refreshing metadata"; "analyze" -> "analyzing"; else -> "trash emptied" }
            else "Couldn't do that (only the server's owner can)."
        }
    }

    // ------------------------------------------------------------ Plex Home profiles

    var homeUsers by mutableStateOf<List<PlexHomeUser>>(emptyList())
        private set
    val activeProfile: String? get() = prefs.getString("plex_profile", null)

    fun loadHomeUsers() {
        val token = prefs.getString("plex_account_token", null) ?: prefs.getString("plex_token", null) ?: return
        viewModelScope.launch {
            io { PlexApi.homeUsers(token, clientId) }.getOrNull()?.let { homeUsers = it }
        }
    }

    /** Switches profile (Plex Home user). [onDone] gets null on success or the problem. */
    fun switchProfile(u: PlexHomeUser, pin: String?, onDone: (String?) -> Unit) {
        val account = prefs.getString("plex_account_token", null) ?: prefs.getString("plex_token", null) ?: return
        viewModelScope.launch {
            val r = io { PlexApi.switchUser(account, clientId, u.uuid, pin) }
            val token = r.getOrNull()
            if (token == null) { onDone(if (u.protected) "Wrong PIN, or Plex couldn't switch." else (r.exceptionOrNull()?.message ?: "Couldn't switch.")); return@launch }
            prefs.edit().putString("plex_account_token", account).putString("plex_token", token).putString("plex_profile", u.title).apply()
            stack.clear()
            connect(token)
            onDone(null)
        }
    }

    private fun loadDetail(item: PlexItem) {
        seasons = emptyList()
        episodes = emptyList()
        selectedSeason = null
        val s = server ?: return
        val rk = item.ratingKey ?: return
        if (item.type != "show" && item.type != "season") return
        val gen = ++detailGen
        detailLoading = true
        viewModelScope.launch {
            if (item.type == "show") {
                val all = io { PlexApi.children(s, clientId, rk) }.getOrNull().orEmpty()
                    .filter { it.type == "season" }
                if (gen != detailGen) return@launch
                seasons = all
                val first = all.firstOrNull { it.index > 0 && !it.watched }
                    ?: all.firstOrNull { it.index > 0 }
                    ?: all.firstOrNull()
                selectedSeason = first
                val seasonKey = first?.ratingKey
                if (seasonKey != null) {
                    val eps = io { PlexApi.children(s, clientId, seasonKey) }.getOrNull().orEmpty()
                    if (gen != detailGen) return@launch
                    episodes = eps
                }
            } else {
                val eps = io { PlexApi.children(s, clientId, rk) }.getOrNull().orEmpty()
                if (gen != detailGen) return@launch
                episodes = eps
            }
            detailLoading = false
        }
    }

    fun selectSeason(season: PlexItem) {
        val s = server ?: return
        val rk = season.ratingKey ?: return
        selectedSeason = season
        episodes = emptyList()
        val gen = ++detailGen
        detailLoading = true
        viewModelScope.launch {
            val eps = io { PlexApi.children(s, clientId, rk) }.getOrNull().orEmpty()
            if (gen != detailGen) return@launch
            episodes = eps
            detailLoading = false
        }
    }

    /** After playback, refresh watch progress on the page the user returns to. */
    private fun refreshDetail() {
        val s = server ?: return
        val scr = screen as? PlexScreen.Detail ?: return
        val current = scr.item
        viewModelScope.launch {
            if (current.playable) {
                val rk = current.ratingKey ?: return@launch
                val fresh = io { PlexApi.page(s, clientId, "/library/metadata/$rk", 0, 1).items.firstOrNull() }.getOrNull()
                if (fresh != null && screen is PlexScreen.Detail) {
                    stack[stack.lastIndex] = PlexScreen.Detail(fresh)
                }
            } else {
                val parent = if (current.type == "season") current else selectedSeason
                val parentKey = parent?.ratingKey
                if (parentKey != null) {
                    io { PlexApi.children(s, clientId, parentKey) }.getOrNull()?.let { episodes = it }
                }
            }
        }
    }

    // ------------------------------------------------------------ Playback and back

    fun play(item: PlexItem) {
        if (!item.playable) return
        val s = server
        val rk = item.ratingKey
        if (s == null || rk == null) {
            playing = item
            return
        }
        // Lists leave out subtitle files, intro markers and the library; fetch the full item first.
        viewModelScope.launch {
            val full = io { PlexApi.page(s, clientId, "/library/metadata/$rk?includeMarkers=1", 0, 1).items.firstOrNull() }.getOrNull()
            playing = if (full?.playable == true) full.copy(viewOffset = item.viewOffset) else item
        }
    }

    fun showNotice(text: String) { notice = text }

    /**
     * Plex as a catch-up source: the guide programme (show + season/episode, or a movie) in your library.
     * Plays the episode or movie; opens the show when the exact episode isn't there. False when it isn't in Plex.
     */
    suspend fun playProgramme(p: Programme): Boolean {
        val s = server ?: return false
        fun norm(t: String) = t.lowercase().replace(Regex("\\(.*?\\)|[^a-z0-9]"), "")
        val title = norm(p.title)
        if (title.isEmpty()) return false
        val hits = quickSearch(p.title).filter { norm(it.title) == title }
        val show = hits.firstOrNull { it.type == "show" }
        val movie = hits.filter { it.type == "movie" }.let { m -> m.firstOrNull { p.year > 0 && it.year == p.year } ?: m.firstOrNull() }
        if (show != null && (p.season > 0 || movie == null)) {
            val rk = show.ratingKey ?: return false
            if (p.season > 0) {
                val leaves = io { PlexApi.page(s, clientId, "/library/metadata/$rk/allLeaves", 0, 3000).items }.getOrNull().orEmpty()
                val ep = leaves.firstOrNull { it.season == p.season && it.index == p.episode }
                    ?: leaves.firstOrNull { p.subTitle.isNotEmpty() && norm(it.title) == norm(p.subTitle) }
                if (ep != null) { play(ep.copy(viewOffset = 0)); return true }
            } else if (p.subTitle.isNotEmpty()) {
                val leaves = io { PlexApi.page(s, clientId, "/library/metadata/$rk/allLeaves", 0, 3000).items }.getOrNull().orEmpty()
                leaves.firstOrNull { norm(it.title) == norm(p.subTitle) }?.let { play(it.copy(viewOffset = 0)); return true }
            }
            open(show)
            return true
        }
        if (movie != null) { resume(movie.copy(viewOffset = 0)); return true }
        return false
    }

    /** A Plex title cast from a phone. Returns false when this server doesn't have it. */
    suspend fun playByKey(ratingKey: String, startMs: Long): Boolean {
        val s = server ?: return false
        val item = io { PlexApi.page(s, clientId, "/library/metadata/$ratingKey", 0, 1).items.firstOrNull() }.getOrNull() ?: return false
        if (!item.playable) { openDetail(item); return true }
        play(item.copy(viewOffset = startMs))
        return true
    }

    fun subtitleUrl(sub: PlexSubtitle): String? = server?.let { PlexApi.subtitleUrl(it, sub.key) }

    /** The next episode after [ep] (for auto-play), or null. */
    suspend fun nextEpisode(ep: PlexItem): PlexItem? {
        val s = server ?: return null
        val show = ep.showKey ?: return null
        if (ep.type != "episode") return null
        val leaves = io { PlexApi.page(s, clientId, "/library/metadata/$show/allLeaves", 0, 3000).items }.getOrNull() ?: return null
        val i = leaves.indexOfFirst { it.ratingKey == ep.ratingKey }
        return if (i >= 0) leaves.getOrNull(i + 1) else null
    }

    /** Switches the player to another item (auto-play next). */
    fun playNow(item: PlexItem) = play(item.copy(viewOffset = 0))

    fun back() {
        if (playing != null) {
            playing = null
            refreshHome()
            refreshDetail()
            // Refresh the Continue Watching row if we're on a library's Recommended tab.
            val lib = (screen as? PlexScreen.Library)?.lib
            val s = server
            if (lib != null && s != null && libTab == LibTab.RECOMMENDED) loadHubs(lib, s)
            return
        }
        if (stack.isEmpty()) return
        stack.removeAt(stack.lastIndex)
        notice = null
        when (val top = stack.lastOrNull()) {
            is PlexScreen.Library -> if (libTab == LibTab.BROWSE) startGrid(libBrowsePath(top.lib), true, gridOffset)
            is PlexScreen.Grid -> startGrid(top.path, false)
            else -> {}
        }
    }

    fun streamUrl(item: PlexItem): String? =
        server?.let { s -> item.partKey?.let { PlexApi.streamUrl(s, it) } }

    // ------------------------------------------------------------ Pictures

    fun poster(item: PlexItem, width: Int = 300): String? =
        server?.let { s -> (item.posterThumb ?: item.thumb)?.let { PlexApi.imageUrl(s, it, width, width * 3 / 2) } }

    fun landscape(item: PlexItem, width: Int = 480): String? =
        server?.let { s ->
            val path = if (item.type == "episode") item.thumb ?: item.art else item.art ?: item.thumb
            path?.let { PlexApi.imageUrl(s, it, width, width * 9 / 16) }
        }

    /** Any picture from the server (or a full web address), resized. */
    fun image(path: String, w: Int, h: Int): String? =
        if (path.startsWith("http")) path else server?.let { s -> PlexApi.imageUrl(s, path, w, h) }

    fun backdrop(item: PlexItem): String? =
        server?.let { s -> (item.art ?: item.thumb)?.let { PlexApi.imageUrl(s, it, 1280, 720) } }

    fun report(item: PlexItem, state: String, timeMs: Long, durationMs: Long) {
        val s = server ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                PlexApi.reportTimeline(s, clientId, item, state, timeMs, durationMs)
            } catch (_: Throwable) {
            }
            // Scrobble to Trakt (start / pause / stop) when signed in.
            if (TraktAccount.signedIn && TraktAccount.scrobbleOn && durationMs > 0) {
                try {
                    val media = traktMedia(s, item) ?: return@launch
                    TraktAccount.scrobble(getApplication<Application>(), item.ratingKey ?: "", state,
                        timeMs * 100.0 / durationMs, media)
                } catch (_: Throwable) {
                }
            }
        }
    }

    private val traktIds = HashMap<String, JSONObject>()

    /** The Trakt body for a movie or episode, from the IDs Plex has for it (IMDb, TMDB, TVDB). */
    private fun traktMedia(s: PlexServer, item: PlexItem): JSONObject? {
        val rk = item.ratingKey ?: return null
        synchronized(traktIds) { traktIds[rk]?.let { return it } }
        val full = PlexApi.page(s, clientId, "/library/metadata/$rk?includeGuids=1", 0, 1).items.firstOrNull() ?: item
        val ids = JSONObject()
        full.imdb?.let { ids.put("imdb", it) }
        full.tmdb?.toIntOrNull()?.let { ids.put("tmdb", it) }
        full.tvdb?.toIntOrNull()?.let { ids.put("tvdb", it) }
        if (ids.length() == 0) return null
        val kind = if (full.type == "episode") "episode" else if (full.type == "movie") "movie" else return null
        val media = JSONObject().put(kind, JSONObject().put("ids", ids))
        synchronized(traktIds) { traktIds[rk] = media }
        return media
    }

    // ------------------------------------------------------------ Trakt page (needs Trakt sign-in)

    var traktTab by mutableStateOf(TraktTab.UPCOMING)
        private set
    /** Each Trakt entry with the matching Plex item, when it's in your library. */
    var traktEntries by mutableStateOf<List<Pair<TraktEntry, PlexItem?>>>(emptyList())
        private set
    var traktLoading by mutableStateOf(false)
        private set
    private var traktPageJob: Job? = null

    fun openTrakt() {
        if (screen is PlexScreen.Trakt) return
        stack.add(PlexScreen.Trakt)
        loadTraktTab()
    }

    fun selectTraktTab(t: TraktTab) {
        traktTab = t
        traktListOpen = null
        loadTraktTab()
    }

    /** Lists shown on the Lists tabs; picking one shows its titles. */
    var traktLists by mutableStateOf<List<TraktApi.UserList>>(emptyList())
        private set
    var traktListOpen by mutableStateOf<TraktApi.UserList?>(null)
        private set

    private fun titleEntry(t: TraktApi.Title) =
        TraktEntry(t.id.title, listOfNotNull(t.year.takeIf { it > 0 }?.toString(), if (t.id.isShow) "Show" else "Movie").joinToString(" · "), t.id)

    fun openTraktList(l: TraktApi.UserList?) {
        traktListOpen = l
        loadTraktTab()
    }

    private fun loadTraktTab() {
        val ctx = getApplication<Application>()
        val tab = traktTab
        val list0 = traktListOpen
        traktPageJob?.cancel()
        traktEntries = emptyList()
        if (tab != TraktTab.LISTS && tab != TraktTab.POPULAR_LISTS) traktLists = emptyList()
        notice = null
        traktLoading = true
        traktPageJob = viewModelScope.launch {
            val r = io {
                val id = TraktAccount.clientId(ctx)
                val token = TraktAccount.token(ctx) ?: throw IllegalStateException("Sign in to Trakt in Settings.")
                fun both(f: (String) -> List<TraktApi.Title>) = (f("movies") + f("shows")).map { titleEntry(it) }
                when (tab) {
                    TraktTab.UPCOMING -> {
                        val start = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                        TraktApi.calendar(id, token, start, 14)
                    }
                    TraktTab.WATCHLIST -> both { TraktApi.watchlistTitles(id, token, it) }
                    TraktTab.RECOMMENDED -> both { TraktApi.recommended(id, token, it, 100) }
                    TraktTab.FAVORITES -> both { TraktApi.favorites(id, token, it) }
                    TraktTab.RATED -> both { TraktApi.ratedHigh(id, token, it) }
                    TraktTab.COLLECTION -> both { TraktApi.collection(id, token, it) }
                    TraktTab.LISTS, TraktTab.POPULAR_LISTS -> {
                        if (list0 != null) {
                            TraktApi.listItems(id, token, list0.id).map { titleEntry(it) }
                        } else {
                            val lists = if (tab == TraktTab.LISTS) TraktApi.myLists(id, token) else TraktApi.popularLists(id)
                            traktLists = lists
                            emptyList()
                        }
                    }
                    TraktTab.HISTORY -> TraktApi.history(id, token, 100)
                }
            }
            val list = r.getOrNull()
            if (list == null) {
                notice = "Couldn't load from Trakt: ${r.exceptionOrNull()?.message}"
            } else {
                val matches = io { index.matchEach(list.map { it.id }) }.getOrNull() ?: list.map { null }
                // Only what's in your Plex library is shown.
                traktEntries = list.zip(matches).filter { it.second != null }.distinctBy { it.second?.ratingKey + it.first.subtitle }
                val listsTab = tab == TraktTab.LISTS || tab == TraktTab.POPULAR_LISTS
                if (traktEntries.isEmpty() && !(listsTab && list0 == null)) notice = when (tab) {
                    TraktTab.UPCOMING -> "Nothing from your library airing in the next two weeks."
                    TraktTab.HISTORY -> "Nothing you watched is in your library."
                    else -> "None of these are in your Plex library."
                }
                if (listsTab && list0 == null && traktLists.isEmpty()) notice = "No lists yet."
            }
            traktLoading = false
        }
    }

    companion object { const val PAGE_SIZE = 60 }
}
