package com.example.tvhub

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

sealed interface PlexState {
    object SignedOut : PlexState
    data class WaitingForCode(val code: String) : PlexState
    object Loading : PlexState
    data class Failed(val message: String) : PlexState
    object Ready : PlexState
}

class PlexViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("tvhub", Context.MODE_PRIVATE)
    private val clientId: String = prefs.getString("client_id", null)
        ?: UUID.randomUUID().toString().also { prefs.edit().putString("client_id", it).apply() }

    var state by mutableStateOf<PlexState>(PlexState.SignedOut)
        private set
    var server by mutableStateOf<PlexServer?>(null)
        private set
    var libraries by mutableStateOf<List<PlexItem>>(emptyList())
        private set
    var busy by mutableStateOf(false)
        private set
    var playing by mutableStateOf<PlexItem?>(null)
        private set

    private val stack = mutableStateListOf<PlexPage>()
    val page: PlexPage? get() = stack.lastOrNull()
    val canGoBack: Boolean get() = playing != null || stack.isNotEmpty()

    init {
        prefs.getString("plex_token", null)?.let { connect(it) }
    }

    fun signIn() {
        viewModelScope.launch {
            try {
                val pin = withContext(Dispatchers.IO) { PlexApi.createPin(clientId) }
                state = PlexState.WaitingForCode(pin.code)
                repeat(150) {                       // ~5 minutes
                    delay(2_000)
                    val token = withContext(Dispatchers.IO) { PlexApi.checkPin(pin, clientId) }
                    if (token != null) {
                        prefs.edit().putString("plex_token", token).apply()
                        connect(token)
                        return@launch
                    }
                }
                state = PlexState.Failed("The code expired. Try again.")
            } catch (e: Exception) {
                state = PlexState.Failed(e.message ?: "Sign-in failed")
            }
        }
    }

    private fun connect(token: String) {
        viewModelScope.launch {
            state = PlexState.Loading
            try {
                val s = withContext(Dispatchers.IO) { PlexApi.findServer(token, clientId) }
                server = s
                libraries = withContext(Dispatchers.IO) { PlexApi.libraries(s, clientId) }
                state = PlexState.Ready
            } catch (e: Exception) {
                state = PlexState.Failed(e.message ?: "Could not reach Plex")
            }
        }
    }

    fun retry() {
        val token = prefs.getString("plex_token", null)
        if (token != null) connect(token) else signIn()
    }

    fun signOut() {
        prefs.edit().remove("plex_token").apply()
        server = null
        libraries = emptyList()
        stack.clear()
        playing = null
        state = PlexState.SignedOut
    }

    fun open(item: PlexItem) {
        val s = server ?: return
        val path = item.path
        when {
            item.playable -> playing = item
            path != null -> viewModelScope.launch {
                busy = true
                try {
                    val items = withContext(Dispatchers.IO) { PlexApi.browse(s, clientId, path) }
                    stack.add(PlexPage(item.title, items))
                } catch (_: Exception) {
                }
                busy = false
            }
        }
    }

    fun back() {
        if (playing != null) playing = null else if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex)
    }

    fun streamUrl(item: PlexItem): String? =
        server?.let { s -> item.partKey?.let { PlexApi.streamUrl(s, it) } }

    fun imageUrl(item: PlexItem): String? =
        server?.let { s -> item.thumb?.let { PlexApi.imageUrl(s, it) } }

    fun report(item: PlexItem, state: String, timeMs: Long, durationMs: Long) {
        val s = server ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                PlexApi.reportTimeline(s, clientId, item, state, timeMs, durationMs)
            } catch (_: Exception) {
            }
        }
    }
}
