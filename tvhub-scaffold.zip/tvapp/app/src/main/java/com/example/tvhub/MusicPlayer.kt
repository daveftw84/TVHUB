package com.example.tvhub

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * The music player. It lives for the whole app (not one screen), and a media service keeps it going in
 * the background with notification / lock-screen / remote controls, so music plays while you browse,
 * play a game or use other apps.
 */
object MusicPlayer {
    enum class Repeat { OFF, ALL, ONE }

    private var exo: ExoPlayer? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var loadJob: Job? = null
    private lateinit var app: Context

    val queue = mutableStateListOf<Song>()
    var index by mutableStateOf(-1)
        private set
    var playing by mutableStateOf(false)
        private set
    var loading by mutableStateOf(false)
        private set
    var shuffle by mutableStateOf(false)
        private set
    var repeat by mutableStateOf(Repeat.OFF)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    /** Recently played and liked songs (saved on this device). */
    var recent by mutableStateOf<List<Song>>(emptyList())
        private set
    var liked by mutableStateOf<List<Song>>(emptyList())
        private set

    val current: Song? get() = queue.getOrNull(index)

    fun init(ctx: Context) {
        if (exo != null) return
        app = ctx.applicationContext
        exo = ExoPlayer.Builder(app)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build().apply {
                addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                    override fun onPlaybackStateChanged(state: Int) {
                        if (state == Player.STATE_ENDED) next(auto = true)
                    }
                    override fun onPlayerError(e: androidx.media3.common.PlaybackException) {
                        error = "Couldn't play this song: ${e.errorCodeName}"
                        next(auto = true)
                    }
                })
            }
        recent = load("music_recent")
        liked = load("music_liked")
    }

    val player: ExoPlayer get() = exo ?: throw IllegalStateException("MusicPlayer.init first")

    /** What the media session (notification, lock screen, remotes) controls: next / previous go through our queue. */
    fun sessionPlayer(): Player = object : ForwardingPlayer(player) {
        override fun getAvailableCommands(): Player.Commands = super.getAvailableCommands().buildUpon()
            .add(Player.COMMAND_SEEK_TO_NEXT).add(Player.COMMAND_SEEK_TO_PREVIOUS)
            .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM).add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM).build()
        override fun isCommandAvailable(command: Int): Boolean = command in setOf(
            Player.COMMAND_SEEK_TO_NEXT, Player.COMMAND_SEEK_TO_PREVIOUS,
            Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM, Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM,
        ) || super.isCommandAvailable(command)
        override fun seekToNext() = next()
        override fun seekToNextMediaItem() = next()
        override fun seekToPrevious() = previous()
        override fun seekToPreviousMediaItem() = previous()
        override fun hasNextMediaItem() = true
        override fun hasPreviousMediaItem() = true
    }

    // --- Playing ---

    /** Plays [songs] starting at [start]. */
    fun playAll(ctx: Context, songs: List<Song>, start: Int = 0, shuffled: Boolean = false) {
        if (songs.isEmpty()) return
        init(ctx)
        queue.clear()
        if (shuffled) {
            val first = songs[start]
            queue += listOf(first) + (songs - first).shuffled()
            playIndex(ctx, 0)
        } else {
            queue += songs
            playIndex(ctx, start)
        }
    }

    /** Starts a radio: the song, then what YouTube Music recommends with it. */
    fun startRadio(ctx: Context, song: Song) {
        playAll(ctx, listOf(song))
        scope.launch {
            val more = withContext(Dispatchers.IO) { runCatching { Music.radio(song) }.getOrDefault(emptyList()) }
            queue += more.filter { s -> queue.none { it.url == s.url } }
        }
    }

    fun playNext(song: Song) { if (queue.isEmpty()) return; queue.add(index + 1, song) }
    fun addToQueue(song: Song) { queue += song }
    fun removeFromQueue(i: Int) {
        if (i == index || i !in queue.indices) return
        queue.removeAt(i)
        if (i < index) index--
    }

    fun playIndex(ctx: Context, i: Int) {
        if (i !in queue.indices) return
        init(ctx)
        index = i
        error = null
        val song = queue[i]
        remember(song)
        // Keep the media service running so music plays on in the background.
        try { app.startService(Intent(app, MusicService::class.java)) } catch (_: Exception) {}
        loadJob?.cancel()
        loading = true
        loadJob = scope.launch {
            val src = withContext(Dispatchers.IO) { runCatching { Music.audioSource(song) } }
            loading = false
            src.onSuccess {
                player.setMediaSource(it)
                player.prepare()
                player.playWhenReady = true
            }.onFailure {
                error = "Couldn't play ${song.title}: ${it.message}"
            }
        }
    }

    fun toggle() {
        val p = exo ?: return
        if (p.isPlaying) p.pause() else if (current != null) p.play()
    }

    fun pause() { exo?.pause() }

    fun next(auto: Boolean = false) {
        if (queue.isEmpty()) return
        if (auto && repeat == Repeat.ONE) { player.seekTo(0); player.play(); return }
        val n = when {
            shuffle && queue.size > 1 -> (queue.indices - index).random()
            index + 1 < queue.size -> index + 1
            repeat == Repeat.ALL || !auto -> 0
            else -> return
        }
        playIndex(app, n)
    }

    fun previous() {
        if (queue.isEmpty()) return
        if ((exo?.currentPosition ?: 0) > 5_000) { player.seekTo(0); return }
        playIndex(app, if (index > 0) index - 1 else queue.lastIndex)
    }

    fun toggleShuffle() { shuffle = !shuffle }
    fun cycleRepeat() { repeat = Repeat.values()[(repeat.ordinal + 1) % Repeat.values().size] }

    fun stop() {
        exo?.stop()
        queue.clear()
        index = -1
    }

    // --- Recently played and liked ---

    private fun prefs() = app.getSharedPreferences("tvhub", Context.MODE_PRIVATE)

    private fun load(key: String): List<Song> = try {
        val a = JSONArray(prefs().getString(key, "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }.map {
            Song(it.getString("url"), it.optString("title"), it.optString("artist"), it.optString("artistUrl").ifEmpty { null },
                it.optString("art").ifEmpty { null }, it.optLong("dur"))
        }
    } catch (_: Exception) { emptyList() }

    private fun save(key: String, list: List<Song>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("url", it.url).put("title", it.title).put("artist", it.artist).put("artistUrl", it.artistUrl ?: "")
                .put("art", it.art ?: "").put("dur", it.durationSec))
        }
        prefs().edit().putString(key, a.toString()).apply()
    }

    private fun remember(s: Song) {
        recent = (listOf(s) + recent.filter { it.url != s.url }).take(100)
        save("music_recent", recent)
    }

    fun isLiked(s: Song?) = s != null && liked.any { it.url == s.url }

    fun toggleLike(s: Song) {
        liked = if (isLiked(s)) liked.filter { it.url != s.url } else listOf(s) + liked
        save("music_liked", liked)
    }
}

/** Keeps music playing in the background, with the media notification and lock-screen / remote controls. */
class MusicService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        MusicPlayer.init(this)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        session = MediaSession.Builder(this, MusicPlayer.sessionPlayer()).setSessionActivity(open).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!MusicPlayer.playing) stopSelf()
    }

    override fun onDestroy() {
        session?.release()
        session = null
        super.onDestroy()
    }
}
