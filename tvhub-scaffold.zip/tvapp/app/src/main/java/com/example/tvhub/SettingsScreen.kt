package com.example.tvhub

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(live: LiveViewModel) {
    val ctx = LocalContext.current
    val tv = rememberIsTv()
    val prefs = remember { AppPrefs(ctx) }
    var playlist by remember { mutableStateOf(prefs.playlistUrl) }
    var epg by remember { mutableStateOf(prefs.epgUrl) }
    var address by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf(false) }

    val server = remember {
        SetupServer { p, e ->
            Handler(Looper.getMainLooper()).post {
                prefs.playlistUrl = p
                prefs.epgUrl = e
                playlist = p
                epg = e
                saved = true
                live.reload()
            }
        }
    }
    DisposableEffect(Unit) { onDispose { server.stop() } }

    // The phone-setup web page is only useful on a TV, where typing is slow.
    LaunchedEffect(tv) {
        if (tv) {
            val port = withContext(Dispatchers.IO) { server.start() }
            val ip = withContext(Dispatchers.IO) { SetupServer.localIp() }
            address = if (port > 0 && ip != null) "http://$ip:$port" else null
        }
    }

    Row(
        Modifier.fillMaxSize().padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(32.dp),
    ) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Settings", style = MaterialTheme.typography.headlineMedium)
            OutlinedTextField(
                value = playlist,
                onValueChange = { playlist = it; saved = false },
                label = { Text("Playlist URL (M3U)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = epg,
                onValueChange = { epg = it; saved = false },
                label = { Text("Guide URL (XMLTV, optional)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )
            Button(
                onClick = {
                    prefs.playlistUrl = playlist.trim()
                    prefs.epgUrl = epg.trim()
                    live.reload()
                    saved = true
                },
                modifier = Modifier.focusRing(ButtonShape),
            ) { Text(if (saved) "Saved" else "Save and reload") }
        }

        if (tv) {
            Column(Modifier.width(300.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Easier: set up from your phone", style = MaterialTheme.typography.titleMedium)
                val a = address
                if (a != null) {
                    val qr = remember(a) { SetupServer.qr(a) }
                    Image(qr, contentDescription = "QR code for $a", modifier = Modifier.size(220.dp))
                    Text(a)
                    Text("Code: ${server.code}", style = MaterialTheme.typography.titleLarge)
                    Text("Scan the QR code, or open the address on any device on your Wi-Fi, then enter the code.")
                } else {
                    Text("Starting phone setup…")
                }
            }
        }
    }
}
