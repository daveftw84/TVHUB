package com.example.tvhub

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

private enum class SPage(val title: String) {
    MENU("Settings"), PLAYLISTS("Playlists Manager"), RECORDINGS("Recordings, Reminders and Downloads"), TRAKT("Trakt integration"),
    SPORTS("Sports"), VPN("VPN"), CASTING("Casting"), MODS("Playlists Modifications"), CONFIG("App Configuration"),
    GENERAL("General"), PLAYBACK("Playback"), VOD("V.O.D"), BEHAVIOR("App Behavior"), OFFSETS("Recordings and Reminders"),
    MULTIVIEW("MultiView settings"), BUTTONS("Button Mapper"), ABOUT("About"),
    PROFILES("Switch Profile"), APPEARANCE("Appearance"), LIBRARIES("Manage Libraries"), SERVICES("Services"), ADVANCED("Advanced & Backup"),
}

/** Settings, laid out like iMPlayer's App menu: grouped cards that open pages. */
@Composable
fun SettingsScreen(live: LiveViewModel) {
    val ctx = LocalContext.current
    remember { Opt.init(ctx); Playlists.load(ctx); true }
    val plex: PlexViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    var stack by remember { mutableStateOf(listOf(SPage.MENU)) }
    val page = stack.last()
    fun go(p: SPage) { stack = stack + p }
    androidx.activity.compose.BackHandler(enabled = stack.size > 1) { stack = stack.dropLast(1) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            if (stack.size > 1) {
                androidx.compose.material3.TextButton(onClick = { stack = stack.dropLast(1) }, modifier = Modifier.focusRing(ButtonShape)) { Text("←", style = MaterialTheme.typography.titleLarge) }
            }
            Text("TV Hub", style = MaterialTheme.typography.titleLarge, color = androidx.compose.ui.graphics.Color(0xFFE5394A))
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 32.dp)) {
            Text(page.title, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(start = 8.dp, top = 8.dp, bottom = 4.dp))
            when (page) {
                SPage.MENU -> {
                    SettingsHeader("Manage")
                    SettingsCard {
                        MenuRow("📋", "Manage Playlists", Playlists.active?.let { "Live TV: ${it.name}" }) { go(SPage.PLAYLISTS) }
                        SettingsDivider(); MenuRow("⏺", "Recordings, Reminders and Downloads") { go(SPage.RECORDINGS) }
                        SettingsDivider(); MenuRow("✔", "Trakt integration", if (TraktAccount.signedIn) "Signed in" + (TraktAccount.username?.let { " as $it" } ?: "") else "Not signed in") { go(SPage.TRAKT) }
                        SettingsDivider(); MenuRow("⚽", "Sports", "Listings, your teams") { go(SPage.SPORTS) }
                        SettingsDivider(); MenuRow("🔒", "VPN", when (Vpn.state) { Vpn.State.ON -> "Connected"; else -> "WireGuard" }) { go(SPage.VPN) }
                        SettingsDivider(); MenuRow("📺", "Casting", "Receive casts, game rooms") { go(SPage.CASTING) }
                    }
                    SettingsHeader("Plex")
                    SettingsCard {
                        MenuRow("👥", "Profiles", plex.activeProfile?.let { "Active: $it" } ?: "Plex Home users") { go(SPage.PROFILES) }
                        SettingsDivider(); MenuRow("📚", "Manage Libraries", "Reorder and hide libraries") { go(SPage.LIBRARIES) }
                        SettingsDivider(); MenuRow("⇄", "Services", "Trakt, Seerr requests, MDBList ratings") { go(SPage.SERVICES) }
                    }
                    SettingsHeader("Preferences & help")
                    SettingsCard {
                        MenuRow("🗂", "Playlists Modifications", "Groups, hidden channels, hidden leagues") { go(SPage.MODS) }
                        SettingsDivider(); MenuRow("⚙", "App Configuration") { go(SPage.CONFIG) }
                        SettingsDivider(); MenuRow("🎨", "Appearance", if (Opt.str("theme", "dark") == "oled") "OLED" else "Dark") { go(SPage.APPEARANCE) }
                        SettingsDivider(); MenuRow("🛠", "Advanced & Backup", "Logs, image cache, reset, export and import") { go(SPage.ADVANCED) }
                        SettingsDivider(); MenuRow("ℹ", "About") { go(SPage.ABOUT) }
                    }
                }
                SPage.CONFIG -> {
                    SettingsHeader("App preferences")
                    SettingsCard {
                        MenuRow("⚙", "General", "Playlist updates and guide") { go(SPage.GENERAL) }
                        SettingsDivider(); MenuRow("▷", "Playback", "Player settings, audio, subtitles and buffering") { go(SPage.PLAYBACK) }
                        SettingsDivider(); MenuRow("🎞", "V.O.D", "Resume progress, intros and Plex / YouTube playback") { go(SPage.VOD) }
                        SettingsDivider(); MenuRow("🧭", "App Behavior", "Startup and navigation behavior") { go(SPage.BEHAVIOR) }
                        SettingsDivider(); MenuRow("⏺", "Recordings and Reminders", "Offsets") { go(SPage.OFFSETS) }
                        SettingsDivider(); MenuRow("▦", "MultiView settings", "Screens, audio and gestures") { go(SPage.MULTIVIEW) }
                        SettingsDivider(); MenuRow("🎮", "Button Mapper", "Remote, controller and touch buttons") { go(SPage.BUTTONS) }
                    }
                }
                SPage.PLAYLISTS -> PlaylistsManager(live)
                SPage.RECORDINGS -> RecordingsRemindersPage()
                SPage.TRAKT -> {
                    TraktAccountSection(scope)
                    Spacer(Modifier.height(12.dp))
                    var id by remember { mutableStateOf(AppPrefs(ctx).traktClientId) }
                    OutlinedTextField(value = id, onValueChange = { id = it; AppPrefs(ctx).traktClientId = it.trim() }, singleLine = true,
                        label = { Text("Trakt Client ID (only if none is built in)") }, modifier = Modifier.fillMaxWidth())
                }
                SPage.SPORTS -> SportsSection(live)
                SPage.VPN -> VpnSection()
                SPage.CASTING -> CastingSection()
                SPage.MODS -> PlaylistMods(live)
                SPage.GENERAL -> GeneralSettings(live)
                SPage.PLAYBACK -> {
                    SettingsHeader("Media Player")
                    SettingsCard {
                        ChoiceRow("Buffer size", "buffer_size", "default", listOf("xs" to "Extra Small", "s" to "Small", "default" to "Default",
                            "big" to "Big", "xl" to "Extra Big"), note = "Takes effect the next time the app starts.")
                        SettingsDivider()
                        SwitchRow("Real time live streams", "realtime_live", false, "Will reduce loading time and delay of the stream (next start)")
                        SettingsDivider()
                        var ua by remember { mutableStateOf(Opt.str("user_agent", "")) }
                        Column(Modifier.padding(horizontal = 22.dp, vertical = 12.dp)) {
                            Text("Set User-Agent", style = MaterialTheme.typography.titleMedium)
                            OutlinedTextField(value = ua, onValueChange = { ua = it; Opt.set("user_agent", it) }, singleLine = true,
                                placeholder = { Text(USER_AGENT) }, modifier = Modifier.fillMaxWidth())
                        }
                        SettingsDivider()
                        MenuRow("▦", "MultiView settings") { go(SPage.MULTIVIEW) }
                    }
                    PlayerBehaviorSettings()
                    SettingsHeader("Languages and auto-play")
                    PlaybackSection()
                }
                SPage.VOD -> VodPlaybackSettings()
                SPage.BEHAVIOR -> AppBehaviorSettings()
                SPage.OFFSETS -> RecordingsRemindersSettings()
                SPage.MULTIVIEW -> {
                    SettingsHeader("Screens")
                    SettingsCard {
                        ChoiceRow("Maximum screens", "mv_max_s", "5", (2..9).map { it.toString() to it.toString() }) { Opt.set("mv_max", it.toInt()) }
                    }
                    SettingsHeader("Audio")
                    SettingsCard {
                        SwitchRow("Unmute fullscreen", "mv_unmute_full", true, "When a screen becomes the main one, play its audio and mute the others.")
                    }
                    MultiViewSettings()
                }
                SPage.BUTTONS -> ButtonMapperSection()
                SPage.PROFILES -> ProfilesPage(plex)
                SPage.APPEARANCE -> AppearanceSettings()
                SPage.LIBRARIES -> ManageLibrariesPage(plex)
                SPage.SERVICES -> ServicesPage { go(SPage.TRAKT) }
                SPage.ADVANCED -> AdvancedSettings()
                SPage.ABOUT -> {
                    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
                    val deviceId = remember {
                        android.provider.Settings.Secure.getString(ctx.contentResolver, android.provider.Settings.Secure.ANDROID_ID).orEmpty()
                    }
                    SettingsCard {
                        Column(Modifier.padding(18.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                            Text("TV Hub", style = MaterialTheme.typography.headlineSmall)
                            Text("TV Hub is a media player: it doesn't provide any channels, movies or games. Use your own playlists, " +
                                "Plex server and game library.", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    SettingsHeader("TV Hub on your TV")
                    SettingsCard {
                        Text("The same app runs on Android TV (Nvidia Shield). Install the APK there, or cast to it from this phone with the 📺 buttons.",
                            modifier = Modifier.padding(18.dp))
                    }
                    SettingsHeader("App & device")
                    SettingsCard {
                        Text("App Version: ${runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""}",
                            style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(18.dp))
                        SettingsDivider()
                        androidx.compose.foundation.layout.Row(Modifier.fillMaxWidth().clickable {
                            clip.setText(androidx.compose.ui.text.AnnotatedString(deviceId))
                        }.padding(18.dp)) {
                            Text("Device ID:\n$deviceId", fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                modifier = Modifier.weight(1f))
                            Text("⧉", style = MaterialTheme.typography.titleLarge, color = androidx.compose.ui.graphics.Color(0xFF4D8DFF))
                        }
                    }
                    SettingsHeader("Acknowledgements")
                    Text("This product uses the Trakt API but is not endorsed or certified by Trakt. Sports schedules from ESPN. " +
                        "YouTube via NewPipe Extractor; games via RomM and LibretroDroid (GPL-3.0). Plex is a trademark of Plex, Inc.",
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 6.dp))
                    Spacer(Modifier.height(12.dp))
                    androidx.compose.material3.TextButton(onClick = { Opt.set("onboarded", false) }) { Text("Show the welcome tips again (next start)") }
                }
            }
        }
    }
}

@Composable
private fun MenuRow(icon: String, title: String, subtitle: String? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().focusRing().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(icon, color = androidx.compose.ui.graphics.Color(0xFF7FA6FF), modifier = Modifier.width(36.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = androidx.compose.ui.graphics.Color(0xFFAAAAAA))
        }
        Text("›", style = MaterialTheme.typography.titleLarge)
    }
}



@Composable
private fun TraktAccountSection(scope: kotlinx.coroutines.CoroutineScope) {
    val ctx = LocalContext.current
    remember { TraktAccount.load(ctx); true }
    Text("Trakt account", style = MaterialTheme.typography.titleMedium)
    val code = TraktAccount.pending
    when {
        code != null -> {
            Text("On your phone or computer, go to ${code.url} and enter this code:")
            Text(code.userCode, style = MaterialTheme.typography.headlineMedium)
            val qr = remember(code.url) { SetupServer.qr(code.url) }
            Image(qr, contentDescription = "QR code for ${code.url}", modifier = Modifier.size(160.dp))
            Text("Waiting for you to approve…", style = MaterialTheme.typography.bodySmall)
            Button(onClick = { TraktAccount.cancelSignIn() }, modifier = Modifier.focusRing(ButtonShape)) { Text("Cancel") }
        }
        TraktAccount.signedIn -> {
            Text("Signed in" + (TraktAccount.username?.let { " as $it" } ?: "") +
                ". Your recommendations and watchlist appear on Library Home, and the Trakt page " +
                "(Library > Trakt) has your calendar, watchlist, recommendations and history.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { TraktAccount.setScrobble(ctx, !TraktAccount.scrobbleOn) },
                    modifier = Modifier.focusRing(ButtonShape),
                ) { Text(if (TraktAccount.scrobbleOn) "Scrobbling: on" else "Scrobbling: off") }
                Button(onClick = { TraktAccount.signOut(ctx) }, modifier = Modifier.focusRing(ButtonShape)) { Text("Sign out") }
            }
            Text(
                "Scrobbling marks what you watch in the Plex player on Trakt (start, pause and stop; " +
                    "it counts as watched past 80%).",
                style = MaterialTheme.typography.bodySmall,
            )
            val appPrefs = remember { AppPrefs(ctx) }
            var live by remember { mutableStateOf(appPrefs.scrobbleLive) }
            Button(
                onClick = { live = !live; appPrefs.scrobbleLive = live },
                modifier = Modifier.focusRing(ButtonShape),
            ) { Text(if (live) "Scrobble Live TV: on" else "Scrobble Live TV: off") }
            Text(
                "Live TV uses the guide to work out what's on. Shows are only scrobbled when the guide has " +
                    "season and episode numbers; movies only when the title matches exactly one Trakt movie. " +
                    "Anything uncertain is skipped.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        else -> {
            Text("Sign in to get your Trakt recommendations, calendar, watchlist and history, and to scrobble what you watch.")
            if (TraktAccount.needsSecret) {
                var secret by remember { mutableStateOf("") }
                Text(
                    "Signing in needs your Trakt app's Client Secret: trakt.tv > Settings > Your API Apps > your app.",
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedTextField(
                    value = secret,
                    onValueChange = { secret = it },
                    label = { Text("Trakt Client Secret") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth().focusRing(),
                )
                Button(
                    onClick = {
                        TraktAccount.saveSecret(ctx, secret)
                        TraktAccount.startSignIn(ctx)
                    },
                    enabled = secret.isNotBlank() && !TraktAccount.starting,
                    modifier = Modifier.focusRing(ButtonShape),
                ) { Text("Save and sign in") }
            } else {
                Button(
                    onClick = { TraktAccount.startSignIn(ctx) },
                    enabled = !TraktAccount.starting,
                    modifier = Modifier.focusRing(ButtonShape),
                ) { Text(if (TraktAccount.starting) "Getting a code…" else "Sign in to Trakt") }
            }
        }
    }
    TraktAccount.message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
}

private val LANGS = listOf("en" to "English", "es" to "Spanish", "fr" to "French", "de" to "German", "it" to "Italian",
    "pt" to "Portuguese", "ja" to "Japanese", "ko" to "Korean", "zh" to "Chinese", "ru" to "Russian", "ar" to "Arabic", "hi" to "Hindi")

/** Subtitles, audio language and auto-play for the Plex player. */
@Composable
private fun PlaybackSection() {
    val ctx = LocalContext.current
    val p = remember { AppPrefs(ctx) }
    var mode by remember { mutableStateOf(p.subtitleMode) }
    var subLang by remember { mutableStateOf(p.subtitleLang) }
    var audio by remember { mutableStateOf(p.audioLang) }
    var next by remember { mutableStateOf(p.autoPlayNext) }
    var pip by remember { mutableStateOf(p.autoPip) }
    fun name(code: String) = LANGS.firstOrNull { it.first == code }?.second ?: code.ifEmpty { "File default" }
    fun cycle(code: String, allowDefault: Boolean): String {
        val codes = (if (allowDefault) listOf("") else emptyList()) + LANGS.map { it.first }
        return codes[(codes.indexOf(code) + 1).mod(codes.size)]
    }
    Spacer(Modifier.height(8.dp))
    Text("Playback", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            mode = when (mode) { "forced" -> "always"; "always" -> "off"; else -> "forced" }
            p.subtitleMode = mode
        }, modifier = Modifier.focusRing(ButtonShape)) {
            Text("Subtitles: " + when (mode) { "always" -> "always on"; "off" -> "off"; else -> "only forced" })
        }
        Button(onClick = { subLang = cycle(subLang, false); p.subtitleLang = subLang }, modifier = Modifier.focusRing(ButtonShape)) {
            Text("Subtitle language: ${name(subLang)}")
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { audio = cycle(audio, true); p.audioLang = audio }, modifier = Modifier.focusRing(ButtonShape)) {
            Text("Audio language: ${name(audio)}")
        }
        Button(onClick = { next = !next; p.autoPlayNext = next }, modifier = Modifier.focusRing(ButtonShape)) {
            Text(if (next) "Auto-play next episode: on" else "Auto-play next episode: off")
        }
    }
    Button(onClick = { pip = !pip; p.autoPip = pip }, modifier = Modifier.focusRing(ButtonShape)) {
        Text(if (pip) "Picture-in-picture when you press Home: on" else "Picture-in-picture when you press Home: off")
    }
    Text(
        "\"Only forced\" shows subtitles just for foreign-language parts. Titles in libraries with Spanish " +
            "(or Español, Latino) in the name always play with Spanish audio and Spanish subtitles.",
        style = MaterialTheme.typography.bodySmall,
    )
}

/** Sports listings: TheSportsDB key (your "login"), country and the teams you follow. */
@Composable
private fun SportsSection(live: LiveViewModel) {
    val ctx = LocalContext.current
    val p = remember { AppPrefs(ctx) }
    var key by remember { mutableStateOf(p.sportsDbKey) }
    var country by remember { mutableStateOf(p.sportsCountry) }
    var teams by remember { mutableStateOf(live.sportsFavorites.joinToString(", ")) }
    var saved by remember { mutableStateOf(false) }
    Spacer(Modifier.height(8.dp))
    Text("Sports", style = MaterialTheme.typography.titleMedium)
    Text(
        "Live TV > Sports lists the games in your guide. For full listings that name the broadcaster, add your " +
            "TheSportsDB key (thesportsdb.com, Patreon). Games are matched to your channels by name.",
        style = MaterialTheme.typography.bodySmall,
    )
    OutlinedTextField(value = key, onValueChange = { key = it; saved = false }, label = { Text("TheSportsDB API key") },
        singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth().focusRing())
    OutlinedTextField(value = country, onValueChange = { country = it; saved = false }, label = { Text("Country for listings") },
        singleLine = true, modifier = Modifier.fillMaxWidth().focusRing())
    OutlinedTextField(value = teams, onValueChange = { teams = it; saved = false }, label = { Text("Your teams and leagues (comma separated)") },
        singleLine = true, modifier = Modifier.fillMaxWidth().focusRing())
    Button(onClick = {
        p.sportsDbKey = key.trim()
        p.sportsCountry = country.trim().ifEmpty { "United States" }
        live.updateSportsFavorites(teams.split(',').map { it.trim() }.filter { it.isNotEmpty() })
        live.loadSports()
        saved = true
    }, modifier = Modifier.focusRing(ButtonShape)) { Text(if (saved) "Saved" else "Save sports settings") }
}

/** WireGuard VPN: paste / import your provider's config, choose TV Hub only or the whole device. */
@Composable
private fun VpnSection() {
    val ctx = LocalContext.current
    var config by remember { mutableStateOf(Vpn.savedConfig(ctx)) }
    var appOnly by remember { mutableStateOf(Vpn.onlyThisApp(ctx)) }
    var auto by remember { mutableStateOf(Vpn.autoConnect(ctx)) }
    var url by remember { mutableStateOf("") }
    var note by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    fun persist() = Vpn.save(ctx, config, appOnly, auto)
    // Android asks once whether TV Hub may set up a VPN.
    val permission = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { if (Vpn.permissionIntent(ctx) == null) Vpn.connect(ctx) else note = "VPN permission wasn't given." }
    // Import a .conf file (phones and tablets).
    val pick = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        config = try { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty() } catch (e: Exception) { "" }
        note = Vpn.check(config) ?: "Config loaded."
        persist()
    }

    Spacer(Modifier.height(8.dp))
    Text("VPN (WireGuard)", style = MaterialTheme.typography.titleMedium)
    Text(
        "Use the WireGuard config from your VPN provider (Mullvad, Proton VPN, Surfshark, PIA, IVPN, AirVPN, or your own " +
            "server). Paste it, pick the .conf file, or load it from a link.",
        style = MaterialTheme.typography.bodySmall,
    )
    val stateText = when (Vpn.state) {
        Vpn.State.ON -> "● Connected  ↓ ${Vpn.size(Vpn.received)}  ↑ ${Vpn.size(Vpn.sent)}"
        Vpn.State.CONNECTING -> "Connecting…"
        Vpn.State.ERROR -> "Not connected"
        Vpn.State.OFF -> "Off"
    }
    Text(stateText, color = if (Vpn.state == Vpn.State.ON) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
    OutlinedTextField(value = config, onValueChange = { config = it }, label = { Text("WireGuard config ([Interface] ... [Peer] ...)") },
        minLines = 4, maxLines = 10, modifier = Modifier.fillMaxWidth().focusRing())
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("…or a link to the .conf file") }, singleLine = true,
            modifier = Modifier.weight(1f).focusRing())
        Button(onClick = {
            scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { java.net.URL(url.trim()).readText() } }
                r.onSuccess { config = it; note = Vpn.check(it) ?: "Config loaded."; persist() }.onFailure { note = "Couldn't download it: ${it.message}" }
            }
        }, enabled = url.isNotBlank(), modifier = Modifier.focusRing(ButtonShape)) { Text("Load") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { try { pick.launch("*/*") } catch (_: Exception) { note = "No file picker on this device: paste the config or use a link." } },
            modifier = Modifier.focusRing(ButtonShape)) { Text("Pick .conf file") }
        Button(onClick = { appOnly = !appOnly; persist() }, modifier = Modifier.focusRing(ButtonShape)) {
            Text(if (appOnly) "Covers: TV Hub only" else "Covers: whole device")
        }
        Button(onClick = { auto = !auto; persist() }, modifier = Modifier.focusRing(ButtonShape)) {
            Text(if (auto) "Connect at start-up: on" else "Connect at start-up: off")
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (Vpn.state == Vpn.State.ON || Vpn.state == Vpn.State.CONNECTING) {
            Button(onClick = { Vpn.disconnect() }, modifier = Modifier.focusRing(ButtonShape)) { Text("Disconnect") }
        } else {
            Button(onClick = {
                val err = Vpn.check(config)
                if (err != null) { note = err; return@Button }
                persist()
                val intent = Vpn.permissionIntent(ctx)
                if (intent != null) permission.launch(intent) else Vpn.connect(ctx)
            }, enabled = config.isNotBlank(), modifier = Modifier.focusRing(ButtonShape)) { Text("Connect") }
        }
        if (Vpn.state == Vpn.State.ON) Text("Reconnect after changing these settings.", style = MaterialTheme.typography.bodySmall)
    }
    (note ?: Vpn.message)?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
}

/** Casting: this TV receives casts (TV Hub on phones, and DLNA apps) and hosts game rooms. */
@Composable
private fun CastingSection() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("tvhub", android.content.Context.MODE_PRIVATE) }
    var on by remember { mutableStateOf(prefs.getBoolean("cast_receive", true)) }
    Spacer(Modifier.height(8.dp))
    Text("Casting", style = MaterialTheme.typography.titleMedium)
    Text(
        "This device can receive casts on your network: from TV Hub on a phone (the 📺 Cast buttons on Live TV, Plex, " +
            "YouTube, Music and games), and from DLNA apps such as BubbleUPnP, Web Video Caster, VLC or LocalCast. " +
            "Chromecast (Google Cast) can't be received by an app; on a Shield, that one is built into the system.",
        style = MaterialTheme.typography.bodySmall,
    )
    val ip = remember { SetupServer.localIp() }
    if (CastHub.running && ip != null) Text("This device: ${CastHub.deviceName} · $ip:${CastHub.port}", color = MaterialTheme.colorScheme.primary)
    Button(onClick = {
        on = !on
        prefs.edit().putBoolean("cast_receive", on).apply()
        if (on) CastHub.start(ctx)
    }, modifier = Modifier.focusRing(ButtonShape)) {
        Text(if (on) "Receive casts: on" else "Receive casts: off (restart the app to stop)")
    }
}
