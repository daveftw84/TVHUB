package com.example.tvhub

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(live: LiveViewModel) {
    val ctx = LocalContext.current
    val prefs = remember { AppPrefs(ctx) }
    var playlist by remember { mutableStateOf(prefs.playlistUrl) }
    var epg by remember { mutableStateOf(prefs.epgUrl) }
    var address by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf(false) }

    val server = remember {
        SetupServer { p, e ->
            Handler(Looper.getMainLooper()).post {
                prefs.playlistUrl = p
                prefs.epgUrl = e
                playlist = p
                epg = e
                saved = true
                live.reload()
            }
        }
    }
    DisposableEffect(Unit) { onDispose { server.stop() } }
    LaunchedEffect(Unit) {
        val port = withContext(Dispatchers.IO) { server.start() }
        val ip = withContext(Dispatchers.IO) { SetupServer.localIp() }
        address = if (port > 0 && ip != null) "http://$ip:$port" else null
    }

    Row(
        Modifier.fillMaxSize().padding(start = 72.dp, top = 16.dp, end = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(32.dp),
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Settings", style = MaterialTheme.typography.headlineMedium)
            UrlField("Playlist URL (M3U)", playlist) { playlist = it; saved = false }
            UrlField("Guide URL (XMLTV, optional)", epg) { epg = it; saved = false }
            Button(onClick = {
                prefs.playlistUrl = playlist.trim()
                prefs.epgUrl = epg.trim()
                live.reload()
                saved = true
            }) { Text(if (saved) "Saved" else "Save and reload") }
        }

        Column(Modifier.width(300.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Easier: set up from your phone", style = MaterialTheme.typography.titleMedium)
            val a = address
            if (a != null) {
                val qr = remember(a) { SetupServer.qr(a) }
                Image(qr, contentDescription = "QR code for $a", modifier = Modifier.size(220.dp))
                Text(a)
                Text("Code: ${server.code}", style = MaterialTheme.typography.titleLarge)
                Text("Scan the QR code, or open the address on any device on your Wi-Fi, then enter the code.")
            } else {
                Text("Starting phone setup…")
            }
        }
    }
}

@Composable
private fun UrlField(label: String, value: String, onChange: (String) -> Unit) {
    Column {
        Text(label)
        Spacer(Modifier.height(4.dp))
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier.fillMaxWidth().border(1.dp, Color.Gray).padding(12.dp),
        )
    }
}
