package com.example.tvhub

import android.app.Application
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class MusicPage { HOME, SEARCH, LIBRARY, NOW_PLAYING, APPS, COLLECTION }

/** Search, albums / playlists / artists and the page stack for the Music tab. */
class MusicViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = AppPrefs(app)
    var page by mutableStateOf(MusicPage.HOME)
    private val history = ArrayList<MusicPage>()
    var query by mutableStateOf("")
        private set
    var suggestions by mutableStateOf<List<String>>(emptyList())
        private set
    var results by mutableStateOf<Music.Results?>(null)
        private set
    var searching by mutableStateOf(false)
        private set
    var recents by mutableStateOf(prefs.recentSearches("music"))
        private set
    var collection by mutableStateOf<MusicCollection?>(null)
        private set
    var collectionSongs by mutableStateOf<List<Song>>(emptyList())
        private set
    /** Recommended for you: radios from the songs you played most recently. */
    var forYou by mutableStateOf<List<Song>>(emptyList())
        private set
    var notice by mutableStateOf<String?>(null)
    private var suggestJob: Job? = null

    fun go(p: MusicPage) { if (p != page) { history += page; page = p } }
    fun back(): Boolean {
        if (history.isEmpty()) return false
        page = history.removeAt(history.lastIndex)
        return true
    }

    fun type(q: String) {
        query = q
        suggestJob?.cancel()
        suggestJob = viewModelScope.launch {
            delay(250)
            suggestions = if (q.trim().length < 2) emptyList() else withContext(Dispatchers.IO) { runCatching { Music.suggestions(q) }.getOrDefault(emptyList()) }.take(8)
        }
    }

    fun search(q: String = query) {
        val t = q.trim()
        if (t.isEmpty()) return
        query = t
        suggestions = emptyList()
        prefs.addRecentSearch("music", t)
        recents = prefs.recentSearches("music")
        viewModelScope.launch {
            searching = true
            val r = withContext(Dispatchers.IO) { runCatching { Music.searchAll(t) } }
            results = r.getOrNull()
            if (r.isFailure) notice = "Search failed: ${r.exceptionOrNull()?.message}"
            searching = false
        }
    }

    fun clearRecents() { prefs.clearRecentSearches("music"); recents = emptyList() }

    fun open(c: MusicCollection) {
        collection = c
        collectionSongs = emptyList()
        go(MusicPage.COLLECTION)
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { Music.songsOf(c) } }
            collectionSongs = r.getOrDefault(emptyList())
            if (r.isFailure) notice = "Couldn't load ${c.title}: ${r.exceptionOrNull()?.message}"
        }
    }

    fun openArtist(s: Song) {
        val url = s.artistUrl ?: return
        open(MusicCollection(url, s.artist, "Artist", null, MusicCollection.Kind.ARTIST))
    }

    private var forYouLoaded = false

    fun loadForYou() {
        if (forYouLoaded) return
        val seeds = MusicPlayer.recent.take(3)
        if (seeds.isEmpty()) return
        forYouLoaded = true
        viewModelScope.launch {
            val mixes = withContext(Dispatchers.IO) { seeds.flatMap { runCatching { Music.radio(it).take(15) }.getOrDefault(emptyList()) } }
            val played = MusicPlayer.recent.take(30).map { it.url }.toSet()
            forYou = mixes.filter { it.url !in played }.distinctBy { it.url }.shuffled().take(40)
        }
    }
}

private val MShape = RoundedCornerShape(8.dp)

@Composable
private fun MChip(label: String, selected: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(label, style = MaterialTheme.typography.labelLarge, maxLines = 1,
        modifier = Modifier.focusRing(shape).clip(shape)
            .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp))
}

@Composable
fun MusicScreen(vm: MusicViewModel) {
    val ctx = LocalContext.current
    remember { MusicPlayer.init(ctx); true }
    BackHandler(enabled = vm.page != MusicPage.HOME) { if (!vm.back()) vm.page = MusicPage.HOME }
    Column(Modifier.fillMaxSize()) {
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            item { Text("Music", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(end = 8.dp)) }
            item { MChip("Home", vm.page == MusicPage.HOME) { vm.go(MusicPage.HOME) } }
            item { MChip("🔍 Search", vm.page == MusicPage.SEARCH) { vm.go(MusicPage.SEARCH) } }
            item { MChip("Library", vm.page == MusicPage.LIBRARY) { vm.go(MusicPage.LIBRARY) } }
            if (MusicPlayer.current != null) item { MChip("♪ Now playing", vm.page == MusicPage.NOW_PLAYING) { vm.go(MusicPage.NOW_PLAYING) } }
            item { MChip("Spotify · Apple · Amazon", vm.page == MusicPage.APPS) { vm.go(MusicPage.APPS) } }
        }
        (vm.notice ?: MusicPlayer.error)?.let {
            Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 20.dp))
        }
        when (vm.page) {
            MusicPage.HOME -> MusicHome(vm)
            MusicPage.SEARCH -> MusicSearch(vm)
            MusicPage.LIBRARY -> MusicLibrary(vm)
            MusicPage.NOW_PLAYING -> NowPlaying(vm)
            MusicPage.APPS -> MusicAppsPage()
            MusicPage.COLLECTION -> CollectionPage(vm)
        }
    }
}

// ---------------------------------------------------------------- Pieces

@Composable
private fun SongRow(s: Song, list: List<Song>, i: Int, vm: MusicViewModel, showArt: Boolean = true) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val active = MusicPlayer.current?.url == s.url
    Column {
        Row(Modifier.fillMaxWidth().focusRing(MShape).clip(MShape)
            .background(if (active) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
            .clickable { MusicPlayer.playAll(ctx, list, i) }.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (showArt) {
                Box(Modifier.size(48.dp).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                    s.art?.let { AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                }
            }
            Column(Modifier.weight(1f)) {
                Text((if (active) "♪ " else "") + s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(listOf(s.artist, YouTube.duration(s.durationSec)).filter { it.isNotEmpty() }.joinToString(" · "),
                    maxLines = 1, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            MChip(if (MusicPlayer.isLiked(s)) "♥" else "♡") { MusicPlayer.toggleLike(s) }
            MChip("⋯") { menu = !menu }
        }
        if (menu) {
            LazyRow(contentPadding = PaddingValues(start = 72.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { MChip("Start radio") { menu = false; MusicPlayer.startRadio(ctx, s) } }
                item { MChip("Play next") { menu = false; MusicPlayer.playNext(s); Toast.makeText(ctx, "Plays next", Toast.LENGTH_SHORT).show() } }
                item { MChip("Add to queue") { menu = false; MusicPlayer.addToQueue(s); Toast.makeText(ctx, "Added to queue", Toast.LENGTH_SHORT).show() } }
                if (s.artistUrl != null) item { MChip("Go to artist") { menu = false; vm.openArtist(s) } }
            }
        }
    }
}

@Composable
private fun CollectionTile(c: MusicCollection, onClick: () -> Unit) {
    val tv = rememberIsTv()
    val w = if (tv) 150.dp else 120.dp
    val shape = if (c.kind == MusicCollection.Kind.ARTIST) CircleShape else MShape
    Column(Modifier.width(w)) {
        Box(Modifier.size(w).focusRing(shape, 1.05f).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onClick)) {
            c.art?.let { AsyncImage(model = it, contentDescription = c.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
        }
        Text(c.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        Text(c.subtitle, maxLines = 1, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SongTiles(title: String, songs: List<Song>) {
    if (songs.isEmpty()) return
    val ctx = LocalContext.current
    val w = if (rememberIsTv()) 150.dp else 120.dp
    Column {
        Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(8.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(songs) { i, s ->
                Column(Modifier.width(w)) {
                    Box(Modifier.size(w).focusRing(MShape, 1.05f).clip(MShape).background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { MusicPlayer.playAll(ctx, songs, i) }) {
                        s.art?.let { AsyncImage(model = it, contentDescription = s.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                    }
                    Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                    Text(s.artist, maxLines = 1, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Pages

@Composable
private fun MusicHome(vm: MusicViewModel) {
    val ctx = LocalContext.current
    LaunchedEffect(MusicPlayer.recent.firstOrNull()?.url) { vm.loadForYou() }
    LaunchedEffect(Unit) { MusicApps.refresh(ctx) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item { OtherAppsPlaying() }
        item { SongTiles("Recommended for You", vm.forYou) }
        item { SongTiles("Recently Played", MusicPlayer.recent.take(30)) }
        item { SongTiles("Liked Songs", MusicPlayer.liked.take(30)) }
        if (MusicPlayer.recent.isEmpty()) item {
            Text("Search for a song, album or artist to start. Music keeps playing while you use other tabs, " +
                "games, or other apps. Your recommendations appear here once you've played a few songs.",
                modifier = Modifier.padding(20.dp))
        }
    }
}

@Composable
private fun MusicSearch(vm: MusicViewModel) {
    val focus = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Throwable) {} }
    val r = vm.results
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            OutlinedTextField(value = vm.query, onValueChange = { vm.type(it) }, singleLine = true,
                placeholder = { Text("Songs, albums, artists, playlists") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { vm.search() }),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).focusRequester(focus))
        }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { MChip("Search") { vm.search() } }
                if (vm.suggestions.isNotEmpty()) items(vm.suggestions) { s -> MChip(s) { vm.search(s) } }
                else {
                    items(vm.recents) { s -> MChip("🕘 $s") { vm.search(s) } }
                    if (vm.recents.isNotEmpty()) item { MChip("Clear") { vm.clearRecents() } }
                }
            }
        }
        if (vm.searching) item { Text("Searching…", modifier = Modifier.padding(horizontal = 20.dp)) }
        if (r != null) {
            listOf("Artists" to r.artists, "Albums" to r.albums, "Playlists" to r.playlists).forEach { (title, list) ->
                if (list.isNotEmpty()) item {
                    Column {
                        Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 20.dp))
                        Spacer(Modifier.height(8.dp))
                        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(list) { c -> CollectionTile(c) { vm.open(c) } }
                        }
                    }
                }
            }
            if (r.songs.isNotEmpty()) item { Text("Songs", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 20.dp)) }
            itemsIndexed(r.songs) { i, s -> Box(Modifier.padding(horizontal = 8.dp)) { SongRow(s, r.songs, i, vm) } }
        }
    }
}

@Composable
private fun CollectionPage(vm: MusicViewModel) {
    val ctx = LocalContext.current
    val c = vm.collection ?: return
    val songs = vm.collectionSongs
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.padding(20.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                val shape = if (c.kind == MusicCollection.Kind.ARTIST) CircleShape else MShape
                Box(Modifier.size(120.dp).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant)) {
                    (c.art ?: songs.firstOrNull()?.art)?.let { AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(c.title, style = MaterialTheme.typography.titleLarge)
                    Text(c.subtitle + if (songs.isNotEmpty()) " · ${songs.size} songs" else "", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MChip("▶ Play", true) { MusicPlayer.playAll(ctx, songs) }
                        MChip("⤮ Shuffle") { if (songs.isNotEmpty()) MusicPlayer.playAll(ctx, songs, songs.indices.random(), shuffled = true) }
                    }
                }
            }
            if (songs.isEmpty()) Text("Loading…", modifier = Modifier.padding(horizontal = 20.dp))
        }
        itemsIndexed(songs) { i, s -> Box(Modifier.padding(horizontal = 8.dp)) { SongRow(s, songs, i, vm, showArt = c.kind != MusicCollection.Kind.ALBUM) } }
    }
}

@Composable
private fun MusicLibrary(vm: MusicViewModel) {
    val liked = MusicPlayer.liked
    val recent = MusicPlayer.recent
    var tab by remember { mutableStateOf(0) }
    val list = if (tab == 0) liked else recent
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MChip("♥ Liked songs (${liked.size})", tab == 0) { tab = 0 }
                MChip("Recently played", tab == 1) { tab = 1 }
                if (list.isNotEmpty()) {
                    val ctx = LocalContext.current
                    MChip("⤮ Shuffle all") { MusicPlayer.playAll(ctx, list, list.indices.random(), shuffled = true) }
                }
            }
            if (list.isEmpty()) Text(if (tab == 0) "Press ♡ on a song to like it." else "Nothing played yet.", modifier = Modifier.padding(20.dp))
        }
        itemsIndexed(list) { i, s -> Box(Modifier.padding(horizontal = 8.dp)) { SongRow(s, list, i, vm) } }
    }
}

@Composable
private fun NowPlaying(vm: MusicViewModel) {
    val ctx = LocalContext.current
    val s = MusicPlayer.current ?: run { Text("Nothing playing.", modifier = Modifier.padding(20.dp)); return }
    var pos by remember { mutableStateOf(0L) }
    var len by remember { mutableStateOf(0L) }
    LaunchedEffect(s.url) {
        while (true) {
            pos = MusicPlayer.player.currentPosition
            len = MusicPlayer.player.duration.coerceAtLeast(0)
            delay(500)
        }
    }
    val wide = rememberIsWide()
    val controls: @Composable () -> Unit = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(s.title, style = MaterialTheme.typography.headlineSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(s.artist, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.clickable { vm.openArtist(s) })
            if (len > 0) {
                Slider(value = pos.toFloat(), onValueChange = { MusicPlayer.player.seekTo(it.toLong()) }, valueRange = 0f..len.toFloat())
                Text("${YouTube.duration(pos / 1000)} / ${YouTube.duration(len / 1000)}", style = MaterialTheme.typography.labelSmall)
            } else if (MusicPlayer.loading) Text("Loading…")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { MChip(if (MusicPlayer.shuffle) "⤮ Shuffle: on" else "⤮ Shuffle: off", MusicPlayer.shuffle) { MusicPlayer.toggleShuffle() } }
                item { MChip("⏮") { MusicPlayer.previous() } }
                item { MChip(if (MusicPlayer.playing) "⏸ Pause" else "▶ Play", true) { MusicPlayer.toggle() } }
                item { MChip("⏭") { MusicPlayer.next() } }
                item {
                    MChip("🔁 " + when (MusicPlayer.repeat) { MusicPlayer.Repeat.OFF -> "Repeat: off"; MusicPlayer.Repeat.ALL -> "Repeat: all"; else -> "Repeat: one" },
                        MusicPlayer.repeat != MusicPlayer.Repeat.OFF) { MusicPlayer.cycleRepeat() }
                }
                item { MChip(if (MusicPlayer.isLiked(s)) "♥ Liked" else "♡ Like") { MusicPlayer.toggleLike(s) } }
                item { MChip("📻 Radio") { MusicPlayer.startRadio(ctx, s) } }
                item { MChip("■ Stop") { MusicPlayer.stop() } }
                item { CastButton({ CastRequest("song", url = s.url, title = s.title, artist = s.artist, art = s.art.orEmpty()) }) }
            }
        }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp)) {
        item {
            if (wide) {
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Box(Modifier.size(260.dp).clip(MShape).background(MaterialTheme.colorScheme.surfaceVariant)) {
                        s.art?.let { AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                    }
                    Box(Modifier.weight(1f)) { controls() }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(MShape).background(MaterialTheme.colorScheme.surfaceVariant)) {
                        s.art?.let { AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                    }
                    controls()
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Up next", style = MaterialTheme.typography.titleMedium)
        }
        itemsIndexed(MusicPlayer.queue) { i, q ->
            if (i <= MusicPlayer.index) return@itemsIndexed
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    ListRow(title = q.title, subtitle = q.artist, onClick = { MusicPlayer.playIndex(ctx, i) })
                }
                MChip("✕") { MusicPlayer.removeFromQueue(i) }
            }
        }
    }
}

/** What Spotify, Apple Music, Amazon Music (or any music app) is playing, with controls. */
@Composable
private fun OtherAppsPlaying() {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) {
        while (true) { MusicApps.refresh(ctx); delay(3_000) }
    }
    val list = MusicApps.nowPlaying
    if (list.isEmpty()) return
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEach { np ->
            Row(Modifier.fillMaxWidth().clip(MShape).background(MaterialTheme.colorScheme.surfaceVariant).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                np.art?.let { Image(it.asImageBitmap(), contentDescription = null, modifier = Modifier.size(56.dp).clip(RoundedCornerShape(4.dp))) }
                Column(Modifier.weight(1f)) {
                    Text("Playing in ${np.app}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(np.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(np.artist, maxLines = 1, style = MaterialTheme.typography.bodySmall)
                }
                MChip("⏮") { np.controller.transportControls.skipToPrevious() }
                MChip(if (np.playing) "⏸" else "▶") {
                    if (np.playing) np.controller.transportControls.pause() else np.controller.transportControls.play()
                    MusicApps.refresh(ctx)
                }
                MChip("⏭") { np.controller.transportControls.skipToNext() }
            }
        }
    }
}

@Composable
private fun MusicAppsPage() {
    val ctx = LocalContext.current
    var access by remember { mutableStateOf(MusicApps.hasAccess(ctx)) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("Spotify, Apple Music and Amazon Music only play in their own apps. Open one here: it keeps playing in the " +
                "background, and TV Hub shows what's playing with play, pause and skip.", style = MaterialTheme.typography.bodyMedium)
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(MusicApps.apps) { a ->
                    val installed = remember(a.name) { MusicApps.installed(ctx, a) != null }
                    Column(Modifier.width(170.dp)) {
                        Box(Modifier.width(170.dp).height(96.dp).focusRing(MShape, 1.05f).clip(MShape).background(Color(a.color))
                            .clickable { MusicApps.open(ctx, a)?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() } }.padding(12.dp),
                            contentAlignment = Alignment.BottomStart) {
                            Text(a.name, style = MaterialTheme.typography.titleMedium, color = Color.White)
                        }
                        Text(if (installed) "Installed" else "Not installed", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        item { OtherAppsPlaying() }
        if (!access) item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("To show and control what those apps are playing, allow TV Hub notification access.", style = MaterialTheme.typography.bodySmall)
                MChip("Allow notification access") {
                    if (!MusicApps.openAccessSettings(ctx)) {
                        Toast.makeText(ctx, "This device hides that setting. On a Shield: adb shell cmd notification allow_listener " +
                            "${ctx.packageName}/${MediaListener::class.java.name}", Toast.LENGTH_LONG).show()
                    }
                }
                MChip("I've allowed it") { access = MusicApps.hasAccess(ctx); MusicApps.refresh(ctx) }
            }
        }
    }
}

// ---------------------------------------------------------------- Mini player (on every tab)

/** The bar shown on every tab while music plays: song, play / pause, next. Select it to open Now Playing. */
@Composable
fun MiniMusicBar(modifier: Modifier, onOpen: () -> Unit) {
    val s = MusicPlayer.current ?: return
    Row(modifier.clip(MShape).background(MaterialTheme.colorScheme.surfaceVariant).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.weight(1f).focusRing(MShape).clip(MShape).clickable(onClick = onOpen).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(4.dp)).background(Color.DarkGray)) {
                s.art?.let { AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
            }
            Column(Modifier.weight(1f)) {
                Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                Text(if (MusicPlayer.loading) "Loading…" else s.artist, maxLines = 1, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        MChip(if (MusicPlayer.playing) "⏸" else "▶") { MusicPlayer.toggle() }
        MChip("⏭") { MusicPlayer.next() }
    }
}
