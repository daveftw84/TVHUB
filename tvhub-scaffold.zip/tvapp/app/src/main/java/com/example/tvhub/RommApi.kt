package com.example.tvhub

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** A console as RomM sees it (one folder of your library on the server). */
data class RommPlatform(
    val id: Int,
    val slug: String,
    val fsSlug: String,
    val name: String,
    val romCount: Int,
    val logo: String?,
)

data class RommCollection(
    val id: Int,
    val name: String,
    val count: Int,
    val cover: String?,
    val smart: Boolean,
    val favorite: Boolean,
    val romIds: Set<Int>,
)

/** What to list. Filters use RomM's names: genres, player_counts, regions, languages, ... */
data class RommQuery(
    val platformIds: List<Int> = emptyList(),
    val search: String = "",
    val collectionId: Int? = null,
    val smartCollectionId: Int? = null,
    val favorite: Boolean = false,
    val lastPlayed: Boolean = false,
    val unplayed: Boolean = false,
    val orderBy: String = "name",
    val orderDir: String = "asc",
    val filters: Map<String, String> = emptyMap(),
)

data class RommPage(val games: List<Game>, val total: Int, val filterValues: Map<String, List<String>>)

/**
 * Client for a RomM server (github.com/rommapp/romm): your game library on your own server,
 * scanned and filled with covers and game info by RomM, the way Plex does for films.
 */
object RommApi {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun request(
        base: String, token: String?, path: String, method: String = "GET",
        body: String? = null, contentType: String = "application/json",
    ): String {
        val c = URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15_000
        c.readTimeout = 40_000
        c.setRequestProperty("Accept", "application/json")
        c.setRequestProperty("User-Agent", "TVHub/1.7")
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", contentType)
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        when (c.responseCode) {
            in 200..299 -> return c.inputStream.bufferedReader().use { it.readText() }
            401 -> throw IOException("RomM rejected the sign-in. Pair this device again.")
            403 -> throw IOException("This RomM token isn't allowed to do that. Give it more permissions in RomM.")
            404 -> throw IOException("Not found on the RomM server (HTTP 404).")
            else -> throw IOException("RomM returned HTTP ${c.responseCode}")
        }
    }

    fun absolute(base: String, path: String): String =
        if (path.startsWith("http://") || path.startsWith("https://")) path else base.trimEnd('/') + "/" + path.trimStart('/')

    /** Swaps the pairing code shown in RomM (Client API Tokens → Pair) for a token. */
    fun exchange(base: String, code: String): String {
        val body = JSONObject().put("code", code.trim()).toString()
        return JSONObject(request(base, null, "/api/client-tokens/exchange", "POST", body)).getString("raw_token")
    }

    fun platforms(base: String, token: String): List<RommPlatform> {
        val a = JSONArray(request(base, token, "/api/platforms"))
        return (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
            RommPlatform(
                id = o.getInt("id"),
                slug = o.optString("slug"),
                fsSlug = o.optString("fs_slug"),
                name = o.optString("display_name").ifEmpty { o.optString("custom_name").ifEmpty { o.optString("name") } },
                romCount = o.optInt("rom_count"),
                logo = o.optString("url_logo").ifEmpty { null }?.let { absolute(base, it) },
            )
        }.filter { it.romCount > 0 }
    }

    fun roms(base: String, token: String, q: RommQuery, offset: Int, limit: Int = 60, withFilterValues: Boolean = false): RommPage {
        val sb = StringBuilder("/api/roms?limit=$limit&offset=$offset")
        q.platformIds.forEach { sb.append("&platform_ids=").append(it) }
        if (q.search.isNotBlank()) sb.append("&search_term=").append(enc(q.search.trim()))
        else sb.append("&order_by=").append(q.orderBy).append("&order_dir=").append(q.orderDir)
        q.collectionId?.let { sb.append("&collection_id=").append(it) }
        q.smartCollectionId?.let { sb.append("&smart_collection_id=").append(it) }
        if (q.favorite) sb.append("&favorite=true")
        if (q.lastPlayed) sb.append("&last_played=true")
        if (q.unplayed) sb.append("&last_played=false")
        q.filters.forEach { (k, v) -> sb.append("&").append(k).append("=").append(enc(v)) }
        sb.append("&with_char_index=false&with_rom_id_index=false&with_provider_metadata=false")
        sb.append("&with_filter_values=").append(withFilterValues)
        val page = JSONObject(request(base, token, sb.toString()))
        val items = page.optJSONArray("items") ?: JSONArray()
        val games = (0 until items.length()).map { toGame(base, items.getJSONObject(it)) }
        val fv = HashMap<String, List<String>>()
        page.optJSONObject("filter_values")?.let { o ->
            for (k in listOf("genres", "player_counts", "regions", "languages", "franchises", "companies", "age_ratings", "tags")) {
                val a = o.optJSONArray(k) ?: continue
                val values = (0 until a.length()).map { a.optString(it) }.filter { it.isNotEmpty() }
                if (values.isNotEmpty()) fv[k] = values
            }
        }
        return RommPage(games, if (page.isNull("total")) offset + games.size else page.optInt("total"), fv)
    }

    private fun toGame(base: String, o: JSONObject): Game {
        val id = o.getInt("id")
        val fsName = o.optString("fs_name")
        val single = o.optBoolean("has_simple_single_file", true)
        // Several files (multi-disc, folders) come down as one zip that includes an .m3u playlist.
        val outName = if (single) fsName else "${o.optString("fs_name_no_ext").ifEmpty { fsName }}.zip"
        val meta = o.optJSONObject("metadatum")
        val genres = meta?.optJSONArray("genres")
        val released = meta?.optLong("first_release_date", 0L) ?: 0L
        val year = if (released <= 0) null else {
            val seconds = if (released > 100_000_000_000L) released / 1000 else released
            java.util.Calendar.getInstance().apply { timeInMillis = seconds * 1000 }.get(java.util.Calendar.YEAR).toString()
        }
        val cover = o.optString("path_cover_large").ifEmpty { o.optString("path_cover_small") }.ifEmpty { o.optString("url_cover") }
        val shots = o.optJSONArray("merged_screenshots")
        val manual = o.optString("path_manual").ifEmpty { o.optString("url_manual") }
        return Game(
            title = o.optString("name").ifEmpty { o.optString("fs_name_no_ext").ifEmpty { fsName } },
            console = "romm:${o.optInt("platform_id")}",
            key = "romm:$id",
            file = outName,
            size = o.optLong("fs_size_bytes"),
            url = base.trimEnd('/') + "/api/roms/$id/content/" + enc(outName).replace("+", "%20"),
            art = cover.ifEmpty { null }?.let { absolute(base, it) },
            year = year,
            genre = genres?.let { g -> (0 until g.length()).map { g.optString(it) }.filter { it.isNotEmpty() }.take(3).joinToString(", ") }
                ?.ifEmpty { null },
            players = meta?.optString("player_count")?.ifEmpty { null },
            summary = o.optString("summary").ifEmpty { null },
            bundle = !single,
            rommId = id,
            manual = manual.ifEmpty { null }?.let { absolute(base, it) },
            screenshots = if (shots == null) emptyList() else
                (0 until shots.length()).map { shots.optString(it) }.filter { it.isNotEmpty() }.map { absolute(base, it) },
            playInBrowser = base.trimEnd('/') + "/rom/$id/ejs",
            myRating = o.optJSONObject("rom_user")?.optInt("rating") ?: 0,
            raId = o.optInt("ra_id"),
            achievements = parseAchievements(base, o.optJSONObject("merged_ra_metadata")),
            titleId = o.optString("title_id").ifEmpty { null }?.takeIf { it != "null" },
            trailer = o.optString("youtube_video_id").ifEmpty { null }?.takeIf { it != "null" },
            status = o.optJSONObject("rom_user")?.let { u -> if (u.isNull("status")) null else u.optString("status").ifEmpty { null } },
        )
    }

    private fun parseAchievements(base: String, ra: JSONObject?): List<Achievement> {
        val a = ra?.optJSONArray("achievements") ?: return emptyList()
        return (0 until a.length()).map { a.getJSONObject(it) }.map { x ->
            val badge = x.optString("badge_path").ifEmpty { x.optString("badge_url") }.ifEmpty { null }
            Achievement(
                raId = x.optInt("ra_id"),
                title = x.optString("title"),
                description = x.optString("description"),
                points = x.optInt("points"),
                badge = badge?.takeIf { it != "null" }?.let { absolute(base, it) },
            )
        }.sortedBy { it.title }
    }

    /** Your RetroAchievements progress (from RomM): achievement ids you've earned, by RetroAchievements game id. */
    fun raEarned(base: String, token: String): Map<Int, Set<Int>> {
        val me = JSONObject(request(base, token, "/api/users/me"))
        val results = me.optJSONObject("ra_progression")?.optJSONArray("results") ?: return emptyMap()
        val out = HashMap<Int, Set<Int>>()
        for (i in 0 until results.length()) {
            val r = results.getJSONObject(i)
            val earned = r.optJSONArray("earned_achievements") ?: JSONArray()
            out[r.optInt("rom_ra_id")] = (0 until earned.length()).map { earned.getJSONObject(it).optInt("ra_id") }.toSet()
        }
        return out
    }

    // --- your own data on a game (rating, status, hidden) ---

    /** Updates your rating / status / hidden flag for a game, e.g. {"rating": 8} or {"hidden": true}. */
    fun updateProps(base: String, token: String, romId: Int, data: JSONObject) {
        request(base, token, "/api/roms/$romId/props", "PUT", data.toString())
    }

    /** One game with all its details (achievements, screenshots, ...). */
    fun romDetails(base: String, token: String, romId: Int): Game = toGame(base, JSONObject(request(base, token, "/api/roms/$romId")))

    /** A random game, optionally from some consoles only. */
    fun random(base: String, token: String, platformIds: List<Int>): Game? {
        val q = platformIds.joinToString("&") { "platform_ids=$it" }
        val text = request(base, token, "/api/roms/random" + if (q.isEmpty()) "" else "?$q")
        val o = JSONObject(text)
        return if (o.has("id")) toGame(base, o) else null
    }

    // --- offline copy of the console list, so downloaded games still launch without the server ---

    fun platformsToJson(list: List<RommPlatform>): String {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("slug", it.slug).put("fs_slug", it.fsSlug)
                .put("display_name", it.name).put("rom_count", it.romCount).put("url_logo", it.logo.orEmpty()))
        }
        return a.toString()
    }

    fun platformsFromJson(text: String): List<RommPlatform> {
        val a = JSONArray(text)
        return (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
            RommPlatform(o.getInt("id"), o.optString("slug"), o.optString("fs_slug"), o.optString("display_name"),
                o.optInt("rom_count"), o.optString("url_logo").ifEmpty { null })
        }
    }

    // --- collections and favorites ---

    private fun parseCollections(base: String, text: String, smart: Boolean): List<RommCollection> {
        val a = JSONArray(text)
        return (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
            val ids = o.optJSONArray("rom_ids") ?: JSONArray()
            val romIds = (0 until ids.length()).map { ids.optInt(it) }.toSet()
            RommCollection(
                id = o.getInt("id"),
                name = o.optString("name"),
                count = o.optInt("rom_count", romIds.size),
                cover = o.optString("path_cover_large").ifEmpty { o.optString("url_cover") }.ifEmpty { null }?.let { absolute(base, it) },
                smart = smart,
                favorite = o.optBoolean("is_favorite"),
                romIds = romIds,
            )
        }
    }

    fun collections(base: String, token: String): List<RommCollection> {
        val normal = parseCollections(base, request(base, token, "/api/collections"), smart = false)
        val smart = try {
            parseCollections(base, request(base, token, "/api/collections/smart"), smart = true)
        } catch (_: Exception) {
            emptyList()
        }
        return normal + smart
    }

    /** Creates the user's favourites collection (RomM keeps favourites as a collection marked as such). */
    fun createFavorites(base: String, token: String): Int {
        val o = JSONObject(
            request(base, token, "/api/collections?is_favorite=true", "POST", "name=Favourites&description=",
                "application/x-www-form-urlencoded")
        )
        return o.getInt("id")
    }

    fun setInCollection(base: String, token: String, collectionId: Int, romId: Int, add: Boolean) {
        val body = JSONObject().put("rom_ids", JSONArray().put(romId)).toString()
        request(base, token, "/api/collections/$collectionId/roms", if (add) "POST" else "DELETE", body)
    }

    // --- play time ---

    /** Tells RomM a game was played, so it shows under Recently played with its play time. */
    fun reportPlay(base: String, token: String, romId: Int, startMs: Long, endMs: Long) {
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val session = JSONObject()
            .put("rom_id", romId)
            .put("start_time", iso.format(Date(startMs)))
            .put("end_time", iso.format(Date(endMs)))
            .put("duration_ms", (endMs - startMs).coerceAtLeast(0))
        val body = JSONObject().put("sessions", JSONArray().put(session)).toString()
        request(base, token, "/api/play-sessions", "POST", body)
    }
}
