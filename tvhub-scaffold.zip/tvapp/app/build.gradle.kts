plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.tvhub"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.tvhub"
        minSdk = 23
        targetSdk = 34
        versionCode = 45
        versionName = "3.8"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true   // NewPipe Extractor uses newer Java APIs
    }
    packaging {
        resources {
            // duplicate files from the extractor's libraries (as in NewPipe)
            excludes += setOf("META-INF/README.md", "META-INF/CHANGES", "META-INF/COPYRIGHT", "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*", "META-INF/NOTICE*")
        }
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
        )
    }
    buildFeatures { compose = true }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.google.zxing:core:3.5.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.work:work-runtime-ktx:2.9.1")   // background save sync

    // Built-in game player: runs libretro cores (the same emulators RetroArch uses) inside the app.
    // GPL-3.0: https://github.com/Swordfish90/LibretroDroid
    implementation("com.github.Swordfish90:LibretroDroid:0.14.0")

    // YouTube: NewPipe Extractor (GPL-3.0), the library NewPipe and PipePipe are built on.
    // https://github.com/TeamNewPipe/NewPipeExtractor
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.27.1")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.1.5")

    val media3 = "1.4.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-session:$media3")   // music in the background (media notification)

    // Built-in VPN: WireGuard's official Android library (Apache-2.0)
    implementation("com.wireguard.android:tunnel:1.0.20230706")
    implementation("androidx.media3:media3-ui:$media3")
}
