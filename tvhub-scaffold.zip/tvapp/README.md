# TV Hub

Android TV app: IPTV live TV with a program guide (TiviMate-style) plus a Plex library browser.

## Run it
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on an Android TV emulator or a real Android TV / Fire TV device.
3. Go to **Settings** and enter your M3U playlist URL (and an optional XMLTV guide URL),
   or scan the QR code with your phone and fill the form there.
4. Go to **Library** and sign in to Plex with the code shown (plex.tv/link).

## Remote controls
- Live TV: OK plays a channel, hold OK adds or removes a favorite, the top row cycles groups.
- Channel Up/Down and Last Channel keys work if your remote has them.
- Recordings: OK plays, hold OK deletes. Files are saved to the app's own storage folder.

## Known limits
- Recording copies the raw stream, so it works for plain TS URLs, not HLS (.m3u8).
- Plex uses direct play only (no transcoding) and the first reachable server on your account.
