# TV Hub

One app for Android TV / Fire TV and phones: IPTV live TV with a program guide (TiviMate-style)
plus a Plex library browser.

- **TV:** side menu, driven by the remote's arrow keys and OK. A white outline shows the focused item.
- **Phone / tablet:** tab bar along the bottom, everything works by touch.

## Run it
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync, or build it with the
   GitHub workflow in `.github/workflows/build.yml`.
2. Go to **Settings** and enter your M3U playlist URL (and an optional XMLTV guide URL).
   On a TV you can scan the QR code with your phone and fill in the form there instead.
3. Go to **Library** and sign in to Plex with the code shown (plex.tv/link).

## Controls
- Live TV: select a channel to play it. Long-press (or hold OK) a channel to favorite it, or use the
  Favorite button under the video. The top row switches group.
- Channel Up/Down and Last Channel keys work if your remote has them.
- Recordings: select to play, Delete button removes (tap twice to confirm).
  Files are saved to the app's own storage folder.

## Known limits
- Recording copies the raw stream, so it works for plain TS URLs, not HLS (.m3u8).
- Plex uses direct play only (no transcoding) and the first reachable server on your account.
